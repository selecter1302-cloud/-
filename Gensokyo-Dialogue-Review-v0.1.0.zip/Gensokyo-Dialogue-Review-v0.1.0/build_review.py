"""Expand every authored review combination; never modify the APK or game data."""
import collections
import html
import json
from pathlib import Path

from body_variants import BEATS, THOUGHTS, boundary_beat

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "review"
CHARS = {"reimu": "레이무", "marisa": "마리사", "sakuya": "사쿠야", "sanae": "사나에"}
RELATIONS = {
    "hate": "싫어함", "friend": "친구", "secret": "연인(비밀)",
    "stranger": "타인", "crush": "짝사랑", "submit": "굴복", "coerced": "협박",
}
BODIES = {"pc": "주인공쪽", "unset": "미정"}
SCENES = {
    "after": ("직후", "관계 직후", "해당 없음"),
    "next_talk": ("다음 만남", "대화하기", "해당 없음"),
    "next_touch_allow": ("다음 만남", "스킨십", "허용 판정"),
    "next_touch_refuse": ("다음 만남", "스킨십", "거절 판정"),
    "next_kiss_allow": ("다음 만남", "키스", "허용 판정"),
    "next_kiss_refuse": ("다음 만남", "키스", "거절 판정"),
    "late_talk": ("시간이 지난 뒤", "대화하기", "해당 없음"),
    "late_touch_allow": ("시간이 지난 뒤", "스킨십", "허용 판정"),
    "late_touch_refuse": ("시간이 지난 뒤", "스킨십", "거절 판정"),
    "late_kiss_allow": ("시간이 지난 뒤", "키스", "허용 판정"),
    "late_kiss_refuse": ("시간이 지난 뒤", "키스", "거절 판정"),
}


def build():
    OUT.mkdir(parents=True, exist_ok=True)
    entries = []
    core = []
    for char, name in CHARS.items():
        raw = (ROOT / "drafts" / f"{char}.txt").read_text(encoding="utf-8").splitlines()
        rows = {}
        for n, line in enumerate(raw, 1):
            if not line.strip():
                continue
            parts = line.split("|")
            assert len(parts) == 4, (char, n, "expected four columns")
            relation, scene, *variants = parts
            assert relation in RELATIONS and scene in SCENES, (char, n)
            assert (relation, scene) not in rows, (char, n, "duplicate condition")
            assert all(v.strip() and len(v) >= 10 for v in variants), (char, n)
            rows[relation, scene] = variants
            core.extend(variants)
        assert set(rows) == {(r, s) for r in RELATIONS for s in SCENES}, char
        for relation, label in RELATIONS.items():
            for bi, (body, body_label) in enumerate(BODIES.items()):
                for scene, (time, action, result) in SCENES.items():
                    for vi, speech in enumerate(rows[relation, scene]):
                        special = relation in {"submit", "coerced"}
                        narration = boundary_beat(char, body, scene) if special else BEATS[char][scene][bi]
                        thought = THOUGHTS[char][relation][bi][vi]
                        ident = f"{char.upper()}-{relation.upper()}-{body.upper()}-{scene.upper()}-{'AB'[vi]}"
                        gate = result
                        if special and scene.endswith("allow"):
                            gate = "허용 판정 후 의사 확인·중단 요청"
                        entries.append({
                            "id": ident, "character": name, "character_key": char,
                            "relation": label, "relation_key": relation,
                            "body_state": body_label, "body_key": body,
                            "time": time, "action": action, "gate": gate,
                            "scene_key": scene, "variant": "AB"[vi],
                            "event_mode": "경계·피해 반응 전용" if special else "자발적 사건 이후",
                            "narration": narration, "speech": speech, "inner_thought": thought,
                            "review_status": "미승인·미적용",
                        })

    assert len(core) == 616
    assert len(entries) == 1232
    assert len({e["id"] for e in entries}) == len(entries)
    assert len({(e["narration"], e["speech"], e["inner_thought"]) for e in entries}) == len(entries)
    assert all(n == 308 for n in collections.Counter(e["character"] for e in entries).values())
    assert all(n == 44 for n in collections.Counter((e["character_key"], e["relation_key"]) for e in entries).values())
    assert all(n == 22 for n in collections.Counter((e["character_key"], e["relation_key"], e["body_key"]) for e in entries).values())
    for e in entries:
        text = " ".join(e[k] for k in ("narration", "speech", "inner_thought"))
        assert not any(x in text for x in ("어제", "방금", "{name}", "TODO", "TBD")), e["id"]
        if e["scene_key"].endswith("refuse"):
            assert not any(x in e["narration"] for x in ("손을 잡은", "입을 맞", "입맞춤을 나", "입술을 포")), e["id"]
        if e["relation_key"] in {"submit", "coerced"}:
            assert not any(x in e["narration"] for x in ("스스로 손을 내", "손을 잡은", "키스했다", "기뻐")), e["id"]

    doc = {
        "purpose": "사용자 검토용 창작 초안. 실행 가능한 게임 패치가 아니다.",
        "source_apk_sha256": "13c4c3c52e930278e0853771508308ff7d720efd21dc4a0ef766012a3e35d333",
        "counts": {"core_speech_candidates": len(core), "unique_core_speech_strings": len(set(core)),
                   "fully_expanded_review_entries": len(entries), "entries_per_character": 308},
        "requirements": "조건·시점·동의·중복 방지 계약은 ../README.md 참조. 몸 상태와 발화의 일부를 공유하는 변형임을 유의.",
        "entries": entries,
    }
    (OUT / "all_dialogue.json").write_text(json.dumps(doc, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    for char, name in CHARS.items():
        lines = [f"# {name} — 사건 이후 대사 전체 검토본", "",
                 "**미승인·미적용. 154개 기본 발화 후보 × 몸 상태 2종 = 308개 완성 항목.**", "",
                 "각 항목은 행동지문 → 실제 발화 → 속마음 순서다. 속마음은 별도 표시 후보이며, 발화처럼 소리 내어 읽히는 문장이 아니다.", "",
                 "몸 상태별로 기본 발화를 공유하되 지문과 속마음을 다르게 쓴다. 분기·시간·강요 관련 주의점은 [검토 안내](../README.md)를 먼저 읽어야 한다.", ""]
        for relation, label in RELATIONS.items():
            lines += [f"## 주인공과의 관계: {label}", ""]
            if relation in {"submit", "coerced"}:
                lines += ["> ‘허용’은 내부 판정 표기다. 이 분기는 자유로운 동의로 간주하지 않으며, 접촉 성공 연출을 쓰지 않고 경계·의사 확인·중단 요청을 쓴다.", ""]
            for body, body_label in BODIES.items():
                lines += [f"### 몸: {body_label}", ""]
                for scene, (time, action, gate) in SCENES.items():
                    subset = [e for e in entries if (e["character_key"], e["relation_key"], e["body_key"], e["scene_key"]) == (char, relation, body, scene)]
                    lines += [f"#### {time} · {action} · {subset[0]['gate']}", ""]
                    for e in subset:
                        lines += [f"**{e['id']}**", "", e["narration"], "", f"{name} 「{e['speech']}」", "", f"*속마음: {e['inner_thought']}*", ""]
        (OUT / f"{char}.md").write_text("\n".join(lines), encoding="utf-8")

    count_lines = ["# 전체 대사 검토 목록", "", "APK에는 아직 적용하지 않았다. 네 인물의 모든 조건별 완성 문장을 아래에 공개한다.", "",
                   "- 기본 발화 후보: 616개 (각 캐릭터 154개)",
                   f"- 서로 완전히 동일하지 않은 기본 발화 문자열: {len(set(core))}개",
                   "- 몸 상태별 속마음: 112개", "- 일반 상황 몸 상태별 행동지문: 88개 + 굴복·협박 전용 지문 조합",
                   "- 최종 검토 항목: 1,232개 (각 캐릭터 308개)", "",
                   "1,232개가 전부 독립된 기본 발화라는 뜻은 아니다. 616개 기본 발화에 두 몸 상태의 행동·속마음을 붙여 만든 완성본이다.", "",
                   "| 캐릭터 | 전체 완성 항목 | 검토 문서 |", "|---|---:|---|"]
    for char, name in CHARS.items():
        count_lines.append(f"| {name} | 308 | [{name} 전체 대사]({char}.md) |")
    count_lines += ["", "[필터 가능한 전체 검토 화면](index.html) · [모든 항목 JSON](all_dialogue.json) · [분기·시점·적용 주의점](../README.md)", "",
                    "## 검토 표시 방법", "", "문장 ID와 함께 ‘유지 / 수정 / 제외’를 지정하면 된다. ‘레이무·친구·몸 미정 전체’처럼 조건 단위로도 지정할 수 있다.", "",
                    "각 항목의 지문·발화·속마음은 한 묶음이다. 실제 게임에서 속마음을 표시할지, 지문에만 녹일지는 별도 적용 결정이며 아직 바꾸지 않았다.", "",
                    "## 확인한 것과 남은 것", "", "구조 검수: 네 캐릭터 × 일곱 관계 × 두 몸 상태 × 열한 장면·판정 칸 × 두 후보의 1,232개 ID가 모두 존재한다.",
                    "고정 날짜 표현·미완성 표식·ID 중복이 없음을 검사했다. 거절 지문 및 굴복·협박 지문에 접촉 성공 지문이 섞이지 않았는지도 검사했다.",
                    "문체·감정·반복감은 사용자 검토 대상이다. 게임 내 실제 분기 연결, 표시, 저장 호환, Android 실행은 아직 구현·검증하지 않았다.", ""]
    (OUT / "전체목록.md").write_text("\n".join(count_lines), encoding="utf-8")

    page = '''<!doctype html>
<html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>사건 이후 대사 전체 검토</title>
<style>
:root{color-scheme:dark}*{box-sizing:border-box}body{margin:0;background:#12151b;color:#e8eaf0;font:16px/1.7 system-ui,sans-serif}main{max-width:1060px;margin:auto;padding:28px 20px 70px}h1{font-size:1.65rem;line-height:1.4}a{color:#9ecbff}small,.muted{color:#b1bac8}.notice{padding:16px 20px;background:#202734;border-left:4px solid #b9b3ff;border-radius:4px}#filters{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px;margin:24px 0}label{font-size:.85rem}select,input,button{font:inherit;background:#212936;color:inherit;border:1px solid #536173;border-radius:7px;padding:9px;width:100%}button{width:auto;cursor:pointer}.search{grid-column:1/-1}.tools{display:flex;flex-wrap:wrap;align-items:center;gap:12px;margin:18px 0}.card{border:1px solid #394353;background:#191f29;border-radius:10px;padding:18px 22px;margin:16px 0;overflow-wrap:anywhere}.card h2{font-size:1rem;color:#a7bddd;font-weight:500;margin:0 0 12px}.speech{font-size:1.08rem;padding-left:14px;border-left:3px solid #8faeec}.thought{color:#c3b5de}.id{font:12px/1.6 ui-monospace,monospace;color:#bbc7d9}.status{font-size:.8rem;color:#e9c27a}.empty{padding:24px}.pager{display:flex;justify-content:space-between;gap:12px}.summary{line-height:1.8}
</style><main><h1>라이벌 연인 사건 이후 대사 · 전체 검토본</h1>
<p class="notice"><strong>미승인·미적용</strong><br>기본 발화 후보 616개를 몸 상태별 지문·속마음과 결합한 <strong>1,232개 완성 항목</strong>입니다. 각 인물 308개. 몸 상태별 항목은 기본 발화를 공유합니다.</p>
<p class="summary">실제 APK를 확인해 작성한 새 초안입니다. 모든 조합을 미리 펼쳤으며, 아래 필터로 전부 검토할 수 있습니다. 굴복·협박의 내부 ‘허용’ 판정은 동의로 간주하지 않고 의사 확인·중단 요청을 썼습니다.<br><a href="../README.md">조건·시점·적용 계약</a> · <a href="전체목록.md">전체 목록</a> · <a href="all_dialogue.json" download>모든 항목 JSON</a></p>
<div id="filters"></div><div class="tools"><strong id="count" role="status"></strong><button id="reset">필터 초기화</button></div>
<div class="pager"><button id="prev">이전 40개</button><span id="position"></span><button id="next">다음 40개</button></div><section id="cards"></section>
<div class="pager"><button id="prevBottom">이전 40개</button><span id="positionBottom"></span><button id="nextBottom">다음 40개</button></div>
<p class="muted">수정할 문장은 ID로 지정하면 됩니다. 각 문장의 ‘ID 복사’ 버튼을 사용할 수 있습니다. 이 문서는 외부 서버나 네트워크를 사용하지 않습니다.</p></main>
<script id="payload" type="application/json">__DATA__</script>
<script>
const entries=JSON.parse(document.getElementById('payload').textContent).entries;
const fields=[['character','캐릭터'],['relation','주인공과의 관계'],['body_state','몸 상태'],['time','시점'],['action','행동'],['gate','판정']];
const controls={};let page=0;const limit=40;
function node(tag,text,cls){const el=document.createElement(tag);if(text!==undefined)el.textContent=text;if(cls)el.className=cls;return el;}
for(const [key,label]of fields){const wrap=node('label',label),sel=node('select');sel.setAttribute('aria-label',label);const all=node('option','전체');all.value='';sel.append(all);for(const v of new Set(entries.map(e=>e[key]))){const op=node('option',v);op.value=v;sel.append(op);}wrap.append(sel);document.getElementById('filters').append(wrap);controls[key]=sel;sel.addEventListener('change',()=>{page=0;render();});}
const searchLabel=node('label','ID / 대사 / 지문 검색','search'),search=node('input');search.type='search';search.placeholder='예: 그분, REIMU-FRIEND-PC';searchLabel.append(search);document.getElementById('filters').append(searchLabel);search.addEventListener('input',()=>{page=0;render();});
function filtered(){const q=search.value.trim().toLocaleLowerCase();return entries.filter(e=>fields.every(([key])=>!controls[key].value||e[key]===controls[key].value)&&(!q||[e.id,e.narration,e.speech,e.inner_thought].some(v=>v.toLocaleLowerCase().includes(q))));}
function render(){const rows=filtered(),pages=Math.max(1,Math.ceil(rows.length/limit));page=Math.min(page,pages-1);document.getElementById('count').textContent=`전체 1,232개 중 ${rows.length}개`;for(const id of ['position','positionBottom'])document.getElementById(id).textContent=`${page+1} / ${pages}쪽`;for(const id of ['prev','prevBottom'])document.getElementById(id).disabled=page===0;for(const id of ['next','nextBottom'])document.getElementById(id).disabled=page>=pages-1;const cards=document.getElementById('cards');cards.replaceChildren();if(!rows.length)cards.append(node('p','해당 조건의 항목이 없습니다.','empty'));for(const e of rows.slice(page*limit,(page+1)*limit)){const card=node('article',undefined,'card');card.append(node('h2',`${e.character} · ${e.relation} · 몸 ${e.body_state} · ${e.time} · ${e.action} · ${e.gate}`),node('p',e.id,'id'),node('p',e.narration),node('p',`${e.character} 「${e.speech}」`,'speech'),node('p',`속마음: ${e.inner_thought}`,'thought'));if(e.event_mode==='경계·피해 반응 전용')card.append(node('p','접촉 성공 연출 없음 · 의사 확인·중단 요청 초안','status'));const copy=node('button','ID 복사');copy.addEventListener('click',async()=>{try{await navigator.clipboard.writeText(e.id);copy.textContent='복사됨';}catch{window.prompt('복사할 ID',e.id);}});card.append(copy);cards.append(card);}}
for(const id of ['prev','prevBottom'])document.getElementById(id).onclick=()=>{if(page>0)page--;render();document.getElementById('filters').scrollIntoView();};for(const id of ['next','nextBottom'])document.getElementById(id).onclick=()=>{if((page+1)*limit<filtered().length)page++;render();document.getElementById('filters').scrollIntoView();};document.getElementById('reset').onclick=()=>{for(const el of Object.values(controls))el.value='';search.value='';page=0;render();};render();
</script></html>'''
    safe_json = json.dumps(doc, ensure_ascii=False).replace("<", "\\u003c").replace(">", "\\u003e").replace("&", "\\u0026")
    (OUT / "index.html").write_text(page.replace("__DATA__", safe_json), encoding="utf-8")
    print(json.dumps(doc["counts"], ensure_ascii=False))
    for p in sorted(OUT.iterdir()):
        print(p.name, p.stat().st_size)


if __name__ == "__main__":
    build()

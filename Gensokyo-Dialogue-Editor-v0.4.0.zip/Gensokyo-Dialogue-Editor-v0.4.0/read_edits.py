"""Validate a saved review and report exact edits by stable ID."""
import argparse,json
from pathlib import Path

def compare(saved,baseline):
    if saved.get('format')!='gensokyo-dialogue-review-edits'or saved.get('format_version')!=2:raise ValueError('지원하지 않는 수정본 형식')
    for k in ['dataset_id','source_apk_sha256']:
        if saved.get(k)!=baseline[k]:raise ValueError('원본/버전 불일치: '+k)
    rows=saved.get('entries');original={e['id']:e for e in baseline['entries']}
    if not isinstance(rows,list)or len(rows)!=len(original)or saved.get('entry_count')!=len(rows):raise ValueError('항목 수 불일치')
    seen=set();changes=[]
    for r in rows:
        uid=r.get('id');e=original.get(uid)
        if not e or uid in seen:raise ValueError('중복/알 수 없는 ID')
        seen.add(uid)
        if r.get('original_text')!=e['text']or any(r.get(k)!=e[k]for k in['character_key','relation_key','body_key','scene_key','variant']):raise ValueError('원본/조건 불일치: '+uid)
        if r.get('decision')not in['pending','use','exclude']:raise ValueError('검토 결과 오류')
        if not isinstance(r.get('edited_text'),str)or not isinstance(r.get('note'),str):raise ValueError('본문/메모 오류')
        if len(r['edited_text'])>20000 or len(r['note'])>4000 or(not r['edited_text'].strip()and r['decision']!='exclude'):raise ValueError('본문/메모 길이 오류')
        if r.get('previous_review'):raise ValueError('이전 검토는 보관본에서 확인')
        if r['edited_text']!=e['text']or r['decision']!='pending'or r['note']:changes.append({**r,**{k:e[k]for k in['character','relation','body_state','time','action','gate']}})
    return changes

def main():
    p=argparse.ArgumentParser();p.add_argument('saved_json',type=Path);p.add_argument('--baseline',type=Path,default=Path(__file__).parent/'review/all_dialogue.json');p.add_argument('--output',type=Path);a=p.parse_args()
    rows=compare(json.loads(a.saved_json.read_text(encoding='utf-8-sig')),json.loads(a.baseline.read_text()));lines=['# 편집 결과 대조','',f'수정·검토·메모 {len(rows)}개','']
    for r in rows:lines += ['## '+r['id'],'',f"{r['character']} · {r['relation']} · {r['body_state']} · {r['time']} · {r['action']} · {r['gate']}",'','원본: '+r['original_text'],'','수정: '+r['edited_text'],'','결과: '+r['decision'],'','메모: '+(r['note']or'없음'),'']
    text='\n'.join(lines)+'\n'
    if a.output:a.output.write_text(text)
    else:print(text)
if __name__=='__main__':main()

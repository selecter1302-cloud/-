"""Review specification only. Not integrated into the APK."""
import json
from pathlib import Path
CHARACTERS={'reimu','marisa','sakuya','sanae'}
RELATIONS={'hate','friend','stranger','crush','submit','coerced'}

def route(c):
    if c.get('character_key') not in CHARACTERS:return None
    # The original accept/refuse and special-situation checks run before this.
    if c.get('existing_special_branch')or not c.get('private_context'):return None
    if c.get('rival_relation')!='lover':return None
    if any(c.get(k)for k in ['rival_knows','rival_present','rival_permission']):return None
    e=c.get('event',{})
    if e.get('actor')!='pc'or e.get('rival_lover_at_event')is not True or e.get('known_to_heroine')is not True or e.get('kind')!='voluntary':return None
    rel=c.get('pc_relation')
    if rel=='lover':
        if c.get('is_public')is not False:return None
        rel='secret'
    elif rel not in RELATIONS:return None
    body=c.get('body_lean')
    if body not in['pc','']:return None
    body='pc'if body=='pc'else'unset'
    day,ed=c.get('day'),e.get('day')
    if type(day)is not int or type(ed)is not int or ed>day:return None
    action=c.get('action')
    if action=='after':
        if not c.get('immediate_event_end')or day!=ed:return None
        scene='after'
    elif action in['talk','touch','kiss']:
        if day-ed>=2:phase='late'
        elif c.get('first_reunion_session'):phase='next'
        else:return None
        if action=='talk':scene=phase+'_talk'
        else:
            gate=c.get('existing_gate')
            if gate not in['allow','refuse']:return None
            scene=phase+'_'+action+'_'+gate
    else:return None
    return c['character_key'],rel,body,scene

def candidates(c,corpus=None,recently_shown=(),recently_spoken=()):
    selected=route(c)
    if selected is None:return []
    if corpus is None:corpus=json.loads((Path(__file__).parent/'review/all_dialogue.json').read_text())
    result=[]
    for e in corpus['entries']:
        if tuple(e[k]for k in['character_key','relation_key','body_key','scene_key'])!=selected:continue
        spoken=e['text'].split('「',1)[-1].split('」',1)[0]if'「'in e['text']else e['text']
        if e['id']not in recently_shown and spoken not in recently_spoken:result.append(e['id'])
    # Exhaustion -> original general dialogue, never force the same confession.
    return result

# 하쿠레이 레이무 · v0.4.0

라이벌의 현재 연인 · 자발적 외도 후 · 미발각. 전부 미검토.

## V04-REIMU-HATE-UNSET-AFTER-A

싫어함 · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「……{rival}한테는 내가 사과할 거야. 네가 입에 올리진 마.」 {name}는 뒤집힌 소매를 거칠게 폈다.

## V04-REIMU-HATE-UNSET-AFTER-B

싫어함 · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「네가 싫은 건 그대로야. 그런데 걔한텐 뭐라고 하지.」 {name}는 옷고름을 묶다 말았다.

## V04-REIMU-HATE-UNSET-NEXT_TALK-A

싫어함 · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name} 「{rival} 얘길 네 입으로 들으니까 더 짜증 나. 내가 무슨 짓을 했는지 알아서.」 {name}는 찻잔을 밀어 놓았다.

## V04-REIMU-HATE-UNSET-NEXT_TALK-B

싫어함 · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name}는 {rival} 이야기에 꺼내던 부적을 말없이 도로 넣었다.

## V04-REIMU-HATE-UNSET-NEXT_TOUCH_ALLOW-A

싫어함 · 몸 미정 · 다음 만남 · 스킨십 · 수락

{name} 「……이번만 가만히 있는 거야. 걔한테 미안한 건 없어지지도 않네.」 {name}는 손끝을 펴지 않았다.

## V04-REIMU-HATE-UNSET-NEXT_TOUCH_REFUSE-A

싫어함 · 몸 미정 · 다음 만남 · 스킨십 · 거절

{name} 「손 치워. {rival}한테 한 번 못 할 짓 했으면 됐어.」 {name}는 손목을 홱 빼냈다.

## V04-REIMU-HATE-UNSET-NEXT_KISS_ALLOW-A

싫어함 · 몸 미정 · 다음 만남 · 키스 · 수락

{name} 「……뭐가 좋다고 이러는지. {rival} 얼굴은 나만 보겠지.」 {name}는 짧게 응한 뒤 이를 악물었다.

## V04-REIMU-HATE-UNSET-NEXT_KISS_REFUSE-A

싫어함 · 몸 미정 · 다음 만남 · 키스 · 거절

{name} 「싫어. 걔한테 미안해서라도 두 번은 안 해.」 {name}는 입술 앞에 부적을 세웠다.

## V04-REIMU-HATE-UNSET-LATE_TALK-A

싫어함 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「잊으라고? {rival} 얼굴 보면 생각나는데. 너야 편하겠지.」 {name}는 식은 차를 그대로 버렸다.

## V04-REIMU-HATE-UNSET-LATE_TALK-B

싫어함 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「새전 넣고 잊으라니. {rival}한테 한 게 돈 넣고 끝낼 일이야?」 {name}는 새전함 쪽을 가리키던 손을 내렸다.

## V04-REIMU-HATE-UNSET-LATE_TOUCH_ALLOW-A

싫어함 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「……가만히 좀 있어. {rival}한테 어떻게 사과할지도 모르겠으니까.」 {name}는 잡힌 손을 무릎에 내려놓았다.

## V04-REIMU-HATE-UNSET-LATE_TOUCH_REFUSE-A

싫어함 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「시간 좀 지났다고 만져도 되는 줄 알아? 걔한테 아직 미안해.」 {name}는 팔을 소매 안으로 감췄다.

## V04-REIMU-HATE-UNSET-LATE_KISS_ALLOW-A

싫어함 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「이러고도 걔한테 돌아가는 내가 싫어. 너도 싫고.」 {name}는 입맞춤 뒤 한숨을 삼켰다.

## V04-REIMU-HATE-UNSET-LATE_KISS_REFUSE-A

싫어함 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「{rival}한테 못 말한다고 네가 괜찮아진 건 아니야.」 {name}는 턱을 틀어 피했다.

## V04-REIMU-HATE-PC-AFTER-A

싫어함 · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「왜 또 네 쪽으로…… 됐어. {rival}한텐 더 미안해지네.」 {name}는 이쪽에 기댔던 어깨를 세웠다.

## V04-REIMU-HATE-PC-AFTER-B

싫어함 · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「좋아하지도 않는 너 때문에 걔한테 이 꼴이야. ……나도 참.」 {name}는 옷을 입으며 헛웃음을 흘렸다.

## V04-REIMU-HATE-PC-NEXT_TALK-A

싫어함 · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name} 「{rival}한테 가야 하는데 네가 오면 멈칫해. 이게 제일 짜증 나.」 {name}는 신발 앞에서 발을 거뒀다.

## V04-REIMU-HATE-PC-NEXT_TALK-B

싫어함 · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name}는 {rival}의 이름에 이쪽으로 기울던 몸을 바로 세웠다.

## V04-REIMU-HATE-PC-NEXT_TOUCH_ALLOW-A

싫어함 · 몸 주인공쪽 · 다음 만남 · 스킨십 · 수락

{name} 「……손은 따뜻하네. 걔한텐 이런 말도 못 하겠어.」 {name}는 잡힌 손을 잠깐 쥐었다.

## V04-REIMU-HATE-PC-NEXT_TOUCH_REFUSE-A

싫어함 · 몸 주인공쪽 · 다음 만남 · 스킨십 · 거절

{name} 「이 손이 또 너를 찾을까 봐 싫어. {rival}한테 미안해서.」 {name}는 양손을 등 뒤에 감췄다.

## V04-REIMU-HATE-PC-NEXT_KISS_ALLOW-A

싫어함 · 몸 주인공쪽 · 다음 만남 · 키스 · 수락

{name} 「받아 줬다고 웃지 마. {rival} 생각하면 난 못 웃겠으니까.」 {name}는 응한 뒤 이쪽 옷깃을 놓았다.

## V04-REIMU-HATE-PC-NEXT_KISS_REFUSE-A

싫어함 · 몸 주인공쪽 · 다음 만남 · 키스 · 거절

{name} 「다가오지 마. 내가 또 받아 주면 걔한테 뭐가 돼.」 {name}는 접은 부적으로 입가를 막았다.

## V04-REIMU-HATE-PC-LATE_TALK-A

싫어함 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「{rival} 옆에 있다가도 네가 생각나. ……정말 싫어, 이런 거.」 {name}는 찻잔 가장자리를 꾹 눌렀다.

## V04-REIMU-HATE-PC-LATE_TALK-B

싫어함 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「걔한테 돌아가선 차도 못 마셨어. 여기선 네 옆이라고 편히 앉네.」 {name}는 방석에 깊이 앉았다가 등을 폈다.

## V04-REIMU-HATE-PC-LATE_TOUCH_ALLOW-A

싫어함 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「손 하나 못 놓으면서 {rival}한테 미안하대. 우습지?」 {name}는 얽힌 손가락을 내려다봤다.

## V04-REIMU-HATE-PC-LATE_TOUCH_REFUSE-A

싫어함 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「너한테 기대면 편하니까 더 안 돼. 걔한테 너무 못됐잖아.」 {name}는 어깨에 닿은 손을 내려 줬다.

## V04-REIMU-HATE-PC-LATE_KISS_ALLOW-A

싫어함 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「……걔 얼굴 생각하다가도 눈을 감게 돼. 바보 같아.」 {name}는 입술을 뗀 뒤 눈을 뜨지 않았다.

## V04-REIMU-HATE-PC-LATE_KISS_REFUSE-A

싫어함 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「그만. {rival}한테 얼굴 들 수는 있어야지.」 {name}는 다가오던 얼굴을 손바닥으로 밀었다.

## V04-REIMU-FRIEND-UNSET-AFTER-A

친구 · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「차 마시던 사이로 돌아가면 좋겠네. {rival}한텐 그것도 거짓말이겠지만.」 {name}는 풀린 옷고름을 내려다봤다.

## V04-REIMU-FRIEND-UNSET-AFTER-B

친구 · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「걔한테 친구 만나러 간다고 했는데. ……친구가 이게 뭐야.」 {name}는 옷깃을 반듯이 여몄다.

## V04-REIMU-FRIEND-UNSET-NEXT_TALK-A

친구 · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name} 「차는 마시고 가. ……{rival}한테도 이렇게 아무렇지 않으면 좋겠네.」 {name}는 찻잔 두 개를 꺼냈다.

## V04-REIMU-FRIEND-UNSET-NEXT_TALK-B

친구 · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name}는 {rival}에게 줄 찻잔을 꺼내다 이쪽 잔과 멀리 떼어 놓았다.

## V04-REIMU-FRIEND-UNSET-NEXT_TOUCH_ALLOW-A

친구 · 몸 미정 · 다음 만남 · 스킨십 · 수락

{name} 「손 정도야…… 하고 넘겼더니 여기까지 왔지. 걔한테 미안하게.」 {name}는 손을 맡긴 채 씁쓸하게 웃었다.

## V04-REIMU-FRIEND-UNSET-NEXT_TOUCH_REFUSE-A

친구 · 몸 미정 · 다음 만남 · 스킨십 · 거절

{name} 「전처럼 굴지 마. {rival}한테 미안해서라도 선은 그어야겠어.」 {name}는 소매 끝으로 손을 물렸다.

## V04-REIMU-FRIEND-UNSET-NEXT_KISS_ALLOW-A

친구 · 몸 미정 · 다음 만남 · 키스 · 수락

{name} 「……친구끼리 이런 건 안 하잖아. 걔한텐 뭐라고 할 건데, 나.」 {name}는 응한 입술을 꾹 다물었다.

## V04-REIMU-FRIEND-UNSET-NEXT_KISS_REFUSE-A

친구 · 몸 미정 · 다음 만남 · 키스 · 거절

{name} 「차나 마셔. {rival}한테 또 거짓말 늘리고 싶진 않아.」 {name}는 찻잔을 사이에 놓았다.

## V04-REIMU-FRIEND-UNSET-LATE_TALK-A

친구 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「걔한테 네 얘길 못 하니까 이상하네. 원래 별것도 다 말했는데.」 {name}는 식어 가는 차를 휘저었다.

## V04-REIMU-FRIEND-UNSET-LATE_TALK-B

친구 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「차가 쓰대, 걔가. 네 생각하다 너무 오래 우렸나 봐. 미안하네.」 {name}는 찻잎을 한꺼번에 덜어냈다.

## V04-REIMU-FRIEND-UNSET-LATE_TOUCH_ALLOW-A

친구 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「……예전엔 이러고 있어도 떳떳했는데. 걔한테.」 {name}는 맞잡은 손 위에 빈손을 얹었다.

## V04-REIMU-FRIEND-UNSET-LATE_TOUCH_REFUSE-A

친구 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「친구면 그만해 줘. 걔 볼 때마다 찔리는 거 알잖아.」 {name}는 이쪽 손을 방석에 내려 줬다.

## V04-REIMU-FRIEND-UNSET-LATE_KISS_ALLOW-A

친구 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「……이제 친구라고만 하긴 어렵네. {rival}한테도.」 {name}는 입맞춤을 마치고 눈썹을 찌푸렸다.

## V04-REIMU-FRIEND-UNSET-LATE_KISS_REFUSE-A

친구 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「싫어. 걔한테 친구라고 소개한 걸 더 후회하게 하지 마.」 {name}는 찻상을 당겨 거리를 뒀다.

## V04-REIMU-FRIEND-PC-AFTER-A

친구 · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「친구라서 편한 줄 알았는데. ……{rival}한테 미안할 정도였네.」 {name}는 이쪽 팔에 둔 손을 거뒀다.

## V04-REIMU-FRIEND-PC-AFTER-B

친구 · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「걔 기다리는 거 알면서 네 옆이 좋았어. 변명도 못 하겠네.」 {name}는 옷을 무릎 위에 모았다.

## V04-REIMU-FRIEND-PC-NEXT_TALK-A

친구 · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name} 「네 옆에 앉는 게 습관이 됐나 봐. {rival}한테 이래도 되나.」 {name}는 붙여 놓았던 방석을 조금 밀었다.

## V04-REIMU-FRIEND-PC-NEXT_TALK-B

친구 · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name}는 이쪽 곁에 앉으려다 {rival}의 자리를 비워 두었다.

## V04-REIMU-FRIEND-PC-NEXT_TOUCH_ALLOW-A

친구 · 몸 주인공쪽 · 다음 만남 · 스킨십 · 수락

{name} 「……따뜻하네. 걔한테 미안해할 땐 이 손 놓아야 하는데.」 {name}는 손가락을 느슨하게 얽었다.

## V04-REIMU-FRIEND-PC-NEXT_TOUCH_REFUSE-A

친구 · 몸 주인공쪽 · 다음 만남 · 스킨십 · 거절

{name} 「안 돼. 네 옆에 있으면 자꾸 잊어버려. {rival} 기다리는 거.」 {name}는 손을 빗자루 자루에 옮겼다.

## V04-REIMU-FRIEND-PC-NEXT_KISS_ALLOW-A

친구 · 몸 주인공쪽 · 다음 만남 · 키스 · 수락

{name} 「내가 먼저 눈 감았네. ……걔한테는 비겁한 짓만 늘어.」 {name}는 입맞춤 뒤 이마를 짚었다.

## V04-REIMU-FRIEND-PC-NEXT_KISS_REFUSE-A

친구 · 몸 주인공쪽 · 다음 만남 · 키스 · 거절

{name} 「친구라는 말로 더 숨기지 마. 걔한테 너무 미안하잖아.」 {name}는 입술 앞에서 손을 폈다.

## V04-REIMU-FRIEND-PC-LATE_TALK-A

친구 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「{rival}한텐 조금 있다 간다 해 놓고 네 옆에 눌러앉네. 못됐다, 나.」 {name}는 빈 찻잔을 다시 채웠다.

## V04-REIMU-FRIEND-PC-LATE_TALK-B

친구 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「친구 보러 오는 거라며 웃었어. {rival} 앞에서. 나도 뻔뻔해졌네.」 {name}는 찻잔을 이쪽으로 밀다 멈췄다.

## V04-REIMU-FRIEND-PC-LATE_TOUCH_ALLOW-A

친구 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「……놓기 싫은 게 문제야. {rival}한테 이 손을 어떻게 내밀지.」 {name}는 맞잡은 손등을 엄지로 문질렀다.

## V04-REIMU-FRIEND-PC-LATE_TOUCH_REFUSE-A

친구 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「이러다 또 늦겠어. 걔한테 기다리라는 말도 이제 미안해.」 {name}는 걸린 소매를 빼며 일어섰다.

## V04-REIMU-FRIEND-PC-LATE_KISS_ALLOW-A

친구 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「네가 좋으면 걔한테도 솔직해야 하는데. ……입만 쉽네.」 {name}는 짧은 입맞춤에 이쪽 소매를 당겼다.

## V04-REIMU-FRIEND-PC-LATE_KISS_REFUSE-A

친구 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「오늘은 그만. 걔한테 갈 때까지 이 기분이면 안 되잖아.」 {name}는 다가온 얼굴에서 시선을 내렸다.

## V04-REIMU-SECRET-UNSET-AFTER-A

연인(비밀) · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「너도 좋아해. 그 말 하면 {rival}한테 덜 미안해질 줄 알았나 봐.」 {name}는 입던 옷을 가슴에 모았다.

## V04-REIMU-SECRET-UNSET-AFTER-B

연인(비밀) · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「걔 몰래 만나기만 해도 미안했는데. ……이젠 정말 못할 짓 했네.」 {name}는 매듭을 다시 풀었다.

## V04-REIMU-SECRET-UNSET-NEXT_TALK-A

연인(비밀) · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name} 「{rival} 얘기만 나오면 네 눈치부터 보네. 내가 미안해야 할 건 걔인데.」 {name}는 이쪽을 보던 눈을 내렸다.

## V04-REIMU-SECRET-UNSET-NEXT_TALK-B

연인(비밀) · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name}는 {rival}에게 할 말을 중얼거리다 이쪽이 듣자 입을 다물었다.

## V04-REIMU-SECRET-UNSET-NEXT_TOUCH_ALLOW-A

연인(비밀) · 몸 미정 · 다음 만남 · 스킨십 · 수락

{name} 「……너한테 기대고 싶은 것도 미안해. 걔한테 한 짓 잊으려고 이러나 싶고.」 {name}는 손등에 이마를 잠깐 댔다.

## V04-REIMU-SECRET-UNSET-NEXT_TOUCH_REFUSE-A

연인(비밀) · 몸 미정 · 다음 만남 · 스킨십 · 거절

{name} 「오늘은 만지지 마. {rival}한테 미안한 채로 네 옆에서 웃긴 싫어.」 {name}는 잡으려던 손을 접었다.

## V04-REIMU-SECRET-UNSET-NEXT_KISS_ALLOW-A

연인(비밀) · 몸 미정 · 다음 만남 · 키스 · 수락

{name} 「좋아하니까 받아 준 거야. 걔를 배신한 건 내 잘못이고.」 {name}는 입술을 떼고도 가까이 앉아 있었다.

## V04-REIMU-SECRET-UNSET-NEXT_KISS_REFUSE-A

연인(비밀) · 몸 미정 · 다음 만남 · 키스 · 거절

{name} 「……안 돼. 걔 생각하면서 너랑 입 맞추는 것도 너무해.」 {name}는 얼굴을 옆으로 돌렸다.

## V04-REIMU-SECRET-UNSET-LATE_TALK-A

연인(비밀) · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「{rival}한테는 여전히 좋아한다고 해. 너한테도. ……비겁하지.」 {name}는 찻잔을 두 손에 감쌌다.

## V04-REIMU-SECRET-UNSET-LATE_TALK-B

연인(비밀) · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「걔가 날 좋아하는 얼굴은 그대로네. 달라진 건 나뿐이고.」 {name}는 마루 먼지를 손으로 쓸었다.

## V04-REIMU-SECRET-UNSET-LATE_TOUCH_ALLOW-A

연인(비밀) · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「이 손 놓는다고 없던 일은 안 되겠지. 걔한텐 그래도 미안해.」 {name}는 맞잡은 손을 오래 바라봤다.

## V04-REIMU-SECRET-UNSET-LATE_TOUCH_REFUSE-A

연인(비밀) · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「걔한테 어떻게 말할지 생각 좀 하게 놔둬.」 {name}는 손을 무릎 아래로 내렸다.

## V04-REIMU-SECRET-UNSET-LATE_KISS_ALLOW-A

연인(비밀) · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「……너도 좋아해서 이러는 내가, 걔한텐 제일 잔인하겠네.」 {name}는 입맞춤을 마치고 미간을 눌렀다.

## V04-REIMU-SECRET-UNSET-LATE_KISS_REFUSE-A

연인(비밀) · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「아직 둘 다 갖고 싶나 봐. 그러니까 오늘은 안 해.」 {name}는 다가온 입가를 손끝으로 막았다.

## V04-REIMU-SECRET-PC-AFTER-A

연인(비밀) · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「{rival}이(가) 기다리는데 네 품이 좋았어. ……내가 잘못한 거야.」 {name}는 이쪽에 걸친 팔을 천천히 풀었다.

## V04-REIMU-SECRET-PC-AFTER-B

연인(비밀) · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「가지 말라고 하고 싶네. 걔한테 미안하단 말 방금 했는데.」 {name}는 이쪽 옷자락을 쥐다 놓았다.

## V04-REIMU-SECRET-PC-NEXT_TALK-A

연인(비밀) · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name} 「네 얼굴 보자마자 좋아지네. {rival}한텐 그렇게 미안했으면서.」 {name}는 풀린 표정을 손으로 가렸다.

## V04-REIMU-SECRET-PC-NEXT_TALK-B

연인(비밀) · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name}는 이쪽 소매를 당기다 {rival}의 이름을 듣고 손을 풀었다.

## V04-REIMU-SECRET-PC-NEXT_TOUCH_ALLOW-A

연인(비밀) · 몸 주인공쪽 · 다음 만남 · 스킨십 · 수락

{name} 「……이 손이 좋아. 걔한테 미안한 마음까지 없어지진 않지만.」 {name}는 이쪽 손바닥에 손을 포갰다.

## V04-REIMU-SECRET-PC-NEXT_TOUCH_REFUSE-A

연인(비밀) · 몸 주인공쪽 · 다음 만남 · 스킨십 · 거절

{name} 「너한테 달라붙으면 {rival} 생각을 안 해. 그래서 지금은 싫어.」 {name}는 기대던 몸을 바로 앉혔다.

## V04-REIMU-SECRET-PC-NEXT_KISS_ALLOW-A

연인(비밀) · 몸 주인공쪽 · 다음 만남 · 키스 · 수락

{name} 「한 번 더 하고 싶어. ……걔한테 사과도 못 한 주제에.」 {name}는 입맞춤 뒤 소매를 놓지 않았다.

## V04-REIMU-SECRET-PC-NEXT_KISS_REFUSE-A

연인(비밀) · 몸 주인공쪽 · 다음 만남 · 키스 · 거절

{name} 「안 돼. 너한테 취해서 걔를 또 잊고 싶진 않아.」 {name}는 이쪽 턱 아래에 손을 댔다.

## V04-REIMU-SECRET-PC-LATE_TALK-A

연인(비밀) · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「{rival}이랑(랑) 있다가도 네가 보고 싶어. 그 사람 앞에서 그랬어, 나.」 {name}는 찻물을 넘치도록 따랐다.

## V04-REIMU-SECRET-PC-LATE_TALK-B

연인(비밀) · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「네 자리부터 따뜻하게 해 놨어. 걔한텐 바쁘다고도 했는데 말이지.」 {name}는 방석을 손바닥으로 꾹 눌렀다.

## V04-REIMU-SECRET-PC-LATE_TOUCH_ALLOW-A

연인(비밀) · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「……네 손인 줄 알았어. 걔가 잡아 줬는데. 미안해서 바로 놨네.」 {name}는 이번엔 맞잡은 손을 놓지 못했다.

## V04-REIMU-SECRET-PC-LATE_TOUCH_REFUSE-A

연인(비밀) · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「지금 잡으면 또 못 놔. {rival}한테 돌아가야 해.」 {name}는 뻗어 오던 손을 가볍게 눌렀다.

## V04-REIMU-SECRET-PC-LATE_KISS_ALLOW-A

연인(비밀) · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「걔한테 미안하단 말이 버릇 될까 봐 무서워. 이렇게 또 받아 주면서.」 {name}는 응한 뒤 이마를 맞댔다.

## V04-REIMU-SECRET-PC-LATE_KISS_REFUSE-A

연인(비밀) · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「……오늘만큼은 걔한테 떳떳하게 가고 싶어.」 {name}는 가까워진 얼굴을 끝내 피했다.

## V04-REIMU-STRANGER-UNSET-AFTER-A

타인 · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「너에 대해 아는 것도 없는데. {rival}한테 이럴 줄은 몰랐네.」 {name}는 옷을 집어 들고 굳었다.

## V04-REIMU-STRANGER-UNSET-AFTER-B

타인 · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「걔한테 무슨 말을 해야 할지 모르겠어. 너한테 할 말도 없고.」 {name}는 등을 세운 채 옷을 입었다.

## V04-REIMU-STRANGER-UNSET-NEXT_TALK-A

타인 · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name} 「……와서 할 얘기가 있어? 난 {rival}한테도 아직 못 했는데.」 {name}는 문턱에 선 채 비키지 않았다.

## V04-REIMU-STRANGER-UNSET-NEXT_TALK-B

타인 · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name}는 {rival}의 안부에는 대답하지 않고 빈 방석만 털었다.

## V04-REIMU-STRANGER-UNSET-NEXT_TOUCH_ALLOW-A

타인 · 몸 미정 · 다음 만남 · 스킨십 · 수락

{name} 「……손만이야. 그때처럼 걔한테 못 할 짓까지 가진 마.」 {name}는 손을 맡기고 딴 곳을 봤다.

## V04-REIMU-STRANGER-UNSET-NEXT_TOUCH_REFUSE-A

타인 · 몸 미정 · 다음 만남 · 스킨십 · 거절

{name} 「친한 척하지 마. 걔한테 미안한 걸 네가 달랠 건 아니야.」 {name}는 가까워진 손을 쳐냈다.

## V04-REIMU-STRANGER-UNSET-NEXT_KISS_ALLOW-A

타인 · 몸 미정 · 다음 만남 · 키스 · 수락

{name} 「……이런 사이가 될 줄도 몰랐네. 걔는 더 모르겠지.」 {name}는 입맞춤에 굳었던 어깨를 내렸다.

## V04-REIMU-STRANGER-UNSET-NEXT_KISS_REFUSE-A

타인 · 몸 미정 · 다음 만남 · 키스 · 거절

{name} 「그날 받아 줬다고 계속 되는 건 아니야. {rival}한테도 미안하고.」 {name}는 옆으로 한 발 비켰다.

## V04-REIMU-STRANGER-UNSET-LATE_TALK-A

타인 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「너는 멀쩡히 잘 지내네. 난 걔랑 눈 마주치는 것도 힘든데.」 {name}는 문설주를 짚었다.

## V04-REIMU-STRANGER-UNSET-LATE_TALK-B

타인 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「걔한테 네 이름 나올까 봐 말을 아껴. 나 원래도 말 없긴 하지만.」 {name}는 내어 두었던 찻잔을 뒤집었다.

## V04-REIMU-STRANGER-UNSET-LATE_TOUCH_ALLOW-A

타인 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「이렇게 손잡을 정도로는 알게 됐네. 걔한테 숨길 것만 늘고.」 {name}는 어색하게 손을 쥐었다 폈다.

## V04-REIMU-STRANGER-UNSET-LATE_TOUCH_REFUSE-A

타인 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「너랑 더 가까워질 생각 없어. {rival} 속이는 것도 이젠 지쳐.」 {name}는 팔꿈치를 안으로 당겼다.

## V04-REIMU-STRANGER-UNSET-LATE_KISS_ALLOW-A

타인 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「……이름도 제대로 안 부르는 너랑 이러네. 걔한테 미안하게.」 {name}는 짧게 응한 뒤 옷깃을 만졌다.

## V04-REIMU-STRANGER-UNSET-LATE_KISS_REFUSE-A

타인 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「돌아가. 걔한테 사과할 생각은 못 하고 또 이러긴 싫어.」 {name}는 문을 반쯤 닫았다.

## V04-REIMU-STRANGER-PC-AFTER-A

타인 · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「……왜 네 쪽이 편한데. {rival} 놔두고, 잘 알지도 못하는 너한테.」 {name}는 기대던 팔을 걷어냈다.

## V04-REIMU-STRANGER-PC-AFTER-B

타인 · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「걔한테 미안하니까 가야 하는데. 몸이 안 움직이네.」 {name}는 옷을 입고도 자리에 남았다.

## V04-REIMU-STRANGER-PC-NEXT_TALK-A

타인 · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name} 「너 보자마자 멈춰 섰어. {rival} 만나러 가던 길인데.」 {name}는 돌려놓은 발끝을 내려다봤다.

## V04-REIMU-STRANGER-PC-NEXT_TALK-B

타인 · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name}는 이쪽을 반기려다 {rival} 이야기에 입가를 굳혔다.

## V04-REIMU-STRANGER-PC-NEXT_TOUCH_ALLOW-A

타인 · 몸 주인공쪽 · 다음 만남 · 스킨십 · 수락

{name} 「……어색하진 않네. 그게 걔한테 더 미안하고.」 {name}는 손바닥을 이쪽 손에 기댔다.

## V04-REIMU-STRANGER-PC-NEXT_TOUCH_REFUSE-A

타인 · 몸 주인공쪽 · 다음 만남 · 스킨십 · 거절

{name} 「모르는 사람인데 손부터 찾네. 걔한테 이러면 안 되는데.」 {name}는 손을 꽉 움켜쥐어 감췄다.

## V04-REIMU-STRANGER-PC-NEXT_KISS_ALLOW-A

타인 · 몸 주인공쪽 · 다음 만남 · 키스 · 수락

{name} 「익숙해지고 싶지도 않았는데. ……{rival}한텐 못 하겠다, 이런 말.」 {name}는 눈을 감고 짧게 응했다.

## V04-REIMU-STRANGER-PC-NEXT_KISS_REFUSE-A

타인 · 몸 주인공쪽 · 다음 만남 · 키스 · 거절

{name} 「네 얼굴 가까워지면 또 잊겠지. 걔가 기다리는 거. 안 돼.」 {name}는 시선을 맞춘 채 뒷걸음쳤다.

## V04-REIMU-STRANGER-PC-LATE_TALK-A

타인 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「네가 어떤 사람인지보다 자꾸 보고 싶은 게 먼저네. 걔한테 죄짓고.」 {name}는 다가오다 마루 끝에 멈췄다.

## V04-REIMU-STRANGER-PC-LATE_TALK-B

타인 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「너한텐 차 더 마시라 해 놓고 걔한텐 늦는다고 해. 미안해할 짓만 고르네.」 {name}는 빈 주전자를 들어 보였다.

## V04-REIMU-STRANGER-PC-LATE_TOUCH_ALLOW-A

타인 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「……손은 기억하네. 걔 앞에서 이러면 무슨 얼굴을 할까.」 {name}는 이쪽 손끝을 조심히 맞잡았다.

## V04-REIMU-STRANGER-PC-LATE_TOUCH_REFUSE-A

타인 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「더 익숙해지기 전에 놔야지. 걔한테 미안한 것도 모르게 되겠어.」 {name}는 손을 빼서 옷자락을 쥐었다.

## V04-REIMU-STRANGER-PC-LATE_KISS_ALLOW-A

타인 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「{rival}한테는 미안하고 네 쪽으론 끌리고. 정말 못났네.」 {name}는 응한 뒤 이쪽 어깨에 이마를 댔다.

## V04-REIMU-STRANGER-PC-LATE_KISS_REFUSE-A

타인 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「안 해. 너한테 또 익숙해져서 걔를 더 속이긴 싫어.」 {name}는 눈을 감기 전에 얼굴을 돌렸다.

## V04-REIMU-CRUSH-UNSET-AFTER-A

짝사랑 · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「좋아한다고 먼저 말했어야 했는데. {rival}한테 이러기 전에.」 {name}는 무녀복을 꼭 쥐었다.

## V04-REIMU-CRUSH-UNSET-AFTER-B

짝사랑 · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「네가 좋아서 그랬어. ……그게 걔한테 변명은 안 되겠지.」 {name}는 붉어진 얼굴을 숙였다.

## V04-REIMU-CRUSH-UNSET-NEXT_TALK-A

짝사랑 · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name} 「너 보면 좋네. 걔한테 미안해하고도 이래.」 {name}는 내밀려던 찻잔을 도로 당겼다.

## V04-REIMU-CRUSH-UNSET-NEXT_TALK-B

짝사랑 · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name}는 {rival}을(를) 부르려다 이쪽과 눈이 마주쳐 찻잔을 내려놨다.

## V04-REIMU-CRUSH-UNSET-NEXT_TOUCH_ALLOW-A

짝사랑 · 몸 미정 · 다음 만남 · 스킨십 · 수락

{name} 「……좋아서 잡는 거야. 걔한텐 못 할 말이네.」 {name}는 손가락 끝만 살며시 걸었다.

## V04-REIMU-CRUSH-UNSET-NEXT_TOUCH_REFUSE-A

짝사랑 · 몸 미정 · 다음 만남 · 스킨십 · 거절

{name} 「좋아한다고 손부터 잡지 마. 걔한테 미안한 건 나니까.」 {name}는 붉어진 손등을 감췄다.

## V04-REIMU-CRUSH-UNSET-NEXT_KISS_ALLOW-A

짝사랑 · 몸 미정 · 다음 만남 · 키스 · 수락

{name} 「기다렸나 봐, 나. 걔한테는 기다리라고 해 놓고.」 {name}는 응한 뒤 눈을 동그랗게 떴다.

## V04-REIMU-CRUSH-UNSET-NEXT_KISS_REFUSE-A

짝사랑 · 몸 미정 · 다음 만남 · 키스 · 거절

{name} 「안 돼. 너 좋아하는 걸 핑계로 걔한테 더 못되게 굴긴 싫어.」 {name}는 볼이 붉어진 채 고개를 저었다.

## V04-REIMU-CRUSH-UNSET-LATE_TALK-A

짝사랑 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「네 이름 들으면 고개가 돌아가. {rival} 앞에서도. ……미안하지.」 {name}는 부채를 반쯤 펼쳤다.

## V04-REIMU-CRUSH-UNSET-LATE_TALK-B

짝사랑 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「걔랑 신사에 앉아 있으면 네가 오나 보게 돼. 정말 못됐지.」 {name}는 입구에서 눈을 거뒀다.

## V04-REIMU-CRUSH-UNSET-LATE_TOUCH_ALLOW-A

짝사랑 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「이런 건 아직도 설레네. 걔한테 미안해서 괴로울 줄만 알았어.」 {name}는 이쪽 손을 소매로 살짝 덮었다.

## V04-REIMU-CRUSH-UNSET-LATE_TOUCH_REFUSE-A

짝사랑 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「만지면 내가 또 좋아하겠지. 걔한테 그렇게 못되게 굴어 놓고.」 {name}는 닿기 전에 손을 뒤로 뺐다.

## V04-REIMU-CRUSH-UNSET-LATE_KISS_ALLOW-A

짝사랑 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「너랑 이러는 게 좋은 게 제일 미안해. {rival}한테.」 {name}는 짧은 입맞춤에 눈을 질끈 감았다.

## V04-REIMU-CRUSH-UNSET-LATE_KISS_REFUSE-A

짝사랑 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「……좋아해. 그러니까 걔한테 말도 못 한 채 더 하게 하지 마.」 {name}는 손바닥으로 제 입을 가렸다.

## V04-REIMU-CRUSH-PC-AFTER-A

짝사랑 · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「좋아하는 게 이렇게 티 나네. 걔한텐 얼마나 못된 얼굴일까.」 {name}는 이쪽에 붙어 있던 무릎을 뗐다.

## V04-REIMU-CRUSH-PC-AFTER-B

짝사랑 · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「네가 가지 말랬으면 못 갔을걸. {rival} 기다리는 거 알면서.」 {name}는 옷을 고쳐 입고도 이쪽을 봤다.

## V04-REIMU-CRUSH-PC-NEXT_TALK-A

짝사랑 · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name} 「……왔네. 이 말부터 좋아서 나오네, 걔한테 미안한데.」 {name}는 웃으려던 입가를 눌렀다.

## V04-REIMU-CRUSH-PC-NEXT_TALK-B

짝사랑 · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name}는 이쪽을 보며 웃다가 {rival}의 이름에 차를 들이켰다.

## V04-REIMU-CRUSH-PC-NEXT_TOUCH_ALLOW-A

짝사랑 · 몸 주인공쪽 · 다음 만남 · 스킨십 · 수락

{name} 「……손 줘. 걔한테 미안하다고 한 지 얼마나 됐다고 이러네.」 {name}는 손바닥을 먼저 내밀었다.

## V04-REIMU-CRUSH-PC-NEXT_TOUCH_REFUSE-A

짝사랑 · 몸 주인공쪽 · 다음 만남 · 스킨십 · 거절

{name} 「안 잡아. 너한테 닿으면 걔한테 미안했던 것도 잠깐 잊어.」 {name}는 이쪽을 향하던 손을 눌러 내렸다.

## V04-REIMU-CRUSH-PC-NEXT_KISS_ALLOW-A

짝사랑 · 몸 주인공쪽 · 다음 만남 · 키스 · 수락

{name} 「……더 하고 싶어. 걔한테 못할 말만 자꾸 생겨.」 {name}는 응한 뒤 이쪽 옷자락에 손을 걸었다.

## V04-REIMU-CRUSH-PC-NEXT_KISS_REFUSE-A

짝사랑 · 몸 주인공쪽 · 다음 만남 · 키스 · 거절

{name} 「그만. 내가 먼저 다가가게 되잖아. 걔한테 뭐가 돼.」 {name}는 뺨을 붉히며 몸을 뒤로 뺐다.

## V04-REIMU-CRUSH-PC-LATE_TALK-A

짝사랑 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「{rival}이(가) 잘해 줄수록 네 생각하면 안 될 것 같은데. 자꾸 나.」 {name}는 마루판의 틈을 손끝으로 짚었다.

## V04-REIMU-CRUSH-PC-LATE_TALK-B

짝사랑 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「네가 좋아하는 차를 걔한테 내놨어. ……미안해할 이유도 잘도 늘지.」 {name}는 찻잎 통의 뚜껑을 세게 닫았다.

## V04-REIMU-CRUSH-PC-LATE_TOUCH_ALLOW-A

짝사랑 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「……네 손이구나. 좋아해 버리니까 걔한테 더 미안하네.」 {name}는 맞잡은 손을 볼에 잠깐 댔다.

## V04-REIMU-CRUSH-PC-LATE_TOUCH_REFUSE-A

짝사랑 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「오늘은 {rival}한테 가야 해. 네 손 잡으면 또 못 가.」 {name}는 손을 내미는 대신 신발을 신었다.

## V04-REIMU-CRUSH-PC-LATE_KISS_ALLOW-A

짝사랑 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「꿈에선 네가 와도 괜찮았는데. 걔한텐 정말 미안하다.」 {name}는 입맞춤 뒤 이쪽 품에 얼굴을 가렸다.

## V04-REIMU-CRUSH-PC-LATE_KISS_REFUSE-A

짝사랑 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「이러면 또 널 기다릴 거야. 걔한텐 계속 미안해하면서. 안 돼.」 {name}는 입술이 닿기 전에 눈을 떴다.

## V04-REIMU-SUBMIT-UNSET-AFTER-A

굴복 · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「걔한테 미안하단 말도 이젠 염치없네. 내가 여기까지 와 놓고.」 {name}는 흐트러진 옷을 말없이 모았다.

## V04-REIMU-SUBMIT-UNSET-AFTER-B

굴복 · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「{rival}한테 숨길지는 네가 정하겠지. ……난 또 비겁하게 가만있고.」 {name}는 옷고름 끝만 쥐고 있었다.

## V04-REIMU-SUBMIT-UNSET-NEXT_TALK-A

굴복 · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name} 「걔 얘기 좀 하지 마. 아직 날 믿는다는 건 아니까.」 {name}는 찻잔을 입에 대지 못했다.

## V04-REIMU-SUBMIT-UNSET-NEXT_TALK-B

굴복 · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name}는 {rival}에게 돌아갈 옷을 개다 말고 무릎에 떨궜다.

## V04-REIMU-SUBMIT-UNSET-NEXT_TOUCH_ALLOW-A

굴복 · 몸 미정 · 다음 만남 · 스킨십 · 수락

{name} 「……그래. 걔 손 잡을 땐 이 손으로 뭘 했는지 생각나겠지.」 {name}는 펴진 손을 그대로 맡겼다.

## V04-REIMU-SUBMIT-UNSET-NEXT_TOUCH_REFUSE-A

굴복 · 몸 미정 · 다음 만남 · 스킨십 · 거절

{name} 「잠깐 놔. 걔한테 미안한 기분까지 버리진 못하겠어.」 {name}는 잡힌 손끝을 안으로 말았다.

## V04-REIMU-SUBMIT-UNSET-NEXT_KISS_ALLOW-A

굴복 · 몸 미정 · 다음 만남 · 키스 · 수락

{name} 「……받아 줄게. 걔한테 사과는 못 하면서 이것만 쉽네.」 {name}는 응한 뒤 어깨를 축 늘어뜨렸다.

## V04-REIMU-SUBMIT-UNSET-NEXT_KISS_REFUSE-A

굴복 · 몸 미정 · 다음 만남 · 키스 · 거절

{name} 「오늘은 못 해. {rival}한테 미안해서, 그 말밖에 없어.」 {name}는 입술을 꼭 다문 채 숙였다.

## V04-REIMU-SUBMIT-UNSET-LATE_TALK-A

굴복 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「걔가 잘 지내냐더라. 그렇다고 했어. ……마지막까지 속이네.」 {name}는 찻잔 바닥을 문질렀다.

## V04-REIMU-SUBMIT-UNSET-LATE_TALK-B

굴복 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「걔한테는 아무 일도 없었대. 내가 그렇게 말했거든.」 {name}는 젖은 천을 접어 무릎에 올렸다.

## V04-REIMU-SUBMIT-UNSET-LATE_TOUCH_ALLOW-A

굴복 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「……따뜻한 건 알겠네. 걔한테도 이러고 웃었는데.」 {name}는 맡긴 손을 조금 오므렸다.

## V04-REIMU-SUBMIT-UNSET-LATE_TOUCH_REFUSE-A

굴복 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「그 손은 놔 줘. 걔한테 내밀 낯도 없지만.」 {name}는 느리게 팔을 거둬들였다.

## V04-REIMU-SUBMIT-UNSET-LATE_KISS_ALLOW-A

굴복 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「걔한테 미안하다는 말보다 이걸 먼저 받아 주네, 나.」 {name}는 입맞춤이 끝나도 고개를 들지 않았다.

## V04-REIMU-SUBMIT-UNSET-LATE_KISS_REFUSE-A

굴복 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「……싫어. 걔 생각만큼은 내버려 둬.」 {name}는 눈을 내리깐 채 얼굴을 비켰다.

## V04-REIMU-SUBMIT-PC-AFTER-A

굴복 · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「또 네 옆으로 갔네. {rival}한테 미안해할 틈도 없이.」 {name}는 붙어 있던 몸을 겨우 세웠다.

## V04-REIMU-SUBMIT-PC-AFTER-B

굴복 · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「걔 기다리는 건 알았어. 그래도 네가 가라는 말 할 때까지 있었네.」 {name}는 입은 옷자락만 정리했다.

## V04-REIMU-SUBMIT-PC-NEXT_TALK-A

굴복 · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name} 「{rival}한테 가려다 여기 왔어. ……네가 부르지도 않았는데.」 {name}는 문 앞에서 양손을 모았다.

## V04-REIMU-SUBMIT-PC-NEXT_TALK-B

굴복 · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name}는 이쪽 옆자리에 앉고도 {rival}의 이름만 작게 되뇌었다.

## V04-REIMU-SUBMIT-PC-NEXT_TOUCH_ALLOW-A

굴복 · 몸 주인공쪽 · 다음 만남 · 스킨십 · 수락

{name} 「……놓으라고 해야 하는데. 걔한테 미안한 것도 아는데.」 {name}는 맞잡은 손을 제 쪽으로 당겼다.

## V04-REIMU-SUBMIT-PC-NEXT_TOUCH_REFUSE-A

굴복 · 몸 주인공쪽 · 다음 만남 · 스킨십 · 거절

{name} 「지금만 안 할래. 또 네 쪽으로 붙으면 걔한테 너무 미안하니까.」 {name}는 팔짱을 껴 손을 눌렀다.

## V04-REIMU-SUBMIT-PC-NEXT_KISS_ALLOW-A

굴복 · 몸 주인공쪽 · 다음 만남 · 키스 · 수락

{name} 「네가 원하면 눈 감게 되네. 걔가 원한 건 이것도 아닌데.」 {name}는 응한 뒤 멍하니 이쪽을 봤다.

## V04-REIMU-SUBMIT-PC-NEXT_KISS_REFUSE-A

굴복 · 몸 주인공쪽 · 다음 만남 · 키스 · 거절

{name} 「……오늘은 {rival} 생각 좀 할게. 잠깐이면 돼.」 {name}는 다가온 입술에서 고개를 내렸다.

## V04-REIMU-SUBMIT-PC-LATE_TALK-A

굴복 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「걔한테는 바쁘다 하고 여기 와. 네 옆에선 할 일도 없는데.」 {name}는 무릎 위의 손을 폈다 접었다.

## V04-REIMU-SUBMIT-PC-LATE_TALK-B

굴복 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「걔가 찾아오면 반가워해야지. 네가 부를까부터 생각하지 말고. ……알아도 이래.」 {name}는 마루 끝으로 발을 늘어뜨렸다.

## V04-REIMU-SUBMIT-PC-LATE_TOUCH_ALLOW-A

굴복 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「……따뜻해서 또 잡아. 걔한테 미안하단 건 말로만 하나 봐.」 {name}는 이쪽 손에 뺨을 비볐다.

## V04-REIMU-SUBMIT-PC-LATE_TOUCH_REFUSE-A

굴복 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「네 손 놓는 것부터 해야겠어. 걔한테 해 줄 게 그거라도 있겠지.」 {name}는 얽힌 손가락을 하나씩 풀었다.

## V04-REIMU-SUBMIT-PC-LATE_KISS_ALLOW-A

굴복 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「이러고 나면 더 미안할 텐데. ……알아도 눈 감네.」 {name}는 입맞춤 뒤 소리 없이 숨을 골랐다.

## V04-REIMU-SUBMIT-PC-LATE_KISS_REFUSE-A

굴복 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「그만해. {rival}한테 돌아가야 하는 건 아직 기억해.」 {name}는 이쪽 어깨를 짚고 거리를 벌렸다.

## V04-REIMU-COERCED-UNSET-AFTER-A

협박 중 · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「걔한테 말하겠단 소리부터 하지 마. 내가 잘못한 건 나도 알아.」 {name}는 옷을 움켜쥔 손에 힘을 줬다.

## V04-REIMU-COERCED-UNSET-AFTER-B

협박 중 · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「{rival}한테 미안해. 그걸 네가 쥐고 흔들 권리는 없어.」 {name}는 매듭을 꽉 조였다.

## V04-REIMU-COERCED-UNSET-NEXT_TALK-A

협박 중 · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name} 「걔 이름으로 날 부르지 마. ……다 들었으니까.」 {name}는 찻잔을 소리 나게 내려놨다.

## V04-REIMU-COERCED-UNSET-NEXT_TALK-B

협박 중 · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name}는 {rival} 이야기를 꺼내려다 이쪽 표정부터 살폈다.

## V04-REIMU-COERCED-UNSET-NEXT_TOUCH_ALLOW-A

협박 중 · 몸 미정 · 다음 만남 · 스킨십 · 수락

{name} 「……손만 잡는 거야. 걔한테 한 짓까지 가벼워지는 건 아니고.」 {name}는 팔을 뻣뻣하게 둔 채 손을 맡겼다.

## V04-REIMU-COERCED-UNSET-NEXT_TOUCH_REFUSE-A

협박 중 · 몸 미정 · 다음 만남 · 스킨십 · 거절

{name} 「{rival}한테 말한다 해도 지금은 만지지 마.」 {name}는 뻗은 손을 단호하게 밀쳤다.

## V04-REIMU-COERCED-UNSET-NEXT_KISS_ALLOW-A

협박 중 · 몸 미정 · 다음 만남 · 키스 · 수락

{name} 「……여기까지. 걔한테 미안해서 가만있는 걸 좋아한다고 하지 마.」 {name}는 짧게 응한 뒤 몸을 굳혔다.

## V04-REIMU-COERCED-UNSET-NEXT_KISS_REFUSE-A

협박 중 · 몸 미정 · 다음 만남 · 키스 · 거절

{name} 「싫다니까. 걔한테 미안한 건 내가 감당해.」 {name}는 입가에 부적을 바짝 댔다.

## V04-REIMU-COERCED-UNSET-LATE_TALK-A

협박 중 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「걔가 상처받을까 봐 못 말한 건데. 이러다 더 못된 거짓말만 늘겠네.」 {name}는 찻상을 움켜잡았다.

## V04-REIMU-COERCED-UNSET-LATE_TALK-B

협박 중 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「퇴치 운운하면서 걔한텐 아무 말도 못 하네. 웃기지, 내가 봐도.」 {name}는 꺼낸 부적을 반으로 접었다.

## V04-REIMU-COERCED-UNSET-LATE_TOUCH_ALLOW-A

협박 중 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「……잠깐이면 돼. 걔한테 또 숨길 얘기 늘리는 것도 지겹네.」 {name}는 손목에 힘을 뺀 채 기다렸다.

## V04-REIMU-COERCED-UNSET-LATE_TOUCH_REFUSE-A

협박 중 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「내가 걔한테 잘못했어도 네 손까지 참을 필요는 없잖아.」 {name}는 손을 탁 털어 냈다.

## V04-REIMU-COERCED-UNSET-LATE_KISS_ALLOW-A

협박 중 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「……받아 줬다고 협박한 게 없어지진 않아. 걔한텐 내가 미안해하고.」 {name}는 응한 뒤 입술을 문질렀다.

## V04-REIMU-COERCED-UNSET-LATE_KISS_REFUSE-A

협박 중 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「그만. {rival}한테 말하든 말든 그건 안 해.」 {name}는 손등으로 다가온 턱을 밀어냈다.

## V04-REIMU-COERCED-PC-AFTER-A

협박 중 · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「네 옆이 편하다고 걔한테 덜 미안한 건 아니야. 그걸로 협박하지 마.」 {name}는 이쪽 어깨에서 몸을 뗐다.

## V04-REIMU-COERCED-PC-AFTER-B

협박 중 · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「내가 다시 붙었다고 걔한테 말하겠단 소리가 괜찮아져?」 {name}는 붙잡았던 옷깃을 세게 놓았다.

## V04-REIMU-COERCED-PC-NEXT_TALK-A

협박 중 · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name} 「네가 부르면 가게 돼. 그걸 걔한테 들킬까 봐 쩔쩔매고.」 {name}는 이쪽 앞에서 발을 멈췄다.

## V04-REIMU-COERCED-PC-NEXT_TALK-B

협박 중 · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name}는 이쪽에 내밀던 손을 {rival}의 이름 한마디에 감췄다.

## V04-REIMU-COERCED-PC-NEXT_TOUCH_ALLOW-A

협박 중 · 몸 주인공쪽 · 다음 만남 · 스킨십 · 수락

{name} 「……따뜻하긴 하네. 이걸 걔한테 들이밀며 웃진 마.」 {name}는 손을 잡고도 이쪽을 노려봤다.

## V04-REIMU-COERCED-PC-NEXT_TOUCH_REFUSE-A

협박 중 · 몸 주인공쪽 · 다음 만남 · 스킨십 · 거절

{name} 「손 내밀면 잡을까 봐 싫어. 걔한테 미안한 것도 네가 이용하잖아.」 {name}는 가까워지던 손에서 물러섰다.

## V04-REIMU-COERCED-PC-NEXT_KISS_ALLOW-A

협박 중 · 몸 주인공쪽 · 다음 만남 · 키스 · 수락

{name} 「나도 받아 준 건 알아. 그렇다고 걔 이름으로 겁주진 마.」 {name}는 응한 뒤 턱에 힘을 줬다.

## V04-REIMU-COERCED-PC-NEXT_KISS_REFUSE-A

협박 중 · 몸 주인공쪽 · 다음 만남 · 키스 · 거절

{name} 「안 해. 너한테 끌린다고 걔한테 죄책감도 없어진 건 아니야.」 {name}는 기울던 몸을 바로잡았다.

## V04-REIMU-COERCED-PC-LATE_TALK-A

협박 중 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「걔 걱정하는 마음까지 비웃지 마. 너한테 오고 싶었던 나도 싫으니까.」 {name}는 찻잎 통을 거칠게 밀었다.

## V04-REIMU-COERCED-PC-LATE_TALK-B

협박 중 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「걔가 날 믿는다고 했어. 난 네가 그 말로 겁줄까부터 생각했고.」 {name}는 찻잔을 양손 안으로 숨겼다.

## V04-REIMU-COERCED-PC-LATE_TOUCH_ALLOW-A

협박 중 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「……잡고 싶어서 잡았어. 걔한테 보여 주겠단 말은 하지 마.」 {name}는 맞잡은 손을 옷자락 아래로 내렸다.

## V04-REIMU-COERCED-PC-LATE_TOUCH_REFUSE-A

협박 중 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「놓아. 걔한테 미안해서라도 네가 시키는 대로만은 안 해.」 {name}는 이쪽 손가락을 밀어 풀었다.

## V04-REIMU-COERCED-PC-LATE_KISS_ALLOW-A

협박 중 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「이런 건 받아 주면서 걔한테 미안하대. 네가 웃을 만도 하네.」 {name}는 입맞춤 뒤 이를 드러내고 웃었다.

## V04-REIMU-COERCED-PC-LATE_KISS_REFUSE-A

협박 중 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「싫어. {rival}한테 할 사과까지 네가 정하진 마.」 {name}는 가까워진 얼굴을 부적으로 가렸다.


# 이자요이 사쿠야 · v0.4.0

라이벌의 현재 연인 · 자발적 외도 후 · 미발각. 전부 미검토.

## V04-SAKUYA-HATE-UNSET-AFTER-A

싫어함 · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「{rival_call}께 제가 무슨 짓을 한 건지. ……당신 얼굴을 보니 실감이 납니다.」 {name}는 머리띠를 바로 쓰지 못했다.

## V04-SAKUYA-HATE-UNSET-AFTER-B

싫어함 · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「싫어하는 분과 이런 일을 하고 돌아왔다는 말까지, 그분께 드려야 할까요.」 {name}는 풀린 옷깃을 꽉 여몄다.

## V04-SAKUYA-HATE-UNSET-NEXT_TALK-A

싫어함 · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name} 「그분께 미안해하고 있습니다. 당신의 위로를 청한 적은 없습니다.」 {name}는 준비하던 잔을 하나 치웠다.

## V04-SAKUYA-HATE-UNSET-NEXT_TALK-B

싫어함 · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name}는 {rival_call}의 안부를 전하다 잔 받침에 물을 흘렸다.

## V04-SAKUYA-HATE-UNSET-NEXT_TOUCH_ALLOW-A

싫어함 · 몸 미정 · 다음 만남 · 스킨십 · 수락

{name} 「손만 내어 드리겠습니다. 그분께 했던 잘못을 가볍게 여기지는 마십시오.」 {name}는 손목을 곧게 둔 채 기다렸다.

## V04-SAKUYA-HATE-UNSET-NEXT_TOUCH_REFUSE-A

싫어함 · 몸 미정 · 다음 만남 · 스킨십 · 거절

{name} 「삼가 주십시오. {rival_call}께 이미 충분히 못할 짓을 했습니다.」 {name}는 소매를 당겨 손을 감췄다.

## V04-SAKUYA-HATE-UNSET-NEXT_KISS_ALLOW-A

싫어함 · 몸 미정 · 다음 만남 · 키스 · 수락

{name} 「……이 정도로 하시죠. 그분께 더는 거짓말하고 싶지 않습니다.」 {name}는 짧게 응한 뒤 턱을 굳혔다.

## V04-SAKUYA-HATE-UNSET-NEXT_KISS_REFUSE-A

싫어함 · 몸 미정 · 다음 만남 · 키스 · 거절

{name} 「거절하겠습니다. 그분께 죄송한 것과 당신을 받아들이는 건 다른 일입니다.」 {name}는 얼굴 앞에 손끝을 세웠다.

## V04-SAKUYA-HATE-UNSET-LATE_TALK-A

싫어함 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「시간이 지났다고 그분께 덜 죄송해지는 건 아니더군요.」 {name}는 차가운 찻주전자를 들었다 놓았다.

## V04-SAKUYA-HATE-UNSET-LATE_TALK-B

싫어함 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「그분께 죄송한 것을 일로 덮고 있습니다. 바쁘다 말씀드리면 믿으시니까요.」 {name}는 개어 둔 행주를 다시 집었다.

## V04-SAKUYA-HATE-UNSET-LATE_TOUCH_ALLOW-A

싫어함 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「……잠시라면. 이 손으로 그분께 아무렇지 않게 차를 드리는 게 어렵습니다.」 {name}는 잡힌 손을 내려다보며 숨을 골랐다.

## V04-SAKUYA-HATE-UNSET-LATE_TOUCH_REFUSE-A

싫어함 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「손을 거두세요. 그분께 미안해할 줄은 아직 압니다.」 {name}는 팔을 등 뒤로 돌려 고정했다.

## V04-SAKUYA-HATE-UNSET-LATE_KISS_ALLOW-A

싫어함 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「이러고 그분께 돌아가겠지요. ……참으로 염치없는 사람이군요, 저는.」 {name}는 응한 뒤 입가를 손수건으로 눌렀다.

## V04-SAKUYA-HATE-UNSET-LATE_KISS_REFUSE-A

싫어함 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「더는 받아들이지 않겠습니다. 그분을 속이는 일도 지쳤습니다.」 {name}는 반걸음 비켜 시선을 맞췄다.

## V04-SAKUYA-HATE-PC-AFTER-A

싫어함 · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「당신 곁이 편하다는 것이 더 불쾌합니다. 그분께 얼마나 잔인한 일인지 아니까요.」 {name}는 기댔던 어깨를 똑바로 폈다.

## V04-SAKUYA-HATE-PC-AFTER-B

싫어함 · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「{rival_call}께 돌아갈 생각조차 늦었습니다. 당신을 싫어한다면서 말이지요.」 {name}는 앞치마 끈을 팽팽히 당겼다.

## V04-SAKUYA-HATE-PC-NEXT_TALK-A

싫어함 · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name} 「당신을 먼저 찾았군요. 그분을 뵈러 가려던 참인데.」 {name}는 문 앞에서 걸음을 돌려 세웠다.

## V04-SAKUYA-HATE-PC-NEXT_TALK-B

싫어함 · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name}는 이쪽으로 향한 잔을 {rival_call} 이야기 끝에 멀리 밀었다.

## V04-SAKUYA-HATE-PC-NEXT_TOUCH_ALLOW-A

싫어함 · 몸 주인공쪽 · 다음 만남 · 스킨십 · 수락

{name} 「……놓지 못하겠군요. 그분 앞에선 이 손을 숨겼으면서.」 {name}는 손가락을 뻣뻣하게 맞물렸다.

## V04-SAKUYA-HATE-PC-NEXT_TOUCH_REFUSE-A

싫어함 · 몸 주인공쪽 · 다음 만남 · 스킨십 · 거절

{name} 「그만두세요. 당신께 기대면 그분 생각부터 잊게 되어 싫습니다.」 {name}는 손을 거둬 앞치마 주름을 잡았다.

## V04-SAKUYA-HATE-PC-NEXT_KISS_ALLOW-A

싫어함 · 몸 주인공쪽 · 다음 만남 · 키스 · 수락

{name} 「제가 응한 건 사실입니다. 그분께 변명할 여지도 없겠지요.」 {name}는 입맞춤을 마치고 입술을 앙다물었다.

## V04-SAKUYA-HATE-PC-NEXT_KISS_REFUSE-A

싫어함 · 몸 주인공쪽 · 다음 만남 · 키스 · 거절

{name} 「안 됩니다. 또 눈을 감으면 그분께 어떤 낯으로 돌아가겠습니까.」 {name}는 이쪽 턱을 손끝으로 밀었다.

## V04-SAKUYA-HATE-PC-LATE_TALK-A

싫어함 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「그분께 다정한 말씀을 듣고도 당신이 떠올랐습니다. ……불쾌할 정도로.」 {name}는 찻숟가락을 반듯이 맞췄다.

## V04-SAKUYA-HATE-PC-LATE_TALK-B

싫어함 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「그분께는 괜찮다 말씀드려도 목소리가 떨립니다. 당신 곁에선 편안한 게 더 싫군요.」 {name}는 잔을 두 손으로 받쳤다.

## V04-SAKUYA-HATE-PC-LATE_TOUCH_ALLOW-A

싫어함 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「이 손이 편해서 더 죄송합니다. 그분께 드릴 말씀이 아니겠지요.」 {name}는 맞잡은 손에서 힘을 빼지 못했다.

## V04-SAKUYA-HATE-PC-LATE_TOUCH_REFUSE-A

싫어함 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「놓으세요. 그분을 또 잊어 버릴 만큼 편해지고 싶지는 않습니다.」 {name}는 손등으로 이쪽 손을 밀어 올렸다.

## V04-SAKUYA-HATE-PC-LATE_KISS_ALLOW-A

싫어함 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「이 정도로 가까워져도 당신이 싫습니다. 그분께는 그저 제 잘못이겠지만.」 {name}는 응한 뒤 뺨에 손을 댔다.

## V04-SAKUYA-HATE-PC-LATE_KISS_REFUSE-A

싫어함 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「거절합니다. 오늘만큼은 그분 앞에서 제 얼굴을 들고 싶군요.」 {name}는 고개를 젖혀 거리를 지켰다.

## V04-SAKUYA-FRIEND-UNSET-AFTER-A

친구 · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「친구를 만나고 온다고 말씀드렸습니다. 그분께 이런 뜻은 아니었을 텐데요.」 {name}는 단추 구멍을 다시 찾았다.

## V04-SAKUYA-FRIEND-UNSET-AFTER-B

친구 · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「{pc_call}과 차를 마시는 걸 좋아했는데. 그분께 죄송한 자리가 되어 버렸군요.」 {name}는 옷을 개다 손을 멈췄다.

## V04-SAKUYA-FRIEND-UNSET-NEXT_TALK-A

친구 · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name} 「차는 드리겠습니다. 그분 앞에서도 이렇게 평소대로 할 수 있으면 좋겠군요.」 {name}는 잔을 소리 없이 놓았다.

## V04-SAKUYA-FRIEND-UNSET-NEXT_TALK-B

친구 · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name}는 {rival_call}께 내어 드릴 차를 설명하다 용량을 잘못 쟀다.

## V04-SAKUYA-FRIEND-UNSET-NEXT_TOUCH_ALLOW-A

친구 · 몸 미정 · 다음 만남 · 스킨십 · 수락

{name} 「전에는 아무렇지도 않았습니다. 이 손이 그분께 미안해질 줄은 몰랐군요.」 {name}는 손을 맡긴 채 눈을 내렸다.

## V04-SAKUYA-FRIEND-UNSET-NEXT_TOUCH_REFUSE-A

친구 · 몸 미정 · 다음 만남 · 스킨십 · 거절

{name} 「친구라면 거리를 지켜 주십시오. 그분께 더 부끄러워지고 싶지 않습니다.」 {name}는 닿은 손을 조용히 떼어 냈다.

## V04-SAKUYA-FRIEND-UNSET-NEXT_KISS_ALLOW-A

친구 · 몸 미정 · 다음 만남 · 키스 · 수락

{name} 「……친구라고 소개한 그분께는 무슨 말씀을 드려야 할까요.」 {name}는 짧게 응한 뒤 어깨를 낮췄다.

## V04-SAKUYA-FRIEND-UNSET-NEXT_KISS_REFUSE-A

친구 · 몸 미정 · 다음 만남 · 키스 · 거절

{name} 「차라리 차를 드시지요. 그분께 친구라는 말까지 거짓이 되게 하진 말아 주세요.」 {name}는 찻잔을 들어 사이를 막았다.

## V04-SAKUYA-FRIEND-UNSET-LATE_TALK-A

친구 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「그분께서 당신과의 근황을 물으십니다. 요즘은 대답할 말이 적더군요.」 {name}는 찻잎을 오래 우려 뒀다.

## V04-SAKUYA-FRIEND-UNSET-LATE_TALK-B

친구 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「아가씨 이야기만 길게 했습니다. 그분께서 제 하루는 묻지 못하시게요.」 {name}는 차를 다시 따르려다 멈췄다.

## V04-SAKUYA-FRIEND-UNSET-LATE_TOUCH_ALLOW-A

친구 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「손은 이대로 두셔도 됩니다. 그분께 죄송한 마음까지 편해지진 않지만요.」 {name}는 맞잡은 손을 탁자 아래에 내렸다.

## V04-SAKUYA-FRIEND-UNSET-LATE_TOUCH_REFUSE-A

친구 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「이제는 곤란합니다. 그분께 여전히 친구라고 말씀드리고 있으니까요.」 {name}는 의자를 뒤로 빼며 손을 거뒀다.

## V04-SAKUYA-FRIEND-UNSET-LATE_KISS_ALLOW-A

친구 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「친구라는 말로 넘기기엔 그분께 너무 죄송하군요.」 {name}는 입맞춤 뒤 옷깃을 가지런히 눌렀다.

## V04-SAKUYA-FRIEND-UNSET-LATE_KISS_REFUSE-A

친구 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「삼가 주세요. 친분을 핑계로 그분께 더 거짓말할 수는 없습니다.」 {name}는 쟁반을 옆구리에 세웠다.

## V04-SAKUYA-FRIEND-PC-AFTER-A

친구 · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「편한 친구라서라고 생각했습니다. 그분께 죄송할 만큼이었다는 건 몰랐고요.」 {name}는 이쪽 팔에서 손을 내렸다.

## V04-SAKUYA-FRIEND-PC-AFTER-B

친구 · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「그분께 돌아가야 하는데 이 곁을 뜨기 싫었습니다. 친구라 부르면서요.」 {name}는 앞치마를 무릎 위에 폈다.

## V04-SAKUYA-FRIEND-PC-NEXT_TALK-A

친구 · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name} 「마침 뵙고 싶었습니다. ……그분 앞에서도 이렇게 솔직했어야 했겠군요.」 {name}는 이쪽에 향했던 몸을 조금 돌렸다.

## V04-SAKUYA-FRIEND-PC-NEXT_TALK-B

친구 · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name}는 이쪽 자리를 고쳐 놓다 {rival_call}의 잔도 나란히 꺼냈다.

## V04-SAKUYA-FRIEND-PC-NEXT_TOUCH_ALLOW-A

친구 · 몸 주인공쪽 · 다음 만남 · 스킨십 · 수락

{name} 「……익숙해졌군요. 그분께는 아직도 그저 친구라 말씀드리는데.」 {name}는 손을 맞잡아 제 쪽에 두었다.

## V04-SAKUYA-FRIEND-PC-NEXT_TOUCH_REFUSE-A

친구 · 몸 주인공쪽 · 다음 만남 · 스킨십 · 거절

{name} 「손을 놓겠습니다. 당신 옆에서 그분을 잊는 건 너무 편하더군요.」 {name}는 얽힌 손끝을 천천히 폈다.

## V04-SAKUYA-FRIEND-PC-NEXT_KISS_ALLOW-A

친구 · 몸 주인공쪽 · 다음 만남 · 키스 · 수락

{name} 「이것까지 원했나 봅니다. 그분께는 친구라며 안심시켜 놓고.」 {name}는 응한 뒤 입술을 달싹였다.

## V04-SAKUYA-FRIEND-PC-NEXT_KISS_REFUSE-A

친구 · 몸 주인공쪽 · 다음 만남 · 키스 · 거절

{name} 「기습은 곤란합니다. 반길 뻔한 제가 그분께 더 죄송해져서요.」 {name}는 얼굴을 피하며 앞치마를 쥐었다.

## V04-SAKUYA-FRIEND-PC-LATE_TALK-A

친구 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「그분과 대화하다 당신 곁을 떠올립니다. 친구라는 말로는 부족하겠지요.」 {name}는 차를 따르다 잔을 넘겨다봤다.

## V04-SAKUYA-FRIEND-PC-LATE_TALK-B

친구 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「차가 남았다 말했지만 당신 몫을 우렸습니다. 그분께는 이 말도 못 하겠군요.」 {name}는 주전자 안을 내려다봤다.

## V04-SAKUYA-FRIEND-PC-LATE_TOUCH_ALLOW-A

친구 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「이 손을 놓기 싫다는 말을 그분 앞에서는 못 하겠습니다.」 {name}는 손가락 사이를 단단히 채웠다.

## V04-SAKUYA-FRIEND-PC-LATE_TOUCH_REFUSE-A

친구 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「오늘은 그분과 한 약속이 있습니다. 당신 손을 잡고 또 미루고 싶지는 않습니다.」 {name}는 손을 거둬 시계를 확인했다.

## V04-SAKUYA-FRIEND-PC-LATE_KISS_ALLOW-A

친구 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「편해서였다는 말은 못 하겠군요. 그분께 미안해도 또 응했으니.」 {name}는 입맞춤 뒤 이쪽 손등을 한 번 눌렀다.

## V04-SAKUYA-FRIEND-PC-LATE_KISS_REFUSE-A

친구 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「그만두겠습니다. 그분께 사과도 못 한 채 여기 익숙해지기는 싫군요.」 {name}는 가까워지던 얼굴을 손으로 가렸다.

## V04-SAKUYA-SECRET-UNSET-AFTER-A

연인(비밀) · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「당신을 좋아한다는 말로 그분께 용서받을 수는 없겠지요.」 {name}는 앞치마 끈을 묶다 내려놨다.

## V04-SAKUYA-SECRET-UNSET-AFTER-B

연인(비밀) · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「먼저 말씀드렸어야 했습니다. 그분의 연인인 채로 당신과 이러기 전에.」 {name}는 머리띠를 무릎에 놓았다.

## V04-SAKUYA-SECRET-UNSET-NEXT_TALK-A

연인(비밀) · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name} 「{rival_call}께는 아직도 제게 아무 일이 없는 줄 아실 겁니다. ……제가 그렇게 말했으니.」 {name}는 잔을 닦는 천을 접었다.

## V04-SAKUYA-SECRET-UNSET-NEXT_TALK-B

연인(비밀) · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name}는 {rival_call}께 할 인사를 입에 올렸다가 이쪽 앞에서 고개를 숙였다.

## V04-SAKUYA-SECRET-UNSET-NEXT_TOUCH_ALLOW-A

연인(비밀) · 몸 미정 · 다음 만남 · 스킨십 · 수락

{name} 「……이대로 있어 주세요. 그분을 배신한 제가 위로까지 청하는군요.」 {name}는 잡힌 손 위에 다른 손을 올렸다.

## V04-SAKUYA-SECRET-UNSET-NEXT_TOUCH_REFUSE-A

연인(비밀) · 몸 미정 · 다음 만남 · 스킨십 · 거절

{name} 「잠시 혼자 있겠습니다. 그분께 죄송한 것을 당신 손으로 달래긴 어렵군요.」 {name}는 손을 거둬 두 무릎을 덮었다.

## V04-SAKUYA-SECRET-UNSET-NEXT_KISS_ALLOW-A

연인(비밀) · 몸 미정 · 다음 만남 · 키스 · 수락

{name} 「좋아합니다. 그분께도 같은 말씀을 드렸다는 것이 부끄럽군요.」 {name}는 응한 뒤 목소리를 낮게 눌렀다.

## V04-SAKUYA-SECRET-UNSET-NEXT_KISS_REFUSE-A

연인(비밀) · 몸 미정 · 다음 만남 · 키스 · 거절

{name} 「오늘은 어렵겠습니다. 그분께 해야 할 말부터 생각하고 싶습니다.」 {name}는 입술을 닫고 고개를 돌렸다.

## V04-SAKUYA-SECRET-UNSET-LATE_TALK-A

연인(비밀) · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「{rival_call}께서 저를 믿으십니다. 여전히 믿으시게 제가 숨기고 있고요.」 {name}는 은수저에 비친 얼굴을 봤다.

## V04-SAKUYA-SECRET-UNSET-LATE_TALK-B

연인(비밀) · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「두 분께 시간을 나누면 된다고 생각했습니다. 그분의 믿음을 나눌 수는 없는데.」 {name}는 시곗바늘을 오래 봤다.

## V04-SAKUYA-SECRET-UNSET-LATE_TOUCH_ALLOW-A

연인(비밀) · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「이 손을 잡으려면 먼저 그분께 솔직해야 했는데. 늦었지요.」 {name}는 손가락을 맞잡은 채 한숨을 내쉬었다.

## V04-SAKUYA-SECRET-UNSET-LATE_TOUCH_REFUSE-A

연인(비밀) · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「더 가까이 있지는 않겠습니다. 그분께 무엇을 말씀드릴지 정하지도 못했으니까요.」 {name}는 소매를 정돈하며 손을 뺐다.

## V04-SAKUYA-SECRET-UNSET-LATE_KISS_ALLOW-A

연인(비밀) · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「그분께서 모르신다고 이 마음까지 떳떳한 건 아니더군요.」 {name}는 입맞춤 뒤 눈썹을 조금 내렸다.

## V04-SAKUYA-SECRET-UNSET-LATE_KISS_REFUSE-A

연인(비밀) · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「안 됩니다. 사과할 용기도 없으면서 당신께만 기대고 싶지는 않습니다.」 {name}는 다가온 입가를 손끝으로 가렸다.

## V04-SAKUYA-SECRET-PC-AFTER-A

연인(비밀) · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「당신 곁에 더 있고 싶었습니다. 그분께서 기다리시는 줄 알면서도.」 {name}는 이쪽 옷깃을 놓고 자세를 바로 했다.

## V04-SAKUYA-SECRET-PC-AFTER-B

연인(비밀) · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「{rival_call}께 미안하다면서 돌아갈 채비도 늦는군요. 저는.」 {name}는 머리띠를 손에 쥐고 앉아 있었다.

## V04-SAKUYA-SECRET-PC-NEXT_TALK-A

연인(비밀) · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name} 「오셨군요. ……기쁜 얼굴부터 드러났네요. 그분께는 죄송해 놓고.」 {name}는 미소를 거두며 차를 내려놨다.

## V04-SAKUYA-SECRET-PC-NEXT_TALK-B

연인(비밀) · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name}는 이쪽 옆에 놓은 제 잔을 {rival_call}의 이름에 거둬들였다.

## V04-SAKUYA-SECRET-PC-NEXT_TOUCH_ALLOW-A

연인(비밀) · 몸 주인공쪽 · 다음 만남 · 스킨십 · 수락

{name} 「……놓고 싶지 않습니다. 그분께는 얼마나 잔인한 말일까요.」 {name}는 맞잡은 손을 제 볼에 살짝 댔다.

## V04-SAKUYA-SECRET-PC-NEXT_TOUCH_REFUSE-A

연인(비밀) · 몸 주인공쪽 · 다음 만남 · 스킨십 · 거절

{name} 「그 손은 나중에 잡겠습니다. 오늘도 그분을 기다리게 할 수는 없습니다.」 {name}는 손을 피하며 옷소매를 내렸다.

## V04-SAKUYA-SECRET-PC-NEXT_KISS_ALLOW-A

연인(비밀) · 몸 주인공쪽 · 다음 만남 · 키스 · 수락

{name} 「조금 더라고 청할 뻔했습니다. 그분께는 돌아간다 말씀드려 놓고.」 {name}는 응한 뒤 이쪽에 둔 손을 내렸다.

## V04-SAKUYA-SECRET-PC-NEXT_KISS_REFUSE-A

연인(비밀) · 몸 주인공쪽 · 다음 만남 · 키스 · 거절

{name} 「이러면 또 그분을 잊습니다. ……지금은 안 되겠습니다.」 {name}는 눈을 감다 말고 몸을 물렸다.

## V04-SAKUYA-SECRET-PC-LATE_TALK-A

연인(비밀) · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「그분 옆에서도 당신께 기대고 싶었습니다. 그분께서 얼마나 서운하실지 알면서요.」 {name}는 찻숟가락을 잔 옆에 놓았다.

## V04-SAKUYA-SECRET-PC-LATE_TALK-B

연인(비밀) · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「당신께 늦지 않으려고 그분의 말씀을 끊었습니다. 돌아가 사과할 일만 느는군요.」 {name}는 접은 손수건을 다시 폈다.

## V04-SAKUYA-SECRET-PC-LATE_TOUCH_ALLOW-A

연인(비밀) · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「이 손에 안심하는 제가 그분께 부끄럽습니다. 그래도 놓지는 못하겠군요.」 {name}는 손을 잡고 긴장을 풀었다.

## V04-SAKUYA-SECRET-PC-LATE_TOUCH_REFUSE-A

연인(비밀) · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「손을 놓아 주세요. 그분께 돌아가겠다는 말은 지키고 싶습니다.」 {name}는 이쪽 손등을 가볍게 두드렸다.

## V04-SAKUYA-SECRET-PC-LATE_KISS_ALLOW-A

연인(비밀) · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「좋아합니다. 그분께 미안하다는 말만으로 제 욕심이 줄지는 않네요.」 {name}는 입맞춤 뒤 이쪽 어깨에 이마를 기댔다.

## V04-SAKUYA-SECRET-PC-LATE_KISS_REFUSE-A

연인(비밀) · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「오늘은 여기까지입니다. 그분 앞에서 또 당신 생각만 하고 싶지는 않습니다.」 {name}는 거리를 두고 머리띠를 바로 했다.

## V04-SAKUYA-STRANGER-UNSET-AFTER-A

타인 · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「제대로 알지도 못하는 분과…… {rival_call}께 무슨 낯으로 돌아갈까요.」 {name}는 옷을 든 채 숨을 멈췄다.

## V04-SAKUYA-STRANGER-UNSET-AFTER-B

타인 · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「당신께 드릴 인사도 찾지 못하겠군요. 그분께 드릴 사과는 더더욱.」 {name}는 단추를 끝까지 채웠다.

## V04-SAKUYA-STRANGER-UNSET-NEXT_TALK-A

타인 · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name} 「다시 오셨습니까. 그분께 숨긴 일이 먼저 떠오릅니다만.」 {name}는 문을 열어 둔 채 옆에 섰다.

## V04-SAKUYA-STRANGER-UNSET-NEXT_TALK-B

타인 · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name}는 {rival_call} 이야기가 끝날 때까지 빈 쟁반을 내려놓지 못했다.

## V04-SAKUYA-STRANGER-UNSET-NEXT_TOUCH_ALLOW-A

타인 · 몸 미정 · 다음 만남 · 스킨십 · 수락

{name} 「……잠깐 내어 드리지요. 그분께 부끄럽다는 사실은 같겠지만.」 {name}는 손끝만 조심스레 맡겼다.

## V04-SAKUYA-STRANGER-UNSET-NEXT_TOUCH_REFUSE-A

타인 · 몸 미정 · 다음 만남 · 스킨십 · 거절

{name} 「가까이 오지 마십시오. 그분께 죄송한 일을 더 늘릴 생각은 없습니다.」 {name}는 손을 등 뒤에 단정히 모았다.

## V04-SAKUYA-STRANGER-UNSET-NEXT_KISS_ALLOW-A

타인 · 몸 미정 · 다음 만남 · 키스 · 수락

{name} 「이런 사이부터 되어 버렸군요. 그분께 어떻게 설명해야 할지도 모르면서.」 {name}는 응한 뒤 시선을 비껴 뒀다.

## V04-SAKUYA-STRANGER-UNSET-NEXT_KISS_REFUSE-A

타인 · 몸 미정 · 다음 만남 · 키스 · 거절

{name} 「그날과 같은 대답을 기대하지 마세요. 그분께 아직 죄송한 마음은 있습니다.」 {name}는 얼굴을 돌려 한 발 물러났다.

## V04-SAKUYA-STRANGER-UNSET-LATE_TALK-A

타인 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「당신을 알아 가는 일조차 그분께 숨겨야 하겠군요. 이미 숨긴 일이 있으니.」 {name}는 방명록을 덮었다.

## V04-SAKUYA-STRANGER-UNSET-LATE_TALK-B

타인 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「그분께 당신을 소개할 때 무슨 관계라 해야 할까요. 손님이라는 말도 거짓이겠지요.」 {name}는 손님용 잔을 선반 끝에 뒀다.

## V04-SAKUYA-STRANGER-UNSET-LATE_TOUCH_ALLOW-A

타인 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「손을 내어 드리는 일은 작군요. 그분께 숨길 것은 또 하나 생기고요.」 {name}는 맞잡은 손을 탁자 끝에 뒀다.

## V04-SAKUYA-STRANGER-UNSET-LATE_TOUCH_REFUSE-A

타인 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「삼가 주세요. 잘 모르는 당신보다 그분께 미안한 마음이 먼저입니다.」 {name}는 손을 거둬 쟁반을 들었다.

## V04-SAKUYA-STRANGER-UNSET-LATE_KISS_ALLOW-A

타인 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「이렇게 얼굴을 외우는 것도 그분께 잔인한 일이군요.」 {name}는 짧은 입맞춤 뒤 입술을 눌러 다물었다.

## V04-SAKUYA-STRANGER-UNSET-LATE_KISS_REFUSE-A

타인 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「돌아가 주십시오. 그분께 말 못 할 일을 되풀이하고 싶지 않습니다.」 {name}는 고개를 숙여 얼굴을 피했다.

## V04-SAKUYA-STRANGER-PC-AFTER-A

타인 · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「당신 곁에서 편안해했습니다. 그분을 배신한 일도 잊을 만큼.」 {name}는 기대던 몸을 천천히 일으켰다.

## V04-SAKUYA-STRANGER-PC-AFTER-B

타인 · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「이유도 모른 채 더 머물고 싶군요. 그분께는 변명조차 안 되겠습니다.」 {name}는 다 입은 옷의 주름만 폈다.

## V04-SAKUYA-STRANGER-PC-NEXT_TALK-A

타인 · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name} 「오신 걸 보고 안심했군요. 그분께 죄송해하던 것이 무색할 만큼.」 {name}는 문고리를 놓고 눈을 내렸다.

## V04-SAKUYA-STRANGER-PC-NEXT_TALK-B

타인 · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name}는 이쪽 의자를 권하다 {rival_call} 얘기에 손을 등 뒤로 모았다.

## V04-SAKUYA-STRANGER-PC-NEXT_TOUCH_ALLOW-A

타인 · 몸 주인공쪽 · 다음 만남 · 스킨십 · 수락

{name} 「이 손은 낯설지 않습니다. 그분께 말씀드릴 수 없는 익숙함이겠지요.」 {name}는 손바닥을 천천히 맞댔다.

## V04-SAKUYA-STRANGER-PC-NEXT_TOUCH_REFUSE-A

타인 · 몸 주인공쪽 · 다음 만남 · 스킨십 · 거절

{name} 「손은 거두겠습니다. 당신께 익숙해질수록 그분께 더 죄송해집니다.」 {name}는 손끝을 앞치마 안에 감췄다.

## V04-SAKUYA-STRANGER-PC-NEXT_KISS_ALLOW-A

타인 · 몸 주인공쪽 · 다음 만남 · 키스 · 수락

{name} 「……생각보다 쉽게 응했군요. 그분을 뵐 때는 이렇게 눈도 못 감는데.」 {name}는 입맞춤 뒤 눈을 깜빡였다.

## V04-SAKUYA-STRANGER-PC-NEXT_KISS_REFUSE-A

타인 · 몸 주인공쪽 · 다음 만남 · 키스 · 거절

{name} 「가까워지면 또 잊겠군요. 그분을 기다리게 했다는 것을.」 {name}는 이쪽 앞에 손바닥을 조용히 폈다.

## V04-SAKUYA-STRANGER-PC-LATE_TALK-A

타인 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「당신께 차를 내어 드리고 싶어졌습니다. 그분께는 일이라고만 말하겠지요.」 {name}는 찻잎을 덜어내며 입술을 다물었다.

## V04-SAKUYA-STRANGER-PC-LATE_TALK-B

타인 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「당신 발소리에 일이 멈춥니다. 그분께는 늘 바쁘다는 말씀만 드렸는데.」 {name}는 찻숟가락을 쥔 손을 내려놨다.

## V04-SAKUYA-STRANGER-PC-LATE_TOUCH_ALLOW-A

타인 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「……기억하고 있었군요, 손이. 그분 앞에선 감춰야 할 기억인데.」 {name}는 맞잡은 손에 천천히 힘을 줬다.

## V04-SAKUYA-STRANGER-PC-LATE_TOUCH_REFUSE-A

타인 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「당신께 기대는 습관은 들이지 않겠습니다. 그분께 숨길 게 이미 많아서요.」 {name}는 손을 무릎 위로 당겼다.

## V04-SAKUYA-STRANGER-PC-LATE_KISS_ALLOW-A

타인 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「모르는 분이라며 밀어낼 수도 없겠군요. 이렇게 또 응했으니 그분께 더 죄송합니다.」 {name}는 입맞춤 뒤 어깨를 폈다.

## V04-SAKUYA-STRANGER-PC-LATE_KISS_REFUSE-A

타인 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「오늘은 안 됩니다. 그분께 사과보다 익숙함을 먼저 쌓고 싶지는 않습니다.」 {name}는 턱을 돌려 입술을 피했다.

## V04-SAKUYA-CRUSH-UNSET-AFTER-A

짝사랑 · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「좋아한다는 말씀부터 드렸어야 했습니다. 그분께 정리할 말씀이 더 먼저였고요.」 {name}는 머리띠를 쥔 손을 내려놨다.

## V04-SAKUYA-CRUSH-UNSET-AFTER-B

짝사랑 · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「기뻤습니다. 그래서 더 {rival_call}께 죄송하군요.」 {name}는 단정히 여민 옷깃을 만지다 멈췄다.

## V04-SAKUYA-CRUSH-UNSET-NEXT_TALK-A

짝사랑 · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name} 「뵙고 싶었습니다. ……그분께 죄송해 놓고 이런 인사를 드리는군요.」 {name}는 미소 짓다 잔을 내려다봤다.

## V04-SAKUYA-CRUSH-UNSET-NEXT_TALK-B

짝사랑 · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name}는 {rival_call}께 전할 말을 묻자 반듯이 접었던 행주를 다시 폈다.

## V04-SAKUYA-CRUSH-UNSET-NEXT_TOUCH_ALLOW-A

짝사랑 · 몸 미정 · 다음 만남 · 스킨십 · 수락

{name} 「……기쁩니다. 그분께는 도저히 할 수 없는 말이지만요.」 {name}는 손끝을 맞대며 볼을 붉혔다.

## V04-SAKUYA-CRUSH-UNSET-NEXT_TOUCH_REFUSE-A

짝사랑 · 몸 미정 · 다음 만남 · 스킨십 · 거절

{name} 「오늘은 손도 어렵겠군요. 그분께 미안한 것보다 설렘이 앞설 것 같아서.」 {name}는 손을 접어 가슴 앞에 모았다.

## V04-SAKUYA-CRUSH-UNSET-NEXT_KISS_ALLOW-A

짝사랑 · 몸 미정 · 다음 만남 · 키스 · 수락

{name} 「바랐던 일입니다. 그분을 배신하고까지 바란 일은 아니었는데.」 {name}는 응한 뒤 붉어진 뺨을 내렸다.

## V04-SAKUYA-CRUSH-UNSET-NEXT_KISS_REFUSE-A

짝사랑 · 몸 미정 · 다음 만남 · 키스 · 거절

{name} 「안 되겠습니다. 좋아한다는 이유로 그분께 더 잔인해지고 싶지는 않습니다.」 {name}는 눈을 내리깔고 얼굴을 비켰다.

## V04-SAKUYA-CRUSH-UNSET-LATE_TALK-A

짝사랑 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「당신의 방문을 기다립니다. 그분께서 저를 기다리실 때에도요.」 {name}는 문 쪽에 놓은 잔을 안으로 옮겼다.

## V04-SAKUYA-CRUSH-UNSET-LATE_TALK-B

짝사랑 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「그분께 드릴 차를 고르다가 당신 취향을 골랐습니다. 손이 먼저 움직였군요.」 {name}는 찻잎 통을 원래 자리에 돌렸다.

## V04-SAKUYA-CRUSH-UNSET-LATE_TOUCH_ALLOW-A

짝사랑 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「손 하나에 기뻐하는군요. 그분께 미안하다며 고민하던 제가.」 {name}는 맞잡은 손 위로 눈을 내렸다.

## V04-SAKUYA-CRUSH-UNSET-LATE_TOUCH_REFUSE-A

짝사랑 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「다가오지 마세요. 반길 것이 뻔해서 그분께 더 부끄럽습니다.」 {name}는 손을 뒤로 모으며 한 발 뺐다.

## V04-SAKUYA-CRUSH-UNSET-LATE_KISS_ALLOW-A

짝사랑 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「좋아합니다. 그분께 죄송하다는 말 뒤에 숨길 수는 없겠군요.」 {name}는 입맞춤 뒤 이쪽 소매를 살짝 잡았다.

## V04-SAKUYA-CRUSH-UNSET-LATE_KISS_REFUSE-A

짝사랑 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「오늘은 받아들이지 않겠습니다. 그분께 솔직할 용기부터 내야겠지요.」 {name}는 입술을 가리고 눈을 맞췄다.

## V04-SAKUYA-CRUSH-PC-AFTER-A

짝사랑 · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「당신께 기대고 싶었습니다. 그분께서 기다리셔도 움직이기 싫을 만큼.」 {name}는 이쪽에 얹었던 손을 무릎에 뒀다.

## V04-SAKUYA-CRUSH-PC-AFTER-B

짝사랑 · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「조금 더 있으라 하시면 남았을 겁니다. 그분께는 얼마나 잔인한 고백일까요.」 {name}는 앞치마를 묶지 못한 채 접었다.

## V04-SAKUYA-CRUSH-PC-NEXT_TALK-A

짝사랑 · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name} 「……반가워서 먼저 다가왔군요. 그분께 미안하다고 생각하던 중이었는데.」 {name}는 걸음을 멈추고 볼을 만졌다.

## V04-SAKUYA-CRUSH-PC-NEXT_TALK-B

짝사랑 · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name}는 이쪽에 차를 권하며 웃다 {rival_call}의 이름에 잔을 내려다봤다.

## V04-SAKUYA-CRUSH-PC-NEXT_TOUCH_ALLOW-A

짝사랑 · 몸 주인공쪽 · 다음 만남 · 스킨십 · 수락

{name} 「잡아 주시면 기쁩니다. 그분께 죄송한 마음보다 먼저 드는 감정이네요.」 {name}는 손바닥을 펴 이쪽 손을 받았다.

## V04-SAKUYA-CRUSH-PC-NEXT_TOUCH_REFUSE-A

짝사랑 · 몸 주인공쪽 · 다음 만남 · 스킨십 · 거절

{name} 「이 손을 잡으면 또 못 가겠습니다. 오늘은 그분과 약속했으니까요.」 {name}는 손을 거둬 제 손목을 감쌌다.

## V04-SAKUYA-CRUSH-PC-NEXT_KISS_ALLOW-A

짝사랑 · 몸 주인공쪽 · 다음 만남 · 키스 · 수락

{name} 「한 번 더 청하고 싶군요. ……그분께는 미안하다 말씀도 못 하면서.」 {name}는 응한 뒤 손으로 붉어진 귀를 가렸다.

## V04-SAKUYA-CRUSH-PC-NEXT_KISS_REFUSE-A

짝사랑 · 몸 주인공쪽 · 다음 만남 · 키스 · 거절

{name} 「그만해 주세요. 그분께 돌아가야 한다는 걸 잊을 것 같습니다.」 {name}는 가까워진 이마를 조용히 밀었다.

## V04-SAKUYA-CRUSH-PC-LATE_TALK-A

짝사랑 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「그분 옆에서도 당신 손이 생각났습니다. 얼굴을 못 들겠더군요.」 {name}는 손가락 마디를 하나씩 문질렀다.

## V04-SAKUYA-CRUSH-PC-LATE_TALK-B

짝사랑 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「당신 뵐 시간을 만들려고 그분께 늦는다고 했습니다. 사과보다 핑계가 빠르네요.」 {name}는 시계 덮개를 닫았다.

## V04-SAKUYA-CRUSH-PC-LATE_TOUCH_ALLOW-A

짝사랑 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「좋습니다. 손 하나 놓지 못하면서 그분께 미안해하기만 하는 제가 싫고요.」 {name}는 이쪽 손을 두 손으로 감쌌다.

## V04-SAKUYA-CRUSH-PC-LATE_TOUCH_REFUSE-A

짝사랑 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「잡지 말아 주세요. 오늘은 그분께 일찍 돌아가겠다고 했습니다.」 {name}는 손을 들어 머리띠만 고쳤다.

## V04-SAKUYA-CRUSH-PC-LATE_KISS_ALLOW-A

짝사랑 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「이렇게 좋은 것을 그분께는 끝내 숨기는군요. 제가 너무 비겁합니다.」 {name}는 입맞춤 뒤 이쪽 팔에 이마를 댔다.

## V04-SAKUYA-CRUSH-PC-LATE_KISS_REFUSE-A

짝사랑 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「안 되겠습니다. 당신을 기다리며 그분을 기다리게 하는 일은 줄이고 싶습니다.」 {name}는 의자를 뒤로 물려 앉았다.

## V04-SAKUYA-SUBMIT-UNSET-AFTER-A

굴복 · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「{rival_call}께 말씀드릴지는 맡기겠습니다. 제가 먼저 죄송하다 말할 염치도 없군요.」 {name}는 옷매무새를 기계적으로 가다듬었다.

## V04-SAKUYA-SUBMIT-UNSET-AFTER-B

굴복 · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「그분께 아무 일 없었다고 하겠지요. ……제가 제 입으로요.」 {name}는 머리띠를 두 번 고쳐 썼다.

## V04-SAKUYA-SUBMIT-UNSET-NEXT_TALK-A

굴복 · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name} 「그분은 잘못이 없으십니다. 제게 다정하셨다는 것 외에는.」 {name}는 빈 잔을 오래 내려다봤다.

## V04-SAKUYA-SUBMIT-UNSET-NEXT_TALK-B

굴복 · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name}는 {rival_call}께서 걱정하셨다는 말에 앞치마 끝만 세웠다.

## V04-SAKUYA-SUBMIT-UNSET-NEXT_TOUCH_ALLOW-A

굴복 · 몸 미정 · 다음 만남 · 스킨십 · 수락

{name} 「……손은 내어 드리겠습니다. 그분 앞에서는 이 손을 접어 두고요.」 {name}는 펼친 손을 움직이지 않았다.

## V04-SAKUYA-SUBMIT-UNSET-NEXT_TOUCH_REFUSE-A

굴복 · 몸 미정 · 다음 만남 · 스킨십 · 거절

{name} 「오늘은 거두겠습니다. 그분께 미안한 마음만이라도 혼자 두고 싶군요.」 {name}는 손을 가져와 무릎 위에 포갰다.

## V04-SAKUYA-SUBMIT-UNSET-NEXT_KISS_ALLOW-A

굴복 · 몸 미정 · 다음 만남 · 키스 · 수락

{name} 「그분께 말씀드리는 것보다 이쪽이 쉽군요. 참으로 비겁하게도.」 {name}는 응한 뒤 눈을 오래 내리깔았다.

## V04-SAKUYA-SUBMIT-UNSET-NEXT_KISS_REFUSE-A

굴복 · 몸 미정 · 다음 만남 · 키스 · 거절

{name} 「죄송하지만 못 하겠습니다. 그분의 얼굴이 자꾸 떠오릅니다.」 {name}는 입술을 깨물고 고개를 내렸다.

## V04-SAKUYA-SUBMIT-UNSET-LATE_TALK-A

굴복 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「그분께서 제 걱정을 하십니다. 저는 괜찮다는 대답만 잘하게 되었고요.」 {name}는 차를 따르지 않은 잔을 돌려놨다.

## V04-SAKUYA-SUBMIT-UNSET-LATE_TALK-B

굴복 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「그분 앞에선 평소처럼 일합니다. 차만 내어 드리면 제 얼굴은 덜 보시니까요.」 {name}는 빈 쟁반으로 앞을 가렸다.

## V04-SAKUYA-SUBMIT-UNSET-LATE_TOUCH_ALLOW-A

굴복 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「따뜻하군요. 그분께 미안하다며 이 손에 안심하고 있습니다.」 {name}는 손을 맡긴 채 어깨를 내렸다.

## V04-SAKUYA-SUBMIT-UNSET-LATE_TOUCH_REFUSE-A

굴복 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「잠시 놓아 주세요. 그분께 내밀 손마저 낯설어졌습니다.」 {name}는 굽힌 손가락을 가슴 쪽으로 당겼다.

## V04-SAKUYA-SUBMIT-UNSET-LATE_KISS_ALLOW-A

굴복 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「……이런 대답만 익숙해지는군요. 그분께는 사과도 못 드리는데.」 {name}는 응한 뒤 앞치마 끝을 세게 쥐었다.

## V04-SAKUYA-SUBMIT-UNSET-LATE_KISS_REFUSE-A

굴복 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「오늘은 안 됩니다. 그분께 미안해하는 것마저 잊고 싶지는 않습니다.」 {name}는 다가온 얼굴 아래로 시선을 떨궜다.

## V04-SAKUYA-SUBMIT-PC-AFTER-A

굴복 · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「그분께 죄송하다 생각하면서도 당신 곁을 못 떴군요.」 {name}는 이쪽 어깨에서 천천히 일어났다.

## V04-SAKUYA-SUBMIT-PC-AFTER-B

굴복 · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「돌아가야 한다는 말씀보다 더 있으라는 말을 기다렸습니다. 그분께 못할 짓이지요.」 {name}는 입고 남은 끈을 접었다.

## V04-SAKUYA-SUBMIT-PC-NEXT_TALK-A

굴복 · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name} 「부르실까 해서 왔습니다. 그분께선 돌아오길 기다리실 텐데.」 {name}는 문간에서 앞치마를 바로 폈다.

## V04-SAKUYA-SUBMIT-PC-NEXT_TALK-B

굴복 · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name}는 이쪽 손을 찾다 {rival_call}의 이름을 듣고 손등을 감췄다.

## V04-SAKUYA-SUBMIT-PC-NEXT_TOUCH_ALLOW-A

굴복 · 몸 주인공쪽 · 다음 만남 · 스킨십 · 수락

{name} 「……손부터 내밀었군요. 그분 앞에선 숨기던 제가.」 {name}는 먼저 잡은 손을 내려다봤다.

## V04-SAKUYA-SUBMIT-PC-NEXT_TOUCH_REFUSE-A

굴복 · 몸 주인공쪽 · 다음 만남 · 스킨십 · 거절

{name} 「놓겠습니다. 그분께 돌아갈 마음을 남겨 두고 싶어서요.」 {name}는 손을 빼 앞치마 안으로 모았다.

## V04-SAKUYA-SUBMIT-PC-NEXT_KISS_ALLOW-A

굴복 · 몸 주인공쪽 · 다음 만남 · 키스 · 수락

{name} 「그분께 죄송해하던 중에도 당신이 오시니 눈을 감는군요.」 {name}는 응한 뒤 작은 숨을 내쉬었다.

## V04-SAKUYA-SUBMIT-PC-NEXT_KISS_REFUSE-A

굴복 · 몸 주인공쪽 · 다음 만남 · 키스 · 거절

{name} 「잠시만 그만해 주세요. 그분 생각을 할 때도 필요합니다.」 {name}는 이쪽 옷깃을 밀어 거리를 뒀다.

## V04-SAKUYA-SUBMIT-PC-LATE_TALK-A

굴복 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「그분께는 일이 남았다고 합니다. 당신 곁에서 아무 일도 하지 않으면서요.」 {name}는 빈 쟁반 위에 손을 얹었다.

## V04-SAKUYA-SUBMIT-PC-LATE_TALK-B

굴복 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「당신께서 부르실까 일까지 서둘렀습니다. 그분께는 기다려 달라 말씀드렸는데.」 {name}는 앞치마의 접힌 선을 눌렀다.

## V04-SAKUYA-SUBMIT-PC-LATE_TOUCH_ALLOW-A

굴복 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「이 손을 잡고 싶습니다. 그분께 죄송해하는 마음은 그다음이 되고요.」 {name}는 이쪽 손을 가져와 무릎에 눕혔다.

## V04-SAKUYA-SUBMIT-PC-LATE_TOUCH_REFUSE-A

굴복 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「오늘은 잡지 않겠습니다. 그분께 했던 약속은 하나라도 지키고 싶군요.」 {name}는 내밀려던 손을 반듯이 접었다.

## V04-SAKUYA-SUBMIT-PC-LATE_KISS_ALLOW-A

굴복 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「제가 원해서 응했습니다. 그분께 미안하다는 말로 덮을 수는 없겠지요.」 {name}는 입맞춤 뒤 한동안 눈을 감고 있었다.

## V04-SAKUYA-SUBMIT-PC-LATE_KISS_REFUSE-A

굴복 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「이제 돌아가겠습니다. 그분께 기다려 달라는 말도 부끄러워져서요.」 {name}는 가까워지던 얼굴에서 몸을 일으켰다.

## V04-SAKUYA-COERCED-UNSET-AFTER-A

협박 중 · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「그분께 잘못한 것은 저입니다. 그 사실로 절 부리셔도 된다는 뜻은 아닙니다.」 {name}는 옷깃을 빈틈없이 여몄다.

## V04-SAKUYA-COERCED-UNSET-AFTER-B

협박 중 · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「{rival_call}께 말씀하시겠다는 위협은 알아들었습니다. 더 확인하지 않으셔도 됩니다.」 {name}는 머리띠를 쥔 손을 굳혔다.

## V04-SAKUYA-COERCED-UNSET-NEXT_TALK-A

협박 중 · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name} 「그분의 이름을 그렇게 쓰지 마세요. 제가 죄송해야 할 분입니다.」 {name}는 찻잔을 소리 내어 치웠다.

## V04-SAKUYA-COERCED-UNSET-NEXT_TALK-B

협박 중 · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name}는 {rival_call}의 이름 뒤에 붙은 위협을 듣고 입술을 하얗게 다물었다.

## V04-SAKUYA-COERCED-UNSET-NEXT_TOUCH_ALLOW-A

협박 중 · 몸 미정 · 다음 만남 · 스킨십 · 수락

{name} 「……손만 내어 드립니다. 그분께 숨겨 준다는 말씀은 그만하시죠.」 {name}는 팔꿈치를 굳힌 채 손을 뒀다.

## V04-SAKUYA-COERCED-UNSET-NEXT_TOUCH_REFUSE-A

협박 중 · 몸 미정 · 다음 만남 · 스킨십 · 거절

{name} 「그만두십시오. 그분께 죄송하다고 모든 접촉을 참지는 않겠습니다.」 {name}는 이쪽 손목을 잡아 떼어 냈다.

## V04-SAKUYA-COERCED-UNSET-NEXT_KISS_ALLOW-A

협박 중 · 몸 미정 · 다음 만남 · 키스 · 수락

{name} 「여기까지입니다. 그분께 또 무엇을 말씀하실 수 있는지 듣고 싶지는 않군요.」 {name}는 짧게 응하고 입술을 다물었다.

## V04-SAKUYA-COERCED-UNSET-NEXT_KISS_REFUSE-A

협박 중 · 몸 미정 · 다음 만남 · 키스 · 거절

{name} 「거절합니다. 그분께 드려야 할 사과로 절 몰아세우진 마세요.」 {name}는 얼굴을 비켜 손을 등 뒤로 모았다.

## V04-SAKUYA-COERCED-UNSET-LATE_TALK-A

협박 중 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「제 잘못을 숨기려다 그분께 거짓말만 더합니다. 당신은 그걸 알고 계시겠지요.」 {name}는 접던 천을 꽉 움켜쥐었다.

## V04-SAKUYA-COERCED-UNSET-LATE_TALK-B

협박 중 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「그분께 사과할 말도 고르지 못했습니다. 당신께 부탁할 말만 늘었고요.」 {name}는 쟁반을 내려놓고 입술을 눌렀다.

## V04-SAKUYA-COERCED-UNSET-LATE_TOUCH_ALLOW-A

협박 중 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「잠시라면 내어 드리지요. 그분께 떳떳해지는 일은 하나도 없습니다만.」 {name}는 손을 펴고 시선을 고정했다.

## V04-SAKUYA-COERCED-UNSET-LATE_TOUCH_REFUSE-A

협박 중 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「손을 거두세요. 그분께 잘못한 대가를 당신께 치를 이유는 없습니다.」 {name}는 이쪽 손등을 단단히 눌러 밀었다.

## V04-SAKUYA-COERCED-UNSET-LATE_KISS_ALLOW-A

협박 중 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「응했으니 충분하시겠지요. 그분께 숨길 것이 늘어난 건 제 몫이고요.」 {name}는 입맞춤 뒤 목덜미를 곧게 세웠다.

## V04-SAKUYA-COERCED-UNSET-LATE_KISS_REFUSE-A

협박 중 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「안 됩니다. 그분께 말씀하신다 해도 제 대답은 같습니다.」 {name}는 손끝 하나로 입가를 가로막았다.

## V04-SAKUYA-COERCED-PC-AFTER-A

협박 중 · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「당신께 기대었다고 협박까지 반길 리 없습니다. 그분께 죄송한 것도 그대로고요.」 {name}는 이쪽 팔을 밀어 몸을 세웠다.

## V04-SAKUYA-COERCED-PC-AFTER-B

협박 중 · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「{rival_call}께 미안해도 당신 곁이 편했습니다. 그걸 약점 삼으시겠지요.」 {name}는 앞치마 끈을 두 번 감았다.

## V04-SAKUYA-COERCED-PC-NEXT_TALK-A

협박 중 · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name} 「오고 싶어 왔습니다. 그분께 들키리라 겁주셔서 오고 싶었던 것은 아닙니다.」 {name}는 문을 닫고 이쪽을 똑바로 봤다.

## V04-SAKUYA-COERCED-PC-NEXT_TALK-B

협박 중 · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name}는 이쪽 곁에 선 채 {rival_call}께 돌아갈 시각만 세 번 확인했다.

## V04-SAKUYA-COERCED-PC-NEXT_TOUCH_ALLOW-A

협박 중 · 몸 주인공쪽 · 다음 만남 · 스킨십 · 수락

{name} 「손은 잡고 싶습니다. 그분께 이것을 말씀하겠다는 위협은 듣고 싶지 않고요.」 {name}는 손을 맞잡되 몸은 세웠다.

## V04-SAKUYA-COERCED-PC-NEXT_TOUCH_REFUSE-A

협박 중 · 몸 주인공쪽 · 다음 만남 · 스킨십 · 거절

{name} 「잡지 않겠습니다. 그분께 미안한 마음을 당신이 이용하고 계시니까요.」 {name}는 손끝을 앞치마에 눌렀다.

## V04-SAKUYA-COERCED-PC-NEXT_KISS_ALLOW-A

협박 중 · 몸 주인공쪽 · 다음 만남 · 키스 · 수락

{name} 「제가 응한 일로 그분께 다시 겁주지는 마십시오.」 {name}는 입맞춤을 마친 뒤 표정을 가다듬었다.

## V04-SAKUYA-COERCED-PC-NEXT_KISS_REFUSE-A

협박 중 · 몸 주인공쪽 · 다음 만남 · 키스 · 거절

{name} 「그만두세요. 끌린다고 해서 그분을 빌미로 삼는 말씀까지 받아들이진 않습니다.」 {name}는 다가온 얼굴을 손등으로 막았다.

## V04-SAKUYA-COERCED-PC-LATE_TALK-A

협박 중 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「그분께 미안하다는 말에 질투냐고 하셨지요. 웃을 수 있는 말씀이 아닙니다.」 {name}는 찻주전자 손잡이에서 힘을 뺐다.

## V04-SAKUYA-COERCED-PC-LATE_TALK-B

협박 중 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「그분께 당신 편을 들었습니다. 위협을 받는다는 말씀조차 제 잘못을 밝혀야 가능하더군요.」 {name}는 찻잔 손잡이를 반대쪽으로 돌렸다.

## V04-SAKUYA-COERCED-PC-LATE_TOUCH_ALLOW-A

협박 중 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「이 손은 원합니다. 그분께 죄송해하는 모습으로 저를 조롱하지는 말아 주세요.」 {name}는 맞잡은 손을 낮게 뒀다.

## V04-SAKUYA-COERCED-PC-LATE_TOUCH_REFUSE-A

협박 중 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「놓아 주세요. 그분께 미안하다면 오늘은 제 발로 돌아가야겠지요.」 {name}는 이쪽 손가락을 차례로 풀었다.

## V04-SAKUYA-COERCED-PC-LATE_KISS_ALLOW-A

협박 중 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「……잠깐 안심했군요. 그분께 숨길 일이 또 생겼다는 것도 잊고.」 {name}는 응한 뒤 눈을 천천히 떴다.

## V04-SAKUYA-COERCED-PC-LATE_KISS_REFUSE-A

협박 중 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「안 되겠습니다. 그분께 드릴 사과까지 당신께 허락받지는 않을 겁니다.」 {name}는 턱을 비켜 시선을 고정했다.


# 키리사메 마리사 · v0.4.0

라이벌의 현재 연인 · 자발적 외도 후 · 미발각. 전부 미검토.

## V04-MARISA-HATE-UNSET-AFTER-A

싫어함 · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「……최악이네. 너도 싫고, {rival}한테 이러는 나도 싫고.」 {name}는 모자를 집어 얼굴을 가렸다.

## V04-MARISA-HATE-UNSET-AFTER-B

싫어함 · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「걔한테 들키지만 않으면 돼? 그걸 말이라고 하냐.」 {name}는 옷 주름을 손바닥으로 세게 눌렀다.

## V04-MARISA-HATE-UNSET-NEXT_TALK-A

싫어함 · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name} 「{rival} 얘기하면서 웃지 마. 너랑 웃을 만큼 안 미안한 건 아니야.」 {name}는 모자 챙을 낮췄다.

## V04-MARISA-HATE-UNSET-NEXT_TALK-B

싫어함 · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name}는 {rival}의 이름에 멈칫하고 모자로 웃는 입을 가렸다.

## V04-MARISA-HATE-UNSET-NEXT_TOUCH_ALLOW-A

싫어함 · 몸 미정 · 다음 만남 · 스킨십 · 수락

{name} 「……손만이다. 걔한테 더 미안할 일 만들지 마.」 {name}는 손을 맡긴 채 눈을 가늘게 떴다.

## V04-MARISA-HATE-UNSET-NEXT_TOUCH_REFUSE-A

싫어함 · 몸 미정 · 다음 만남 · 스킨십 · 거절

{name} 「어이쿠 같은 소리도 안 나와. 걔한테 미안하니까 치워.」 {name}는 손등으로 이쪽 손을 쳐냈다.

## V04-MARISA-HATE-UNSET-NEXT_KISS_ALLOW-A

싫어함 · 몸 미정 · 다음 만남 · 키스 · 수락

{name} 「……받아 줬으니까 됐지? 걔한텐 이게 얼마나 못된 짓인지나 알아?」 {name}는 짧게 응한 뒤 모자를 고쳐 썼다.

## V04-MARISA-HATE-UNSET-NEXT_KISS_REFUSE-A

싫어함 · 몸 미정 · 다음 만남 · 키스 · 거절

{name} 「웃기지 마. {rival} 얼굴 생각하면 난 못 해.」 {name}는 모자 챙으로 다가온 얼굴을 막았다.

## V04-MARISA-HATE-UNSET-LATE_TALK-A

싫어함 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「걔가 나더러 괜찮냐더라. 너한테 와서 이 꼴인데도.」 {name}는 마른 웃음을 짧게 뱉었다.

## V04-MARISA-HATE-UNSET-LATE_TALK-B

싫어함 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「걔가 웃으면 그날 거짓말이 생각나. 넌 그걸 웃긴 얘기처럼 꺼내고.」 {name}는 모자 끈을 길게 늘어뜨렸다.

## V04-MARISA-HATE-UNSET-LATE_TOUCH_ALLOW-A

싫어함 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「……그래, 잡아. 이러고 걔한텐 멀쩡한 척할 내가 더 웃겨.」 {name}는 잡힌 손의 마디를 굽혔다.

## V04-MARISA-HATE-UNSET-LATE_TOUCH_REFUSE-A

싫어함 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「{rival}한테 못 할 짓 한 번 더 쌓으라고? 됐어.」 {name}는 손을 주머니 깊이 넣었다.

## V04-MARISA-HATE-UNSET-LATE_KISS_ALLOW-A

싫어함 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「이러고도 걔한텐 사랑한댄다, 내가. ……참 잘났어.」 {name}는 응한 뒤 씁쓸하게 입꼬리를 비틀었다.

## V04-MARISA-HATE-UNSET-LATE_KISS_REFUSE-A

싫어함 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「싫다니까. 걔한테 말 못 하는 거랑 네가 싫은 건 별개야.」 {name}는 이쪽 이마를 손가락으로 밀었다.

## V04-MARISA-HATE-PC-AFTER-A

싫어함 · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「너 싫다니까 왜 안 떨어져지냐. {rival}한테 더럽게 미안하네.」 {name}는 이쪽 팔에서 모자를 떼어 냈다.

## V04-MARISA-HATE-PC-AFTER-B

싫어함 · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「걔한테 가야 하는데 여기 누워 있었네. 나도 진짜 답 없다.」 {name}는 모자를 쓴 채 한동안 앉아 있었다.

## V04-MARISA-HATE-PC-NEXT_TALK-A

싫어함 · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name} 「네가 왔다고 웃을 뻔했어. {rival}한테는 미안해서 웃지도 못하면서.」 {name}는 입가를 손등으로 훔쳤다.

## V04-MARISA-HATE-PC-NEXT_TALK-B

싫어함 · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name}는 이쪽으로 향하던 빗자루를 {rival} 얘기에 벽 쪽으로 돌렸다.

## V04-MARISA-HATE-PC-NEXT_TOUCH_ALLOW-A

싫어함 · 몸 주인공쪽 · 다음 만남 · 스킨십 · 수락

{name} 「……이 손이 편한 게 짜증 나. 걔한테 미안하단 말도 싸져 버리잖아.」 {name}는 맞잡은 손을 거칠게 내렸다.

## V04-MARISA-HATE-PC-NEXT_TOUCH_REFUSE-A

싫어함 · 몸 주인공쪽 · 다음 만남 · 스킨십 · 거절

{name} 「또 네 옆에 붙게 만들지 마. {rival}한테 그 짓은 더 싫어.」 {name}는 내밀던 손을 허리에 얹었다.

## V04-MARISA-HATE-PC-NEXT_KISS_ALLOW-A

싫어함 · 몸 주인공쪽 · 다음 만남 · 키스 · 수락

{name} 「네가 좋은 거랑은 다르다. ……걔한텐 똑같은 배신이겠지만.」 {name}는 응한 뒤 모자로 입가를 눌렀다.

## V04-MARISA-HATE-PC-NEXT_KISS_REFUSE-A

싫어함 · 몸 주인공쪽 · 다음 만남 · 키스 · 거절

{name} 「싫어. 네 얼굴 보면 또 눈 감을까 봐 더 싫어. 걔한테 미안하니까.」 {name}는 모자를 사이에 끼웠다.

## V04-MARISA-HATE-PC-LATE_TALK-A

싫어함 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「{rival} 옆에 있다가 네 손 생각이 났어. 내가 왜 이러냐, 정말.」 {name}는 손바닥을 바지에 문질렀다.

## V04-MARISA-HATE-PC-LATE_TALK-B

싫어함 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「걔 앞에선 모자 챙만 봐. 여기선 네 얼굴 자꾸 보고. 내가 왜 이럴까.」 {name}는 모자를 눈높이까지 들었다.

## V04-MARISA-HATE-PC-LATE_TOUCH_ALLOW-A

싫어함 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「손은 안 놓네, 나. {rival}한테 미안하다면서 말이야.」 {name}는 엇갈린 손가락을 꽉 쥐었다.

## V04-MARISA-HATE-PC-LATE_TOUCH_REFUSE-A

싫어함 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「편해지려고 네 손 잡으면 걔한텐 뭐가 되냐. 오늘은 됐어.」 {name}는 손이 닿기 전에 주먹을 쥐었다.

## V04-MARISA-HATE-PC-LATE_KISS_ALLOW-A

싫어함 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「……헤헤도 안 나오네. 걔한테 돌아갈 거면서 또 이랬어.」 {name}는 입맞춤 뒤 모자 안쪽만 봤다.

## V04-MARISA-HATE-PC-LATE_KISS_REFUSE-A

싫어함 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「그만. 오늘은 걔 얼굴 제대로 보고 싶어.」 {name}는 이쪽 어깨를 밀어 세웠다.

## V04-MARISA-FRIEND-UNSET-AFTER-A

친구 · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「친구끼리 사고 좀 쳤다고 넘기냐? {rival}한테는 그게 아니잖아.」 {name}는 벗은 모자를 두 손으로 구겼다.

## V04-MARISA-FRIEND-UNSET-AFTER-B

친구 · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「헤헤…… 같이 놀다 온다고 했는데. 걔한테 말 못 할 짓 하고 왔네.」 {name}는 웃다 말고 옷을 여몄다.

## V04-MARISA-FRIEND-UNSET-NEXT_TALK-A

친구 · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name} 「버섯 얘기나 할까. ……이런 식으로 덮으면 걔한테 더 미안한가.」 {name}는 봉지 입구를 잘못 묶었다.

## V04-MARISA-FRIEND-UNSET-NEXT_TALK-B

친구 · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name}는 {rival}에게 들려주려던 버섯 얘기를 하다 모자 끈만 감았다.

## V04-MARISA-FRIEND-UNSET-NEXT_TOUCH_ALLOW-A

친구 · 몸 미정 · 다음 만남 · 스킨십 · 수락

{name} 「전엔 잡아도 별생각 없었는데. 걔한테 찔릴 줄이야.」 {name}는 손을 잡은 채 시선을 굴렸다.

## V04-MARISA-FRIEND-UNSET-NEXT_TOUCH_REFUSE-A

친구 · 몸 미정 · 다음 만남 · 스킨십 · 거절

{name} 「어이쿠, 거기까지만. 걔한테 친구라고 말한 게 미안해져서.」 {name}는 손을 쏙 빼 등 뒤로 돌렸다.

## V04-MARISA-FRIEND-UNSET-NEXT_KISS_ALLOW-A

친구 · 몸 미정 · 다음 만남 · 키스 · 수락

{name} 「……친구치곤 너무 갔지. 걔한테는 처음부터 그랬고.」 {name}는 응한 뒤 제 모자 챙을 튕겼다.

## V04-MARISA-FRIEND-UNSET-NEXT_KISS_REFUSE-A

친구 · 몸 미정 · 다음 만남 · 키스 · 거절

{name} 「친구면 말 좀 들어 줘. {rival}한테 더 미안해지긴 싫어.」 {name}는 손바닥을 세워 얼굴 사이를 막았다.

## V04-MARISA-FRIEND-UNSET-LATE_TALK-A

친구 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「걔가 너랑 잘 놀았냐고 물어. 이젠 그 말이 제일 힘들어.」 {name}는 빗자루 손잡이를 꼭 끌어안았다.

## V04-MARISA-FRIEND-UNSET-LATE_TALK-B

친구 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「버섯 얘길 잔뜩 했어. 걔가 다른 건 못 묻게. 참 잘 떠들더라, 나.」 {name}는 봉지를 묶던 끈을 놓쳤다.

## V04-MARISA-FRIEND-UNSET-LATE_TOUCH_ALLOW-A

친구 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「……잡고는 있을게. 걔가 보면 친구란 말부터 못 믿겠지만.」 {name}는 손을 제 무릎 옆에 놓았다.

## V04-MARISA-FRIEND-UNSET-LATE_TOUCH_REFUSE-A

친구 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「{rival}한테 친구라면서 또 붙어 다니긴 좀 그렇잖아.」 {name}는 의자를 반 바퀴 돌렸다.

## V04-MARISA-FRIEND-UNSET-LATE_KISS_ALLOW-A

친구 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「이거까지 장난이라곤 못 하겠다. 걔한테 미안해서.」 {name}는 응한 뒤 쓴웃음을 지었다.

## V04-MARISA-FRIEND-UNSET-LATE_KISS_REFUSE-A

친구 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「그날도 장난으로 시작했지. 걔한테 더 못할 짓 하긴 싫어.」 {name}는 모자를 고쳐 쓰며 얼굴을 뺐다.

## V04-MARISA-FRIEND-PC-AFTER-A

친구 · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「네 옆이 편하다고 막 이래도 되는 건 아닌데. {rival}한테는.」 {name}는 기대던 팔꿈치를 뗐다.

## V04-MARISA-FRIEND-PC-AFTER-B

친구 · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「친구 좋아하듯 좋아하는 줄 알았어. 걔한테 들킬까 걱정할 만큼이네.」 {name}는 흩어진 옷을 한 벌씩 주웠다.

## V04-MARISA-FRIEND-PC-NEXT_TALK-A

친구 · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name} 「헤헤, 왔냐. ……또 먼저 웃었네. 걔한테 그렇게 미안해 놓고.」 {name}는 인사하던 손을 머리에 얹었다.

## V04-MARISA-FRIEND-PC-NEXT_TALK-B

친구 · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name}는 이쪽 의자를 당기다 {rival}의 이름을 듣고 뒷목을 긁었다.

## V04-MARISA-FRIEND-PC-NEXT_TOUCH_ALLOW-A

친구 · 몸 주인공쪽 · 다음 만남 · 스킨십 · 수락

{name} 「……손이 먼저 가네. 걔한테 말한 친구 사이랑 많이 다르지.」 {name}는 손가락을 가볍게 걸어 왔다.

## V04-MARISA-FRIEND-PC-NEXT_TOUCH_REFUSE-A

친구 · 몸 주인공쪽 · 다음 만남 · 스킨십 · 거절

{name} 「너랑 있으면 풀어져서 안 돼. {rival}한테 한 짓도 잊을 뻔하고.」 {name}는 손을 빼 모자 꼭대기를 눌렀다.

## V04-MARISA-FRIEND-PC-NEXT_KISS_ALLOW-A

친구 · 몸 주인공쪽 · 다음 만남 · 키스 · 수락

{name} 「이게 친구끼리 할 짓은 아닌데. 걔한텐 미안한 일만 늘어난다.」 {name}는 응한 뒤 이쪽 팔에 손을 남겼다.

## V04-MARISA-FRIEND-PC-NEXT_KISS_REFUSE-A

친구 · 몸 주인공쪽 · 다음 만남 · 키스 · 거절

{name} 「한 번 더 하면 또 눌러앉겠지. 걔 기다리는데 안 돼.」 {name}는 이쪽 가슴팍에 모자를 댔다.

## V04-MARISA-FRIEND-PC-LATE_TALK-A

친구 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「{rival}이랑(랑) 얘기하다 네가 보고 싶었어. 친구라기엔 너무했지.」 {name}는 의자 위에서 다리를 바꿔 꼬았다.

## V04-MARISA-FRIEND-PC-LATE_TALK-B

친구 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「재밌는 데 가자고 네가 말하면 따라가고 싶어. 걔한텐 일 있댔으면서.」 {name}는 빗자루를 이쪽 가까이 끌었다.

## V04-MARISA-FRIEND-PC-LATE_TOUCH_ALLOW-A

친구 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「놓기가 아깝네. 걔가 잡아 줄 때도 네 손 생각이 나서 미안한데.」 {name}는 맞잡은 손을 장난처럼 흔들다 멈췄다.

## V04-MARISA-FRIEND-PC-LATE_TOUCH_REFUSE-A

친구 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「오늘은 친구답게 있자. 걔한테 아직 친구라고만 말하고 다니니까.」 {name}는 이쪽 손 대신 모자를 집었다.

## V04-MARISA-FRIEND-PC-LATE_KISS_ALLOW-A

친구 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「네가 좋은 게 이렇게 티 나네. 걔 앞에선 꼭 숨기면서.」 {name}는 입맞춤 뒤 이쪽 어깨에 턱을 댔다.

## V04-MARISA-FRIEND-PC-LATE_KISS_REFUSE-A

친구 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「안 돼. 네 옆에 더 있자고 걔한테 또 늦는다곤 못 하겠어.」 {name}는 가까워지던 몸을 뒤로 뺐다.

## V04-MARISA-SECRET-UNSET-AFTER-A

연인(비밀) · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「너도 좋아하니까 된다고 생각했나 봐. {rival}한텐 그게 아니잖아.」 {name}는 모자 안의 먼지만 털었다.

## V04-MARISA-SECRET-UNSET-AFTER-B

연인(비밀) · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「걔한테 말부터 했어야지. ……좋다고 같이 누워 놓고 이제 와서 이러네.」 {name}는 옷을 입다 이마를 쳤다.

## V04-MARISA-SECRET-UNSET-NEXT_TALK-A

연인(비밀) · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name} 「너랑 사귄다는 말부터 못 했는데. 걔한텐 숨길 것만 더 생겼어.」 {name}는 모자를 무릎 사이에 끼웠다.

## V04-MARISA-SECRET-UNSET-NEXT_TALK-B

연인(비밀) · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name}는 {rival} 앞에서 할 인사를 흉내 내다 웃음을 뚝 끊었다.

## V04-MARISA-SECRET-UNSET-NEXT_TOUCH_ALLOW-A

연인(비밀) · 몸 미정 · 다음 만남 · 스킨십 · 수락

{name} 「……잡아 줘. 걔한테 한 짓 너한테 위로받는 것도 웃기네.」 {name}는 손을 쥐고 고개를 숙였다.

## V04-MARISA-SECRET-UNSET-NEXT_TOUCH_REFUSE-A

연인(비밀) · 몸 미정 · 다음 만남 · 스킨십 · 거절

{name} 「오늘은 좀 놔둬. {rival}한테 미안한 얼굴로 너한테 붙긴 싫어.」 {name}는 손을 모자 속에 포갰다.

## V04-MARISA-SECRET-UNSET-NEXT_KISS_ALLOW-A

연인(비밀) · 몸 미정 · 다음 만남 · 키스 · 수락

{name} 「좋아하는 건 진짜야. 걔한테 거짓말하는 것도 진짜고.」 {name}는 응한 뒤 얼굴에서 웃음을 지웠다.

## V04-MARISA-SECRET-UNSET-NEXT_KISS_REFUSE-A

연인(비밀) · 몸 미정 · 다음 만남 · 키스 · 거절

{name} 「잠깐. 걔한텐 미안하다고도 못 했는데 너무 편하게 이러잖아.」 {name}는 입술 앞에 검지를 댔다.

## V04-MARISA-SECRET-UNSET-LATE_TALK-A

연인(비밀) · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「{rival} 얘기 피하면 우리끼린 편하지. 걔만 계속 모르는 거고.」 {name}는 모자 끈을 꼬았다.

## V04-MARISA-SECRET-UNSET-LATE_TALK-B

연인(비밀) · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「걔 앞에선 네 얘기만 빼면 되겠지 했어. 빼니까 남는 얘기가 없더라.」 {name}는 벌렸던 입을 헛웃음으로 닫았다.

## V04-MARISA-SECRET-UNSET-LATE_TOUCH_ALLOW-A

연인(비밀) · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「미안해서 놓으려다 네 손 또 잡네. 걔한텐 염치도 없지.」 {name}는 손을 잡고 천천히 숨을 내쉬었다.

## V04-MARISA-SECRET-UNSET-LATE_TOUCH_REFUSE-A

연인(비밀) · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「{rival}한테 어떻게 말할지 좀 정하자. 만지면 또 넘어갈 것 같아.」 {name}는 이쪽 손을 탁자에 내려뒀다.

## V04-MARISA-SECRET-UNSET-LATE_KISS_ALLOW-A

연인(비밀) · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「나 좋다고 해 줘서 기쁜데. 걔한테도 같은 소리 듣고 왔어.」 {name}는 입맞춤 뒤 입술을 만지작거렸다.

## V04-MARISA-SECRET-UNSET-LATE_KISS_REFUSE-A

연인(비밀) · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「안 해. 걔한테 미안한 걸 너한테 달래 달라는 꼴이잖아.」 {name}는 모자를 얼굴 앞에 들었다.

## V04-MARISA-SECRET-PC-AFTER-A

연인(비밀) · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「헤헤…… 네 옆에서 안 가고 싶더라. 걔 기다리는 건 알았는데.」 {name}는 모자를 쓰려다 다시 내려놨다.

## V04-MARISA-SECRET-PC-AFTER-B

연인(비밀) · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「{rival}한텐 미안해서 가야겠고, 너한텐 더 있고 싶고. 욕심 참 많다.」 {name}는 이쪽 팔을 잡았다 놓았다.

## V04-MARISA-SECRET-PC-NEXT_TALK-A

연인(비밀) · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name} 「왔냐! ……걔한테도 이렇게 반겨 놓고 너 보자마자 이래.」 {name}는 벌린 팔을 어색하게 내렸다.

## V04-MARISA-SECRET-PC-NEXT_TALK-B

연인(비밀) · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name}는 이쪽 손에 모자를 맡기려다 {rival} 얘기에 도로 껴안았다.

## V04-MARISA-SECRET-PC-NEXT_TOUCH_ALLOW-A

연인(비밀) · 몸 주인공쪽 · 다음 만남 · 스킨십 · 수락

{name} 「네 손은 알아보겠어. 걔한테 들으면 얼마나 잔인한 소리겠냐.」 {name}는 맞잡은 손에 뺨을 기댔다.

## V04-MARISA-SECRET-PC-NEXT_TOUCH_REFUSE-A

연인(비밀) · 몸 주인공쪽 · 다음 만남 · 스킨십 · 거절

{name} 「잡으면 또 걔한테 늦어. 오늘까지 그러긴 미안하잖아.」 {name}는 손을 피하고 모자를 집어 들었다.

## V04-MARISA-SECRET-PC-NEXT_KISS_ALLOW-A

연인(비밀) · 몸 주인공쪽 · 다음 만남 · 키스 · 수락

{name} 「헤헤…… 한 번 더란 말이 나오네. 걔한텐 미안하다면서.」 {name}는 응한 뒤 코끝을 이쪽에 붙였다.

## V04-MARISA-SECRET-PC-NEXT_KISS_REFUSE-A

연인(비밀) · 몸 주인공쪽 · 다음 만남 · 키스 · 거절

{name} 「너랑 이러면 걔 생각 안 나. 그게 무서워서 오늘은 안 해.」 {name}는 다가온 얼굴에서 천천히 물러났다.

## V04-MARISA-SECRET-PC-LATE_TALK-A

연인(비밀) · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「걔가 다정하게 굴수록 너랑 있는 게 더 미안해. 그래도 오네, 나는.」 {name}는 벗은 모자를 탁자 끝에 걸었다.

## V04-MARISA-SECRET-PC-LATE_TALK-B

연인(비밀) · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「네가 앉던 쪽부터 치우네. 걔한텐 어질러져서 못 온다 해 놓고.」 {name}는 옆자리 물건을 급히 주웠다.

## V04-MARISA-SECRET-PC-LATE_TOUCH_ALLOW-A

연인(비밀) · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「이 손 때문에 못 가겠어. 걔한테도 기다리지 말란 말을 못 했는데.」 {name}는 얽힌 손가락을 이쪽 무릎에 뒀다.

## V04-MARISA-SECRET-PC-LATE_TOUCH_REFUSE-A

연인(비밀) · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「오늘은 걔랑 약속했어. 네 손 잡고 또 미루면 진짜 최악이지.」 {name}는 손을 빼고 빗자루를 쥐었다.

## V04-MARISA-SECRET-PC-LATE_KISS_ALLOW-A

연인(비밀) · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「좋아해. ……걔한테 말한 다음에도 너한테 이 말 할 수 있을까.」 {name}는 입맞춤 뒤 잠깐 눈썹을 내렸다.

## V04-MARISA-SECRET-PC-LATE_KISS_REFUSE-A

연인(비밀) · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「그만. 걔한테 갈 때까지 네 옆에서 못 일어나겠어.」 {name}는 이쪽 옷깃을 놓고 등을 폈다.

## V04-MARISA-STRANGER-UNSET-AFTER-A

타인 · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「헤헤, 실수했다…… 로 될 일이 아니지. {rival}한테는.」 {name}는 모자를 주워 웃다 말았다.

## V04-MARISA-STRANGER-UNSET-AFTER-B

타인 · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「너도 잘 모르는데 걔한테 이런 짓을 했네. 나 참.」 {name}는 옷에 묻은 먼지를 쓸어 냈다.

## V04-MARISA-STRANGER-UNSET-NEXT_TALK-A

타인 · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name} 「다시 볼 줄 몰랐는데. 걔한테 미안한 것도 다시 확 오네.」 {name}는 빗자루를 들고 문 앞에 섰다.

## V04-MARISA-STRANGER-UNSET-NEXT_TALK-B

타인 · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name}는 {rival}의 이름을 듣고 장난스럽게 걸쳤던 다리를 내렸다.

## V04-MARISA-STRANGER-UNSET-NEXT_TOUCH_ALLOW-A

타인 · 몸 미정 · 다음 만남 · 스킨십 · 수락

{name} 「손까지 어색하네. 걔한테 못할 짓은 먼저 해 놓고.」 {name}는 잡힌 손을 뻣뻣하게 폈다.

## V04-MARISA-STRANGER-UNSET-NEXT_TOUCH_REFUSE-A

타인 · 몸 미정 · 다음 만남 · 스킨십 · 거절

{name} 「어이쿠, 친한 척은 사양할게. 걔한테도 미안하고.」 {name}는 손을 피하며 빗자루를 돌려 쥐었다.

## V04-MARISA-STRANGER-UNSET-NEXT_KISS_ALLOW-A

타인 · 몸 미정 · 다음 만남 · 키스 · 수락

{name} 「……어색하다고 웃어 버릴 뻔했어. 걔한텐 웃을 일도 아닌데.」 {name}는 응한 뒤 모자 끝을 매만졌다.

## V04-MARISA-STRANGER-UNSET-NEXT_KISS_REFUSE-A

타인 · 몸 미정 · 다음 만남 · 키스 · 거절

{name} 「한 번 그랬으면 계속 해도 돼? 걔한텐 한 번도 너무한 거였어.」 {name}는 얼굴 앞에 손을 불쑥 들었다.

## V04-MARISA-STRANGER-UNSET-LATE_TALK-A

타인 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「{rival}은(는) 널 모르는데. 난 네 얼굴만 보면 걔한테 찔리고.」 {name}는 문고리를 쥔 채 얘기했다.

## V04-MARISA-STRANGER-UNSET-LATE_TALK-B

타인 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「걔한테 널 뭐라고 설명하냐. 모르는 놈이라기엔 못 할 짓을 같이 했잖아.」 {name}는 모자 안에 손을 넣었다 뺐다.

## V04-MARISA-STRANGER-UNSET-LATE_TOUCH_ALLOW-A

타인 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「……손은 잡아 줄게. 걔한테 숨긴 걸 친해지는 걸로 덮을 순 없지만.」 {name}는 손끝을 겨우 걸쳤다.

## V04-MARISA-STRANGER-UNSET-LATE_TOUCH_REFUSE-A

타인 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「더 가까워지자는 거면 됐어. 걔한테 거짓말만 늘겠네.」 {name}는 손을 뒤로 빼 모자를 털었다.

## V04-MARISA-STRANGER-UNSET-LATE_KISS_ALLOW-A

타인 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「이젠 네 얼굴은 기억하겠네. 걔한테 미안한 얼굴로.」 {name}는 응한 입술을 꾹 눌렀다.

## V04-MARISA-STRANGER-UNSET-LATE_KISS_REFUSE-A

타인 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「돌아가. 걔 생각하면서 너한테 입 맞출 정도로 뻔뻔하진 못하겠다.」 {name}는 턱을 뒤로 당겼다.

## V04-MARISA-STRANGER-PC-AFTER-A

타인 · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「잘 알지도 못하는 네 옆에서 안 가고 싶었어. 걔한테 미안하게.」 {name}는 이쪽에 뻗은 손을 내려다봤다.

## V04-MARISA-STRANGER-PC-AFTER-B

타인 · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「네가 편한 이유는 모르겠는데. {rival}한테 못 할 짓 한 건 알겠네.」 {name}는 옷을 입고 모자를 깊게 썼다.

## V04-MARISA-STRANGER-PC-NEXT_TALK-A

타인 · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name} 「또 왔냐. ……반가운 게 더 미안하네, 걔한테.」 {name}는 문을 열다 잠깐 웃었다.

## V04-MARISA-STRANGER-PC-NEXT_TALK-B

타인 · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name}는 이쪽에 먼저 건넬 뻔한 농담을 {rival} 앞에서처럼 삼켰다.

## V04-MARISA-STRANGER-PC-NEXT_TOUCH_ALLOW-A

타인 · 몸 주인공쪽 · 다음 만남 · 스킨십 · 수락

{name} 「……이 손은 기억나네. 걔한테 미안해지는 것도 같이.」 {name}는 손바닥을 마주 댔다.

## V04-MARISA-STRANGER-PC-NEXT_TOUCH_REFUSE-A

타인 · 몸 주인공쪽 · 다음 만남 · 스킨십 · 거절

{name} 「잡으면 또 풀어질 것 같아. {rival}한테 이래도 되나 싶고.」 {name}는 손이 닿기 전에 모자를 끌어안았다.

## V04-MARISA-STRANGER-PC-NEXT_KISS_ALLOW-A

타인 · 몸 주인공쪽 · 다음 만남 · 키스 · 수락

{name} 「왜 이렇게 익숙하냐. 걔한텐 미안해서 말도 못 하겠는데.」 {name}는 눈을 감고 응했다가 볼을 문질렀다.

## V04-MARISA-STRANGER-PC-NEXT_KISS_REFUSE-A

타인 · 몸 주인공쪽 · 다음 만남 · 키스 · 거절

{name} 「아직 너 잘 몰라. 자꾸 가까워져서 걔한테 더 미안해지고 싶진 않아.」 {name}는 모자로 제 입술을 가렸다.

## V04-MARISA-STRANGER-PC-LATE_TALK-A

타인 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「너는 조금 알게 됐어. 그걸 걔한테 말 못 하는 것도 알아.」 {name}는 빗자루 손잡이를 이쪽에서 돌렸다.

## V04-MARISA-STRANGER-PC-LATE_TALK-B

타인 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「이젠 네가 오는 소리를 알아. 걔한텐 또 말을 못 할 게 생겼지.」 {name}는 문으로 돌렸던 고개를 숙였다.

## V04-MARISA-STRANGER-PC-LATE_TOUCH_ALLOW-A

타인 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「……이번엔 네 손인 줄 알았어. 걔한테도 이러면 큰일인데.」 {name}는 손가락을 맞대다 작게 떨었다.

## V04-MARISA-STRANGER-PC-LATE_TOUCH_REFUSE-A

타인 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「계속 잡으면 너한테 익숙해지겠지. 걔한텐 또 숨기고. 안 해.」 {name}는 주머니 속에서 손을 움켜쥐었다.

## V04-MARISA-STRANGER-PC-LATE_KISS_ALLOW-A

타인 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「이러다 네가 좋아질까 봐 겁나. 걔한테 사과할 생각도 못 했는데.」 {name}는 응한 뒤 허공에 웃음을 흘렸다.

## V04-MARISA-STRANGER-PC-LATE_KISS_REFUSE-A

타인 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「그만. 모르는 척하고 걔한테 돌아가기 점점 힘들어져.」 {name}는 옆으로 비켜 모자를 고쳐 들었다.

## V04-MARISA-CRUSH-UNSET-AFTER-A

짝사랑 · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「좋아한다고 말부터 할걸. 걔한테는 그 전에 말했어야 하고.」 {name}는 옷을 든 채 입을 달싹였다.

## V04-MARISA-CRUSH-UNSET-AFTER-B

짝사랑 · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「꿈은 아니었네. 좋아했는데…… {rival}한테는 미안한 꿈이겠지.」 {name}는 모자로 붉어진 볼을 부쳤다.

## V04-MARISA-CRUSH-UNSET-NEXT_TALK-A

짝사랑 · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name} 「헤헤, 네 얼굴 보니까…… 아, 걔한테 미안하던 건 어디 가냐.」 {name}는 손으로 입꼬리를 내렸다.

## V04-MARISA-CRUSH-UNSET-NEXT_TALK-B

짝사랑 · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name}는 {rival}에게도 말했느냐는 물음에 모자 챙만 눌렀다.

## V04-MARISA-CRUSH-UNSET-NEXT_TOUCH_ALLOW-A

짝사랑 · 몸 미정 · 다음 만남 · 스킨십 · 수락

{name} 「……기쁘네. 걔한테 한 짓 생각하면 이러면 안 될 것 같은데.」 {name}는 잡은 손을 조금 흔들었다.

## V04-MARISA-CRUSH-UNSET-NEXT_TOUCH_REFUSE-A

짝사랑 · 몸 미정 · 다음 만남 · 스킨십 · 거절

{name} 「잡지 마. 좋아서 웃을 것 같아서 걔한테 미안해.」 {name}는 두 손으로 모자를 덮었다.

## V04-MARISA-CRUSH-UNSET-NEXT_KISS_ALLOW-A

짝사랑 · 몸 미정 · 다음 만남 · 키스 · 수락

{name} 「헤헤…… 좋긴 좋다. 걔한테는 정말 못 할 짓이고.」 {name}는 응한 뒤 붉어진 귀를 가렸다.

## V04-MARISA-CRUSH-UNSET-NEXT_KISS_REFUSE-A

짝사랑 · 몸 미정 · 다음 만남 · 키스 · 거절

{name} 「안 돼. 네가 좋아서 또 넘기면 걔한테 너무하잖아.」 {name}는 웃음기 없이 모자 챙을 세웠다.

## V04-MARISA-CRUSH-UNSET-LATE_TALK-A

짝사랑 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「네가 오나 기다려져. 걔가 날 기다리는 것도 알면서.」 {name}는 문 쪽으로 돌려놓은 의자를 바로 했다.

## V04-MARISA-CRUSH-UNSET-LATE_TALK-B

짝사랑 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「네 자랑 할 뻔했어, 걔한테. 좋은 거 보면 걔한테 말하던 버릇이 남았나 봐.」 {name}는 입술을 삐뚤게 내밀었다.

## V04-MARISA-CRUSH-UNSET-LATE_TOUCH_ALLOW-A

짝사랑 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「……손 잡았다고 좋단다. 걔한텐 이 손으로 얼마나 못되게 굴었는데.」 {name}는 손등으로 웃는 입을 가렸다.

## V04-MARISA-CRUSH-UNSET-LATE_TOUCH_REFUSE-A

짝사랑 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「안 잡을래. 걔한테 미안한 것보다 설레는 게 먼저라서.」 {name}는 이쪽 손에서 손끝을 거뒀다.

## V04-MARISA-CRUSH-UNSET-LATE_KISS_ALLOW-A

짝사랑 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「바랐던 건데도 걔 얼굴이 떠오르네. 그래도 또 받아 줬고.」 {name}는 입맞춤 뒤 볼을 톡톡 쳤다.

## V04-MARISA-CRUSH-UNSET-LATE_KISS_REFUSE-A

짝사랑 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「지금 네가 보고 싶던 건 맞아. 걔한테 더 미안할 일은 안 할래.」 {name}는 달아오른 얼굴을 돌렸다.

## V04-MARISA-CRUSH-PC-AFTER-A

짝사랑 · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「헤헤…… 이러고 싶었나 봐. 걔한테 미안한 것도 다 알면서.」 {name}는 이쪽 팔을 베다 일어났다.

## V04-MARISA-CRUSH-PC-AFTER-B

짝사랑 · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「네가 더 있으랬으면 좋겠어. {rival}한텐 늦는다고도 못 했으면서.」 {name}는 모자를 집었다 내려놨다.

## V04-MARISA-CRUSH-PC-NEXT_TALK-A

짝사랑 · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name} 「네 쪽으로 발이 먼저 가네. 걔한테는 산책 간다고 했는데.」 {name}는 이쪽을 향한 발끝을 감췄다.

## V04-MARISA-CRUSH-PC-NEXT_TALK-B

짝사랑 · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name}는 이쪽에 붙였던 발끝을 {rival}의 이름에 슬쩍 거뒀다.

## V04-MARISA-CRUSH-PC-NEXT_TOUCH_ALLOW-A

짝사랑 · 몸 주인공쪽 · 다음 만남 · 스킨십 · 수락

{name} 「……잡아 줘. 이런 말이 쉬워질수록 걔한테 더 못되게 구네.」 {name}는 이쪽 손에 손가락을 끼웠다.

## V04-MARISA-CRUSH-PC-NEXT_TOUCH_REFUSE-A

짝사랑 · 몸 주인공쪽 · 다음 만남 · 스킨십 · 거절

{name} 「손 잡으면 또 못 놔. 오늘은 걔한테 가야 하니까.」 {name}는 뻗던 팔을 억지로 접었다.

## V04-MARISA-CRUSH-PC-NEXT_KISS_ALLOW-A

짝사랑 · 몸 주인공쪽 · 다음 만남 · 키스 · 수락

{name} 「한 번 더는…… 내가 할 뻔했네. 걔 생각도 못 하고.」 {name}는 응한 뒤 이쪽을 다시 끌다 멈췄다.

## V04-MARISA-CRUSH-PC-NEXT_KISS_REFUSE-A

짝사랑 · 몸 주인공쪽 · 다음 만남 · 키스 · 거절

{name} 「잠깐, 안 돼. 네 앞에선 걔한테 미안한 것도 잊어버려.」 {name}는 제 입가를 급히 덮었다.

## V04-MARISA-CRUSH-PC-LATE_TALK-A

짝사랑 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「{rival}이(가) 웃어 주면 네 웃는 얼굴도 떠올라. 미안해서 나만 못 웃고.」 {name}는 모자를 손안에서 돌렸다.

## V04-MARISA-CRUSH-PC-LATE_TALK-B

짝사랑 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「연구는 안 하고 네가 올 시간만 보네. 걔한텐 바쁜 마법사라 했는데.」 {name}는 펼친 책을 손으로 덮었다.

## V04-MARISA-CRUSH-PC-LATE_TOUCH_ALLOW-A

짝사랑 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「이 손 놓기 싫다. 걔한테 돌아가는 길엔 또 미안해하겠지.」 {name}는 맞잡은 손에 볼을 붙였다.

## V04-MARISA-CRUSH-PC-LATE_TOUCH_REFUSE-A

짝사랑 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「오늘만 안 잡아 볼게. 걔한테 미안하단 걸 말로만 하긴 싫어서.」 {name}는 이쪽 손 대신 제 손목을 쥐었다.

## V04-MARISA-CRUSH-PC-LATE_KISS_ALLOW-A

짝사랑 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「좋아해. ……걔한텐 그 말 듣고도 속이면서 너한테 왔어.」 {name}는 입맞춤 뒤 목소리를 낮췄다.

## V04-MARISA-CRUSH-PC-LATE_KISS_REFUSE-A

짝사랑 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「그만해 줘. 네 옆에 더 있다가 걔한테 또 거짓말하겠어.」 {name}는 한 발 뒤로 물러나 모자를 썼다.

## V04-MARISA-SUBMIT-UNSET-AFTER-A

굴복 · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「헤헤…… 최악이네. 걔한테 미안한 걸로 끝내지도 못하고.」 {name}는 모자를 무릎에 뒤집어 뒀다.

## V04-MARISA-SUBMIT-UNSET-AFTER-B

굴복 · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「{rival}한테 말할지는 네가 정해. 내가 먼저 말할 용기는 없네.」 {name}는 옷 단추를 하나씩 채웠다.

## V04-MARISA-SUBMIT-UNSET-NEXT_TALK-A

굴복 · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name} 「걔가 뭘 잘못한 건 없어. 나만 이런 거지. ……그래.」 {name}는 빗자루 솔 끝을 내려다봤다.

## V04-MARISA-SUBMIT-UNSET-NEXT_TALK-B

굴복 · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name}는 {rival}의 안부를 묻다 갈라진 웃음으로 말을 얼버무렸다.

## V04-MARISA-SUBMIT-UNSET-NEXT_TOUCH_ALLOW-A

굴복 · 몸 미정 · 다음 만남 · 스킨십 · 수락

{name} 「……잡아도 돼. 걔 손 앞에선 숨기겠지만.」 {name}는 손을 이쪽 무릎에 툭 올렸다.

## V04-MARISA-SUBMIT-UNSET-NEXT_TOUCH_REFUSE-A

굴복 · 몸 미정 · 다음 만남 · 스킨십 · 거절

{name} 「오늘은 좀 놔줘. 걔한테 미안한 걸로 머리가 꽉 차서.」 {name}는 손바닥을 안으로 말아 쥐었다.

## V04-MARISA-SUBMIT-UNSET-NEXT_KISS_ALLOW-A

굴복 · 몸 미정 · 다음 만남 · 키스 · 수락

{name} 「받아 주는 건 쉽네. 걔한테 한마디 하는 건 못 하면서.」 {name}는 응한 뒤 힘없이 웃었다.

## V04-MARISA-SUBMIT-UNSET-NEXT_KISS_REFUSE-A

굴복 · 몸 미정 · 다음 만남 · 키스 · 거절

{name} 「못 하겠다. 걔 얼굴만 자꾸 보여서.」 {name}는 모자를 들어 입술을 가린 채 고개를 숙였다.

## V04-MARISA-SUBMIT-UNSET-LATE_TALK-A

굴복 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「{rival}이(가) 걱정해 줘. 난 괜찮다고 해. ……끝도 없네.」 {name}는 모자 안감을 손톱으로 긁었다.

## V04-MARISA-SUBMIT-UNSET-LATE_TALK-B

굴복 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「걔한테 멀쩡한 척하다 버섯 얘기만 한참 했어. 걔는 재밌게 듣더라.」 {name}는 말린 버섯을 봉지에 쏟았다.

## V04-MARISA-SUBMIT-UNSET-LATE_TOUCH_ALLOW-A

굴복 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「……따뜻하다. 걔한테 미안하면 놓아야 하는데.」 {name}는 맡긴 손을 조금씩 쥐었다.

## V04-MARISA-SUBMIT-UNSET-LATE_TOUCH_REFUSE-A

굴복 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「그 손만은 놔. 걔 앞에서 아무렇지 않게 내밀 수가 없어.」 {name}는 팔을 몸 뒤로 돌렸다.

## V04-MARISA-SUBMIT-UNSET-LATE_KISS_ALLOW-A

굴복 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「걔한테 못할 짓이라고 말하면서 또 눈 감네. 참 편리하다.」 {name}는 응한 뒤 눈두덩을 눌렀다.

## V04-MARISA-SUBMIT-UNSET-LATE_KISS_REFUSE-A

굴복 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「……그만. 미안해할 정신까지 없애진 마.」 {name}는 턱을 낮추고 얼굴을 피했다.

## V04-MARISA-SUBMIT-PC-AFTER-A

굴복 · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「네 옆이 좋네. 걔한테 미안할 자격도 없나 봐.」 {name}는 기대 누웠던 팔을 늦게 뗐다.

## V04-MARISA-SUBMIT-PC-AFTER-B

굴복 · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「걔가 기다릴 텐데. 네가 잡으면 또 안 갈 거잖아, 나.」 {name}는 입고 남은 리본을 손에 감았다.

## V04-MARISA-SUBMIT-PC-NEXT_TALK-A

굴복 · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name} 「불렀냐? ……아니지. 내가 오고 싶어서 왔지. 걔 놔두고.」 {name}는 이쪽 앞에 모자를 벗어 뒀다.

## V04-MARISA-SUBMIT-PC-NEXT_TALK-B

굴복 · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name}는 이쪽 곁에서 모자를 벗고도 {rival} 이야기에는 고개를 못 들었다.

## V04-MARISA-SUBMIT-PC-NEXT_TOUCH_ALLOW-A

굴복 · 몸 주인공쪽 · 다음 만남 · 스킨십 · 수락

{name} 「……네 손이 편해. 걔한테 미안하단 말도 못 믿겠다, 이러니까.」 {name}는 손을 잡고 이쪽으로 조금 옮겼다.

## V04-MARISA-SUBMIT-PC-NEXT_TOUCH_REFUSE-A

굴복 · 몸 주인공쪽 · 다음 만남 · 스킨십 · 거절

{name} 「잠깐만 안 잡을래. 걔한테 갈 힘도 좀 남겨야지.」 {name}는 손끝을 피하고 빗자루를 당겼다.

## V04-MARISA-SUBMIT-PC-NEXT_KISS_ALLOW-A

굴복 · 몸 주인공쪽 · 다음 만남 · 키스 · 수락

{name} 「네가 오면 응하게 되네. 걔 생각하던 것도 금방 잊고.」 {name}는 입맞춤에 이쪽 어깨를 붙잡았다.

## V04-MARISA-SUBMIT-PC-NEXT_KISS_REFUSE-A

굴복 · 몸 주인공쪽 · 다음 만남 · 키스 · 거절

{name} 「안 돼. 걔한테 미안하다고 오늘은 한 번쯤 멈추고 싶어.」 {name}는 제 모자를 둘 사이에 놓았다.

## V04-MARISA-SUBMIT-PC-LATE_TALK-A

굴복 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「걔가 잘해 준 얘기 하러 와서 네 옆에 붙네. 뭐 하냐, 나.」 {name}는 의자를 이쪽에 붙이다 멈췄다.

## V04-MARISA-SUBMIT-PC-LATE_TALK-B

굴복 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「빗자루 잡으면 네 쪽으로 오네. 걔한테 간다고 문 나서 놓고.」 {name}는 빗자루 자루를 발끝으로 멀리 밀었다.

## V04-MARISA-SUBMIT-PC-LATE_TOUCH_ALLOW-A

굴복 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「헤헤…… 또 잡았다. 걔한테도 이런 얼굴 하고 거짓말하겠지.」 {name}는 이쪽 손가락을 놓쳤다 다시 잡았다.

## V04-MARISA-SUBMIT-PC-LATE_TOUCH_REFUSE-A

굴복 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「놓는 것도 해 봐야지. 걔한테 돌아갈 때마다 이렇게 미안한데.」 {name}는 손을 끌어와 제 무릎에 묻었다.

## V04-MARISA-SUBMIT-PC-LATE_KISS_ALLOW-A

굴복 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「좋으니까 눈 감았어. 걔한테 안 미안해서가 아니라.」 {name}는 응한 뒤 모자를 가슴에 안았다.

## V04-MARISA-SUBMIT-PC-LATE_KISS_REFUSE-A

굴복 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「오늘은 그만할래. 걔랑 한 약속 하나쯤은 지켜야지.」 {name}는 가까워지던 얼굴 앞에서 팔을 폈다.

## V04-MARISA-COERCED-UNSET-AFTER-A

협박 중 · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「걔한테 잘못한 건 나야. 그걸로 네 말까지 다 들으란 거냐.」 {name}는 옷을 끌어당기며 이를 악물었다.

## V04-MARISA-COERCED-UNSET-AFTER-B

협박 중 · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「{rival}한테 말하겠단 소리는 그만해. 무서운 건 벌써 아니까.」 {name}는 모자를 거꾸로 쓴 채 굳었다.

## V04-MARISA-COERCED-UNSET-NEXT_TALK-A

협박 중 · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name} 「걔 이름 걸고 장난치지 마. 난 그걸로 못 웃어.」 {name}는 버섯 봉지를 탁자에 탁 내려놨다.

## V04-MARISA-COERCED-UNSET-NEXT_TALK-B

협박 중 · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name}는 {rival}에게 알리겠다는 말에 빗자루를 떨어뜨렸다.

## V04-MARISA-COERCED-UNSET-NEXT_TOUCH_ALLOW-A

협박 중 · 몸 미정 · 다음 만남 · 스킨십 · 수락

{name} 「……잠깐이다. 걔한테 비밀로 해 준다고 뻐기진 말고.」 {name}는 손을 맡기고 모자만 노려봤다.

## V04-MARISA-COERCED-UNSET-NEXT_TOUCH_REFUSE-A

협박 중 · 몸 미정 · 다음 만남 · 스킨십 · 거절

{name} 「치워. 걔한테 미안한 게 네가 만져도 된단 뜻은 아니야.」 {name}는 이쪽 손을 손날로 밀었다.

## V04-MARISA-COERCED-UNSET-NEXT_KISS_ALLOW-A

협박 중 · 몸 미정 · 다음 만남 · 키스 · 수락

{name} 「받아 줬으니 됐지. 이걸로 걔한테 또 겁주진 마.」 {name}는 짧게 응한 뒤 얼굴을 굳혔다.

## V04-MARISA-COERCED-UNSET-NEXT_KISS_REFUSE-A

협박 중 · 몸 미정 · 다음 만남 · 키스 · 거절

{name} 「싫어. 걔한테 말할까 봐 겁먹은 거랑 이건 다르지.」 {name}는 이쪽 가슴을 밀어 거리를 뒀다.

## V04-MARISA-COERCED-UNSET-LATE_TALK-A

협박 중 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「내가 망친 거 알아. 걔한테 상처 준단 말로 자꾸 확인하지 마.」 {name}는 모자를 구겼다가 급히 폈다.

## V04-MARISA-COERCED-UNSET-LATE_TALK-B

협박 중 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「걔가 알면 버리겠지, 라는 말. 네 입으론 좀 듣기 싫다. 내가 못돼도.」 {name}는 씩 웃으려다 이를 악물었다.

## V04-MARISA-COERCED-UNSET-LATE_TOUCH_ALLOW-A

협박 중 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「……손은 줄게. 걔한테 한 일까지 없애 주는 건 아니잖아.」 {name}는 손끝만 내어 줬다.

## V04-MARISA-COERCED-UNSET-LATE_TOUCH_REFUSE-A

협박 중 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「안 잡아. {rival}한테 미안하다고 네 장난감 될 생각은 없어.」 {name}는 손을 뒤로 빼 소매를 걷었다.

## V04-MARISA-COERCED-UNSET-LATE_KISS_ALLOW-A

협박 중 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「이러면 걔한테 또 숨겨야겠네. 그게 네가 바라던 거냐.」 {name}는 응한 뒤 입가를 손등으로 눌렀다.

## V04-MARISA-COERCED-UNSET-LATE_KISS_REFUSE-A

협박 중 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「그만. 걔한테 미움받을까 무서운 걸로 이러진 마.」 {name}는 모자를 이쪽 얼굴 앞으로 내밀었다.

## V04-MARISA-COERCED-PC-AFTER-A

협박 중 · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「다시 네 옆으로 갔다고 웃지 마. 걔한테 미안해서 죽겠는데.」 {name}는 이쪽 팔을 떼고 모자를 썼다.

## V04-MARISA-COERCED-PC-AFTER-B

협박 중 · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「끌리는 거랑 협박하는 건 다르잖아. 걔한테 내가 잘못한 거지 네가 잘한 게 아니고.」 {name}는 옷끈을 세게 당겼다.

## V04-MARISA-COERCED-PC-NEXT_TALK-A

협박 중 · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name} 「오고 싶어서 왔는데도 네가 말했나 겁나. 걔한테 못되게 군 값인가.」 {name}는 문간에서 모자를 움켜쥐었다.

## V04-MARISA-COERCED-PC-NEXT_TALK-B

협박 중 · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name}는 이쪽에 기대 웃다가 {rival}의 이름에 어깨를 움츠렸다.

## V04-MARISA-COERCED-PC-NEXT_TOUCH_ALLOW-A

협박 중 · 몸 주인공쪽 · 다음 만남 · 스킨십 · 수락

{name} 「……잡고 싶긴 했어. 걔한테 보여 준다느니 하진 마.」 {name}는 손을 쥔 채 이쪽 얼굴을 살폈다.

## V04-MARISA-COERCED-PC-NEXT_TOUCH_REFUSE-A

협박 중 · 몸 주인공쪽 · 다음 만남 · 스킨십 · 거절

{name} 「안 잡을래. 걔한테 미안한 걸 네가 재밌어하니까.」 {name}는 움찔한 손을 주머니에 넣었다.

## V04-MARISA-COERCED-PC-NEXT_KISS_ALLOW-A

협박 중 · 몸 주인공쪽 · 다음 만남 · 키스 · 수락

{name} 「내가 응한 건 맞아. 그걸로 걔한테 겁줄 거리 늘리지는 말고.」 {name}는 입맞춤 뒤 웃지 않고 눈을 맞췄다.

## V04-MARISA-COERCED-PC-NEXT_KISS_REFUSE-A

협박 중 · 몸 주인공쪽 · 다음 만남 · 키스 · 거절

{name} 「멈춰. 너한테 끌려도 걔 이름으로 협박하는 건 못 참아.」 {name}는 이쪽 얼굴을 챙으로 밀어냈다.

## V04-MARISA-COERCED-PC-LATE_TALK-A

협박 중 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「걔한테 미안하다니까 너 질투하냐고 웃더라. 내가 그렇게 우습냐.」 {name}는 빗자루 자루를 꺾일 듯 쥐었다.

## V04-MARISA-COERCED-PC-LATE_TALK-B

협박 중 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「걔한텐 네 편까지 들었어. 걔 이름으로 겁주는 네가 좋을 때도 있어서. 참 못났네.」 {name}는 모자 챙을 눈썹 위로 당겼다.

## V04-MARISA-COERCED-PC-LATE_TOUCH_ALLOW-A

협박 중 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「네 손은 좋네. 걔한테 이걸로 겁주는 네 얼굴은 싫고.」 {name}는 손을 잡되 의자는 당기지 않았다.

## V04-MARISA-COERCED-PC-LATE_TOUCH_REFUSE-A

협박 중 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「놔. 걔한테 미안해서라도 오늘은 네가 부르는 대로 안 갈래.」 {name}는 손가락을 세워 맞잡은 손을 풀었다.

## V04-MARISA-COERCED-PC-LATE_KISS_ALLOW-A

협박 중 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「……눈 감으니까 잠깐 편하더라. 걔한테 또 숨길 일 늘었는데.」 {name}는 응한 뒤 씁쓸하게 모자를 들었다.

## V04-MARISA-COERCED-PC-LATE_KISS_REFUSE-A

협박 중 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「안 해. 걔한테 사과할 말은 내가 정할 거야, 네가 아니라.」 {name}는 턱을 치켜들어 얼굴을 피했다.


# 코치야 사나에 · v0.4.0

라이벌의 현재 연인 · 자발적 외도 후 · 미발각. 전부 미검토.

## V04-SANAE-HATE-UNSET-AFTER-A

싫어함 · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「{rival_call}한테 뭐라고 하죠. 좋아하지도 않는 분이랑 이래 놓고.」 {name}는 옷을 끌어안고 얼굴을 찌푸렸다.

## V04-SANAE-HATE-UNSET-AFTER-B

싫어함 · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「없던 일로요? 그분이 모르면 제가 한 일도 없어져요?」 {name}는 웃으려다 고름을 세게 당겼다.

## V04-SANAE-HATE-UNSET-NEXT_TALK-A

싫어함 · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name} 「밝게 인사할 줄 아셨어요? 그분한테 미안한데 당신까지 반기긴 싫어요.」 {name}는 내밀던 손을 거뒀다.

## V04-SANAE-HATE-UNSET-NEXT_TALK-B

싫어함 · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name}는 {rival_call}의 이름에 맞장구를 치려다 말을 멈췄다.

## V04-SANAE-HATE-UNSET-NEXT_TOUCH_ALLOW-A

싫어함 · 몸 미정 · 다음 만남 · 스킨십 · 수락

{name} 「……손만이에요. 그분한테 더 미안할 일은 말고요.」 {name}는 손을 맡긴 채 고개를 비스듬히 돌렸다.

## V04-SANAE-HATE-UNSET-NEXT_TOUCH_REFUSE-A

싫어함 · 몸 미정 · 다음 만남 · 스킨십 · 거절

{name} 「만지지 마세요. 그분한테 잘못했다고 당신이 괜찮아진 건 아니에요.」 {name}는 손을 홱 빼냈다.

## V04-SANAE-HATE-UNSET-NEXT_KISS_ALLOW-A

싫어함 · 몸 미정 · 다음 만남 · 키스 · 수락

{name} 「……이제 됐죠. 그분한텐 또 아무렇지 않게 웃어야겠네요.」 {name}는 응한 뒤 입술을 꾹 눌렀다.

## V04-SANAE-HATE-UNSET-NEXT_KISS_REFUSE-A

싫어함 · 몸 미정 · 다음 만남 · 키스 · 거절

{name} 「싫어요. 그분한테 미안한 걸 숨기는 것도 벅차니까.」 {name}는 두 손으로 다가온 가슴을 밀었다.

## V04-SANAE-HATE-UNSET-LATE_TALK-A

싫어함 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「그분은 잘해 주세요. 그래서 더 미안한 거, 당신은 모르겠죠.」 {name}는 옷소매를 무릎에 눌렀다.

## V04-SANAE-HATE-UNSET-LATE_TALK-B

싫어함 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「그분이 웃어 보래요. 잘 웃는 게 좋다는데 당신 앞에서는 못 하겠어요.」 {name}는 볼을 손으로 들었다가 놓았다.

## V04-SANAE-HATE-UNSET-LATE_TOUCH_ALLOW-A

싫어함 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「……가만히는 있을게요. 그분한테 이런 걸 숨기는 제가 더 싫네요.」 {name}는 잡힌 손을 축 늘어뜨렸다.

## V04-SANAE-HATE-UNSET-LATE_TOUCH_REFUSE-A

싫어함 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「그날 받아 줬어도 오늘은 싫어요. 그분한테 더 미안해지기도 싫고.」 {name}는 손을 제 등 뒤로 넘겼다.

## V04-SANAE-HATE-UNSET-LATE_KISS_ALLOW-A

싫어함 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「이러고서 그분한텐 좋아한다고 하겠죠. ……제가요, 제가.」 {name}는 응한 뒤 마른침을 삼켰다.

## V04-SANAE-HATE-UNSET-LATE_KISS_REFUSE-A

싫어함 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「거절할게요. 그분한테 잘못한 것도 당신 얼굴 보는 것도 이제 지겨워요.」 {name}는 턱을 홱 돌렸다.

## V04-SANAE-HATE-PC-AFTER-A

싫어함 · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「왜 당신 옆이 편해요? 그분한텐 미안해 죽겠는데, 싫어하는 분 옆에서.」 {name}는 기대던 팔을 밀어냈다.

## V04-SANAE-HATE-PC-AFTER-B

싫어함 · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「{rival_call}이 기다리실 텐데 일어나기 싫었어요. 진짜 싫네요, 저도.」 {name}는 옷을 다 입고도 앉아 있었다.

## V04-SANAE-HATE-PC-NEXT_TALK-A

싫어함 · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name} 「오셨네요…… 반가울 뻔했어요. 그분한테는 고개도 못 들었는데.」 {name}는 풀린 표정을 급히 가다듬었다.

## V04-SANAE-HATE-PC-NEXT_TALK-B

싫어함 · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name}는 이쪽을 반기던 얼굴로 {rival_call}의 안부를 묻다 굳었다.

## V04-SANAE-HATE-PC-NEXT_TOUCH_ALLOW-A

싫어함 · 몸 주인공쪽 · 다음 만남 · 스킨십 · 수락

{name} 「……따뜻하네요. 이런 게 좋으니까 그분한테 더 죄송한데.」 {name}는 잡힌 손을 제 쪽으로 당겼다.

## V04-SANAE-HATE-PC-NEXT_TOUCH_REFUSE-A

싫어함 · 몸 주인공쪽 · 다음 만남 · 스킨십 · 거절

{name} 「안 잡을래요. 당신 옆에서 편해지면 그분 생각을 안 하게 돼요.」 {name}는 손을 감추며 소매를 내렸다.

## V04-SANAE-HATE-PC-NEXT_KISS_ALLOW-A

싫어함 · 몸 주인공쪽 · 다음 만남 · 키스 · 수락

{name} 「제가 받아 줬으니 당신은 좋겠죠. 그분한테 미안할 사람은 저고요.」 {name}는 응한 뒤 볼을 세게 문질렀다.

## V04-SANAE-HATE-PC-NEXT_KISS_REFUSE-A

싫어함 · 몸 주인공쪽 · 다음 만남 · 키스 · 거절

{name} 「가까이 오지 마세요. 또 받아 주면 그분한테 뭐가 돼요.」 {name}는 손바닥으로 제 입을 막았다.

## V04-SANAE-HATE-PC-LATE_TALK-A

싫어함 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「그분 손인데 당신 손인 줄 알았어요. ……그 앞에서 울 뻔했고요.」 {name}는 손끝을 하나씩 내려다봤다.

## V04-SANAE-HATE-PC-LATE_TALK-B

싫어함 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「그분 앞에선 웃는 연습 안 해도 잘되는데. 당신 옆이 편한 건 더 싫네요.」 {name}는 이쪽에 붙였던 의자를 발로 밀었다.

## V04-SANAE-HATE-PC-LATE_TOUCH_ALLOW-A

싫어함 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「이러면 편하긴 해요. 그분한테 사과할 일은 또 늘지만.」 {name}는 손을 쥐고 어깨 힘을 풀었다.

## V04-SANAE-HATE-PC-LATE_TOUCH_REFUSE-A

싫어함 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「놓으세요. 당신한테 달라붙고 싶을수록 그분한텐 더 못되게 구는 것 같아서요.」 {name}는 손목을 당겨 몸에 붙였다.

## V04-SANAE-HATE-PC-LATE_KISS_ALLOW-A

싫어함 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「……또 눈 감았네요. 그분 생각하면 그러면 안 될 것 같았는데.」 {name}는 응한 뒤 눈을 질끈 감았다.

## V04-SANAE-HATE-PC-LATE_KISS_REFUSE-A

싫어함 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「안 해요. 그분 얼굴 볼 때까지 당신을 잊어 보고 싶어요.」 {name}는 가까워진 얼굴에서 한 걸음 빠졌다.

## V04-SANAE-FRIEND-UNSET-AFTER-A

친구 · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「에헤헤, 친구끼리 사고 쳤네요…… 가 아니죠. 그분한테 뭐라고 해요.」 {name}는 웃던 입을 손으로 가렸다.

## V04-SANAE-FRIEND-UNSET-AFTER-B

친구 · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「{rival_call}한테 친구 보러 온다고 했는데. 그 말이 거짓말이 됐어요.」 {name}는 풀린 리본을 무릎에 놓았다.

## V04-SANAE-FRIEND-UNSET-NEXT_TALK-A

친구 · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name} 「제 얘기 들어보세요, 오늘…… 아, 그분 얘긴 못 하겠네요.」 {name}는 밝게 들었던 손을 내렸다.

## V04-SANAE-FRIEND-UNSET-NEXT_TALK-B

친구 · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name}는 {rival_call}께도 해 드린 이야기를 꺼냈다가 웃는 소리를 낮췄다.

## V04-SANAE-FRIEND-UNSET-NEXT_TOUCH_ALLOW-A

친구 · 몸 미정 · 다음 만남 · 스킨십 · 수락

{name} 「전엔 손잡고 다녀도 안 미안했는데. 그분한테 숨기는 손이 됐네요.」 {name}는 손을 맡기고 입술을 삐죽였다.

## V04-SANAE-FRIEND-UNSET-NEXT_TOUCH_REFUSE-A

친구 · 몸 미정 · 다음 만남 · 스킨십 · 거절

{name} 「친구면 오늘은 좀 참아 주세요. 그분한테 미안하단 말도 못 했으니까.」 {name}는 손을 빼 치맛자락을 잡았다.

## V04-SANAE-FRIEND-UNSET-NEXT_KISS_ALLOW-A

친구 · 몸 미정 · 다음 만남 · 키스 · 수락

{name} 「……이건 친구라서가 아니잖아요. 그분한테 그렇게 말하고 다녔는데.」 {name}는 응한 뒤 고개를 갸웃하다 숙였다.

## V04-SANAE-FRIEND-UNSET-NEXT_KISS_REFUSE-A

친구 · 몸 미정 · 다음 만남 · 키스 · 거절

{name} 「안 돼요. 친구 만나러 왔다는 말을 더 거짓말로 만들긴 싫어요.」 {name}는 한 바퀴 비켜 얼굴을 피했다.

## V04-SANAE-FRIEND-UNSET-LATE_TALK-A

친구 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「예전처럼 수다 떨면 괜찮을 줄 알았어요. 그분한테 숨기는 얘기만 늘고요.」 {name}는 늘어놓던 이야기를 뚝 끊었다.

## V04-SANAE-FRIEND-UNSET-LATE_TALK-B

친구 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「바깥 세계 얘기를 잔뜩 했어요. 그분이 제 얘기는 못 묻게요. 잘 들어 주시더라고요.」 {name}는 들떠 있던 손짓을 멈췄다.

## V04-SANAE-FRIEND-UNSET-LATE_TOUCH_ALLOW-A

친구 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「손은 잡을게요. 그분께 친구라고 소개한 게 자꾸 찔리긴 하지만.」 {name}는 손등을 조심스럽게 쓰다듬었다.

## V04-SANAE-FRIEND-UNSET-LATE_TOUCH_REFUSE-A

친구 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「오늘은 친구답게만 놀아요. 그분한테 여전히 그렇게 말씀드리니까요.」 {name}는 손을 거둬 가슴 앞에 모았다.

## V04-SANAE-FRIEND-UNSET-LATE_KISS_ALLOW-A

친구 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「에헤헤…… 친구라는 말 뒤에 숨기 편하네요. 그분한텐 너무 미안하지만.」 {name}는 입맞춤 뒤 눈꼬리를 내렸다.

## V04-SANAE-FRIEND-UNSET-LATE_KISS_REFUSE-A

친구 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「다음에 더 친해지면…… 같은 말도 못 하겠네요. 그분한테 이미 잘못해서.」 {name}는 양손을 펴 얼굴 사이에 뒀다.

## V04-SANAE-FRIEND-PC-AFTER-A

친구 · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「친구라서 달라붙는 건 줄 알았는데. 그분한테 미안할 만큼 좋았어요.」 {name}는 이쪽 팔에서 볼을 뗐다.

## V04-SANAE-FRIEND-PC-AFTER-B

친구 · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「그분한테 돌아가야 하는데 여기 더 있고 싶었어요. 친구 보러 온 것치곤 너무했죠.」 {name}는 옷을 입다 이쪽을 다시 봤다.

## V04-SANAE-FRIEND-PC-NEXT_TALK-A

친구 · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name} 「{pc_call}! ……너무 반겼네요. 그분한테 미안해하던 참인데.」 {name}는 달려오다 발을 멈췄다.

## V04-SANAE-FRIEND-PC-NEXT_TALK-B

친구 · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name}는 이쪽 팔을 잡으려다 {rival_call}의 이름에 양손을 접었다.

## V04-SANAE-FRIEND-PC-NEXT_TOUCH_ALLOW-A

친구 · 몸 주인공쪽 · 다음 만남 · 스킨십 · 수락

{name} 「에헤헤, 또 잡았어요. 그분한테 말한 친구 사이는 이렇지 않았는데.」 {name}는 손을 잡고 이쪽에 바짝 앉았다.

## V04-SANAE-FRIEND-PC-NEXT_TOUCH_REFUSE-A

친구 · 몸 주인공쪽 · 다음 만남 · 스킨십 · 거절

{name} 「잡으면 또 늦을걸요. 그분한테 기다려 달라는 말도 이젠 미안해서.」 {name}는 손을 피하며 무릎을 세웠다.

## V04-SANAE-FRIEND-PC-NEXT_KISS_ALLOW-A

친구 · 몸 주인공쪽 · 다음 만남 · 키스 · 수락

{name} 「좋아지니까 더 하게 되네요. 그분한테는 비밀인 채로요.」 {name}는 응한 뒤 이쪽 어깨에 볼을 댔다.

## V04-SANAE-FRIEND-PC-NEXT_KISS_REFUSE-A

친구 · 몸 주인공쪽 · 다음 만남 · 키스 · 거절

{name} 「잠깐만요. 당신 옆에선 그분 생각을 너무 쉽게 잊어요. 그건 싫어요.」 {name}는 다가온 얼굴을 양손으로 멈췄다.

## V04-SANAE-FRIEND-PC-LATE_TALK-A

친구 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「그분 옆에서도 당신이랑 놀고 싶어져요. 친구라서라고 넘기기엔 미안하고요.」 {name}는 발끝으로 바닥을 문질렀다.

## V04-SANAE-FRIEND-PC-LATE_TALK-B

친구 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「친구 만나러 와서 기분 좋았대요, 제가. 그분 앞에서도 이렇게 잘 웃었어요.」 {name}는 웃던 얼굴을 소매로 덮었다.

## V04-SANAE-FRIEND-PC-LATE_TOUCH_ALLOW-A

친구 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「이 손 잡고 있으면 편해요. 그분한테는 숨길수록 불편해지고요.」 {name}는 이쪽 손을 제 무릎 위에 올렸다.

## V04-SANAE-FRIEND-PC-LATE_TOUCH_REFUSE-A

친구 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「오늘은 손 안 잡을래요. 그분한테 가겠단 말도 또 미루기 싫어서.」 {name}는 양손을 제 무릎 아래에 넣었다.

## V04-SANAE-FRIEND-PC-LATE_KISS_ALLOW-A

친구 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「한 번 더요…… 아, 이런 말까지 해 놓고 친구라고만 하네요. 그분한테.」 {name}는 응한 뒤 제 입가를 콕 눌렀다.

## V04-SANAE-FRIEND-PC-LATE_KISS_REFUSE-A

친구 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「그만요. 같이 있으면 즐겁다고 그분한테 더 미안할 일까지 늘리긴 싫어요.」 {name}는 고개를 돌려 숨을 골랐다.

## V04-SANAE-SECRET-UNSET-AFTER-A

연인(비밀) · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「당신도 좋아해요. ……그분한테는 그 말이 제일 상처겠죠.」 {name}는 옷을 챙기다 볼을 감쌌다.

## V04-SANAE-SECRET-UNSET-AFTER-B

연인(비밀) · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「둘 다 좋다고 넘길 일이 아니었어요. 그분은 제가 자기 연인인 줄 아시는데.」 {name}는 리본을 다시 묶다 한숨을 쉬었다.

## V04-SANAE-SECRET-UNSET-NEXT_TALK-A

연인(비밀) · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name} 「그분한테 평소처럼 웃었어요. 연습도 안 했는데 잘되더라고요. ……미안하게.」 {name}는 웃는 얼굴을 손끝으로 눌렀다.

## V04-SANAE-SECRET-UNSET-NEXT_TALK-B

연인(비밀) · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name}는 {rival_call}께도 좋아한다 말했느냐는 물음에 고름 끝을 꼬았다.

## V04-SANAE-SECRET-UNSET-NEXT_TOUCH_ALLOW-A

연인(비밀) · 몸 미정 · 다음 만남 · 스킨십 · 수락

{name} 「손 좀 잡아 주세요. 그분한테 잘못하고 위로까지 바라네요, 제가.」 {name}는 손을 맞잡아 가슴 가까이 뒀다.

## V04-SANAE-SECRET-UNSET-NEXT_TOUCH_REFUSE-A

연인(비밀) · 몸 미정 · 다음 만남 · 스킨십 · 거절

{name} 「오늘은 혼자 있을게요. 그분한테 미안한 걸 당신한테 달래 달라고 하긴 좀 그래요.」 {name}는 손을 거둬 옷깃에 포갰다.

## V04-SANAE-SECRET-UNSET-NEXT_KISS_ALLOW-A

연인(비밀) · 몸 미정 · 다음 만남 · 키스 · 수락

{name} 「좋아해요. 그분한테도 했던 말인 게 미안해서 목에 걸리네요.」 {name}는 응한 뒤 목을 한번 가다듬었다.

## V04-SANAE-SECRET-UNSET-NEXT_KISS_REFUSE-A

연인(비밀) · 몸 미정 · 다음 만남 · 키스 · 거절

{name} 「안 돼요. 그분한테 말도 못 하면서 우리끼리만 좋으면 너무하잖아요.」 {name}는 입술 앞에 손가락을 댔다.

## V04-SANAE-SECRET-UNSET-LATE_TALK-A

연인(비밀) · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「그분이 저한테 제일 소중하대요. 저는 두 사람한테 같은 말을 했는데.」 {name}는 붙이려던 미소를 거뒀다.

## V04-SANAE-SECRET-UNSET-LATE_TALK-B

연인(비밀) · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「둘 다 좋으니까 다정하게 굴면 된다 생각했어요. 그분은 그 뜻으로 웃으신 게 아닌데.」 {name}는 모았던 손을 천천히 폈다.

## V04-SANAE-SECRET-UNSET-LATE_TOUCH_ALLOW-A

연인(비밀) · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「이러면 안심돼요. 그분한테 사과하는 대신 여기서 안심하고 있는 게 문제죠.」 {name}는 손을 꽉 잡았다가 힘을 풀었다.

## V04-SANAE-SECRET-UNSET-LATE_TOUCH_REFUSE-A

연인(비밀) · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「잠깐 놔 주세요. 그분께 어떻게 말할지 생각하려고요. 피하지 말고요.」 {name}는 손을 빼 이마에 댔다.

## V04-SANAE-SECRET-UNSET-LATE_KISS_ALLOW-A

연인(비밀) · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「에헤헤…… 좋아요. 그래서 더 그분한테 못할 짓 같아요.」 {name}는 입맞춤 뒤 어색하게 웃었다.

## V04-SANAE-SECRET-UNSET-LATE_KISS_REFUSE-A

연인(비밀) · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「오늘은 안 할래요. 그분한테 미안하단 말만 하고 달라지는 게 없잖아요.」 {name}는 가까워진 얼굴에서 눈을 내렸다.

## V04-SANAE-SECRET-PC-AFTER-A

연인(비밀) · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「조금 더 있을까요? ……그분 기다리시는데 이런 말부터 나오네요.」 {name}는 이쪽 옷자락에서 손을 늦게 뗐다.

## V04-SANAE-SECRET-PC-AFTER-B

연인(비밀) · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「여기선 기분 좋아서 그분 생각을 늦게 했어요. 그게 더 죄송해요.」 {name}는 입은 옷깃을 꼭 붙잡았다.

## V04-SANAE-SECRET-PC-NEXT_TALK-A

연인(비밀) · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name} 「보고 싶었어요! ……그분한텐 바쁘다고 하고 와 놓고요.」 {name}는 반갑게 들었던 팔을 접었다.

## V04-SANAE-SECRET-PC-NEXT_TALK-B

연인(비밀) · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name}는 이쪽 곁으로 의자를 옮기다 {rival_call} 얘기에 자리를 띄웠다.

## V04-SANAE-SECRET-PC-NEXT_TOUCH_ALLOW-A

연인(비밀) · 몸 주인공쪽 · 다음 만남 · 스킨십 · 수락

{name} 「이 손이 좋아요. 그분한텐 도저히 할 수 없는 말이네요.」 {name}는 손바닥을 포개 손가락을 엮었다.

## V04-SANAE-SECRET-PC-NEXT_TOUCH_REFUSE-A

연인(비밀) · 몸 주인공쪽 · 다음 만남 · 스킨십 · 거절

{name} 「잡으면 또 못 갈 것 같아요. 오늘은 그분 기다리게 하지 않을래요.」 {name}는 손을 뒤로 빼 등을 세웠다.

## V04-SANAE-SECRET-PC-NEXT_KISS_ALLOW-A

연인(비밀) · 몸 주인공쪽 · 다음 만남 · 키스 · 수락

{name} 「한 번 더…… 아, 제가 더 하고 싶네요. 그분한테 미안한 것도 잊고.」 {name}는 응한 뒤 이쪽 소매를 살짝 당겼다.

## V04-SANAE-SECRET-PC-NEXT_KISS_REFUSE-A

연인(비밀) · 몸 주인공쪽 · 다음 만남 · 키스 · 거절

{name} 「안 돼요. 당신 가까우면 그분한테 돌아갈 생각이 뚝 끊겨 버려요.」 {name}는 다가온 이마를 손바닥으로 받쳤다.

## V04-SANAE-SECRET-PC-LATE_TALK-A

연인(비밀) · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「그분이 다정할수록 죄송한데 당신은 또 보고 싶어요. 말도 안 되죠.」 {name}는 무릎 위에 손을 겹쳤다.

## V04-SANAE-SECRET-PC-LATE_TALK-B

연인(비밀) · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「그분한텐 걱정 말랬어요. 당신 만나러 빨리 가고 싶어서 대답도 빨리 했고요.」 {name}는 제 입을 손가락으로 톡 쳤다.

## V04-SANAE-SECRET-PC-LATE_TOUCH_ALLOW-A

연인(비밀) · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「안 놓고 싶어요. 그분한테 갈 땐 또 미안하겠지만 지금은요.」 {name}는 잡은 손을 제 쪽으로 꼭 끌었다.

## V04-SANAE-SECRET-PC-LATE_TOUCH_REFUSE-A

연인(비밀) · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「오늘은 그냥 둘게요. 그분한테 일찍 온다고 했으니 그건 지키려고요.」 {name}는 이쪽 손 대신 옷매무새를 잡았다.

## V04-SANAE-SECRET-PC-LATE_KISS_ALLOW-A

연인(비밀) · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「눈 감으면 당신만 생각나요. 그분께는 그게 제일 죄송하고요.」 {name}는 입맞춤 뒤 이쪽 팔에 기댔다.

## V04-SANAE-SECRET-PC-LATE_KISS_REFUSE-A

연인(비밀) · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「여기까지요. 그분한테 돌아가는 길에도 당신 생각만 하게 만들진 마세요.」 {name}는 얼굴을 비키며 고름을 고쳤다.

## V04-SANAE-STRANGER-UNSET-AFTER-A

타인 · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「에헤헤…… 인사부터 어색하네요. 그분한테 못할 일부터 해 버렸으니까.」 {name}는 옷을 들어 얼굴을 반쯤 가렸다.

## V04-SANAE-STRANGER-UNSET-AFTER-B

타인 · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「{rival_call}은 제가 당신을 만난 것도 모르실 텐데. ……이렇게까지 했어요.」 {name}는 리본을 쥔 손을 내렸다.

## V04-SANAE-STRANGER-UNSET-NEXT_TALK-A

타인 · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name} 「다시 오실 줄 몰랐어요. 그분한테 미안한 일이 눈앞에 온 것 같네요.」 {name}는 반갑게 웃으려다 멈췄다.

## V04-SANAE-STRANGER-UNSET-NEXT_TALK-B

타인 · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name}는 {rival_call}의 안부에 밝게 대답하다 끝을 흐렸다.

## V04-SANAE-STRANGER-UNSET-NEXT_TOUCH_ALLOW-A

타인 · 몸 미정 · 다음 만남 · 스킨십 · 수락

{name} 「손은 아직 어색하네요. 그분한테 미안할 일은 먼저 해 놓고.」 {name}는 손끝을 뻣뻣하게 내어 줬다.

## V04-SANAE-STRANGER-UNSET-NEXT_TOUCH_REFUSE-A

타인 · 몸 미정 · 다음 만남 · 스킨십 · 거절

{name} 「잠깐, 친한 척하진 마세요. 그분한테 미안한 걸 그냥 넘길 순 없어서요.」 {name}는 닿기 전에 팔을 뒤로 돌렸다.

## V04-SANAE-STRANGER-UNSET-NEXT_KISS_ALLOW-A

타인 · 몸 미정 · 다음 만남 · 키스 · 수락

{name} 「……이런 것도 인사처럼 해 버리네요. 그분께는 웃을 일 아니겠죠.」 {name}는 응한 뒤 어색하게 목을 움츠렸다.

## V04-SANAE-STRANGER-UNSET-NEXT_KISS_REFUSE-A

타인 · 몸 미정 · 다음 만남 · 키스 · 거절

{name} 「안 돼요. 그날 제가 받아 줬다고 그분께 또 못할 짓 하긴 싫어요.」 {name}는 두 손으로 입가를 가렸다.

## V04-SANAE-STRANGER-UNSET-LATE_TALK-A

타인 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「당신을 알게 됐다는 말부터 그분께 못 하겠어요. 뭐 했냐고 물으실까 봐요.」 {name}는 웃으며 열던 입을 닫았다.

## V04-SANAE-STRANGER-UNSET-LATE_TALK-B

타인 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「잘 아는 분도 아니라고 말할 수 있겠죠. 그분한테 그 뒤는 못 말하겠지만요.」 {name}는 고개를 끄덕이다 멈췄다.

## V04-SANAE-STRANGER-UNSET-LATE_TOUCH_ALLOW-A

타인 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「잡아도 되지만 익숙하진 않아요. 그분한테 숨기는 것도 익숙해지긴 싫고요.」 {name}는 손을 잡은 채 허리를 폈다.

## V04-SANAE-STRANGER-UNSET-LATE_TOUCH_REFUSE-A

타인 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「더 친해지는 건 어려워요. 그분께 비밀로 하는 게 이미 너무 커서요.」 {name}는 손을 거둬 소매 속에 넣었다.

## V04-SANAE-STRANGER-UNSET-LATE_KISS_ALLOW-A

타인 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「이러면 얼굴은 안 잊겠네요. 그분한테는 미안할 때마다 떠오를 거고요.」 {name}는 짧게 응하고 뺨을 긁었다.

## V04-SANAE-STRANGER-UNSET-LATE_KISS_REFUSE-A

타인 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「돌아가실래요? 그분께 사과는 못 하고 당신만 더 만나는 건 좀 그래요.」 {name}는 다가온 얼굴에서 한 발 비켰다.

## V04-SANAE-STRANGER-PC-AFTER-A

타인 · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「잘 모르는데 당신 옆이 편했어요. 그분한텐 뭐라고 해야 할지 더 모르겠네요.」 {name}는 이쪽 어깨에서 천천히 떨어졌다.

## V04-SANAE-STRANGER-PC-AFTER-B

타인 · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「그분께 돌아가려는데 또 붙어 있고 싶어요. ……저 왜 이래요.」 {name}는 옷을 입으며 이쪽을 힐끗 봤다.

## V04-SANAE-STRANGER-PC-NEXT_TALK-A

타인 · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name} 「또 오셨네요! ……기쁘면 안 될 것 같은데 그분한테 미안해서요.」 {name}는 웃던 볼을 손바닥으로 눌렀다.

## V04-SANAE-STRANGER-PC-NEXT_TALK-B

타인 · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name}는 이쪽 이야기를 묻던 중 {rival_call}의 이름에 질문을 삼켰다.

## V04-SANAE-STRANGER-PC-NEXT_TOUCH_ALLOW-A

타인 · 몸 주인공쪽 · 다음 만남 · 스킨십 · 수락

{name} 「손은 벌써 익숙해요. 이런 말부터 그분께 못 하겠네요.」 {name}는 손을 맞잡고 가만히 웃다 숙였다.

## V04-SANAE-STRANGER-PC-NEXT_TOUCH_REFUSE-A

타인 · 몸 주인공쪽 · 다음 만남 · 스킨십 · 거절

{name} 「안 잡을게요. 잘 모르는 분께 또 기대면 그분한테 더 미안해져요.」 {name}는 뻗던 손을 제 팔에 감았다.

## V04-SANAE-STRANGER-PC-NEXT_KISS_ALLOW-A

타인 · 몸 주인공쪽 · 다음 만남 · 키스 · 수락

{name} 「……익숙해서 눈 감았어요. 그분 앞에서는 눈도 못 마주치는데.」 {name}는 응한 뒤 눈꺼풀을 만졌다.

## V04-SANAE-STRANGER-PC-NEXT_KISS_REFUSE-A

타인 · 몸 주인공쪽 · 다음 만남 · 키스 · 거절

{name} 「잠깐요. 이렇게 가까우면 그분 생각을 또 미룰 것 같아요.」 {name}는 이쪽을 막고 고개를 천천히 저었다.

## V04-SANAE-STRANGER-PC-LATE_TALK-A

타인 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「당신을 더 알면 편해질 줄 알았어요. 그분께 숨길 게 더 늘 뿐이네요.」 {name}는 세던 손가락을 접었다.

## V04-SANAE-STRANGER-PC-LATE_TALK-B

타인 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「이제 오시면 반가워요. 그분께는 당신을 모른 척해야 할까 봐 미안하고요.」 {name}는 웃으려던 입술을 비뚤게 다물었다.

## V04-SANAE-STRANGER-PC-LATE_TOUCH_ALLOW-A

타인 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「이 손 기억나네요. 그분 손을 잡을 때도 생각나서 미안했어요.」 {name}는 맞잡은 손을 가까이 들여다봤다.

## V04-SANAE-STRANGER-PC-LATE_TOUCH_REFUSE-A

타인 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「오늘은 안 해요. 당신한테 익숙해지는 걸로 그분께 진 빚이 줄진 않잖아요.」 {name}는 손을 거두고 옷주름을 폈다.

## V04-SANAE-STRANGER-PC-LATE_KISS_ALLOW-A

타인 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「이런 걸 먼저 익혀 버렸네요. 그분한테 진심으로 미안하단 말은 못 하면서.」 {name}는 응한 뒤 코끝을 손끝으로 눌렀다.

## V04-SANAE-STRANGER-PC-LATE_KISS_REFUSE-A

타인 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「안 돼요. 더 있고 싶어지면 그분께 또 거짓말할 테니까요.」 {name}는 얼굴을 피하며 고개를 숙였다.

## V04-SANAE-CRUSH-UNSET-AFTER-A

짝사랑 · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「좋아한다고 먼저 말하려 했는데. 그분께는 그 전에 정리했어야 했고요.」 {name}는 옷을 꼭 쥐고 볼을 붉혔다.

## V04-SANAE-CRUSH-UNSET-AFTER-B

짝사랑 · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「기쁘긴 했어요. 그분한테 미안하니까 기쁘면 안 될 줄 알았는데.」 {name}는 웃다가 입술을 깨물었다.

## V04-SANAE-CRUSH-UNSET-NEXT_TALK-A

짝사랑 · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name} 「{pc_call}, 보고 싶었어요! ……그분께 미안하단 말부터 해야 하는데요.」 {name}는 반갑게 손을 흔들다 멈췄다.

## V04-SANAE-CRUSH-UNSET-NEXT_TALK-B

짝사랑 · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name}는 {rival_call} 앞에서 어땠느냐는 말에 웃는 입만 남겼다.

## V04-SANAE-CRUSH-UNSET-NEXT_TOUCH_ALLOW-A

짝사랑 · 몸 미정 · 다음 만남 · 스킨십 · 수락

{name} 「에헤헤…… 손 하나에 이러네요. 그분한테는 못 보여 드릴 얼굴이죠.」 {name}는 손을 잡고 배시시 웃다 숙였다.

## V04-SANAE-CRUSH-UNSET-NEXT_TOUCH_REFUSE-A

짝사랑 · 몸 미정 · 다음 만남 · 스킨십 · 거절

{name} 「손 잡으면 웃을 것 같아요. 그분께 미안하다면서 그건 좀 아니잖아요.」 {name}는 양손을 제 볼에 붙였다.

## V04-SANAE-CRUSH-UNSET-NEXT_KISS_ALLOW-A

짝사랑 · 몸 미정 · 다음 만남 · 키스 · 수락

{name} 「좋아요. ……좋다고 바로 대답하는 게 그분께는 잔인하겠죠.」 {name}는 응한 뒤 가슴 앞에 손을 모았다.

## V04-SANAE-CRUSH-UNSET-NEXT_KISS_REFUSE-A

짝사랑 · 몸 미정 · 다음 만남 · 키스 · 거절

{name} 「안 해요. 당신이 좋단 말로 그분께 한 짓을 자꾸 넘기려 하니까요, 제가.」 {name}는 입술을 피하며 한숨을 쉬었다.

## V04-SANAE-CRUSH-UNSET-LATE_TALK-A

짝사랑 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「당신 오나 기다려져요. 그분이 저한테 해 주는 걸 제가 당신한테 하네요.」 {name}는 문 쪽에 두었던 발을 거뒀다.

## V04-SANAE-CRUSH-UNSET-LATE_TALK-B

짝사랑 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「연애 얘기 상담하고 싶었어요. 그분한테요. 누구 좋아하냐고 물으시겠죠.」 {name}는 들뜬 손을 무릎으로 내렸다.

## V04-SANAE-CRUSH-UNSET-LATE_TOUCH_ALLOW-A

짝사랑 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「설레네요. 그분한테 잘못한 건 알면서 손 하나에 또 이래요.」 {name}는 이쪽 손을 두 번 고쳐 잡았다.

## V04-SANAE-CRUSH-UNSET-LATE_TOUCH_REFUSE-A

짝사랑 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「오늘은 참을래요. 그분한테 미안한 마음보다 당신이 먼저 좋을 것 같아서.」 {name}는 손을 뺀 채 발끝을 모았다.

## V04-SANAE-CRUSH-UNSET-LATE_KISS_ALLOW-A

짝사랑 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「좋아해요. 그분께 죄송하다고 해서 이 말이 없어지진 않네요.」 {name}는 입맞춤 뒤 붉어진 입가를 가렸다.

## V04-SANAE-CRUSH-UNSET-LATE_KISS_REFUSE-A

짝사랑 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「그만요. 그분께 솔직하지도 못하면서 당신께만 좋아한다고 하긴 싫어요.」 {name}는 웃으려던 얼굴을 돌렸다.

## V04-SANAE-CRUSH-PC-AFTER-A

짝사랑 · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「조금만 더…… 이러고 싶어요. 그분께 미안해도 이 말부터 나오네요.」 {name}는 이쪽에 기댄 팔을 풀지 못했다.

## V04-SANAE-CRUSH-PC-AFTER-B

짝사랑 · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「당신이 잡아 줬으면 했어요. 그분은 돌아오기만 기다리실 텐데.」 {name}는 옷을 들고 한동안 움직이지 않았다.

## V04-SANAE-CRUSH-PC-NEXT_TALK-A

짝사랑 · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name} 「왔네요! 당신 쪽으로 뛰려는 걸 참았어요. 그분께 미안해하면서도 이래요.」 {name}는 앞섰던 발을 도로 모았다.

## V04-SANAE-CRUSH-PC-NEXT_TALK-B

짝사랑 · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name}는 이쪽을 보며 들뜬 목소리를 내다 {rival_call}의 이름에 볼을 감췄다.

## V04-SANAE-CRUSH-PC-NEXT_TOUCH_ALLOW-A

짝사랑 · 몸 주인공쪽 · 다음 만남 · 스킨십 · 수락

{name} 「잡아 주세요. ……그분한텐 죄송한 마음만으론 부족할 것 같네요, 이러니까.」 {name}는 손을 먼저 내밀어 꼭 쥐었다.

## V04-SANAE-CRUSH-PC-NEXT_TOUCH_REFUSE-A

짝사랑 · 몸 주인공쪽 · 다음 만남 · 스킨십 · 거절

{name} 「안 잡을래요. 당신 손 잡으면 그분께 돌아갈 마음부터 약해져요.」 {name}는 손을 뒤로 감추며 고개를 저었다.

## V04-SANAE-CRUSH-PC-NEXT_KISS_ALLOW-A

짝사랑 · 몸 주인공쪽 · 다음 만남 · 키스 · 수락

{name} 「에헤헤, 한 번 더…… 아, 그분께는 기다리라고 해 놓고요.」 {name}는 응한 뒤 이쪽 옷깃을 끌었다 놓았다.

## V04-SANAE-CRUSH-PC-NEXT_KISS_REFUSE-A

짝사랑 · 몸 주인공쪽 · 다음 만남 · 키스 · 거절

{name} 「멈춰 주세요. 그분 생각하다가도 당신 가까우면 금방 잊어버려요.」 {name}는 제 입가 앞에 손을 세웠다.

## V04-SANAE-CRUSH-PC-LATE_TALK-A

짝사랑 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「그분이 다정하면 당신도 이럴까 생각해요. 미안해서 대답도 늦고요.」 {name}는 고름 끝을 손바닥에 접었다.

## V04-SANAE-CRUSH-PC-LATE_TALK-B

짝사랑 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「예쁘게 보이고 싶어서 머리 만졌어요. 그분 앞에선 그냥 외출인데 유난 떨지 말자고 했고요.」 {name}는 머리 장식을 빼서 쥐었다.

## V04-SANAE-CRUSH-PC-LATE_TOUCH_ALLOW-A

짝사랑 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「이 손 놓기 싫어요. 그분한텐 같은 손으로 아무렇지 않게 인사하겠죠.」 {name}는 이쪽 손에 볼을 살짝 비볐다.

## V04-SANAE-CRUSH-PC-LATE_TOUCH_REFUSE-A

짝사랑 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「오늘은 그분께 갈래요. 당신 손부터 찾는 걸 한 번은 참아 보고 싶어요.」 {name}는 손을 빼 옷고름을 반듯이 폈다.

## V04-SANAE-CRUSH-PC-LATE_KISS_ALLOW-A

짝사랑 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「당신만 보이네요. 그분도 이렇게 저만 보고 계실 텐데 미안해서요.」 {name}는 응한 뒤 눈가를 손끝으로 눌렀다.

## V04-SANAE-CRUSH-PC-LATE_KISS_REFUSE-A

짝사랑 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「더는 안 해요. 당신을 또 기다리게 될까 봐요. 그분은 절 기다리시고요.」 {name}는 얼굴을 피하고 작게 숨을 내쉬었다.

## V04-SANAE-SUBMIT-UNSET-AFTER-A

굴복 · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「그분한테 말씀하실지는 맡길게요. 제가 먼저 말할 용기는 없나 봐요.」 {name}는 옷고름을 내려다보며 웃었다.

## V04-SANAE-SUBMIT-UNSET-AFTER-B

굴복 · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「{rival_call} 앞에선 평소처럼 할게요. 미안한 티 내면 물어보실 테니까.」 {name}는 입가를 억지로 끌어올렸다.

## V04-SANAE-SUBMIT-UNSET-NEXT_TALK-A

굴복 · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name} 「그분은 잘못한 거 없어요. 제가 잘못한 걸 모르시는 것뿐이에요.」 {name}는 주먹을 폈다 다시 쥐었다.

## V04-SANAE-SUBMIT-UNSET-NEXT_TALK-B

굴복 · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name}는 {rival_call}께 괜찮다고 하던 웃음을 짓다 소매로 얼굴을 가렸다.

## V04-SANAE-SUBMIT-UNSET-NEXT_TOUCH_ALLOW-A

굴복 · 몸 미정 · 다음 만남 · 스킨십 · 수락

{name} 「네, 손은 여기요. 그분께 내밀 땐 또 숨기겠지만.」 {name}는 손을 내어 놓고 움직이지 않았다.

## V04-SANAE-SUBMIT-UNSET-NEXT_TOUCH_REFUSE-A

굴복 · 몸 미정 · 다음 만남 · 스킨십 · 거절

{name} 「지금은 놔 주세요. 그분한테 미안한 생각밖에 못 하겠어요.」 {name}는 손을 거둬 가슴에 붙였다.

## V04-SANAE-SUBMIT-UNSET-NEXT_KISS_ALLOW-A

굴복 · 몸 미정 · 다음 만남 · 키스 · 수락

{name} 「이건 쉽게 받아 주네요. 그분께 미안하단 한마디는 못 하면서요.」 {name}는 응한 뒤 웃다 목을 움츠렸다.

## V04-SANAE-SUBMIT-UNSET-NEXT_KISS_REFUSE-A

굴복 · 몸 미정 · 다음 만남 · 키스 · 거절

{name} 「못 하겠어요. 그분이 웃으시던 얼굴이 자꾸 보여서요.」 {name}는 입술을 숨기듯 고개를 숙였다.

## V04-SANAE-SUBMIT-UNSET-LATE_TALK-A

굴복 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「그분이 잘 지내냐고 물으셔서 웃었어요. ……너무 잘 웃었어요.」 {name}는 입꼬리를 손끝으로 내렸다.

## V04-SANAE-SUBMIT-UNSET-LATE_TALK-B

굴복 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「그분은 제 수다를 잘 들어 주세요. 저는 말만 계속하면 안 들킬까 싶어서 떠드는데.」 {name}는 웃음 섞인 말을 끊고 숨을 삼켰다.

## V04-SANAE-SUBMIT-UNSET-LATE_TOUCH_ALLOW-A

굴복 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「따뜻하네요. 그분한테 미안하다고 하면서 이 손에 편해지고요.」 {name}는 맡긴 손을 작게 움켜쥐었다.

## V04-SANAE-SUBMIT-UNSET-LATE_TOUCH_REFUSE-A

굴복 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「그 손만은 오늘 안 잡을래요. 그분께 보여 드릴 손도 없어진 것 같아서.」 {name}는 두 손을 소매 안에 넣었다.

## V04-SANAE-SUBMIT-UNSET-LATE_KISS_ALLOW-A

굴복 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「……그분한테 못할 짓이라고 해 놓고 또 받아 주네요.」 {name}는 입맞춤 뒤 눈을 천천히 내렸다.

## V04-SANAE-SUBMIT-UNSET-LATE_KISS_REFUSE-A

굴복 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「오늘은 싫어요. 그분한테 미안해할 시간도 좀 주세요.」 {name}는 고개를 돌려 이쪽을 보지 않았다.

## V04-SANAE-SUBMIT-PC-AFTER-A

굴복 · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「옆이 편해서 안 일어났어요. 그분이 기다리는 건 나중에 생각했고요.」 {name}는 이쪽에 얹은 팔을 느리게 풀었다.

## V04-SANAE-SUBMIT-PC-AFTER-B

굴복 · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「더 있으라고 하시면 있을 거예요. 그분께는 미안하다고만 생각하면서.」 {name}는 옷을 챙겨 놓고도 손을 뻗었다.

## V04-SANAE-SUBMIT-PC-NEXT_TALK-A

굴복 · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name} 「부르실까 봐 왔어요. 그분께 돌아갈 시간부터 놓쳤지만요.」 {name}는 문턱을 넘자마자 어깨를 풀었다.

## V04-SANAE-SUBMIT-PC-NEXT_TALK-B

굴복 · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name}는 이쪽 옷자락을 잡은 채 {rival_call}의 안부에는 고개만 끄덕였다.

## V04-SANAE-SUBMIT-PC-NEXT_TOUCH_ALLOW-A

굴복 · 몸 주인공쪽 · 다음 만남 · 스킨십 · 수락

{name} 「에헤헤, 손부터 잡네요. 그분한테 미안하다며 숨기던 제가.」 {name}는 이쪽 손을 찾아 두 손으로 잡았다.

## V04-SANAE-SUBMIT-PC-NEXT_TOUCH_REFUSE-A

굴복 · 몸 주인공쪽 · 다음 만남 · 스킨십 · 거절

{name} 「지금은 놓을래요. 그분한테 돌아갈 힘까지 풀려 버리겠어요.」 {name}는 얽힌 손가락을 힘주어 폈다.

## V04-SANAE-SUBMIT-PC-NEXT_KISS_ALLOW-A

굴복 · 몸 주인공쪽 · 다음 만남 · 키스 · 수락

{name} 「당신 오시면 눈 감게 돼요. 그분께 미안하던 것도 잠깐은 없어지고요.」 {name}는 응한 뒤 이쪽 옆에 붙어 앉았다.

## V04-SANAE-SUBMIT-PC-NEXT_KISS_REFUSE-A

굴복 · 몸 주인공쪽 · 다음 만남 · 키스 · 거절

{name} 「그만요. 그분 생각을 하는 데도 시간이 필요해요. 계속 잊으니까.」 {name}는 얼굴 앞에 옷소매를 들었다.

## V04-SANAE-SUBMIT-PC-LATE_TALK-A

굴복 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「그분한텐 바쁘다고 했어요. 당신 오시나 기다리느라 바빴네요.」 {name}는 제 말을 듣고 작게 헛웃음 쳤다.

## V04-SANAE-SUBMIT-PC-LATE_TALK-B

굴복 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「그분께 신경 쓰지 말라 했어요. 당신 오시나 신경 쓰느라 대답도 못 했으면서.」 {name}는 창 쪽으로 돌렸던 고개를 내렸다.

## V04-SANAE-SUBMIT-PC-LATE_TOUCH_ALLOW-A

굴복 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「이 손이 좋아요. 그분께 미안한 것보다 먼저 좋아하는 제가 미워요.」 {name}는 손을 잡은 채 이마를 낮췄다.

## V04-SANAE-SUBMIT-PC-LATE_TOUCH_REFUSE-A

굴복 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「오늘은 안 잡을래요. 그분께 가겠다는 약속 하나라도 지키고 싶어요.」 {name}는 손을 뺀 뒤 신발을 챙겼다.

## V04-SANAE-SUBMIT-PC-LATE_KISS_ALLOW-A

굴복 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「제가 원해서 또 받아 줬네요. 그분한테는 그게 제일 미안한데.」 {name}는 입맞춤 뒤 떨리는 웃음을 흘렸다.

## V04-SANAE-SUBMIT-PC-LATE_KISS_REFUSE-A

굴복 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「오늘은 여기까지요. 그분께 미안하다는 말을 생각만으로 끝내긴 싫어서요.」 {name}는 가까워진 어깨를 조용히 밀었다.

## V04-SANAE-COERCED-UNSET-AFTER-A

협박 중 · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「그분께 잘못한 건 알아요. 그렇다고 당신이 겁줘도 되는 건 아니잖아요.」 {name}는 옷을 꼭 여미고 눈을 들었다.

## V04-SANAE-COERCED-UNSET-AFTER-B

협박 중 · 몸 미정 · 직후 · 관계 직후 · 해당 없음

{name} 「{rival_call}한테 말하신다는 거 알았어요. 더 들으면 울 것 같으니까 그만요.」 {name}는 리본을 쥔 손에 힘을 줬다.

## V04-SANAE-COERCED-UNSET-NEXT_TALK-A

협박 중 · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name} 「그분 이름으로 절 놀리지 마세요. 전 그 말에 못 웃어요.」 {name}는 웃으려던 입을 꾹 닫았다.

## V04-SANAE-COERCED-UNSET-NEXT_TALK-B

협박 중 · 몸 미정 · 다음 만남 · 대화하기 · 해당 없음

{name}는 {rival_call}께 전할까 묻는 말에 웃음부터 멈췄다.

## V04-SANAE-COERCED-UNSET-NEXT_TOUCH_ALLOW-A

협박 중 · 몸 미정 · 다음 만남 · 스킨십 · 수락

{name} 「……손만이에요. 그분한테 비밀로 해 준다고 고맙단 말까지 바라진 마세요.」 {name}는 손을 내어 놓고 시선을 피했다.

## V04-SANAE-COERCED-UNSET-NEXT_TOUCH_REFUSE-A

협박 중 · 몸 미정 · 다음 만남 · 스킨십 · 거절

{name} 「싫어요. 그분께 죄송하다고 당신 손까지 참아야 해요?」 {name}는 손목을 빼며 눈을 크게 떴다.

## V04-SANAE-COERCED-UNSET-NEXT_KISS_ALLOW-A

협박 중 · 몸 미정 · 다음 만남 · 키스 · 수락

{name} 「이만큼이면 됐죠. 그분한테 할 말이 더 생겼다고 겁주진 말고요.」 {name}는 짧게 응한 뒤 어깨를 굳혔다.

## V04-SANAE-COERCED-UNSET-NEXT_KISS_REFUSE-A

협박 중 · 몸 미정 · 다음 만남 · 키스 · 거절

{name} 「안 해요. 그분께 미움받을까 무서운 걸로 이러지 마세요.」 {name}는 얼굴을 피하며 두 손을 들었다.

## V04-SANAE-COERCED-UNSET-LATE_TALK-A

협박 중 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「그분이 상처받을까 숨기는데 계속 더 나빠지네요. 당신은 그걸 아시겠죠.」 {name}는 말아 쥔 소매를 펴지 못했다.

## V04-SANAE-COERCED-UNSET-LATE_TALK-B

협박 중 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「그분이 모르면 된다고 자꾸 말하게 돼요. 그게 그분 위하는 말은 아닌데요.」 {name}는 벌린 손가락을 꼭 붙였다.

## V04-SANAE-COERCED-UNSET-LATE_TOUCH_ALLOW-A

협박 중 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「잠깐은 괜찮아요. 그분께 숨겨 주는 값이라는 말은 하지 마세요.」 {name}는 손을 맡기되 몸을 멀리 뒀다.

## V04-SANAE-COERCED-UNSET-LATE_TOUCH_REFUSE-A

협박 중 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「안 잡아요. 그분께 잘못한 일로 당신한테 벌 받는 건 싫어요.」 {name}는 내밀던 손을 힘주어 접었다.

## V04-SANAE-COERCED-UNSET-LATE_KISS_ALLOW-A

협박 중 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「……또 받아 줬네요. 그분께 미안한 건 저만 챙기면 되겠죠.」 {name}는 응한 뒤 입가에 손을 대고 굳었다.

## V04-SANAE-COERCED-UNSET-LATE_KISS_REFUSE-A

협박 중 · 몸 미정 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「그만하세요. 그분께 말하신대도 지금은 싫어요.」 {name}는 이쪽 얼굴을 양손으로 단호하게 밀었다.

## V04-SANAE-COERCED-PC-AFTER-A

협박 중 · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「당신 옆으로 갔다고 그런 말까지 괜찮은 건 아니에요. 그분께도 미안하고요.」 {name}는 이쪽 어깨에서 몸을 일으켰다.

## V04-SANAE-COERCED-PC-AFTER-B

협박 중 · 몸 주인공쪽 · 직후 · 관계 직후 · 해당 없음

{name} 「끌리는 건 맞아요. 그분한테 들킬까 겁먹는 것까지 좋아하는 건 아니고요.」 {name}는 고름 매듭을 꽉 조여 묶었다.

## V04-SANAE-COERCED-PC-NEXT_TALK-A

협박 중 · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name} 「오고 싶었어요. 그런데 그분께 말씀하셨나 무서운 마음도 같이 와요.」 {name}는 인사하려던 손을 떨궜다.

## V04-SANAE-COERCED-PC-NEXT_TALK-B

협박 중 · 몸 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

{name}는 이쪽 손 쪽으로 움직이다 {rival_call}의 이름에 무릎을 붙들었다.

## V04-SANAE-COERCED-PC-NEXT_TOUCH_ALLOW-A

협박 중 · 몸 주인공쪽 · 다음 만남 · 스킨십 · 수락

{name} 「잡고는 싶었어요. 그분한테 이걸 말할까 겁주진 마세요.」 {name}는 손을 맞잡은 채 이쪽 눈치를 봤다.

## V04-SANAE-COERCED-PC-NEXT_TOUCH_REFUSE-A

협박 중 · 몸 주인공쪽 · 다음 만남 · 스킨십 · 거절

{name} 「안 잡을래요. 그분한테 미안한 걸 당신이 자꾸 이용하니까.」 {name}는 손을 피하며 팔꿈치를 모았다.

## V04-SANAE-COERCED-PC-NEXT_KISS_ALLOW-A

협박 중 · 몸 주인공쪽 · 다음 만남 · 키스 · 수락

{name} 「제가 받아 준 건 맞아요. 그렇다고 그분한테 들킬까 떠보지는 마세요.」 {name}는 응한 뒤 애써 표정을 폈다.

## V04-SANAE-COERCED-PC-NEXT_KISS_REFUSE-A

협박 중 · 몸 주인공쪽 · 다음 만남 · 키스 · 거절

{name} 「멈춰요. 당신에게 끌린다고 그분을 빌미로 겁주는 건 싫어요.」 {name}는 고개를 젖혀 입술을 피했다.

## V04-SANAE-COERCED-PC-LATE_TALK-A

협박 중 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「그분께 미안하다니까 질투하냐고 하셨죠. 전 그 농담엔 못 웃어요.」 {name}는 웃는 모양으로 벌렸던 입을 닫았다.

## V04-SANAE-COERCED-PC-LATE_TALK-B

협박 중 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 대화하기 · 해당 없음

{name} 「그분한테 당신 나쁜 분 아니랬어요. 제가 좋을 때도 있다고 겁주시는 건 빼고요.」 {name}는 애써 올린 입꼬리를 내렸다.

## V04-SANAE-COERCED-PC-LATE_TOUCH_ALLOW-A

협박 중 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 수락

{name} 「이 손은 좋아요. 그분께 죄송해하는 마음까지 장난으로 만들진 마세요.」 {name}는 손을 잡고도 손목을 굳혔다.

## V04-SANAE-COERCED-PC-LATE_TOUCH_REFUSE-A

협박 중 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 스킨십 · 거절

{name} 「놓아 주세요. 그분께 갈지 말지 오늘은 제가 정하고 싶어요.」 {name}는 맞잡은 손에서 손끝을 밀어 뺐다.

## V04-SANAE-COERCED-PC-LATE_KISS_ALLOW-A

협박 중 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 수락

{name} 「눈 감으면 편하네요. 그분한테 또 숨겨야 한다는 건 잠깐 잊고요.」 {name}는 입맞춤 뒤 소리 없이 입술을 다물었다.

## V04-SANAE-COERCED-PC-LATE_KISS_REFUSE-A

협박 중 · 몸 주인공쪽 · 시간이 지난 뒤 (2일 이상) · 키스 · 거절

{name} 「오늘은 안 돼요. 그분께 죄송하다고 말할 용기는 제 걸로 내고 싶어요.」 {name}는 다가온 얼굴을 피하고 허리를 폈다.


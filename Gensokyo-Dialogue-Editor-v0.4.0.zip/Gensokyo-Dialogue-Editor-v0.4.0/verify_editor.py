"""Observable browser checks against the actual generated HTML."""
import functools,http.server,json,threading,tempfile,collections
from pathlib import Path
from playwright.sync_api import sync_playwright
from read_edits import compare
ROOT=Path(__file__).resolve().parent
base=json.loads((ROOT/'review/all_dialogue.json').read_text());checks=[];errors=[]
class Handler(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Handler,directory=str(ROOT)))
threading.Thread(target=server.serve_forever,daemon=True).start()
url=f'http://127.0.0.1:{server.server_address[1]}/review/index.html'
with sync_playwright()as pw:
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 context=browser.new_context(accept_downloads=True,viewport={'width':1440,'height':1000});page=context.new_page()
 page.on('pageerror',lambda e:errors.append(str(e)));page.on('dialog',lambda d:d.accept());page.goto(url);page.wait_for_selector('article.card')
 def snap():return page.evaluate('documentForExport()')
 initial=snap();assert len(initial['entries'])==784 and not compare(initial,base)
 assert page.locator('article.card').first.locator('.preview').inner_text().startswith('하쿠레이 레이무 「')
 assert '」 레이무는'in page.locator('article.card').first.locator('.preview').inner_text()
 checks.append('fresh editor: 784 pending entries; full speaker, short narrator, required spaces')
 card=page.locator('article.card').first;card.get_by_text('APK 순정 대사 비교',exact=True).click()
 assert '{name}'in card.locator('details').nth(1).inner_text() and 'reimu/lines/'in card.locator('details').nth(1).inner_text()
 checks.append('native APK references displayed with original row IDs and direction caveat')
 assert page.locator('.legacy').count()>0
 checks.append('previous user edits/statuses visible as separate references; new approvals reset')
 # Selection insertion through visible per-card buttons, not injected state.
 area=card.locator('textarea[data-field=text]');area.fill('앞뒤');area.evaluate('a=>a.setSelectionRange(1,1)')
 card.locator('[data-token="{pc}"]').click();assert area.input_value()=='앞{pc}뒤';assert area.evaluate('a=>a.selectionStart')==5
 area.evaluate('a=>a.setSelectionRange(1,5)');card.locator('[data-token="{rival}"]').click();assert area.input_value()=='앞{rival}뒤'
 assert card.locator('[data-field=decision]').input_value()=='pending'
 checks.append('name buttons insert/replace selection, preserve caret, and do not approve text automatically')
 area.fill('{name} 「주인공, 라이벌, {주인공}, {라이벌}, {pc}, {rival}.」 {name}는 고개를 숙였다.')
 card.locator('[data-field=decision]').select_option('exclude');card.locator('textarea[data-field=note]').fill('주인공 라이벌 메모는 보존')
 page.locator('#convertNames').click();assert page.locator('#replaceDialog').evaluate('d=>d.open')
 assert not page.locator('#replaceFields').is_visible();assert '4곳'in page.locator('#replaceCount').inner_text()
 page.locator('#replaceApply').click();a=snap()['entries'][0]
 assert a['edited_text']=='{name} 「{pc}, {rival}, {pc}, {rival}, {pc}, {rival}.」 {name}는 고개를 숙였다.'
 assert a['decision']=='exclude'and a['note']=='주인공 라이벌 메모는 보존'
 page.locator('#replaceUndo').click();assert snap()['entries'][0]['edited_text'].startswith('{name} 「주인공, 라이벌')
 checks.append('name conversion preview/apply/undo; existing tokens stay intact; notes and excluded status preserved')
 page.locator('#replaceClose').click();page.keyboard.press('Control+h');assert page.locator('#replaceDialog').evaluate('d=>d.open')
 assert page.locator('#replaceFields').is_visible();page.locator('#replaceClose').click()
 # All/filtered changes include hidden/excluded entries and retain review metadata.
 page.get_by_label('캐릭터',exact=True).select_option('하쿠레이 레이무');page.get_by_label('주인공과의 관계',exact=True).select_option('싫어함')
 assert '28개'in page.locator('#count').inner_text();before=snap()
 page.locator('#openReplace').click();page.locator('#replaceFind').fill('{name}');page.locator('#replaceWith').fill('{short}');page.locator('#replaceScope').select_option('all');page.locator('#replaceApply').click()
 after=snap()
 for a,b in zip(after['entries'],before['entries']):
  assert a['edited_text']==b['edited_text'].replace('{name}','{short}')
  assert (a['decision'],a['note'])==(b['decision'],b['note'])
 page.locator('#replaceUndo').click();assert snap()['entries']==before['entries']
 page.locator('#replaceScope').select_option('filtered');page.locator('#replaceApply').click()
 for a,b in zip(snap()['entries'],before['entries']):assert a['edited_text']==(b['edited_text'].replace('{name}','{short}')if a['id'].startswith('V04-REIMU-HATE-')else b['edited_text'])
 page.locator('#replaceUndo').click();page.locator('#replaceClose').click()
 checks.append('Ctrl+H all/filtered scopes, hidden characters, excluded entries, metadata preservation, undo')
 assert page.evaluate("literalReplace('a.b aXb','a.b','$&',true).text")=='$& aXb'
 assert page.evaluate("literalReplace('Test test TEST','test','X',false).text")=='X X X'
 assert page.evaluate("literalReplace('abc','b','',true).text")=='ac'
 checks.append('literal replacement handles regex punctuation, dollar text, case-insensitive and empty replacement')
 # New manual changes are protected from bulk undo.
 page.locator('#openReplace').click();page.locator('#replaceScope').select_option('all');page.locator('#replaceApply').click();page.locator('#replaceClose').click()
 page.locator('article.card').first.locator('textarea[data-field=text]').fill('나중에 직접 수정한 본문')
 page.locator('#openReplace').click();page.locator('#replaceUndo').click();page.locator('#replaceClose').click()
 assert snap()['entries'][0]['edited_text']=='나중에 직접 수정한 본문'
 checks.append('undo keeps a later manual edit')
 # Preview names/particles and text-node rendering.
 area=page.locator('article.card').first.locator('textarea[data-field=text]')
 area.fill('{name} 「{pc}은(는) {rival}을(를) 봤어. <img src=x onerror=alert(1)>」 {name}는 멈췄다.')
 page.locator('#pcName').fill('철수');page.locator('#rivalName').fill('영희')
 preview=page.locator('article.card').first.locator('.preview');assert '철수는 영희를'in preview.inner_text();assert preview.locator('img').count()==0
 colors=preview.locator('span').evaluate_all('xs=>xs.map(x=>getComputedStyle(x).color)')
 assert 'rgb(255, 102, 102)'in colors and 'rgb(255, 255, 255)'in colors and 'rgb(160, 160, 160)'in colors
 checks.append('custom names, Korean particles, name/speech/narration colors, safe literal HTML preview')
 # Actual download and independent Python reader.
 with page.expect_download()as info:page.locator('#export').click()
 download=info.value;save=ROOT/'observations/browser-saved-example.json';download.save_as(save)
 exported=json.loads(save.read_text());assert exported['entries']==snap()['entries'];changes=compare(exported,base);assert len(changes)==1
 page.locator('article.card').first.locator('textarea[data-field=text]').fill('불러오기 전 다른 본문')
 page.locator('#importFile').set_input_files(save);page.wait_for_function("document.querySelector('[data-field=text]').value.includes('<img')")
 assert snap()['entries']==exported['entries'];page.reload();page.wait_for_selector('article.card');assert snap()['entries']==exported['entries']
 checks.append('actual JSON download -> independent Python validation -> import -> reload restores text/status/note/names')
 # Reject a corrupted/old review without changing the current document.
 bad=ROOT/'observations/invalid-example.json';wrong=json.loads(save.read_text());wrong['entries'][0]['original_text']='wrong';bad.write_text(json.dumps(wrong))
 previous=snap()['entries'];page.locator('#importFile').set_input_files(bad);page.wait_for_function("document.querySelector('#message').textContent.includes('불러오지 않았습니다')");assert snap()['entries']==previous
 page.locator('#importFile').set_input_files(ROOT/'archive/사용자원본-v0.3.0.json');page.wait_for_function("document.querySelector('#message').textContent.includes('다른 버전')");assert snap()['entries']==previous
 checks.append('corrupt and previous-version imports rejected atomically; archived original untouched')
 page.locator('#resetFilters').click();page.evaluate('window.scrollTo(0,document.body.scrollHeight)')
 box=page.locator('#export').bounding_box();assert box and box['x']+box['width']<=1440 and 0<=box['y']<1000-box['height']
 # Fresh page screenshot rather than the deliberately invalid test text.
 clean=browser.new_context(viewport={'width':1440,'height':1000});fresh=clean.new_page();fresh.goto(url);fresh.wait_for_selector('article.card')
 fresh.locator('article.card').first.get_by_text('APK 순정 대사 비교',exact=True).click();fresh.locator('article.card').first.scroll_into_view_if_needed()
 fresh.screenshot(path=str(ROOT/'observations/desktop.png'))
 mobile=browser.new_context(viewport={'width':390,'height':844},is_mobile=True);mp=mobile.new_page();mp.goto(url);mp.wait_for_selector('article.card');mp.evaluate('window.scrollTo(0,document.body.scrollHeight)')
 box=mp.locator('#export').bounding_box();assert box and 0<=box['x']and box['x']+box['width']<=391 and 0<=box['y']and box['y']+box['height']<=844
 with mp.expect_download()as mi:mp.locator('#export').click()
 assert mi.value.suggested_filename.startswith('Gensokyo-Dialogue-Edits-v0.4.0-')
 mp.screenshot(path=str(ROOT/'observations/mobile.png'))
 checks.append('fixed right save remains clickable after scrolling on desktop/mobile; mobile download succeeds')
 assert not errors,errors
 browser.close()
server.shutdown()
result={'browser_checks':'passed','checks':checks,'page_errors':errors}
(ROOT/'observations/browser-validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False))

"""Build the review-only editor from independently authored full paragraphs."""
import json,re,collections,hashlib,statistics
from pathlib import Path
ROOT=Path(__file__).resolve().parent
AUDIT=ROOT.parent/'original-dialogue-audit'
if not AUDIT.exists():AUDIT=ROOT/'original-dialogue'
DATASET='gensokyo-dialogue-editor-v0.4.0'
APK_SHA='13c4c3c52e930278e0853771508308ff7d720efd21dc4a0ef766012a3e35d333'
RELATIONS={'hate':'싫어함','friend':'친구','secret':'연인(비밀)','stranger':'타인','crush':'짝사랑','submit':'굴복','coerced':'협박 중'}
ORDER=[('after','A'),('after','B'),('next_talk','A'),('next_talk','B'),('next_touch_allow','A'),('next_touch_refuse','A'),('next_kiss_allow','A'),('next_kiss_refuse','A'),('late_talk','A'),('late_talk','B'),('late_touch_allow','A'),('late_touch_refuse','A'),('late_kiss_allow','A'),('late_kiss_refuse','A')]

def normalized(t):
    for a,b in [('{rival}이랑','{rival}이랑(랑)'),('{rival}랑','{rival}이랑(랑)'),('{rival}은','{rival}은(는)'),('{rival}가','{rival}이(가)'),('{rival}이 ','{rival}이(가) '),('{rival}을','{rival}을(를)'),('{rival}과','{rival}과(와)')]:
        t=re.sub(re.escape(a)+r'(?!\()',lambda _m:b,t)
    return t

def native_rows(c):
    return [json.loads(x)for x in (AUDIT/f'{c}.jsonl').read_text().splitlines()]

def native_refs(c,scene,rel,rows):
    action='sex_after'if scene=='after'else scene.split('_')[1]
    key=action+('_refused'if scene.endswith('_refuse')else'')
    specific=[r for r in rows if '/'+key+'/'in r['path'] and 'rival_lover'in r['tags'] and 'cheating'in r['tags'] and not any(x in r['tags']for x in ['submit','rival_present','came'])]
    guilty=[r for r in rows if '/'+('sex_after'if scene=='after'else'talk')+'/'in r['path'] and set(r['tags'])=={'lover','guilty'}]
    voice=[r for r in rows if '/'+key+'/'in r['path'] and (rel in r['tags']if rel not in['secret','coerced','submit']else'lover'in r['tags'])]
    if not voice:voice=[r for r in rows if '/'+key+'/'in r['path'] and not r['tags']]
    result=[];seen=set()
    for r in specific[:2]+guilty[:2]+voice[:2]:
        if r['id']not in seen:
            result.append({'id':r['id'],'tags':r['tags'],'text':r['ko'],'use':'반대 방향 죄책감 반응 참고'if'lover'in r['tags']and'guilty'in r['tags']else'원본 말투·행동 참고'});seen.add(r['id'])
    return result

def build():
    chars=json.loads((ROOT/'characters.json').read_text());entries=[];native={}
    for c,info in chars.items():
        rows=native_rows(c);native[c]=rows
        groups=(ROOT/'drafts'/f'{c}.txt').read_text().strip().split('[')[1:]
        assert len(groups)==14
        for group in groups:
            head,*texts=group.strip().splitlines();rel,body=head[:-1].split('/');assert rel in RELATIONS and body in['pc','unset'];assert len(texts)==14
            for text,(scene,v)in zip(texts,ORDER):
                t=normalized(text);assert t.startswith('{name}');assert not re.search(r'[ぁ-ヺ一-龯]',t)
                assert not re.search(r'\{name\}「|」\{name\}',t)
                assert re.fullmatch(r'\{name\} 「[^「」]+」 \{name\}.+|\{name\}[^「」]+',t)
                if scene=='after':time,action,gate='직후','관계 직후','해당 없음'
                else:
                    phase,act,*g=scene.split('_');time='다음 만남'if phase=='next'else'시간이 지난 뒤 (2일 이상)';action={'talk':'대화하기','touch':'스킨십','kiss':'키스'}[act];gate={'allow':'수락','refuse':'거절'}.get(g[0]if g else'','해당 없음')
                entries.append({'id':f'V04-{c.upper()}-{rel.upper()}-{body.upper()}-{scene.upper()}-{v}','character_key':c,'character':info['name'],'relation_key':rel,'relation':RELATIONS[rel],'body_key':body,'body_state':'주인공쪽'if body=='pc'else'미정','scene_key':scene,'time':time,'action':action,'gate':gate,'variant':v,'kind':'spoken'if'「'in t else'narrative','kind_label':'대사 → 짧은 지문'if'「'in t else'지문만','premise':'rival_current_lover_and_voluntary_pc_affair','text':t,'source_refs':native_refs(c,scene,rel,rows)})
    assert len(entries)==784 and len({e['text']for e in entries})==784
    narration=[e['text'].split('」 ',1)[-1]for e in entries]
    assert len(set(narration))==len(narration),'Repeated complete narration'
    buckets=collections.Counter((e['character_key'],e['relation_key'],e['body_key'],e['scene_key'])for e in entries)
    assert len(buckets)==616 and set(buckets.values())=={1,2}
    old=json.loads((ROOT/'archive/반영된수정본-v0.3.1.json').read_text());prior=collections.defaultdict(list)
    for r in old['entries']:
        if r['edited_text']!=r['original_text']or r['decision']!='pending'or r['note']:
            key='/'.join(r[k]for k in['character_key','relation_key','body_key','scene_key'])
            prior[key].append(r)
    counts={'complete_outputs':len(entries),'spoken_outputs':sum(e['kind']=='spoken'for e in entries),'narration_only_outputs':sum(e['kind']=='narrative'for e in entries),'conditions':len(buckets),'per_character':196,'unique_complete_templates':len(set(e['text']for e in entries)),'unique_complete_narrations':len(set(narration)),'unique_spoken_strings':len({e['text'].split('「')[1].split('」')[0]for e in entries if'「'in e['text']}),'median_template_characters':statistics.median(len(e['text'])for e in entries),'max_template_characters':max(len(e['text'])for e in entries),'max_narration_characters':max(len(s)for s in narration)}
    doc={'dataset_id':DATASET,'schema_version':2,'source_apk_sha256':APK_SHA,'characters':chars,'counts':counts,'purpose':'라이벌의 현재 연인이 자발적으로 주인공과 외도한 뒤의 미발각·비공개 분기. 전면 재작성 검토본. APK 미적용.','premise':{'rival_relation':'lover','rival_lover_at_event':True,'event_actor':'pc','event_kind':'voluntary','rival_knows':False,'rival_permission':False},'initial_review':{},'initial_preview_names':old['preview_names'],'previous_reviews':dict(prior),'entries':entries}
    out=ROOT/'review';out.mkdir(exist_ok=True)
    (out/'all_dialogue.json').write_text(json.dumps(doc,ensure_ascii=False,indent=2)+'\n')
    for c,info in chars.items():
        lines=[f"# {info['name']} · v0.4.0",'','라이벌의 현재 연인 · 자발적 외도 후 · 미발각. 전부 미검토.','']
        for e in entries:
            if e['character_key']!=c:continue
            lines += [f"## {e['id']}",'',f"{e['relation']} · 몸 {e['body_state']} · {e['time']} · {e['action']} · {e['gate']}",'',e['text'],'']
        (out/f'{c}.md').write_text('\n'.join(lines)+'\n')
    (out/'전체목록.md').write_text('# 전체 목록\n\n'+ '\n'.join(f'- [{v["name"]} · 196개]({k}.md)'for k,v in chars.items())+'\n\n전체 784개, 조건 616개. 직후·대화는 조건당 2개, 스킨십·키스는 수락/거절 각각 1개다. 후보 소진 시 원래 대사로 돌아가도록 설계했다.\n')
    payload=json.dumps(doc,ensure_ascii=False).replace('<','\\u003c').replace('>','\\u003e').replace('&','\\u0026')
    (out/'index.html').write_text((ROOT/'editor_template.html').read_text().replace('__DATA__',payload))
    refs={r['id']:r for e in entries for r in e['source_refs']}
    # Include the complete extracted original active character/common transcripts.
    origin=ROOT/'original-dialogue';origin.mkdir(exist_ok=True)
    import shutil
    for c in [*chars,'basic']:
        src,dst=AUDIT/f'{c}.jsonl',origin/f'{c}.jsonl'
        if src.resolve()!=dst.resolve():shutil.copyfile(src,dst)
    (ROOT/'원본대조목록.json').write_text(json.dumps({'apk_sha256':APK_SHA,'referenced_original_rows':len(refs),'references':list(refs.values())},ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(counts,ensure_ascii=False))
if __name__=='__main__':build()

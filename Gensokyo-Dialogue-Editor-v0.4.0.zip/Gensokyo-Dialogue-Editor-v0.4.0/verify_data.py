import json,re,collections,hashlib,copy
from pathlib import Path
from review_route import route,candidates
ROOT=Path(__file__).parent
d=json.loads((ROOT/'review/all_dialogue.json').read_text());es=d['entries']
assert len(es)==784 and not d['initial_review']
assert collections.Counter(e['character_key']for e in es)==dict.fromkeys(['reimu','marisa','sakuya','sanae'],196)
assert len(set(e['text']for e in es))==784
n=[e['text'].split('」 ',1)[-1]for e in es];assert len(set(n))==784
assert sum('「'not in e['text']for e in es)==56
assert max(map(len,n))==51
sources={c:{r['id']:r for r in map(json.loads,(ROOT/'original-dialogue'/f'{c}.jsonl').read_text().splitlines())}for c in ['reimu','marisa','sakuya','sanae']}
for e in es:
 assert set(re.findall(r'\{([^}]+)\}',e['text']))<=set(['name','pc','rival','pc_call','rival_call'])
 assert not re.search(r'\{name\}「|」\{name\}|어제|속마음|[ぁ-ヺ一-龯]',e['text'])
 assert e['premise']=='rival_current_lover_and_voluntary_pc_affair'and e['source_refs']
 assert re.fullmatch(r'\{name\} 「[^「」]+」 \{name\}.+|\{name\}[^「」]+',e['text'])
 for ref in e['source_refs']:
  char=ref['id'].split('/')[0];src=sources[char]
  assert src[ref['id']]['ko']==ref['text'] and src[ref['id']]['tags']==ref['tags']
base={'character_key':'reimu','pc_relation':'friend','rival_relation':'lover','private_context':True,'body_lean':'pc','day':10,'event':{'actor':'pc','rival_lover_at_event':True,'known_to_heroine':True,'kind':'voluntary','day':10},'action':'after','immediate_event_end':True,'first_reunion_session':True,'existing_gate':'allow'}
covered=set()
for e in es:
 c=copy.deepcopy(base);c['character_key']=e['character_key'];c['pc_relation']='lover'if e['relation_key']=='secret'else e['relation_key'];c['is_public']=False;c['body_lean']='pc'if e['body_key']=='pc'else''
 if e['scene_key']=='after':c['action']='after'
 else:
  phase,act,*g=e['scene_key'].split('_');c['action']=act;c['day']=11 if phase=='next'else 17;c['existing_gate']=g[0]if g else'allow'
 assert route(c)==tuple(e[k]for k in['character_key','relation_key','body_key','scene_key'])
 ids=candidates(c,d);assert e['id']in ids and candidates(c,d,recently_shown=ids)==[]
 covered.add(route(c))
assert len(covered)==616
for key,values in {'rival_relation':['friend','crush','hate','wavering','quarrel',''],'rival_present':[True],'rival_knows':[True],'rival_permission':[True],'private_context':[False],'existing_special_branch':[True],'body_lean':['rival',None],'day':[9,None]}.items():
 for v in values:
  c=copy.deepcopy(base);c[key]=v;assert route(c)is None,(key,v)
for key,values in {'kind':['forced','coerced','sleeping','hypno','unknown'],'actor':['rival'],'rival_lover_at_event':[False,None],'known_to_heroine':[False,None],'day':[None,11]}.items():
 for v in values:
  c=copy.deepcopy(base);c['event'][key]=v;assert route(c)is None,(key,v)
c=copy.deepcopy(base);c.update(pc_relation='lover',is_public=True);assert route(c)is None
c=copy.deepcopy(base);c.update(action='kiss',existing_gate='refuse',day=11);assert route(c)[-1]=='next_kiss_refuse'
c.update(day=12);assert route(c)[-1]=='late_kiss_refuse'
c.update(day=11,first_reunion_session=False);assert route(c)is None
old=ROOT/'archive/사용자원본-v0.3.0.json'
assert hashlib.sha256(old.read_bytes()).hexdigest()=='035e007d3bbdcad21db03b57b187e10103d62dc054dc9c6226fe15b02659e32f'
print(json.dumps({'data_checks':'passed','covered_condition_buckets':len(covered),'complete_outputs':len(es),'source_refs_verified':sum(len(e['source_refs'])for e in es),'original_user_upload_unchanged':True},ensure_ascii=False))

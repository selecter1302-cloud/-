# BLACK VEIL · 최후 방어선 — NIGHTMARE INTIMACY v0.8

성인 여성 보좌관과 함께하는 한국어 탑뷰 타워 디펜스입니다. Windows 10/11 x64용 오프라인 싱글 플레이 게임입니다. ZIP을 풀고 `BlackVeil.exe`를 실행하면 됩니다.

## v0.8 변경

- **의상 56벌 전부 상반신 클로즈업**. 288픽셀로 줄인 그림을 다시 키우던 단계를 제거했습니다. 최초 정장 얼굴과 각 의상의 원본 픽셀을 그대로 가져오며, 새 의상은 800픽셀 이상의 원본 상반신 이미지를 직접 표시합니다. 그림과 썸네일 모두 클로즈업입니다. 다른 얼굴을 덮어씌우거나 눈을 다시 그리지 않습니다.
- **호감도 8 → 16단계**. 후반 연인 전용 대화, 8개 새 관계 에피소드, 더 가까운 거리·포옹·입맞춤·함께할 내일을 묻는 질문을 추가했습니다. 플레이어 질문과 보좌관 질문이 각각 32개이며, 준비된 NPC 대사는 총 866개입니다. 기존 24개 질문에도 후반 연인 답변을 추가했습니다. 존댓말을 유지하며 우정 선택은 존중합니다.
- **부위별 터치**. 그림의 머리·볼·어깨·손·옷깃을 누르면 호감도에 맞는 대사가 나옵니다. 5개 부위 × 16단계의 반응을 준비했습니다. 화면 밖의 손은 쉘터 → 손길·부위별 교감 버튼으로도 선택할 수 있습니다. 진행 중 선택지는 터치로 덮어쓰지 않습니다.
- **장신구 시스템 제거 → 선물함**. 장미·백합·튤립 꽃다발, 초콜릿, 커피, 차, 시집, 오르골, 편지, 향초, 곰 인형, 압화 책갈피의 12종입니다. 구매해 보관하거나 바로 건네고, 선물할 때 한 개씩 소모합니다. 첫 선물과 반복 선물에 반응하며 호감이 쌓입니다. 이전 장신구 소유분은 실제 구매 가격으로 한 번 정보 환급됩니다. 원화 자체에 그려진 의상 장식은 그대로입니다.
- **여성 감염체 6 → 12종**. 카바레 무희, 몰락한 수녀, 독안개 조향사, 블러드 디바, 체인 사냥꾼, 가면 백작부인을 추가했습니다. 각자 다른 그림과 4개 보행 프레임, 해금 시점과 전투 능력이 있습니다.
- **악몽 전선**. 후반 체력과 공세 물량·속도를 크게 높이고, 보호막·돌진·회복·포탑 연사 저하·속박을 추가했습니다. 저격은 방해형 적을 우선 노리고 보호막을 관통합니다. 고레벨 사거리의 성장 폭을 줄여 포탑 위치와 교차 사격이 계속 중요해집니다. 피해·공격속도·무기 레벨·연구는 계속 성장합니다.
- **기존 성장 유지**. 24종 연구, 무기 6종 무한 레벨업과 +1/+10 강화, 24개 무료+24개 영구 구매 배치칸, 확장 가격 직접 설정, 1·2·3·4·5·10배속, 쉘터 꾸미기를 유지합니다.

처음 이전 저장을 불러오면 악몽 전선으로 전환하며 전투를 일시정지합니다. 장신구 환급과 기존 포탑·연구를 확인하고 계속하기를 누르세요. 진행 중 적의 위치와 남은 체력 비율을 유지하면서 새 난이도를 적용합니다.

## 저장과 조작

저장 파일은 `%APPDATA%\BlackVeil\black_veil.json`, 백업은 `black_veil.json.bak`입니다. 기존 의상·정보·포탑 레벨·연구·관계·대화·쉘터와 진행 중 선택지를 이어갑니다. 15초 간격, 메뉴 조작, 정상 종료 때 저장합니다.

| 조작 | 동작 |
| --- | --- |
| 1–6 / 하단 무기 | 배치할 무기 선택 |
| 지도 + / 기존 포탑 | 배치 / 강화·매각 |
| U / Shift+U | 선택 포탑 +1 / +10 강화 |
| SPACE | 웨이브 시작·정지 / 쉘터 대사 다음 |
| F / 배속 버튼 | 1·2·3·4·5·10배속 순환 |
| Q | 지원 포격 |
| B | 배치칸 확장·가격 설정 |
| S | 독대 쉘터 |
| 보좌관 그림 클릭 | 해당 부위의 교감 대사 |
| 의상실 → 선물함 | 선물 구매·보관·전달 |
| ESC / F11 | 돌아가기·정지 / 전체 화면 |

의상실·쉘터·선물함·연구·확장에서는 전투가 멈춥니다. 확장은 기본 10,000 정보, 구매마다 1.35배이며 연구·확장 화면에서 가격과 증가율을 직접 바꿀 수 있습니다. 현금 결제는 없습니다.

입력 질문은 준비된 주제와 연결해 답하는 오프라인 기능입니다. 외부 생성형 AI와 연결하지 않습니다. 초상은 원화 기반 2D이며 얼굴을 변형하는 모션은 사용하지 않습니다. `Advisor-Preview-v0.8.mp4`는 실제 게임 화면 녹화입니다.

## 개발과 검증

Godot 4.6.3, OpenGL 3.3 호환 렌더러를 사용합니다. 이 클라우드에서는 아래 명령을 사용합니다.

```bash
bash tools/godot.sh --headless --script tests/test_game.gd
bash tools/godot.sh --headless --script tests/test_progression.gd
bash tools/godot.sh --headless --script tests/test_relationship.gd
bash tools/godot.sh --headless --script tests/test_nightmare.gd
bash tools/godot.sh --headless --audio-driver Dummy --script tests/test_portraits.gd -- --smoke
bash tools/godot.sh --headless --audio-driver Dummy --script tests/test_audio.gd -- --smoke
bash tools/godot.sh --audio-driver Dummy --script tests/test_v08_ui.gd -- --smoke
bash tools/godot.sh --headless --script tools/balance_check.gd
bash tools/godot.sh --headless --script tools/nightmare_benchmark.gd
bash tools/godot.sh --audio-driver Dummy --script tools/preview_v08.gd -- --smoke
bash tools/godot.sh --audio-driver Dummy --script tools/record_v08.gd -- --smoke
bash tools/godot.sh --headless --export-release 'Windows Desktop' dist/BlackVeil.exe
python3 tools/package_release.py
```

최초 원화 얼굴 픽셀 일치, 원본 해상도, 56벌의 클로즈업과 얼굴 중앙 정렬, 16단계 대사·터치·선물 소비·저장 이전·환급 중복 방지·적 특수 능력·실제 조작을 검사합니다. Windows EXE의 내장 게임도 Linux Godot에서 따로 실행합니다. Windows 실기기는 이 환경에서 미확인입니다.

변경 원인·난이도 공식·저장 이전은 `REDEVELOPMENT.md`, 엔진·폰트 라이선스는 `THIRD_PARTY_LICENSES.txt`와 `assets/FONT-LICENSE.txt`에 있습니다. 원화는 이미지 생성 도구로 제작했습니다.

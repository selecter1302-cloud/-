# 하쿠레이 레이무 · 사용자 수정 반영본 v0.3.1

사용자 본문·검토 결과를 보존하고 이름·따옴표 경계 공백만 통일했다.

### 싫어함 · 주인공쪽 · 직후 · 관계 직후 · 해당 없음

**V03-REIMU-HATE-PC-AFTER-A · use**

{name} 「너보다 {rival}이...... 훨씬 기분 좋았어.」 {name}는 겨우 거짓말을 했다.

**V03-REIMU-HATE-PC-AFTER-B · use**

{name} 「……더러운 년.」 {name}는 고개를 숙이고 읊조리며 자책했다.

### 싫어함 · 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

**V03-REIMU-HATE-PC-NEXT_TALK-A · use**

{name} 「…….」 {name}는 입술을 짓씹고는 대답하지 않았다.

**V03-REIMU-HATE-PC-NEXT_TALK-B · use**

{name}는 말없이 눈을 돌렸다.

### 싫어함 · 주인공쪽 · 다음 만남 · 스킨십 · 수락

**V03-REIMU-HATE-PC-NEXT_TOUCH_ALLOW-A · use**

{name} 「……손은 가만히 둬.」 {name}는 잡힌 손을 보다 눈쌀을 찌푸렸다.

**V03-REIMU-HATE-PC-NEXT_TOUCH_ALLOW-B · use**

{name} 「……안았다고 건방 떨지마.」 {name}는 잡힌 손을 보다가 부적을 감췄다.

### 싫어함 · 주인공쪽 · 다음 만남 · 스킨십 · 거절

**V03-REIMU-HATE-PC-NEXT_TOUCH_REFUSE-A · use**

{name} 「꺼져.」 {name}는 내밀려던 손을 거두고 이쪽 손을 막았다.

**V03-REIMU-HATE-PC-NEXT_TOUCH_REFUSE-B · use**

{name}는 뻗어 온 손을 말없이 쳐냈다.

### 싫어함 · 주인공쪽 · 다음 만남 · 키스 · 수락

**V03-REIMU-HATE-PC-NEXT_KISS_ALLOW-A · use**

{name} 「…….」 {name}는 끝난 뒤에야 부적 쥔 손을 폈다.

**V03-REIMU-HATE-PC-NEXT_KISS_ALLOW-B · use**

{name} 「……더러워.」 {name}는 소매로 입술을 훔쳤다.

### 싫어함 · 주인공쪽 · 다음 만남 · 키스 · 거절

**V03-REIMU-HATE-PC-NEXT_KISS_REFUSE-A · pending**

{name} 「……가까이 오지 마. 나도 내가 싫어지니까.」 {name}는 다가서려다 말고 손바닥으로 막았다.

**V03-REIMU-HATE-PC-NEXT_KISS_REFUSE-B · use**

{name} 「역겨운 얼굴 치워.」 {name}는 {pc}의 턱을 손바닥으로 막았다.

### 싫어함 · 주인공쪽 · 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-REIMU-HATE-PC-LATE_TALK-A · use**

{name} 「언젠가, 힘이 돌아오면...」 {name}는 {pc}를 노려봤다.

**V03-REIMU-HATE-PC-LATE_TALK-B · use**

{name} 「……넌 {rival}에게 아무런 감정도 없어?」 {name}는 무언가를 억누르며 말했다.

### 싫어함 · 주인공쪽 · 시간이 지난 뒤 · 스킨십 · 수락

**V03-REIMU-HATE-PC-LATE_TOUCH_ALLOW-A · exclude**

{name} 「……이 손이 익었다고 다 잊은 건 아니야.」 {name}는 잡힌 손을 보다가 부적을 감췄다.

**V03-REIMU-HATE-PC-LATE_TOUCH_ALLOW-B · exclude**

{name} 「……이젠 네가 어디 있는지부터 보게 되네.」 {name}는 잡힌 손을 보다가 부적을 감췄다.

### 싫어함 · 주인공쪽 · 시간이 지난 뒤 · 스킨십 · 거절

**V03-REIMU-HATE-PC-LATE_TOUCH_REFUSE-A · use**

{name} 「……더러운 손 치워.」 {name}는 {pc}의 손을 쳐냈다.

**V03-REIMU-HATE-PC-LATE_TOUCH_REFUSE-B · use**

{name} 「난 {rival} 거야.」 {name}는 차가운 눈으로 {pc}를 흘겼다.

### 싫어함 · 주인공쪽 · 시간이 지난 뒤 · 키스 · 수락

**V03-REIMU-HATE-PC-LATE_KISS_ALLOW-A · exclude**

{name} 「……내가 먼저 기다린 것 같아서 더 싫어.」 {name}는 끝난 뒤에야 부적 쥔 손을 폈다.

**V03-REIMU-HATE-PC-LATE_KISS_ALLOW-B · exclude**

{name}는 이쪽을 먼저 보고도 입술이 떨어지자 고개를 돌렸다.

### 싫어함 · 주인공쪽 · 시간이 지난 뒤 · 키스 · 거절

**V03-REIMU-HATE-PC-LATE_KISS_REFUSE-A · use**

{name} 「……이대로 또 넘어갈 줄 알았어? 착각하지마.」 {name}는 고개를 들려다 말고 이쪽 얼굴을 막았다.

**V03-REIMU-HATE-PC-LATE_KISS_REFUSE-B · exclude**

{name} 「미쳤어?」 {name}는 인상을 구기며 혐오감을 드러냈다.

### 싫어함 · 미정 · 직후 · 관계 직후 · 해당 없음

**V03-REIMU-HATE-UNSET-AFTER-A · use**

{name} 「왜 나는……」 {name}는 옷깃을 여미고 허공을 보았다.

**V03-REIMU-HATE-UNSET-AFTER-B · use**

{name} 「그 녀석한테만은 모르는 일로 해.」 {name}는 옷깃을 여미고 부적만 내려다봤다.

### 싫어함 · 미정 · 다음 만남 · 대화하기 · 해당 없음

**V03-REIMU-HATE-UNSET-NEXT_TALK-A · exclude**

{name} 「그 녀석 얘기면 됐어. 듣기 싫으니까.」 {name}는 대답하고는 찻잔을 집었다.

**V03-REIMU-HATE-UNSET-NEXT_TALK-B · use**

{name}는 눈을 마주치지 않은 채 부적을 만지작거렸다.

### 싫어함 · 미정 · 다음 만남 · 스킨십 · 수락

**V03-REIMU-HATE-UNSET-NEXT_TOUCH_ALLOW-A · exclude**

{name} 「……잠깐이야. 착각하지 마.」 {name}는 손은 그대로 두고 찻잔만 바라봤다.

**V03-REIMU-HATE-UNSET-NEXT_TOUCH_ALLOW-B · exclude**

{name} 「그 녀석 얘기는 하지 말자. 지금은.」 {name}는 손은 그대로 두고 찻잔만 바라봤다.

### 싫어함 · 미정 · 다음 만남 · 스킨십 · 거절

**V03-REIMU-HATE-UNSET-NEXT_TOUCH_REFUSE-A · use**

{name} 「그 일로 뭐든 될 줄 알았어?」 {name}는 뻗어 온 손을 탁 쳐냈다.

**V03-REIMU-HATE-UNSET-NEXT_TOUCH_REFUSE-B · use**

{name}는 눈을 마주치지 않은 채 뻗어 온 손을 쳐냈다.

### 싫어함 · 미정 · 다음 만남 · 키스 · 수락

**V03-REIMU-HATE-UNSET-NEXT_KISS_ALLOW-A · exclude**

{name} 「……그 녀석보다 낫다는 소리는 하지 마.」 {name}는 입가를 소매로 닦고 고개를 돌렸다.

**V03-REIMU-HATE-UNSET-NEXT_KISS_ALLOW-B · exclude**

{name} 「그 녀석 얘기는 하지 말자. 지금은.」 {name}는 입가를 소매로 닦고 고개를 돌렸다.

### 싫어함 · 미정 · 다음 만남 · 키스 · 거절

**V03-REIMU-HATE-UNSET-NEXT_KISS_REFUSE-A · use**

{name} 「저리 꺼져.」 {name}는 {pc}를 밀어내고는 혀를 찼다.

**V03-REIMU-HATE-UNSET-NEXT_KISS_REFUSE-B · use**

{name} 「나는 {rival}의 여자야. 너같은 쓰레기의 여자가 아니라고.」 {name}는 얼굴을 돌리고 부적 한 장을 꺼냈다.

### 싫어함 · 미정 · 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-REIMU-HATE-UNSET-LATE_TALK-A · use**

{name} 「널 볼 때마다 짜증이 치밀어올라.」 {name}는 대답하고는 찻잔을 집었다.

**V03-REIMU-HATE-UNSET-LATE_TALK-B · use**

{name} 「너보다 {rival}가 훨씬 기분 좋았어.」 {name}는 겨우 거짓말을 했다.

### 싫어함 · 미정 · 시간이 지난 뒤 · 스킨십 · 수락

**V03-REIMU-HATE-UNSET-LATE_TOUCH_ALLOW-A · exclude**

{name} 「……화 풀린 거 아니니까.」 {name}는 손은 그대로 두고 찻잔만 바라봤다.

**V03-REIMU-HATE-UNSET-LATE_TOUCH_ALLOW-B · exclude**

{name} 「그 녀석한테 못 말한다고 너까지 괜찮아진 건 아니야.」 {name}는 손은 그대로 두고 찻잔만 바라봤다.

### 싫어함 · 미정 · 시간이 지난 뒤 · 스킨십 · 거절

**V03-REIMU-HATE-UNSET-LATE_TOUCH_REFUSE-A · use**

{name} 「또야? ……오늘은 건드리지 마.」 {name}는 손을 피하고 방석을 옆으로 옮겼다.

**V03-REIMU-HATE-UNSET-LATE_TOUCH_REFUSE-B · use**

{name} 「말했잖아. 난{rival}의 여자야. 그 더러운 손 분질러버리기 전에 꺼져.」 {name}는 흉흉한 눈빛으로 일갈했다.

### 싫어함 · 미정 · 시간이 지난 뒤 · 키스 · 수락

**V03-REIMU-HATE-UNSET-LATE_KISS_ALLOW-A · exclude**

{name} 「……그 녀석한테는 아직 말도 못 했는데.」 {name}는 입가를 소매로 닦고 고개를 돌렸다.

**V03-REIMU-HATE-UNSET-LATE_KISS_ALLOW-B · exclude**

{name}는 눈을 마주치지 않은 채 입술이 떨어지자 고개를 돌렸다.

### 싫어함 · 미정 · 시간이 지난 뒤 · 키스 · 거절

**V03-REIMU-HATE-UNSET-LATE_KISS_REFUSE-A · use**

{name} 「그만해. 다음엔 진짜 퇴치할 거야.」 {name}는 얼굴을 돌린 채 한 발 물러났다.

**V03-REIMU-HATE-UNSET-LATE_KISS_REFUSE-B · exclude**

{name} 「그 녀석한테 못 말한다고 너까지 괜찮아진 건 아니야.」 {name}는 얼굴을 돌린 채 한 발 물러났다.

### 친구 · 주인공쪽 · 직후 · 관계 직후 · 해당 없음

**V03-REIMU-FRIEND-PC-AFTER-A · pending**

{name} 「……친구치곤 너무 편하네. 그게 문제야.」 {name}는 옷깃을 여미다 말고 곁에 주저앉았다.

**V03-REIMU-FRIEND-PC-AFTER-B · pending**

{name} 「……네 옆이 편한 게 문제네.」 {name}는 옷깃을 여미다 말고 곁에 주저앉았다.

### 친구 · 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

**V03-REIMU-FRIEND-PC-NEXT_TALK-A · pending**

{name} 「옆에 앉아. ……아니, 조금 떨어져서.」 {name}는 옆자리를 비워 주다 손을 멈췄다.

**V03-REIMU-FRIEND-PC-NEXT_TALK-B · pending**

{name}는 평소처럼 곁에 오려다가 찻잔만 밀어 주었다.

### 친구 · 주인공쪽 · 다음 만남 · 스킨십 · 수락

**V03-REIMU-FRIEND-PC-NEXT_TOUCH_ALLOW-A · pending**

{name} 「……친구끼리 이래도 되나. 이제는.」 {name}는 손가락을 걸었다가 자기 손을 내려다봤다.

**V03-REIMU-FRIEND-PC-NEXT_TOUCH_ALLOW-B · pending**

{name}는 평소처럼 곁에 오려다가 잡힌 손을 내려다보았다.

### 친구 · 주인공쪽 · 다음 만남 · 스킨십 · 거절

**V03-REIMU-FRIEND-PC-NEXT_TOUCH_REFUSE-A · pending**

{name} 「……그냥 옆에만 있어. 손은 말고.」 {name}는 내밀려던 손을 거두고 이쪽 손을 막았다.

**V03-REIMU-FRIEND-PC-NEXT_TOUCH_REFUSE-B · pending**

{name} 「……전엔 그냥 옆자리였는데.」 {name}는 내밀려던 손을 거두고 이쪽 손을 막았다.

### 친구 · 주인공쪽 · 다음 만남 · 키스 · 수락

**V03-REIMU-FRIEND-PC-NEXT_KISS_ALLOW-A · pending**

{name} 「……친구라고 하기엔 너무 좋아하네, 나.」 {name}는 눈을 감았다가 뒤늦게 입가를 가렸다.

**V03-REIMU-FRIEND-PC-NEXT_KISS_ALLOW-B · pending**

{name} 「……전엔 그냥 옆자리였는데.」 {name}는 눈을 감았다가 뒤늦게 입가를 가렸다.

### 친구 · 주인공쪽 · 다음 만남 · 키스 · 거절

**V03-REIMU-FRIEND-PC-NEXT_KISS_REFUSE-A · pending**

{name} 「……또 괜찮다고 할 뻔했네. 안 돼.」 {name}는 다가서려다 말고 손바닥으로 막았다.

**V03-REIMU-FRIEND-PC-NEXT_KISS_REFUSE-B · pending**

{name} 「……전엔 그냥 옆자리였는데.」 {name}는 다가서려다 말고 손바닥으로 막았다.

### 친구 · 주인공쪽 · 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-REIMU-FRIEND-PC-LATE_TALK-A · pending**

{name} 「……네 자리부터 비워 두게 되네.」 {name}는 차를 두 잔 따르다 손을 멈췄다.

**V03-REIMU-FRIEND-PC-LATE_TALK-B · pending**

{name} 「……네 잔부터 꺼냈네. 나도 참.」 {name}는 차를 두 잔 따르다 손을 멈췄다.

### 친구 · 주인공쪽 · 시간이 지난 뒤 · 스킨십 · 수락

**V03-REIMU-FRIEND-PC-LATE_TOUCH_ALLOW-A · pending**

{name} 「……손부터 찾았네. 친구라서 그렇다고 할까.」 {name}는 손을 맞잡고도 눈은 마주치지 않았다.

**V03-REIMU-FRIEND-PC-LATE_TOUCH_ALLOW-B · pending**

{name} 「……네 잔부터 꺼냈네. 나도 참.」 {name}는 손을 맞잡고도 눈은 마주치지 않았다.

### 친구 · 주인공쪽 · 시간이 지난 뒤 · 스킨십 · 거절

**V03-REIMU-FRIEND-PC-LATE_TOUCH_REFUSE-A · pending**

{name} 「……기대 버리기 전에 그만하자.」 {name}는 뻗으려던 손을 소매 안으로 거뒀다.

**V03-REIMU-FRIEND-PC-LATE_TOUCH_REFUSE-B · pending**

{name} 「……네 잔부터 꺼냈네. 나도 참.」 {name}는 뻗으려던 손을 소매 안으로 거뒀다.

### 친구 · 주인공쪽 · 시간이 지난 뒤 · 키스 · 수락

**V03-REIMU-FRIEND-PC-LATE_KISS_ALLOW-A · pending**

{name} 「……이젠 친구라는 말이 더 이상하네.」 {name}는 먼저 감았던 눈을 뒤늦게 떴다.

**V03-REIMU-FRIEND-PC-LATE_KISS_ALLOW-B · pending**

{name}는 평소처럼 곁에 오려다가 입술이 떨어지자 고개를 돌렸다.

### 친구 · 주인공쪽 · 시간이 지난 뒤 · 키스 · 거절

**V03-REIMU-FRIEND-PC-LATE_KISS_REFUSE-A · pending**

{name} 「……오늘은 말 좀 하자. 붙어 있지 말고.」 {name}는 고개를 들려다 말고 이쪽 얼굴을 막았다.

**V03-REIMU-FRIEND-PC-LATE_KISS_REFUSE-B · pending**

{name} 「……네 잔부터 꺼냈네. 나도 참.」 {name}는 고개를 들려다 말고 이쪽 얼굴을 막았다.

### 친구 · 미정 · 직후 · 관계 직후 · 해당 없음

**V03-REIMU-FRIEND-UNSET-AFTER-A · pending**

{name} 「……이제 그 녀석 고민은 누구한테 말하지.」 {name}는 부적 모서리를 손끝으로 문질렀다.

**V03-REIMU-FRIEND-UNSET-AFTER-B · pending**

{name} 「친구라고 말하면 그 녀석이 믿을까.」 {name}는 부적 모서리를 손끝으로 문질렀다.

### 친구 · 미정 · 다음 만남 · 대화하기 · 해당 없음

**V03-REIMU-FRIEND-UNSET-NEXT_TALK-A · pending**

{name} 「차는 줄게. ……그 얘긴 아직 하지 말자.」 {name}는 찻잔을 내려놓고 눈을 피했다.

**V03-REIMU-FRIEND-UNSET-NEXT_TALK-B · pending**

{name}는 차를 권하려다 말고 찻잔만 밀어 주었다.

### 친구 · 미정 · 다음 만남 · 스킨십 · 수락

**V03-REIMU-FRIEND-UNSET-NEXT_TOUCH_ALLOW-A · pending**

{name} 「……그 녀석한테도 이렇게 태연하면 좋겠네.」 {name}는 손을 빼지 않고 소매 끝만 당겼다.

**V03-REIMU-FRIEND-UNSET-NEXT_TOUCH_ALLOW-B · pending**

{name}는 차를 권하려다 말고 잡힌 손을 내려다보았다.

### 친구 · 미정 · 다음 만남 · 스킨십 · 거절

**V03-REIMU-FRIEND-UNSET-NEXT_TOUCH_REFUSE-A · pending**

{name} 「오늘은 얘기만 하자. ……응?」 {name}는 뻗어 온 손을 탁 쳐냈다.

**V03-REIMU-FRIEND-UNSET-NEXT_TOUCH_REFUSE-B · pending**

{name} 「친구라서 편했는데 이젠 말도 고르게 되네.」 {name}는 뻗어 온 손을 탁 쳐냈다.

### 친구 · 미정 · 다음 만남 · 키스 · 수락

**V03-REIMU-FRIEND-UNSET-NEXT_KISS_ALLOW-A · pending**

{name} 「……이러고 또 친구라고 부를 거야?」 {name}는 입술이 떨어지자 곧 고개를 돌렸다.

**V03-REIMU-FRIEND-UNSET-NEXT_KISS_ALLOW-B · pending**

{name} 「친구라서 편했는데 이젠 말도 고르게 되네.」 {name}는 입술이 떨어지자 곧 고개를 돌렸다.

### 친구 · 미정 · 다음 만남 · 키스 · 거절

**V03-REIMU-FRIEND-UNSET-NEXT_KISS_REFUSE-A · pending**

{name} 「장난이었다고 하면 그 녀석한테 더 미안해.」 {name}는 얼굴을 돌리고 부적 한 장을 꺼냈다.

**V03-REIMU-FRIEND-UNSET-NEXT_KISS_REFUSE-B · pending**

{name} 「친구라서 편했는데 이젠 말도 고르게 되네.」 {name}는 얼굴을 돌리고 부적 한 장을 꺼냈다.

### 친구 · 미정 · 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-REIMU-FRIEND-UNSET-LATE_TALK-A · pending**

{name} 「전처럼 웃으면 잊을 줄 알았는데.」 {name}는 대답 대신 찻잔만 기울였다.

**V03-REIMU-FRIEND-UNSET-LATE_TALK-B · pending**

{name} 「그 녀석한테는 친구라고만 말했어.」 {name}는 대답 대신 찻잔만 기울였다.

### 친구 · 미정 · 시간이 지난 뒤 · 스킨십 · 수락

**V03-REIMU-FRIEND-UNSET-LATE_TOUCH_ALLOW-A · pending**

{name} 「……놓으라고 해야 하는데 말이 안 나와.」 {name}는 잡힌 손을 보다가 소매 끝을 당겼다.

**V03-REIMU-FRIEND-UNSET-LATE_TOUCH_ALLOW-B · pending**

{name} 「그 녀석한테는 친구라고만 말했어.」 {name}는 잡힌 손을 보다가 소매 끝을 당겼다.

### 친구 · 미정 · 시간이 지난 뒤 · 스킨십 · 거절

**V03-REIMU-FRIEND-UNSET-LATE_TOUCH_REFUSE-A · pending**

{name} 「친구니까 다 괜찮다는 건 아니야.」 {name}는 손을 피하고 방석을 옆으로 옮겼다.

**V03-REIMU-FRIEND-UNSET-LATE_TOUCH_REFUSE-B · pending**

{name} 「그 녀석한테는 친구라고만 말했어.」 {name}는 손을 피하고 방석을 옆으로 옮겼다.

### 친구 · 미정 · 시간이 지난 뒤 · 키스 · 수락

**V03-REIMU-FRIEND-UNSET-LATE_KISS_ALLOW-A · pending**

{name} 「……그 녀석 얘기만 안 하면 편하겠지.」 {name}는 입가를 소매로 가렸다.

**V03-REIMU-FRIEND-UNSET-LATE_KISS_ALLOW-B · pending**

{name}는 차를 권하려다 말고 입술이 떨어지자 고개를 돌렸다.

### 친구 · 미정 · 시간이 지난 뒤 · 키스 · 거절

**V03-REIMU-FRIEND-UNSET-LATE_KISS_REFUSE-A · pending**

{name} 「또 웃고 넘어가면 나만 바보 같잖아.」 {name}는 얼굴을 돌린 채 한 발 물러났다.

**V03-REIMU-FRIEND-UNSET-LATE_KISS_REFUSE-B · pending**

{name} 「그 녀석한테는 친구라고만 말했어.」 {name}는 얼굴을 돌린 채 한 발 물러났다.

### 연인(비밀) · 주인공쪽 · 직후 · 관계 직후 · 해당 없음

**V03-REIMU-SECRET-PC-AFTER-A · pending**

{name} 「……조금만 더. ……나, 돌아가야 하는데.」 {name}는 옷깃을 여미다 말고 곁에 주저앉았다.

**V03-REIMU-SECRET-PC-AFTER-B · pending**

{name} 「……조금만 더. 돌아가긴 할 거야.」 {name}는 옷깃을 여미다 말고 곁에 주저앉았다.

### 연인(비밀) · 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

**V03-REIMU-SECRET-PC-NEXT_TALK-A · pending**

{name} 「……왔네. 네 목소리만 기다리고 있었어.」 {name}는 옆자리를 비워 주다 손을 멈췄다.

**V03-REIMU-SECRET-PC-NEXT_TALK-B · pending**

{name}는 이쪽 곁에 머뭇거리며 찻잔만 밀어 주었다.

### 연인(비밀) · 주인공쪽 · 다음 만남 · 스킨십 · 수락

**V03-REIMU-SECRET-PC-NEXT_TOUCH_ALLOW-A · pending**

{name} 「……놓지 마. 누가 오기 전까지만.」 {name}는 손가락을 걸었다가 자기 손을 내려다봤다.

**V03-REIMU-SECRET-PC-NEXT_TOUCH_ALLOW-B · pending**

{name}는 이쪽 곁에 머뭇거리며 잡힌 손을 내려다보았다.

### 연인(비밀) · 주인공쪽 · 다음 만남 · 스킨십 · 거절

**V03-REIMU-SECRET-PC-NEXT_TOUCH_REFUSE-A · pending**

{name} 「……오늘은 떨어져 있자. 또 늦을 테니까.」 {name}는 내밀려던 손을 거두고 이쪽 손을 막았다.

**V03-REIMU-SECRET-PC-NEXT_TOUCH_REFUSE-B · pending**

{name} 「……또 늦겠네. 네가 와서.」 {name}는 내밀려던 손을 거두고 이쪽 손을 막았다.

### 연인(비밀) · 주인공쪽 · 다음 만남 · 키스 · 수락

**V03-REIMU-SECRET-PC-NEXT_KISS_ALLOW-A · pending**

{name} 「……한 번만 더. ……계속 이러네.」 {name}는 눈을 감았다가 뒤늦게 입가를 가렸다.

**V03-REIMU-SECRET-PC-NEXT_KISS_ALLOW-B · pending**

{name} 「……또 늦겠네. 네가 와서.」 {name}는 눈을 감았다가 뒤늦게 입가를 가렸다.

### 연인(비밀) · 주인공쪽 · 다음 만남 · 키스 · 거절

**V03-REIMU-SECRET-PC-NEXT_KISS_REFUSE-A · pending**

{name} 「……또 다 잊을 뻔했네. 오늘은 안 돼.」 {name}는 다가서려다 말고 손바닥으로 막았다.

**V03-REIMU-SECRET-PC-NEXT_KISS_REFUSE-B · pending**

{name} 「……또 늦겠네. 네가 와서.」 {name}는 다가서려다 말고 손바닥으로 막았다.

### 연인(비밀) · 주인공쪽 · 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-REIMU-SECRET-PC-LATE_TALK-A · pending**

{name} 「……여기 오면 시간을 안 보게 돼.」 {name}는 차를 두 잔 따르다 손을 멈췄다.

**V03-REIMU-SECRET-PC-LATE_TALK-B · pending**

{name} 「……여기 있으면 돌아갈 생각을 안 해.」 {name}는 차를 두 잔 따르다 손을 멈췄다.

### 연인(비밀) · 주인공쪽 · 시간이 지난 뒤 · 스킨십 · 수락

**V03-REIMU-SECRET-PC-LATE_TOUCH_ALLOW-A · pending**

{name} 「……다른 손을 잡으면 이상할 것 같아.」 {name}는 손을 맞잡고도 눈은 마주치지 않았다.

**V03-REIMU-SECRET-PC-LATE_TOUCH_ALLOW-B · pending**

{name} 「……여기 있으면 돌아갈 생각을 안 해.」 {name}는 손을 맞잡고도 눈은 마주치지 않았다.

### 연인(비밀) · 주인공쪽 · 시간이 지난 뒤 · 스킨십 · 거절

**V03-REIMU-SECRET-PC-LATE_TOUCH_REFUSE-A · pending**

{name} 「……옆에 있으면 결심이 오래 안 가.」 {name}는 뻗으려던 손을 소매 안으로 거뒀다.

**V03-REIMU-SECRET-PC-LATE_TOUCH_REFUSE-B · pending**

{name} 「……여기 있으면 돌아갈 생각을 안 해.」 {name}는 뻗으려던 손을 소매 안으로 거뒀다.

### 연인(비밀) · 주인공쪽 · 시간이 지난 뒤 · 키스 · 수락

**V03-REIMU-SECRET-PC-LATE_KISS_ALLOW-A · pending**

{name} 「……그 녀석한텐 늦는다고 했어. 너 기다리려고.」 {name}는 먼저 감았던 눈을 뒤늦게 떴다.

**V03-REIMU-SECRET-PC-LATE_KISS_ALLOW-B · pending**

{name}는 이쪽 곁에 머뭇거리며 입술이 떨어지자 고개를 돌렸다.

### 연인(비밀) · 주인공쪽 · 시간이 지난 뒤 · 키스 · 거절

**V03-REIMU-SECRET-PC-LATE_KISS_REFUSE-A · pending**

{name} 「……이러고 또 아무 말 못 하겠지. 그만하자.」 {name}는 고개를 들려다 말고 이쪽 얼굴을 막았다.

**V03-REIMU-SECRET-PC-LATE_KISS_REFUSE-B · pending**

{name} 「……여기 있으면 돌아갈 생각을 안 해.」 {name}는 고개를 들려다 말고 이쪽 얼굴을 막았다.

### 연인(비밀) · 미정 · 직후 · 관계 직후 · 해당 없음

**V03-REIMU-SECRET-UNSET-AFTER-A · pending**

{name} 「……좋아해. 그래서 더 미안하네.」 {name}는 부적 모서리를 손끝으로 문질렀다.

**V03-REIMU-SECRET-UNSET-AFTER-B · pending**

{name} 「널 좋아해. 그 녀석도 잊은 건 아니고.」 {name}는 부적 모서리를 손끝으로 문질렀다.

### 연인(비밀) · 미정 · 다음 만남 · 대화하기 · 해당 없음

**V03-REIMU-SECRET-UNSET-NEXT_TALK-A · pending**

{name} 「그 녀석이 잘 잤냐고 하더라. ……대답 못 했어.」 {name}는 찻잔을 내려놓고 눈을 피했다.

**V03-REIMU-SECRET-UNSET-NEXT_TALK-B · pending**

{name}는 문 쪽을 한 번 보고 찻잔만 밀어 주었다.

### 연인(비밀) · 미정 · 다음 만남 · 스킨십 · 수락

**V03-REIMU-SECRET-UNSET-NEXT_TOUCH_ALLOW-A · pending**

{name} 「……이러면 돌아가기 싫어지는데.」 {name}는 손을 빼지 않고 소매 끝만 당겼다.

**V03-REIMU-SECRET-UNSET-NEXT_TOUCH_ALLOW-B · pending**

{name}는 문 쪽을 한 번 보고 잡힌 손을 내려다보았다.

### 연인(비밀) · 미정 · 다음 만남 · 스킨십 · 거절

**V03-REIMU-SECRET-UNSET-NEXT_TOUCH_REFUSE-A · pending**

{name} 「다정하게 굴지 마. 할 말을 못 하겠잖아.」 {name}는 뻗어 온 손을 탁 쳐냈다.

**V03-REIMU-SECRET-UNSET-NEXT_TOUCH_REFUSE-B · pending**

{name} 「그 녀석 앞에선 너 기다렸단 말을 삼켰어.」 {name}는 뻗어 온 손을 탁 쳐냈다.

### 연인(비밀) · 미정 · 다음 만남 · 키스 · 수락

**V03-REIMU-SECRET-UNSET-NEXT_KISS_ALLOW-A · pending**

{name} 「……그 녀석 생각도 나는데, 너도 좋아.」 {name}는 입술이 떨어지자 곧 고개를 돌렸다.

**V03-REIMU-SECRET-UNSET-NEXT_KISS_ALLOW-B · pending**

{name} 「그 녀석 앞에선 너 기다렸단 말을 삼켰어.」 {name}는 입술이 떨어지자 곧 고개를 돌렸다.

### 연인(비밀) · 미정 · 다음 만남 · 키스 · 거절

**V03-REIMU-SECRET-UNSET-NEXT_KISS_REFUSE-A · pending**

{name} 「입 맞추면 그 녀석 일이 없어져?」 {name}는 얼굴을 돌리고 부적 한 장을 꺼냈다.

**V03-REIMU-SECRET-UNSET-NEXT_KISS_REFUSE-B · pending**

{name} 「그 녀석 앞에선 너 기다렸단 말을 삼켰어.」 {name}는 얼굴을 돌리고 부적 한 장을 꺼냈다.

### 연인(비밀) · 미정 · 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-REIMU-SECRET-UNSET-LATE_TALK-A · pending**

{name} 「언제까지 비밀로 둘 거야. ……나도 피했지만.」 {name}는 대답 대신 찻잔만 기울였다.

**V03-REIMU-SECRET-UNSET-LATE_TALK-B · pending**

{name} 「비밀로 두는 건 쉬워졌는데 그 녀석 보긴 어렵네.」 {name}는 대답 대신 찻잔만 기울였다.

### 연인(비밀) · 미정 · 시간이 지난 뒤 · 스킨십 · 수락

**V03-REIMU-SECRET-UNSET-LATE_TOUCH_ALLOW-A · pending**

{name} 「……이 손 잡고 그 녀석한텐 뭘 말하지.」 {name}는 잡힌 손을 보다가 소매 끝을 당겼다.

**V03-REIMU-SECRET-UNSET-LATE_TOUCH_ALLOW-B · pending**

{name} 「비밀로 두는 건 쉬워졌는데 그 녀석 보긴 어렵네.」 {name}는 잡힌 손을 보다가 소매 끝을 당겼다.

### 연인(비밀) · 미정 · 시간이 지난 뒤 · 스킨십 · 거절

**V03-REIMU-SECRET-UNSET-LATE_TOUCH_REFUSE-A · pending**

{name} 「오늘은 얘기부터 해. ……그 녀석 얘기도.」 {name}는 손을 피하고 방석을 옆으로 옮겼다.

**V03-REIMU-SECRET-UNSET-LATE_TOUCH_REFUSE-B · pending**

{name} 「비밀로 두는 건 쉬워졌는데 그 녀석 보긴 어렵네.」 {name}는 손을 피하고 방석을 옆으로 옮겼다.

### 연인(비밀) · 미정 · 시간이 지난 뒤 · 키스 · 수락

**V03-REIMU-SECRET-UNSET-LATE_KISS_ALLOW-A · pending**

{name} 「……너만 좋다고 말하면 편할 텐데.」 {name}는 입가를 소매로 가렸다.

**V03-REIMU-SECRET-UNSET-LATE_KISS_ALLOW-B · pending**

{name}는 문 쪽을 한 번 보고 입술이 떨어지자 고개를 돌렸다.

### 연인(비밀) · 미정 · 시간이 지난 뒤 · 키스 · 거절

**V03-REIMU-SECRET-UNSET-LATE_KISS_REFUSE-A · pending**

{name} 「오늘은 그 녀석 일부터 정하자.」 {name}는 얼굴을 돌린 채 한 발 물러났다.

**V03-REIMU-SECRET-UNSET-LATE_KISS_REFUSE-B · pending**

{name} 「비밀로 두는 건 쉬워졌는데 그 녀석 보긴 어렵네.」 {name}는 얼굴을 돌린 채 한 발 물러났다.

### 타인 · 주인공쪽 · 직후 · 관계 직후 · 해당 없음

**V03-REIMU-STRANGER-PC-AFTER-A · pending**

{name} 「……돌아가야 하는데 여기서 못 일어나겠네.」 {name}는 옷깃을 여미다 말고 곁에 주저앉았다.

**V03-REIMU-STRANGER-PC-AFTER-B · pending**

{name} 「……자리부터 익숙해졌네.」 {name}는 옷깃을 여미다 말고 곁에 주저앉았다.

### 타인 · 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

**V03-REIMU-STRANGER-PC-NEXT_TALK-A · pending**

{name} 「……또 네 자리부터 찾았네.」 {name}는 옆자리를 비워 주다 손을 멈췄다.

**V03-REIMU-STRANGER-PC-NEXT_TALK-B · pending**

{name}는 가까이 섰다가 뒤늦게 찻잔만 밀어 주었다.

### 타인 · 주인공쪽 · 다음 만남 · 스킨십 · 수락

**V03-REIMU-STRANGER-PC-NEXT_TOUCH_ALLOW-A · pending**

{name} 「……이 손은 안 낯선데. 이상하네.」 {name}는 손가락을 걸었다가 자기 손을 내려다봤다.

**V03-REIMU-STRANGER-PC-NEXT_TOUCH_ALLOW-B · pending**

{name} 「……네가 있는 곳은 금방 찾겠네.」 {name}는 손가락을 걸었다가 자기 손을 내려다봤다.

### 타인 · 주인공쪽 · 다음 만남 · 스킨십 · 거절

**V03-REIMU-STRANGER-PC-NEXT_TOUCH_REFUSE-A · pending**

{name} 「……가까이 왔다고 다 괜찮은 줄 알아?」 {name}는 내밀려던 손을 거두고 이쪽 손을 막았다.

**V03-REIMU-STRANGER-PC-NEXT_TOUCH_REFUSE-B · pending**

{name}는 가까이 섰다가 뒤늦게 뻗어 온 손을 말없이 쳐냈다.

### 타인 · 주인공쪽 · 다음 만남 · 키스 · 수락

**V03-REIMU-STRANGER-PC-NEXT_KISS_ALLOW-A · pending**

{name} 「……그 녀석 앞보다 여기서 눈이 잘 감기네.」 {name}는 눈을 감았다가 뒤늦게 입가를 가렸다.

**V03-REIMU-STRANGER-PC-NEXT_KISS_ALLOW-B · pending**

{name} 「……네가 있는 곳은 금방 찾겠네.」 {name}는 눈을 감았다가 뒤늦게 입가를 가렸다.

### 타인 · 주인공쪽 · 다음 만남 · 키스 · 거절

**V03-REIMU-STRANGER-PC-NEXT_KISS_REFUSE-A · pending**

{name} 「……또 쉽게 대답하려고 했네. 안 돼.」 {name}는 다가서려다 말고 손바닥으로 막았다.

**V03-REIMU-STRANGER-PC-NEXT_KISS_REFUSE-B · pending**

{name} 「……네가 있는 곳은 금방 찾겠네.」 {name}는 다가서려다 말고 손바닥으로 막았다.

### 타인 · 주인공쪽 · 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-REIMU-STRANGER-PC-LATE_TALK-A · pending**

{name} 「……네가 어디 있는지는 잘 알겠네.」 {name}는 차를 두 잔 따르다 손을 멈췄다.

**V03-REIMU-STRANGER-PC-LATE_TALK-B · pending**

{name} 「……말보다 발이 먼저 이쪽으로 왔네.」 {name}는 차를 두 잔 따르다 손을 멈췄다.

### 타인 · 주인공쪽 · 시간이 지난 뒤 · 스킨십 · 수락

**V03-REIMU-STRANGER-PC-LATE_TOUCH_ALLOW-A · pending**

{name} 「……손은 익었네. 네가 뭘 좋아하는지는 몰라도.」 {name}는 손을 맞잡고도 눈은 마주치지 않았다.

**V03-REIMU-STRANGER-PC-LATE_TOUCH_ALLOW-B · pending**

{name} 「……말보다 발이 먼저 이쪽으로 왔네.」 {name}는 손을 맞잡고도 눈은 마주치지 않았다.

### 타인 · 주인공쪽 · 시간이 지난 뒤 · 스킨십 · 거절

**V03-REIMU-STRANGER-PC-LATE_TOUCH_REFUSE-A · pending**

{name} 「……손 안 잡고도 얘기는 할 수 있잖아.」 {name}는 뻗으려던 손을 소매 안으로 거뒀다.

**V03-REIMU-STRANGER-PC-LATE_TOUCH_REFUSE-B · pending**

{name} 「……말보다 발이 먼저 이쪽으로 왔네.」 {name}는 뻗으려던 손을 소매 안으로 거뒀다.

### 타인 · 주인공쪽 · 시간이 지난 뒤 · 키스 · 수락

**V03-REIMU-STRANGER-PC-LATE_KISS_ALLOW-A · pending**

{name} 「……눈부터 감았네. 물어볼 건 많은데.」 {name}는 먼저 감았던 눈을 뒤늦게 떴다.

**V03-REIMU-STRANGER-PC-LATE_KISS_ALLOW-B · pending**

{name}는 가까이 섰다가 뒤늦게 입술이 떨어지자 고개를 돌렸다.

### 타인 · 주인공쪽 · 시간이 지난 뒤 · 키스 · 거절

**V03-REIMU-STRANGER-PC-LATE_KISS_REFUSE-A · pending**

{name} 「……이 거리만 익숙해지면 곤란하지.」 {name}는 고개를 들려다 말고 이쪽 얼굴을 막았다.

**V03-REIMU-STRANGER-PC-LATE_KISS_REFUSE-B · pending**

{name} 「……말보다 발이 먼저 이쪽으로 왔네.」 {name}는 고개를 들려다 말고 이쪽 얼굴을 막았다.

### 타인 · 미정 · 직후 · 관계 직후 · 해당 없음

**V03-REIMU-STRANGER-UNSET-AFTER-A · pending**

{name} 「……너에 대해 아는 게 뭐가 있다고.」 {name}는 부적 모서리를 손끝으로 문질렀다.

**V03-REIMU-STRANGER-UNSET-AFTER-B · pending**

{name} 「그 녀석한테 널 뭐라고 하지.」 {name}는 부적 모서리를 손끝으로 문질렀다.

### 타인 · 미정 · 다음 만남 · 대화하기 · 해당 없음

**V03-REIMU-STRANGER-UNSET-NEXT_TALK-A · pending**

{name} 「차는 네가 타. ……그 녀석 얘긴 빼고.」 {name}는 찻잔을 내려놓고 눈을 피했다.

**V03-REIMU-STRANGER-UNSET-NEXT_TALK-B · pending**

{name}는 한 걸음 떨어져서 찻잔만 밀어 주었다.

### 타인 · 미정 · 다음 만남 · 스킨십 · 수락

**V03-REIMU-STRANGER-UNSET-NEXT_TOUCH_ALLOW-A · pending**

{name} 「……손만이야. 잘 아는 사이인 척하지 마.」 {name}는 손을 빼지 않고 소매 끝만 당겼다.

**V03-REIMU-STRANGER-UNSET-NEXT_TOUCH_ALLOW-B · pending**

{name} 「너에 대해 물어볼 게 많았는데 그 녀석부터 생각나.」 {name}는 손을 빼지 않고 소매 끝만 당겼다.

### 타인 · 미정 · 다음 만남 · 스킨십 · 거절

**V03-REIMU-STRANGER-UNSET-NEXT_TOUCH_REFUSE-A · pending**

{name} 「잠깐. 아직 너랑 말하는 것도 어색해.」 {name}는 뻗어 온 손을 탁 쳐냈다.

**V03-REIMU-STRANGER-UNSET-NEXT_TOUCH_REFUSE-B · pending**

{name}는 한 걸음 떨어져서 뻗어 온 손을 말없이 쳐냈다.

### 타인 · 미정 · 다음 만남 · 키스 · 수락

**V03-REIMU-STRANGER-UNSET-NEXT_KISS_ALLOW-A · pending**

{name} 「……너한텐 무슨 뜻이야, 이거.」 {name}는 입술이 떨어지자 곧 고개를 돌렸다.

**V03-REIMU-STRANGER-UNSET-NEXT_KISS_ALLOW-B · pending**

{name} 「너에 대해 물어볼 게 많았는데 그 녀석부터 생각나.」 {name}는 입술이 떨어지자 곧 고개를 돌렸다.

### 타인 · 미정 · 다음 만남 · 키스 · 거절

**V03-REIMU-STRANGER-UNSET-NEXT_KISS_REFUSE-A · pending**

{name} 「너랑 어떤 사이인지도 모르잖아.」 {name}는 얼굴을 돌리고 부적 한 장을 꺼냈다.

**V03-REIMU-STRANGER-UNSET-NEXT_KISS_REFUSE-B · pending**

{name} 「너에 대해 물어볼 게 많았는데 그 녀석부터 생각나.」 {name}는 얼굴을 돌리고 부적 한 장을 꺼냈다.

### 타인 · 미정 · 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-REIMU-STRANGER-UNSET-LATE_TALK-A · pending**

{name} 「너는 좀 알게 됐는데 그 녀석한텐 할 말이 없어.」 {name}는 대답 대신 찻잔만 기울였다.

**V03-REIMU-STRANGER-UNSET-LATE_TALK-B · pending**

{name} 「너는 좀 알겠어. 걔한텐 아직 말 못 했지만.」 {name}는 대답 대신 찻잔만 기울였다.

### 타인 · 미정 · 시간이 지난 뒤 · 스킨십 · 수락

**V03-REIMU-STRANGER-UNSET-LATE_TOUCH_ALLOW-A · pending**

{name} 「……오늘은 괜찮아. 오늘은.」 {name}는 잡힌 손을 보다가 소매 끝을 당겼다.

**V03-REIMU-STRANGER-UNSET-LATE_TOUCH_ALLOW-B · pending**

{name} 「너는 좀 알겠어. 걔한텐 아직 말 못 했지만.」 {name}는 잡힌 손을 보다가 소매 끝을 당겼다.

### 타인 · 미정 · 시간이 지난 뒤 · 스킨십 · 거절

**V03-REIMU-STRANGER-UNSET-LATE_TOUCH_REFUSE-A · pending**

{name} 「자주 봤다고 네가 내 연인이 되는 건 아니야.」 {name}는 손을 피하고 방석을 옆으로 옮겼다.

**V03-REIMU-STRANGER-UNSET-LATE_TOUCH_REFUSE-B · pending**

{name} 「너는 좀 알겠어. 걔한텐 아직 말 못 했지만.」 {name}는 손을 피하고 방석을 옆으로 옮겼다.

### 타인 · 미정 · 시간이 지난 뒤 · 키스 · 수락

**V03-REIMU-STRANGER-UNSET-LATE_KISS_ALLOW-A · pending**

{name} 「……우린 무슨 사이라고 말해야 해?」 {name}는 입가를 소매로 가렸다.

**V03-REIMU-STRANGER-UNSET-LATE_KISS_ALLOW-B · pending**

{name}는 한 걸음 떨어져서 입술이 떨어지자 고개를 돌렸다.

### 타인 · 미정 · 시간이 지난 뒤 · 키스 · 거절

**V03-REIMU-STRANGER-UNSET-LATE_KISS_REFUSE-A · pending**

{name} 「오늘은 네 얘기부터 해 봐. 핑계 말고.」 {name}는 얼굴을 돌린 채 한 발 물러났다.

**V03-REIMU-STRANGER-UNSET-LATE_KISS_REFUSE-B · pending**

{name} 「너는 좀 알겠어. 걔한텐 아직 말 못 했지만.」 {name}는 얼굴을 돌린 채 한 발 물러났다.

### 짝사랑 · 주인공쪽 · 직후 · 관계 직후 · 해당 없음

**V03-REIMU-CRUSH-PC-AFTER-A · pending**

{name} 「……나 지금 웃었어? 그 녀석 생각도 안 하고.」 {name}는 옷깃을 여미다 말고 곁에 주저앉았다.

**V03-REIMU-CRUSH-PC-AFTER-B · pending**

{name} 「……돌아가기 싫은 얼굴이었어?」 {name}는 옷깃을 여미다 말고 곁에 주저앉았다.

### 짝사랑 · 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

**V03-REIMU-CRUSH-PC-NEXT_TALK-A · pending**

{name} 「기다린 거 아니야. ……차는 더 탔지만.」 {name}는 옆자리를 비워 주다 손을 멈췄다.

**V03-REIMU-CRUSH-PC-NEXT_TALK-B · pending**

{name}는 기쁜 얼굴을 감추려다 찻잔만 밀어 주었다.

### 짝사랑 · 주인공쪽 · 다음 만남 · 스킨십 · 수락

**V03-REIMU-CRUSH-PC-NEXT_TOUCH_ALLOW-A · pending**

{name} 「……놓으라는 말은 안 했잖아.」 {name}는 손가락을 걸었다가 자기 손을 내려다봤다.

**V03-REIMU-CRUSH-PC-NEXT_TOUCH_ALLOW-B · pending**

{name}는 기쁜 얼굴을 감추려다 잡힌 손을 내려다보았다.

### 짝사랑 · 주인공쪽 · 다음 만남 · 스킨십 · 거절

**V03-REIMU-CRUSH-PC-NEXT_TOUCH_REFUSE-A · pending**

{name} 「……이 손 잡으면 또 아무것도 못 묻잖아.」 {name}는 내밀려던 손을 거두고 이쪽 손을 막았다.

**V03-REIMU-CRUSH-PC-NEXT_TOUCH_REFUSE-B · pending**

{name} 「……네가 오면 벌써 웃게 되네.」 {name}는 내밀려던 손을 거두고 이쪽 손을 막았다.

### 짝사랑 · 주인공쪽 · 다음 만남 · 키스 · 수락

**V03-REIMU-CRUSH-PC-NEXT_KISS_ALLOW-A · pending**

{name} 「……기다렸다고 하면 웃을 거야?」 {name}는 눈을 감았다가 뒤늦게 입가를 가렸다.

**V03-REIMU-CRUSH-PC-NEXT_KISS_ALLOW-B · pending**

{name} 「……네가 오면 벌써 웃게 되네.」 {name}는 눈을 감았다가 뒤늦게 입가를 가렸다.

### 짝사랑 · 주인공쪽 · 다음 만남 · 키스 · 거절

**V03-REIMU-CRUSH-PC-NEXT_KISS_REFUSE-A · pending**

{name} 「……오늘은 네 대답부터 들을래.」 {name}는 다가서려다 말고 손바닥으로 막았다.

**V03-REIMU-CRUSH-PC-NEXT_KISS_REFUSE-B · pending**

{name} 「……네가 오면 벌써 웃게 되네.」 {name}는 다가서려다 말고 손바닥으로 막았다.

### 짝사랑 · 주인공쪽 · 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-REIMU-CRUSH-PC-LATE_TALK-A · pending**

{name} 「……네 발소리면 문부터 보게 돼.」 {name}는 차를 두 잔 따르다 손을 멈췄다.

**V03-REIMU-CRUSH-PC-LATE_TALK-B · pending**

{name} 「……네 목소리면 하던 일도 멈추게 돼.」 {name}는 차를 두 잔 따르다 손을 멈췄다.

### 짝사랑 · 주인공쪽 · 시간이 지난 뒤 · 스킨십 · 수락

**V03-REIMU-CRUSH-PC-LATE_TOUCH_ALLOW-A · pending**

{name} 「……내가 먼저 잡았네. 부끄럽게.」 {name}는 손을 맞잡고도 눈은 마주치지 않았다.

**V03-REIMU-CRUSH-PC-LATE_TOUCH_ALLOW-B · pending**

{name} 「……네 목소리면 하던 일도 멈추게 돼.」 {name}는 손을 맞잡고도 눈은 마주치지 않았다.

### 짝사랑 · 주인공쪽 · 시간이 지난 뒤 · 스킨십 · 거절

**V03-REIMU-CRUSH-PC-LATE_TOUCH_REFUSE-A · pending**

{name} 「……기대고 있으면 네 말이 다 좋게 들려.」 {name}는 뻗으려던 손을 소매 안으로 거뒀다.

**V03-REIMU-CRUSH-PC-LATE_TOUCH_REFUSE-B · pending**

{name} 「……네 목소리면 하던 일도 멈추게 돼.」 {name}는 뻗으려던 손을 소매 안으로 거뒀다.

### 짝사랑 · 주인공쪽 · 시간이 지난 뒤 · 키스 · 수락

**V03-REIMU-CRUSH-PC-LATE_KISS_ALLOW-A · pending**

{name} 「……너 기다리려고 그 녀석한테 늦는다고 했어.」 {name}는 먼저 감았던 눈을 뒤늦게 떴다.

**V03-REIMU-CRUSH-PC-LATE_KISS_ALLOW-B · pending**

{name}는 기쁜 얼굴을 감추려다 입술이 떨어지자 고개를 돌렸다.

### 짝사랑 · 주인공쪽 · 시간이 지난 뒤 · 키스 · 거절

**V03-REIMU-CRUSH-PC-LATE_KISS_REFUSE-A · pending**

{name} 「……말로 해. 가까이 오면 또 못 물어보니까.」 {name}는 고개를 들려다 말고 이쪽 얼굴을 막았다.

**V03-REIMU-CRUSH-PC-LATE_KISS_REFUSE-B · pending**

{name} 「……네 목소리면 하던 일도 멈추게 돼.」 {name}는 고개를 들려다 말고 이쪽 얼굴을 막았다.

### 짝사랑 · 미정 · 직후 · 관계 직후 · 해당 없음

**V03-REIMU-CRUSH-UNSET-AFTER-A · pending**

{name} 「……기뻤어. 그게 제일 미안해.」 {name}는 부적 모서리를 손끝으로 문질렀다.

**V03-REIMU-CRUSH-UNSET-AFTER-B · pending**

{name} 「……기쁜 게 더 미안하네.」 {name}는 부적 모서리를 손끝으로 문질렀다.

### 짝사랑 · 미정 · 다음 만남 · 대화하기 · 해당 없음

**V03-REIMU-CRUSH-UNSET-NEXT_TALK-A · pending**

{name} 「그 녀석 앞에서도 네가 언제 오나 생각했어.」 {name}는 찻잔을 내려놓고 눈을 피했다.

**V03-REIMU-CRUSH-UNSET-NEXT_TALK-B · pending**

{name}는 귀가 붉어진 채로 찻잔만 밀어 주었다.

### 짝사랑 · 미정 · 다음 만남 · 스킨십 · 수락

**V03-REIMU-CRUSH-UNSET-NEXT_TOUCH_ALLOW-A · pending**

{name} 「……기쁜 얼굴 하지 말아야 하는데.」 {name}는 손을 빼지 않고 소매 끝만 당겼다.

**V03-REIMU-CRUSH-UNSET-NEXT_TOUCH_ALLOW-B · pending**

{name}는 귀가 붉어진 채로 잡힌 손을 내려다보았다.

### 짝사랑 · 미정 · 다음 만남 · 스킨십 · 거절

**V03-REIMU-CRUSH-UNSET-NEXT_TOUCH_REFUSE-A · pending**

{name} 「좋아한다고 늘 괜찮은 건 아니야.」 {name}는 뻗어 온 손을 탁 쳐냈다.

**V03-REIMU-CRUSH-UNSET-NEXT_TOUCH_REFUSE-B · pending**

{name} 「좋아하는 얼굴은 못 숨기겠어. 그 녀석 앞에서도.」 {name}는 뻗어 온 손을 탁 쳐냈다.

### 짝사랑 · 미정 · 다음 만남 · 키스 · 수락

**V03-REIMU-CRUSH-UNSET-NEXT_KISS_ALLOW-A · pending**

{name} 「……너도 같은 마음이면 좋겠네.」 {name}는 입술이 떨어지자 곧 고개를 돌렸다.

**V03-REIMU-CRUSH-UNSET-NEXT_KISS_ALLOW-B · pending**

{name} 「좋아하는 얼굴은 못 숨기겠어. 그 녀석 앞에서도.」 {name}는 입술이 떨어지자 곧 고개를 돌렸다.

### 짝사랑 · 미정 · 다음 만남 · 키스 · 거절

**V03-REIMU-CRUSH-UNSET-NEXT_KISS_REFUSE-A · pending**

{name} 「내가 좋아하는 건 알잖아. ……너는?」 {name}는 얼굴을 돌리고 부적 한 장을 꺼냈다.

**V03-REIMU-CRUSH-UNSET-NEXT_KISS_REFUSE-B · pending**

{name} 「좋아하는 얼굴은 못 숨기겠어. 그 녀석 앞에서도.」 {name}는 얼굴을 돌리고 부적 한 장을 꺼냈다.

### 짝사랑 · 미정 · 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-REIMU-CRUSH-UNSET-LATE_TALK-A · pending**

{name} 「아직도 너만 기다리네. 그 녀석한테 미안하게.」 {name}는 대답 대신 찻잔만 기울였다.

**V03-REIMU-CRUSH-UNSET-LATE_TALK-B · pending**

{name} 「넌 어떤데. 나만 그 녀석한테 미안한 건 싫어.」 {name}는 대답 대신 찻잔만 기울였다.

### 짝사랑 · 미정 · 시간이 지난 뒤 · 스킨십 · 수락

**V03-REIMU-CRUSH-UNSET-LATE_TOUCH_ALLOW-A · pending**

{name} 「……좋아하는 티는 이제 못 숨기겠어.」 {name}는 잡힌 손을 보다가 소매 끝을 당겼다.

**V03-REIMU-CRUSH-UNSET-LATE_TOUCH_ALLOW-B · pending**

{name} 「넌 어떤데. 나만 그 녀석한테 미안한 건 싫어.」 {name}는 잡힌 손을 보다가 소매 끝을 당겼다.

### 짝사랑 · 미정 · 시간이 지난 뒤 · 스킨십 · 거절

**V03-REIMU-CRUSH-UNSET-LATE_TOUCH_REFUSE-A · pending**

{name} 「이러기 전에 내 질문부터 대답해.」 {name}는 손을 피하고 방석을 옆으로 옮겼다.

**V03-REIMU-CRUSH-UNSET-LATE_TOUCH_REFUSE-B · pending**

{name} 「넌 어떤데. 나만 그 녀석한테 미안한 건 싫어.」 {name}는 손을 피하고 방석을 옆으로 옮겼다.

### 짝사랑 · 미정 · 시간이 지난 뒤 · 키스 · 수락

**V03-REIMU-CRUSH-UNSET-LATE_KISS_ALLOW-A · pending**

{name} 「……계속 이러면서 내 마음은 모른 척하지 마.」 {name}는 입가를 소매로 가렸다.

**V03-REIMU-CRUSH-UNSET-LATE_KISS_ALLOW-B · pending**

{name}는 귀가 붉어진 채로 입술이 떨어지자 고개를 돌렸다.

### 짝사랑 · 미정 · 시간이 지난 뒤 · 키스 · 거절

**V03-REIMU-CRUSH-UNSET-LATE_KISS_REFUSE-A · pending**

{name} 「나만 기대하고 있으면 좀 비참하잖아.」 {name}는 얼굴을 돌린 채 한 발 물러났다.

**V03-REIMU-CRUSH-UNSET-LATE_KISS_REFUSE-B · pending**

{name} 「넌 어떤데. 나만 그 녀석한테 미안한 건 싫어.」 {name}는 얼굴을 돌린 채 한 발 물러났다.

### 굴복 · 주인공쪽 · 직후 · 관계 직후 · 해당 없음

**V03-REIMU-SUBMIT-PC-AFTER-A · pending**

{name} 「……안 불러도 또 오겠지, 나.」 {name}는 부적을 쥔 채 곁에 주저앉았다.

**V03-REIMU-SUBMIT-PC-AFTER-B · pending**

{name} 「……또 네가 부르길 기다리겠지.」 {name}는 부적을 쥔 채 곁에 주저앉았다.

### 굴복 · 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

**V03-REIMU-SUBMIT-PC-NEXT_TALK-A · pending**

{name} 「……부르기 전에 와 버렸네.」 {name}는 먼저 돌아보고도 부적을 감췄다.

**V03-REIMU-SUBMIT-PC-NEXT_TALK-B · pending**

{name}는 부르기도 전에 돌아보고 찻잔만 밀어 주었다.

### 굴복 · 주인공쪽 · 다음 만남 · 스킨십 · 수락

**V03-REIMU-SUBMIT-PC-NEXT_TOUCH_ALLOW-A · pending**

{name} 「……이젠 손 빼는 게 더 어색하네.」 {name}는 잡힌 손을 보다가 부적을 감췄다.

**V03-REIMU-SUBMIT-PC-NEXT_TOUCH_ALLOW-B · pending**

{name}는 부르기도 전에 돌아보고 잡힌 손을 내려다보았다.

### 굴복 · 주인공쪽 · 다음 만남 · 스킨십 · 거절

**V03-REIMU-SUBMIT-PC-NEXT_TOUCH_REFUSE-A · pending**

{name} 「……옆에 왔어도 오늘은 싫어.」 {name}는 내밀려던 손을 거두고 이쪽 손을 막았다.

**V03-REIMU-SUBMIT-PC-NEXT_TOUCH_REFUSE-B · pending**

{name} 「……내가 먼저 와 버렸네.」 {name}는 내밀려던 손을 거두고 이쪽 손을 막았다.

### 굴복 · 주인공쪽 · 다음 만남 · 키스 · 수락

**V03-REIMU-SUBMIT-PC-NEXT_KISS_ALLOW-A · pending**

{name} 「……눈 감는 건 벌써 어렵지도 않네.」 {name}는 끝난 뒤에야 부적 쥔 손을 폈다.

**V03-REIMU-SUBMIT-PC-NEXT_KISS_ALLOW-B · pending**

{name} 「……내가 먼저 와 버렸네.」 {name}는 끝난 뒤에야 부적 쥔 손을 폈다.

### 굴복 · 주인공쪽 · 다음 만남 · 키스 · 거절

**V03-REIMU-SUBMIT-PC-NEXT_KISS_REFUSE-A · pending**

{name} 「……기다리는 것 같아도 지금은 아니야.」 {name}는 다가서려다 말고 손바닥으로 막았다.

**V03-REIMU-SUBMIT-PC-NEXT_KISS_REFUSE-B · pending**

{name} 「……내가 먼저 와 버렸네.」 {name}는 다가서려다 말고 손바닥으로 막았다.

### 굴복 · 주인공쪽 · 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-REIMU-SUBMIT-PC-LATE_TALK-A · pending**

{name} 「……또 여기부터 왔네. 그 녀석 방은 못 가면서.」 {name}는 먼저 돌아보고도 부적을 감췄다.

**V03-REIMU-SUBMIT-PC-LATE_TALK-B · pending**

{name} 「……여기 오는 건 빨라졌네.」 {name}는 먼저 돌아보고도 부적을 감췄다.

### 굴복 · 주인공쪽 · 시간이 지난 뒤 · 스킨십 · 수락

**V03-REIMU-SUBMIT-PC-LATE_TOUCH_ALLOW-A · pending**

{name} 「……손이 먼저 나왔네. 웃지 마.」 {name}는 잡힌 손을 보다가 부적을 감췄다.

**V03-REIMU-SUBMIT-PC-LATE_TOUCH_ALLOW-B · pending**

{name} 「……여기 오는 건 빨라졌네.」 {name}는 잡힌 손을 보다가 부적을 감췄다.

### 굴복 · 주인공쪽 · 시간이 지난 뒤 · 스킨십 · 거절

**V03-REIMU-SUBMIT-PC-LATE_TOUCH_REFUSE-A · pending**

{name} 「……오늘은 손 빼고 싶어.」 {name}는 뻗으려던 손을 소매 안으로 거뒀다.

**V03-REIMU-SUBMIT-PC-LATE_TOUCH_REFUSE-B · pending**

{name} 「……여기 오는 건 빨라졌네.」 {name}는 뻗으려던 손을 소매 안으로 거뒀다.

### 굴복 · 주인공쪽 · 시간이 지난 뒤 · 키스 · 수락

**V03-REIMU-SUBMIT-PC-LATE_KISS_ALLOW-A · pending**

{name} 「……그 녀석 생각보다 눈 감는 게 빨랐네.」 {name}는 끝난 뒤에야 부적 쥔 손을 폈다.

**V03-REIMU-SUBMIT-PC-LATE_KISS_ALLOW-B · pending**

{name}는 부르기도 전에 돌아보고 입술이 떨어지자 고개를 돌렸다.

### 굴복 · 주인공쪽 · 시간이 지난 뒤 · 키스 · 거절

**V03-REIMU-SUBMIT-PC-LATE_KISS_REFUSE-A · pending**

{name} 「……곁에 남아도 오늘은 싫어.」 {name}는 고개를 들려다 말고 이쪽 얼굴을 막았다.

**V03-REIMU-SUBMIT-PC-LATE_KISS_REFUSE-B · pending**

{name} 「……여기 오는 건 빨라졌네.」 {name}는 고개를 들려다 말고 이쪽 얼굴을 막았다.

### 굴복 · 미정 · 직후 · 관계 직후 · 해당 없음

**V03-REIMU-SUBMIT-UNSET-AFTER-A · pending**

{name} 「……이제 가도 돼? 그 녀석이 기다릴 텐데.」 {name}는 옷깃을 여미고 부적만 내려다봤다.

**V03-REIMU-SUBMIT-UNSET-AFTER-B · pending**

{name} 「그 녀석한텐 평소처럼 하면 되겠지.」 {name}는 옷깃을 여미고 부적만 내려다봤다.

### 굴복 · 미정 · 다음 만남 · 대화하기 · 해당 없음

**V03-REIMU-SUBMIT-UNSET-NEXT_TALK-A · pending**

{name} 「그 녀석한텐 괜찮다고 했어. ……그뿐이야.」 {name}는 대답하고는 찻잔을 집었다.

**V03-REIMU-SUBMIT-UNSET-NEXT_TALK-B · pending**

{name}는 고개를 내린 채 찻잔만 밀어 주었다.

### 굴복 · 미정 · 다음 만남 · 스킨십 · 수락

**V03-REIMU-SUBMIT-UNSET-NEXT_TOUCH_ALLOW-A · pending**

{name} 「……가만히 있으면 되는 거지.」 {name}는 손은 그대로 두고 찻잔만 바라봤다.

**V03-REIMU-SUBMIT-UNSET-NEXT_TOUCH_ALLOW-B · pending**

{name}는 고개를 내린 채 잡힌 손을 내려다보았다.

### 굴복 · 미정 · 다음 만남 · 스킨십 · 거절

**V03-REIMU-SUBMIT-UNSET-NEXT_TOUCH_REFUSE-A · pending**

{name} 「손만은 놔. ……잠깐이라도.」 {name}는 뻗어 온 손을 탁 쳐냈다.

**V03-REIMU-SUBMIT-UNSET-NEXT_TOUCH_REFUSE-B · pending**

{name} 「그 녀석이 괜찮냐고 물으면 웃기만 해.」 {name}는 뻗어 온 손을 탁 쳐냈다.

### 굴복 · 미정 · 다음 만남 · 키스 · 수락

**V03-REIMU-SUBMIT-UNSET-NEXT_KISS_ALLOW-A · pending**

{name} 「……이제 됐어? 돌아가야 해.」 {name}는 입가를 소매로 닦고 고개를 돌렸다.

**V03-REIMU-SUBMIT-UNSET-NEXT_KISS_ALLOW-B · pending**

{name} 「그 녀석이 괜찮냐고 물으면 웃기만 해.」 {name}는 입가를 소매로 닦고 고개를 돌렸다.

### 굴복 · 미정 · 다음 만남 · 키스 · 거절

**V03-REIMU-SUBMIT-UNSET-NEXT_KISS_REFUSE-A · pending**

{name} 「……싫다고 말해도 되는 거잖아.」 {name}는 얼굴을 돌리고 부적 한 장을 꺼냈다.

**V03-REIMU-SUBMIT-UNSET-NEXT_KISS_REFUSE-B · pending**

{name} 「그 녀석이 괜찮냐고 물으면 웃기만 해.」 {name}는 얼굴을 돌리고 부적 한 장을 꺼냈다.

### 굴복 · 미정 · 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-REIMU-SUBMIT-UNSET-LATE_TALK-A · pending**

{name} 「그 녀석 앞에선 평소처럼 했어. 칭찬하지 마.」 {name}는 대답하고는 찻잔을 집었다.

**V03-REIMU-SUBMIT-UNSET-LATE_TALK-B · pending**

{name} 「그 녀석한테 차를 따르는데 손이 멈추더라.」 {name}는 대답하고는 찻잔을 집었다.

### 굴복 · 미정 · 시간이 지난 뒤 · 스킨십 · 수락

**V03-REIMU-SUBMIT-UNSET-LATE_TOUCH_ALLOW-A · pending**

{name} 「……그 녀석이 이 손을 안 봤으면 좋겠네.」 {name}는 손은 그대로 두고 찻잔만 바라봤다.

**V03-REIMU-SUBMIT-UNSET-LATE_TOUCH_ALLOW-B · pending**

{name} 「그 녀석한테 차를 따르는데 손이 멈추더라.」 {name}는 손은 그대로 두고 찻잔만 바라봤다.

### 굴복 · 미정 · 시간이 지난 뒤 · 스킨십 · 거절

**V03-REIMU-SUBMIT-UNSET-LATE_TOUCH_REFUSE-A · pending**

{name} 「늘 가만히 있었다고 오늘도 같지는 않아.」 {name}는 손을 피하고 방석을 옆으로 옮겼다.

**V03-REIMU-SUBMIT-UNSET-LATE_TOUCH_REFUSE-B · pending**

{name} 「그 녀석한테 차를 따르는데 손이 멈추더라.」 {name}는 손을 피하고 방석을 옆으로 옮겼다.

### 굴복 · 미정 · 시간이 지난 뒤 · 키스 · 수락

**V03-REIMU-SUBMIT-UNSET-LATE_KISS_ALLOW-A · pending**

{name} 「……끝났으면 말해. 할 일이 있으니까.」 {name}는 입가를 소매로 닦고 고개를 돌렸다.

**V03-REIMU-SUBMIT-UNSET-LATE_KISS_ALLOW-B · pending**

{name}는 고개를 내린 채 입술이 떨어지자 고개를 돌렸다.

### 굴복 · 미정 · 시간이 지난 뒤 · 키스 · 거절

**V03-REIMU-SUBMIT-UNSET-LATE_KISS_REFUSE-A · pending**

{name} 「그만해. ……그 말까지 못 하게 하진 마.」 {name}는 얼굴을 돌린 채 한 발 물러났다.

**V03-REIMU-SUBMIT-UNSET-LATE_KISS_REFUSE-B · pending**

{name} 「그 녀석한테 차를 따르는데 손이 멈추더라.」 {name}는 얼굴을 돌린 채 한 발 물러났다.

### 협박 · 주인공쪽 · 직후 · 관계 직후 · 해당 없음

**V03-REIMU-COERCED-PC-AFTER-A · pending**

{name} 「……곁에 있어야 네가 무슨 말 할지 알겠어서.」 {name}는 부적을 쥔 채 곁에 주저앉았다.

**V03-REIMU-COERCED-PC-AFTER-B · pending**

{name} 「……곁에 있어야 네 말을 먼저 듣겠어서.」 {name}는 부적을 쥔 채 곁에 주저앉았다.

### 협박 · 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

**V03-REIMU-COERCED-PC-NEXT_TALK-A · pending**

{name} 「……네가 부르나 듣고 있었어.」 {name}는 먼저 돌아보고도 부적을 감췄다.

**V03-REIMU-COERCED-PC-NEXT_TALK-B · pending**

{name}는 이쪽 표정부터 살피고 찻잔만 밀어 주었다.

### 협박 · 주인공쪽 · 다음 만남 · 스킨십 · 수락

**V03-REIMU-COERCED-PC-NEXT_TOUCH_ALLOW-A · pending**

{name} 「……손은 그냥 둘게. 걔한텐 말하지 마.」 {name}는 잡힌 손을 보다가 부적을 감췄다.

**V03-REIMU-COERCED-PC-NEXT_TOUCH_ALLOW-B · pending**

{name} 「……네가 부르나 듣고 있었어.」 {name}는 잡힌 손을 보다가 부적을 감췄다.

### 협박 · 주인공쪽 · 다음 만남 · 스킨십 · 거절

**V03-REIMU-COERCED-PC-NEXT_TOUCH_REFUSE-A · pending**

{name} 「……옆에 있다고 안 무서운 줄 알았어?」 {name}는 내밀려던 손을 거두고 이쪽 손을 막았다.

**V03-REIMU-COERCED-PC-NEXT_TOUCH_REFUSE-B · pending**

{name}는 이쪽 표정부터 살피고 뻗어 온 손을 말없이 쳐냈다.

### 협박 · 주인공쪽 · 다음 만남 · 키스 · 수락

**V03-REIMU-COERCED-PC-NEXT_KISS_ALLOW-A · pending**

{name} 「……약속부터 해. 그 녀석한텐 말 안 한다고.」 {name}는 끝난 뒤에야 부적 쥔 손을 폈다.

**V03-REIMU-COERCED-PC-NEXT_KISS_ALLOW-B · pending**

{name} 「……네가 부르나 듣고 있었어.」 {name}는 끝난 뒤에야 부적 쥔 손을 폈다.

### 협박 · 주인공쪽 · 다음 만남 · 키스 · 거절

**V03-REIMU-COERCED-PC-NEXT_KISS_REFUSE-A · pending**

{name} 「……오늘도 안 피할 줄 알았지.」 {name}는 다가서려다 말고 손바닥으로 막았다.

**V03-REIMU-COERCED-PC-NEXT_KISS_REFUSE-B · pending**

{name} 「……네가 부르나 듣고 있었어.」 {name}는 다가서려다 말고 손바닥으로 막았다.

### 협박 · 주인공쪽 · 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-REIMU-COERCED-PC-LATE_TALK-A · pending**

{name} 「……네가 어디 있는지부터 보게 되네.」 {name}는 먼저 돌아보고도 부적을 감췄다.

**V03-REIMU-COERCED-PC-LATE_TALK-B · pending**

{name} 「……자꾸 네 눈치부터 보네.」 {name}는 먼저 돌아보고도 부적을 감췄다.

### 협박 · 주인공쪽 · 시간이 지난 뒤 · 스킨십 · 수락

**V03-REIMU-COERCED-PC-LATE_TOUCH_ALLOW-A · pending**

{name} 「……익숙한 척은 할 수 있어.」 {name}는 잡힌 손을 보다가 부적을 감췄다.

**V03-REIMU-COERCED-PC-LATE_TOUCH_ALLOW-B · pending**

{name} 「……자꾸 네 눈치부터 보네.」 {name}는 잡힌 손을 보다가 부적을 감췄다.

### 협박 · 주인공쪽 · 시간이 지난 뒤 · 스킨십 · 거절

**V03-REIMU-COERCED-PC-LATE_TOUCH_REFUSE-A · pending**

{name} 「……오늘은 손 뺄 거야. 지금이라도.」 {name}는 뻗으려던 손을 소매 안으로 거뒀다.

**V03-REIMU-COERCED-PC-LATE_TOUCH_REFUSE-B · pending**

{name} 「……자꾸 네 눈치부터 보네.」 {name}는 뻗으려던 손을 소매 안으로 거뒀다.

### 협박 · 주인공쪽 · 시간이 지난 뒤 · 키스 · 수락

**V03-REIMU-COERCED-PC-LATE_KISS_ALLOW-A · pending**

{name} 「……눈부터 감았네. 정말 싫다.」 {name}는 끝난 뒤에야 부적 쥔 손을 폈다.

**V03-REIMU-COERCED-PC-LATE_KISS_ALLOW-B · pending**

{name}는 이쪽 표정부터 살피고 입술이 떨어지자 고개를 돌렸다.

### 협박 · 주인공쪽 · 시간이 지난 뒤 · 키스 · 거절

**V03-REIMU-COERCED-PC-LATE_KISS_REFUSE-A · pending**

{name} 「……기다린 것처럼 보여도 아니야.」 {name}는 고개를 들려다 말고 이쪽 얼굴을 막았다.

**V03-REIMU-COERCED-PC-LATE_KISS_REFUSE-B · pending**

{name} 「……자꾸 네 눈치부터 보네.」 {name}는 고개를 들려다 말고 이쪽 얼굴을 막았다.

### 협박 · 미정 · 직후 · 관계 직후 · 해당 없음

**V03-REIMU-COERCED-UNSET-AFTER-A · pending**

{name} 「……그 녀석한테 말 안 할 거지.」 {name}는 옷깃을 여미고 부적만 내려다봤다.

**V03-REIMU-COERCED-UNSET-AFTER-B · pending**

{name} 「그 녀석한테만은 말하지 마.」 {name}는 옷깃을 여미고 부적만 내려다봤다.

### 협박 · 미정 · 다음 만남 · 대화하기 · 해당 없음

**V03-REIMU-COERCED-UNSET-NEXT_TALK-A · pending**

{name} 「할 말이 그거야? 그 녀석 이름은 빼고 해.」 {name}는 대답하고는 찻잔을 집었다.

**V03-REIMU-COERCED-UNSET-NEXT_TALK-B · pending**

{name}는 문간에서 눈을 떼지 못한 채 찻잔만 밀어 주었다.

### 협박 · 미정 · 다음 만남 · 스킨십 · 수락

**V03-REIMU-COERCED-UNSET-NEXT_TOUCH_ALLOW-A · pending**

{name} 「……알았어. 웃으라고는 하지 마.」 {name}는 손은 그대로 두고 찻잔만 바라봤다.

**V03-REIMU-COERCED-UNSET-NEXT_TOUCH_ALLOW-B · pending**

{name} 「그 녀석 이름을 들으면 말이 안 나와.」 {name}는 손은 그대로 두고 찻잔만 바라봤다.

### 협박 · 미정 · 다음 만남 · 스킨십 · 거절

**V03-REIMU-COERCED-UNSET-NEXT_TOUCH_REFUSE-A · pending**

{name} 「손 치워. 그 녀석 얘기로 말 바꾸게 하지 마.」 {name}는 뻗어 온 손을 탁 쳐냈다.

**V03-REIMU-COERCED-UNSET-NEXT_TOUCH_REFUSE-B · pending**

{name}는 문간에서 눈을 떼지 못한 채 뻗어 온 손을 말없이 쳐냈다.

### 협박 · 미정 · 다음 만남 · 키스 · 수락

**V03-REIMU-COERCED-UNSET-NEXT_KISS_ALLOW-A · pending**

{name} 「……이제 보내 줘. 얼굴 좀 고치게.」 {name}는 입가를 소매로 닦고 고개를 돌렸다.

**V03-REIMU-COERCED-UNSET-NEXT_KISS_ALLOW-B · pending**

{name} 「그 녀석 이름을 들으면 말이 안 나와.」 {name}는 입가를 소매로 닦고 고개를 돌렸다.

### 협박 · 미정 · 다음 만남 · 키스 · 거절

**V03-REIMU-COERCED-UNSET-NEXT_KISS_REFUSE-A · pending**

{name} 「……고개 돌린 거 봤잖아. 그만해.」 {name}는 얼굴을 돌리고 부적 한 장을 꺼냈다.

**V03-REIMU-COERCED-UNSET-NEXT_KISS_REFUSE-B · pending**

{name} 「그 녀석 이름을 들으면 말이 안 나와.」 {name}는 얼굴을 돌리고 부적 한 장을 꺼냈다.

### 협박 · 미정 · 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-REIMU-COERCED-UNSET-LATE_TALK-A · pending**

{name} 「언제까지 그 녀석 이름으로 날 부를 거야.」 {name}는 대답하고는 찻잔을 집었다.

**V03-REIMU-COERCED-UNSET-LATE_TALK-B · pending**

{name} 「그 녀석 앞에서 웃는 법만 늘었어.」 {name}는 대답하고는 찻잔을 집었다.

### 협박 · 미정 · 시간이 지난 뒤 · 스킨십 · 수락

**V03-REIMU-COERCED-UNSET-LATE_TOUCH_ALLOW-A · pending**

{name} 「……그 녀석 앞에서도 이러고 있을까 봐.」 {name}는 손은 그대로 두고 찻잔만 바라봤다.

**V03-REIMU-COERCED-UNSET-LATE_TOUCH_ALLOW-B · pending**

{name} 「그 녀석 앞에서 웃는 법만 늘었어.」 {name}는 손은 그대로 두고 찻잔만 바라봤다.

### 협박 · 미정 · 시간이 지난 뒤 · 스킨십 · 거절

**V03-REIMU-COERCED-UNSET-LATE_TOUCH_REFUSE-A · pending**

{name} 「그 얘긴 꺼내지 마. ……싫어.」 {name}는 손을 피하고 방석을 옆으로 옮겼다.

**V03-REIMU-COERCED-UNSET-LATE_TOUCH_REFUSE-B · pending**

{name} 「그 녀석 앞에서 웃는 법만 늘었어.」 {name}는 손을 피하고 방석을 옆으로 옮겼다.

### 협박 · 미정 · 시간이 지난 뒤 · 키스 · 수락

**V03-REIMU-COERCED-UNSET-LATE_KISS_ALLOW-A · pending**

{name} 「……됐지. 그 녀석한텐 늦었다고만 할게.」 {name}는 입가를 소매로 닦고 고개를 돌렸다.

**V03-REIMU-COERCED-UNSET-LATE_KISS_ALLOW-B · pending**

{name}는 문간에서 눈을 떼지 못한 채 입술이 떨어지자 고개를 돌렸다.

### 협박 · 미정 · 시간이 지난 뒤 · 키스 · 거절

**V03-REIMU-COERCED-UNSET-LATE_KISS_REFUSE-A · pending**

{name} 「그 녀석이 걱정된다고 다 받아야 해?」 {name}는 얼굴을 돌린 채 한 발 물러났다.

**V03-REIMU-COERCED-UNSET-LATE_KISS_REFUSE-B · pending**

{name} 「그 녀석 앞에서 웃는 법만 늘었어.」 {name}는 얼굴을 돌린 채 한 발 물러났다.

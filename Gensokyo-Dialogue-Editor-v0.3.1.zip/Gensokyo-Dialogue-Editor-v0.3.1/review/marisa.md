# 키리사메 마리사 · 사용자 수정 반영본 v0.3.1

사용자 본문·검토 결과를 보존하고 이름·따옴표 경계 공백만 통일했다.

### 싫어함 · 주인공쪽 · 직후 · 관계 직후 · 해당 없음

**V03-MARISA-HATE-PC-AFTER-A · pending**

{name} 「……이렇게 편한 게 더 짜증 나네.」 {name}는 모자를 집고도 일어나지 않았다.

**V03-MARISA-HATE-PC-AFTER-B · pending**

{name} 「……여기선 일어나는 게 더 어렵네. 짜증 나.」 {name}는 모자를 집고도 일어나지 않았다.

### 싫어함 · 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

**V03-MARISA-HATE-PC-NEXT_TALK-A · pending**

{name} 「……또 네 쪽으로 왔네. 웃을 일 아니거든.」 {name}는 먼저 돌아보고도 모자챙을 당겼다.

**V03-MARISA-HATE-PC-NEXT_TALK-B · pending**

{name}는 이쪽을 먼저 찾고도 모자챙만 고쳐 썼다.

### 싫어함 · 주인공쪽 · 다음 만남 · 스킨십 · 수락

**V03-MARISA-HATE-PC-NEXT_TOUCH_ALLOW-A · pending**

{name} 「……손은 그냥 둬. 기뻐하지 말고.」 {name}는 잡힌 손을 보며 모자챙을 내렸다.

**V03-MARISA-HATE-PC-NEXT_TOUCH_ALLOW-B · pending**

{name} 「……또 네 옆이네. 마음에 안 들어.」 {name}는 잡힌 손을 보며 모자챙을 내렸다.

### 싫어함 · 주인공쪽 · 다음 만남 · 스킨십 · 거절

**V03-MARISA-HATE-PC-NEXT_TOUCH_REFUSE-A · pending**

{name} 「……내가 가까이 왔다고 이러진 마.」 {name}는 내밀려던 손을 거두고 이쪽 손을 밀었다.

**V03-MARISA-HATE-PC-NEXT_TOUCH_REFUSE-B · pending**

{name}는 이쪽을 먼저 찾고도 뻗은 손을 피하고 모자를 눌러썼다.

### 싫어함 · 주인공쪽 · 다음 만남 · 키스 · 수락

**V03-MARISA-HATE-PC-NEXT_KISS_ALLOW-A · pending**

{name} 「……너한텐 왜 이렇게 말이 안 나오냐.」 {name}는 끝나자 서둘러 모자로 얼굴을 가렸다.

**V03-MARISA-HATE-PC-NEXT_KISS_ALLOW-B · pending**

{name} 「……또 네 옆이네. 마음에 안 들어.」 {name}는 끝나자 서둘러 모자로 얼굴을 가렸다.

### 싫어함 · 주인공쪽 · 다음 만남 · 키스 · 거절

**V03-MARISA-HATE-PC-NEXT_KISS_REFUSE-A · pending**

{name} 「……또 휩쓸릴 줄 알았냐. 안 돼.」 {name}는 다가서려다 멈추고 모자챙으로 막았다.

**V03-MARISA-HATE-PC-NEXT_KISS_REFUSE-B · pending**

{name} 「……또 네 옆이네. 마음에 안 들어.」 {name}는 다가서려다 멈추고 모자챙으로 막았다.

### 싫어함 · 주인공쪽 · 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-MARISA-HATE-PC-LATE_TALK-A · pending**

{name} 「……빗자루도 여기 두고 갔네. 짜증 나.」 {name}는 먼저 돌아보고도 모자챙을 당겼다.

**V03-MARISA-HATE-PC-LATE_TALK-B · pending**

{name} 「……빗자루도 이쪽에 두고 갔네. 나 참.」 {name}는 먼저 돌아보고도 모자챙을 당겼다.

### 싫어함 · 주인공쪽 · 시간이 지난 뒤 · 스킨십 · 수락

**V03-MARISA-HATE-PC-LATE_TOUCH_ALLOW-A · pending**

{name} 「……손은 익었지. 네가 좋아진 건 아니고.」 {name}는 잡힌 손을 보며 모자챙을 내렸다.

**V03-MARISA-HATE-PC-LATE_TOUCH_ALLOW-B · pending**

{name} 「……빗자루도 이쪽에 두고 갔네. 나 참.」 {name}는 잡힌 손을 보며 모자챙을 내렸다.

### 싫어함 · 주인공쪽 · 시간이 지난 뒤 · 스킨십 · 거절

**V03-MARISA-HATE-PC-LATE_TOUCH_REFUSE-A · pending**

{name} 「……옆에 온 거랑 손 잡는 건 달라.」 {name}는 내밀던 손을 빼고 모자로 사이를 막았다.

**V03-MARISA-HATE-PC-LATE_TOUCH_REFUSE-B · pending**

{name} 「……빗자루도 이쪽에 두고 갔네. 나 참.」 {name}는 내밀던 손을 빼고 모자로 사이를 막았다.

### 싫어함 · 주인공쪽 · 시간이 지난 뒤 · 키스 · 수락

**V03-MARISA-HATE-PC-LATE_KISS_ALLOW-A · pending**

{name} 「……내가 먼저 모자를 벗네. 기가 막혀.」 {name}는 끝나자 서둘러 모자로 얼굴을 가렸다.

**V03-MARISA-HATE-PC-LATE_KISS_ALLOW-B · pending**

{name}는 이쪽을 먼저 찾고도 입술이 떨어지자 모자를 눌러썼다.

### 싫어함 · 주인공쪽 · 시간이 지난 뒤 · 키스 · 거절

**V03-MARISA-HATE-PC-LATE_KISS_REFUSE-A · pending**

{name} 「……이걸 기다린 줄 알았어? 틀렸네.」 {name}는 다가오던 고개를 돌리고 모자를 세웠다.

**V03-MARISA-HATE-PC-LATE_KISS_REFUSE-B · pending**

{name} 「……빗자루도 이쪽에 두고 갔네. 나 참.」 {name}는 다가오던 고개를 돌리고 모자를 세웠다.

### 싫어함 · 미정 · 직후 · 관계 직후 · 해당 없음

**V03-MARISA-HATE-UNSET-AFTER-A · pending**

{name} 「……그 녀석한텐 뭐라고 하지. 넌 웃지 마.」 {name}는 모자를 눌러쓰고 입을 다물었다.

**V03-MARISA-HATE-UNSET-AFTER-B · pending**

{name} 「걔 얼굴은 어떻게 보냐. 넌 웃지 마.」 {name}는 모자를 눌러쓰고 입을 다물었다.

### 싫어함 · 미정 · 다음 만남 · 대화하기 · 해당 없음

**V03-MARISA-HATE-UNSET-NEXT_TALK-A · pending**

{name} 「그 녀석이 네 얘길 하더라. 대답하기 싫었어.」 {name}는 대답하고는 모자만 만지작거렸다.

**V03-MARISA-HATE-UNSET-NEXT_TALK-B · pending**

{name}는 모자챙 아래로 눈을 숨기고 모자챙만 고쳐 썼다.

### 싫어함 · 미정 · 다음 만남 · 스킨십 · 수락

**V03-MARISA-HATE-UNSET-NEXT_TOUCH_ALLOW-A · pending**

{name} 「……잡고 있다고 화 풀린 건 아니야.」 {name}는 손을 빼지 않고 모자 그늘로 숨었다.

**V03-MARISA-HATE-UNSET-NEXT_TOUCH_ALLOW-B · pending**

{name} 「그 녀석 얘긴 관두자. 농담도 안 나오니까.」 {name}는 손을 빼지 않고 모자 그늘로 숨었다.

### 싫어함 · 미정 · 다음 만남 · 스킨십 · 거절

**V03-MARISA-HATE-UNSET-NEXT_TOUCH_REFUSE-A · pending**

{name} 「야, 손. 그 일로 뭐든 된다고 생각했냐?」 {name}는 손을 가볍게 피하고 웃음을 거뒀다.

**V03-MARISA-HATE-UNSET-NEXT_TOUCH_REFUSE-B · pending**

{name}는 모자챙 아래로 눈을 숨기고 뻗은 손을 피하고 모자를 눌러썼다.

### 싫어함 · 미정 · 다음 만남 · 키스 · 수락

**V03-MARISA-HATE-UNSET-NEXT_KISS_ALLOW-A · pending**

{name} 「……그 녀석보다 낫다는 소린 하지 마.」 {name}는 입술이 떨어지자 모자챙을 눌러썼다.

**V03-MARISA-HATE-UNSET-NEXT_KISS_ALLOW-B · pending**

{name} 「그 녀석 얘긴 관두자. 농담도 안 나오니까.」 {name}는 입술이 떨어지자 모자챙을 눌러썼다.

### 싫어함 · 미정 · 다음 만남 · 키스 · 거절

**V03-MARISA-HATE-UNSET-NEXT_KISS_REFUSE-A · pending**

{name} 「싫다니까. 농담으로도 넘기지 마.」 {name}는 이마 앞에 손바닥을 세웠다.

**V03-MARISA-HATE-UNSET-NEXT_KISS_REFUSE-B · pending**

{name} 「그 녀석 얘긴 관두자. 농담도 안 나오니까.」 {name}는 이마 앞에 손바닥을 세웠다.

### 싫어함 · 미정 · 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-MARISA-HATE-UNSET-LATE_TALK-A · pending**

{name} 「그 녀석 앞에서 네 얘기까지 골라 해야 하잖아.」 {name}는 대답하고는 모자만 만지작거렸다.

**V03-MARISA-HATE-UNSET-LATE_TALK-B · pending**

{name} 「걔한테 말 못 했다고 너랑 잘될 줄 알진 마.」 {name}는 대답하고는 모자만 만지작거렸다.

### 싫어함 · 미정 · 시간이 지난 뒤 · 스킨십 · 수락

**V03-MARISA-HATE-UNSET-LATE_TOUCH_ALLOW-A · pending**

{name} 「……그 녀석한텐 말도 못 했는데 잘도 이러네.」 {name}는 손을 빼지 않고 모자 그늘로 숨었다.

**V03-MARISA-HATE-UNSET-LATE_TOUCH_ALLOW-B · pending**

{name} 「걔한테 말 못 했다고 너랑 잘될 줄 알진 마.」 {name}는 손을 빼지 않고 모자 그늘로 숨었다.

### 싫어함 · 미정 · 시간이 지난 뒤 · 스킨십 · 거절

**V03-MARISA-HATE-UNSET-LATE_TOUCH_REFUSE-A · pending**

{name} 「안 된다니까. 이제 알아들을 때도 됐잖아.」 {name}는 손을 뒤로 빼며 한 발 비켰다.

**V03-MARISA-HATE-UNSET-LATE_TOUCH_REFUSE-B · pending**

{name} 「걔한테 말 못 했다고 너랑 잘될 줄 알진 마.」 {name}는 손을 뒤로 빼며 한 발 비켰다.

### 싫어함 · 미정 · 시간이 지난 뒤 · 키스 · 수락

**V03-MARISA-HATE-UNSET-LATE_KISS_ALLOW-A · pending**

{name} 「……네가 이긴 것 같은 표정 짓지 마.」 {name}는 입술이 떨어지자 모자챙을 눌러썼다.

**V03-MARISA-HATE-UNSET-LATE_KISS_ALLOW-B · pending**

{name}는 모자챙 아래로 눈을 숨기고 입술이 떨어지자 모자를 눌러썼다.

### 싫어함 · 미정 · 시간이 지난 뒤 · 키스 · 거절

**V03-MARISA-HATE-UNSET-LATE_KISS_REFUSE-A · pending**

{name} 「그만해. 네 얼굴 가까이서 보고 싶지 않아.」 {name}는 얼굴을 피한 채 빗자루를 고쳐 쥐었다.

**V03-MARISA-HATE-UNSET-LATE_KISS_REFUSE-B · pending**

{name} 「걔한테 말 못 했다고 너랑 잘될 줄 알진 마.」 {name}는 얼굴을 피한 채 빗자루를 고쳐 쥐었다.

### 친구 · 주인공쪽 · 직후 · 관계 직후 · 해당 없음

**V03-MARISA-FRIEND-PC-AFTER-A · pending**

{name} 「헤헤. ……네 옆이 편하니까 큰일이네.」 {name}는 모자를 집었다가 도로 내려놓았다.

**V03-MARISA-FRIEND-PC-AFTER-B · pending**

{name} 「헤헤. ……친구치곤 오래 붙어 있네.」 {name}는 모자를 집었다가 도로 내려놓았다.

### 친구 · 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

**V03-MARISA-FRIEND-PC-NEXT_TALK-A · pending**

{name} 「여기 앉아. ……평소처럼 부르네, 나.」 {name}는 옆에 앉자마자 모자챙을 내렸다.

**V03-MARISA-FRIEND-PC-NEXT_TALK-B · pending**

{name}는 옆에 앉으려다 멈추고 모자챙만 고쳐 썼다.

### 친구 · 주인공쪽 · 다음 만남 · 스킨십 · 수락

**V03-MARISA-FRIEND-PC-NEXT_TOUCH_ALLOW-A · pending**

{name} 「……전엔 장난으로 빼던 손인데 말이야.」 {name}는 먼저 손가락을 걸고는 시선을 피했다.

**V03-MARISA-FRIEND-PC-NEXT_TOUCH_ALLOW-B · pending**

{name}는 옆에 앉으려다 멈추고 잡힌 손을 모자 그늘에 숨겼다.

### 친구 · 주인공쪽 · 다음 만남 · 스킨십 · 거절

**V03-MARISA-FRIEND-PC-NEXT_TOUCH_REFUSE-A · pending**

{name} 「……오늘은 그냥 옆에만 있어 줘.」 {name}는 내밀려던 손을 거두고 이쪽 손을 밀었다.

**V03-MARISA-FRIEND-PC-NEXT_TOUCH_REFUSE-B · pending**

{name} 「……너한테 기대는 건 쉬운데 말이야.」 {name}는 내밀려던 손을 거두고 이쪽 손을 밀었다.

### 친구 · 주인공쪽 · 다음 만남 · 키스 · 수락

**V03-MARISA-FRIEND-PC-NEXT_KISS_ALLOW-A · pending**

{name} 「……친구란 말이 좀 이상해졌네.」 {name}는 미리 벗어 둔 모자로 얼굴을 가렸다.

**V03-MARISA-FRIEND-PC-NEXT_KISS_ALLOW-B · pending**

{name} 「……너한테 기대는 건 쉬운데 말이야.」 {name}는 미리 벗어 둔 모자로 얼굴을 가렸다.

### 친구 · 주인공쪽 · 다음 만남 · 키스 · 거절

**V03-MARISA-FRIEND-PC-NEXT_KISS_REFUSE-A · pending**

{name} 「……이러면 또 네 옆에 눌러앉잖아.」 {name}는 다가서려다 멈추고 모자챙으로 막았다.

**V03-MARISA-FRIEND-PC-NEXT_KISS_REFUSE-B · pending**

{name} 「……너한테 기대는 건 쉬운데 말이야.」 {name}는 다가서려다 멈추고 모자챙으로 막았다.

### 친구 · 주인공쪽 · 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-MARISA-FRIEND-PC-LATE_TALK-A · pending**

{name} 「……네 자리부터 찾네. 전이랑 다른 뜻으로.」 {name}는 벗어 둔 모자를 다시 썼다.

**V03-MARISA-FRIEND-PC-LATE_TALK-B · pending**

{name} 「……내 자리처럼 앉게 되네.」 {name}는 벗어 둔 모자를 다시 썼다.

### 친구 · 주인공쪽 · 시간이 지난 뒤 · 스킨십 · 수락

**V03-MARISA-FRIEND-PC-LATE_TOUCH_ALLOW-A · pending**

{name} 「……내가 먼저 잡네. 버릇이 됐나 봐.」 {name}는 손을 당기려다 말고 고개를 숙였다.

**V03-MARISA-FRIEND-PC-LATE_TOUCH_ALLOW-B · pending**

{name} 「……내 자리처럼 앉게 되네.」 {name}는 손을 당기려다 말고 고개를 숙였다.

### 친구 · 주인공쪽 · 시간이 지난 뒤 · 스킨십 · 거절

**V03-MARISA-FRIEND-PC-LATE_TOUCH_REFUSE-A · pending**

{name} 「……편해서 그래. 오늘은 좀 떨어져 있을래.」 {name}는 내밀던 손을 빼고 모자로 사이를 막았다.

**V03-MARISA-FRIEND-PC-LATE_TOUCH_REFUSE-B · pending**

{name} 「……내 자리처럼 앉게 되네.」 {name}는 내밀던 손을 빼고 모자로 사이를 막았다.

### 친구 · 주인공쪽 · 시간이 지난 뒤 · 키스 · 수락

**V03-MARISA-FRIEND-PC-LATE_KISS_ALLOW-A · pending**

{name} 「……친구로 돌아간다고 하면 넌 믿냐?」 {name}는 벗은 모자를 쥐고 한동안 웃지 못했다.

**V03-MARISA-FRIEND-PC-LATE_KISS_ALLOW-B · pending**

{name}는 옆에 앉으려다 멈추고 입술이 떨어지자 모자를 눌러썼다.

### 친구 · 주인공쪽 · 시간이 지난 뒤 · 키스 · 거절

**V03-MARISA-FRIEND-PC-LATE_KISS_REFUSE-A · pending**

{name} 「……오늘은 얘기 좀 하자. 모자 벗기지 말고.」 {name}는 다가오던 고개를 돌리고 모자를 세웠다.

**V03-MARISA-FRIEND-PC-LATE_KISS_REFUSE-B · pending**

{name} 「……내 자리처럼 앉게 되네.」 {name}는 다가오던 고개를 돌리고 모자를 세웠다.

### 친구 · 미정 · 직후 · 관계 직후 · 해당 없음

**V03-MARISA-FRIEND-UNSET-AFTER-A · pending**

{name} 「……친구니까 괜찮다고 생각했나 봐.」 {name}는 모자를 눌러쓰고 헛기침했다.

**V03-MARISA-FRIEND-UNSET-AFTER-B · pending**

{name} 「친구면 이런 걱정은 없었겠지.」 {name}는 모자를 눌러쓰고 헛기침했다.

### 친구 · 미정 · 다음 만남 · 대화하기 · 해당 없음

**V03-MARISA-FRIEND-UNSET-NEXT_TALK-A · pending**

{name} 「버섯 얘기나 할까. 그 녀석 얘긴 아직 어렵고.」 {name}는 빗자루를 세워 놓고 머리를 긁었다.

**V03-MARISA-FRIEND-UNSET-NEXT_TALK-B · pending**

{name}는 농담을 꺼내려다 말고 모자챙만 고쳐 썼다.

### 친구 · 미정 · 다음 만남 · 스킨십 · 수락

**V03-MARISA-FRIEND-UNSET-NEXT_TOUCH_ALLOW-A · pending**

{name} 「……친구끼리라 괜찮다고 하면 더 나쁜가.」 {name}는 손을 빼지 않은 채 모자챙을 만졌다.

**V03-MARISA-FRIEND-UNSET-NEXT_TOUCH_ALLOW-B · pending**

{name}는 농담을 꺼내려다 말고 잡힌 손을 모자 그늘에 숨겼다.

### 친구 · 미정 · 다음 만남 · 스킨십 · 거절

**V03-MARISA-FRIEND-UNSET-NEXT_TOUCH_REFUSE-A · pending**

{name} 「손은 나중에. 말동무나 해 줘, 친구잖아.」 {name}는 손을 가볍게 피하고 웃음을 거뒀다.

**V03-MARISA-FRIEND-UNSET-NEXT_TOUCH_REFUSE-B · pending**

{name} 「그 녀석 얘긴 하려다 말았어. 네 앞에선.」 {name}는 손을 가볍게 피하고 웃음을 거뒀다.

### 친구 · 미정 · 다음 만남 · 키스 · 수락

**V03-MARISA-FRIEND-UNSET-NEXT_KISS_ALLOW-A · pending**

{name} 「헤헤. ……그 녀석 생각이 나서 더 못 웃겠다.」 {name}는 입술이 떨어지자 모자를 눌러썼다.

**V03-MARISA-FRIEND-UNSET-NEXT_KISS_ALLOW-B · pending**

{name} 「그 녀석 얘긴 하려다 말았어. 네 앞에선.」 {name}는 입술이 떨어지자 모자를 눌러썼다.

### 친구 · 미정 · 다음 만남 · 키스 · 거절

**V03-MARISA-FRIEND-UNSET-NEXT_KISS_REFUSE-A · pending**

{name} 「안 돼. 친구 사이 장난이라고 하긴 늦었어.」 {name}는 이마 앞에 손바닥을 세웠다.

**V03-MARISA-FRIEND-UNSET-NEXT_KISS_REFUSE-B · pending**

{name} 「그 녀석 얘긴 하려다 말았어. 네 앞에선.」 {name}는 이마 앞에 손바닥을 세웠다.

### 친구 · 미정 · 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-MARISA-FRIEND-UNSET-LATE_TALK-A · pending**

{name} 「너랑 웃고 나면 그 녀석 앞에선 조용해져.」 {name}는 하다 만 농담을 삼키고 모자를 만졌다.

**V03-MARISA-FRIEND-UNSET-LATE_TALK-B · pending**

{name} 「걔가 널 좋은 친구라는데 내가 웃질 못했어.」 {name}는 하다 만 농담을 삼키고 모자를 만졌다.

### 친구 · 미정 · 시간이 지난 뒤 · 스킨십 · 수락

**V03-MARISA-FRIEND-UNSET-LATE_TOUCH_ALLOW-A · pending**

{name} 「……이 손 잡는 걸 그 녀석한텐 뭐라고 할까.」 {name}는 손을 잡은 채 모자 끝만 만지작거렸다.

**V03-MARISA-FRIEND-UNSET-LATE_TOUCH_ALLOW-B · pending**

{name} 「걔가 널 좋은 친구라는데 내가 웃질 못했어.」 {name}는 손을 잡은 채 모자 끝만 만지작거렸다.

### 친구 · 미정 · 시간이 지난 뒤 · 스킨십 · 거절

**V03-MARISA-FRIEND-UNSET-LATE_TOUCH_REFUSE-A · pending**

{name} 「친구니까 참아 달라고 해도 되잖아.」 {name}는 손을 뒤로 빼며 한 발 비켰다.

**V03-MARISA-FRIEND-UNSET-LATE_TOUCH_REFUSE-B · pending**

{name} 「걔가 널 좋은 친구라는데 내가 웃질 못했어.」 {name}는 손을 뒤로 빼며 한 발 비켰다.

### 친구 · 미정 · 시간이 지난 뒤 · 키스 · 수락

**V03-MARISA-FRIEND-UNSET-LATE_KISS_ALLOW-A · pending**

{name} 「그 녀석이 널 좋은 친구라던데. ……나 참.」 {name}는 입술이 떨어지자 모자 그늘로 숨었다.

**V03-MARISA-FRIEND-UNSET-LATE_KISS_ALLOW-B · pending**

{name}는 농담을 꺼내려다 말고 입술이 떨어지자 모자를 눌러썼다.

### 친구 · 미정 · 시간이 지난 뒤 · 키스 · 거절

**V03-MARISA-FRIEND-UNSET-LATE_KISS_REFUSE-A · pending**

{name} 「이러고 또 친구라고 웃긴 싫어.」 {name}는 얼굴을 피한 채 빗자루를 고쳐 쥐었다.

**V03-MARISA-FRIEND-UNSET-LATE_KISS_REFUSE-B · pending**

{name} 「걔가 널 좋은 친구라는데 내가 웃질 못했어.」 {name}는 얼굴을 피한 채 빗자루를 고쳐 쥐었다.

### 연인(비밀) · 주인공쪽 · 직후 · 관계 직후 · 해당 없음

**V03-MARISA-SECRET-PC-AFTER-A · pending**

{name} 「헤헤, 조금만 더. ……돌아가야 하는데.」 {name}는 모자를 집었다가 도로 내려놓았다.

**V03-MARISA-SECRET-PC-AFTER-B · pending**

{name} 「……모자는 나중에 쓸래. 좀 더 있다 가게.」 {name}는 모자를 집었다가 도로 내려놓았다.

### 연인(비밀) · 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

**V03-MARISA-SECRET-PC-NEXT_TALK-A · pending**

{name} 「왔냐. ……왜 벌써 웃냐, 나도 참.」 {name}는 옆에 앉자마자 모자챙을 내렸다.

**V03-MARISA-SECRET-PC-NEXT_TALK-B · pending**

{name}는 곁을 떠나지 못한 채 모자챙만 고쳐 썼다.

### 연인(비밀) · 주인공쪽 · 다음 만남 · 스킨십 · 수락

**V03-MARISA-SECRET-PC-NEXT_TOUCH_ALLOW-A · pending**

{name} 「……손 잡고 있으면 시간 가는 걸 모르겠어.」 {name}는 먼저 손가락을 걸고는 시선을 피했다.

**V03-MARISA-SECRET-PC-NEXT_TOUCH_ALLOW-B · pending**

{name}는 곁을 떠나지 못한 채 잡힌 손을 모자 그늘에 숨겼다.

### 연인(비밀) · 주인공쪽 · 다음 만남 · 스킨십 · 거절

**V03-MARISA-SECRET-PC-NEXT_TOUCH_REFUSE-A · pending**

{name} 「……이 손 놓아야 돌아가겠지. 오늘은 놔 줘.」 {name}는 내밀려던 손을 거두고 이쪽 손을 밀었다.

**V03-MARISA-SECRET-PC-NEXT_TOUCH_REFUSE-B · pending**

{name} 「……네가 오니까 웃음부터 나네.」 {name}는 내밀려던 손을 거두고 이쪽 손을 밀었다.

### 연인(비밀) · 주인공쪽 · 다음 만남 · 키스 · 수락

**V03-MARISA-SECRET-PC-NEXT_KISS_ALLOW-A · pending**

{name} 「……한 번 더라고 먼저 말할 뻔했네.」 {name}는 미리 벗어 둔 모자로 얼굴을 가렸다.

**V03-MARISA-SECRET-PC-NEXT_KISS_ALLOW-B · pending**

{name} 「……네가 오니까 웃음부터 나네.」 {name}는 미리 벗어 둔 모자로 얼굴을 가렸다.

### 연인(비밀) · 주인공쪽 · 다음 만남 · 키스 · 거절

**V03-MARISA-SECRET-PC-NEXT_KISS_REFUSE-A · pending**

{name} 「……오늘도 웃고 끝내긴 싫어. 잠깐만.」 {name}는 다가서려다 멈추고 모자챙으로 막았다.

**V03-MARISA-SECRET-PC-NEXT_KISS_REFUSE-B · pending**

{name} 「……네가 오니까 웃음부터 나네.」 {name}는 다가서려다 멈추고 모자챙으로 막았다.

### 연인(비밀) · 주인공쪽 · 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-MARISA-SECRET-PC-LATE_TALK-A · pending**

{name} 「……여기선 시계를 안 보게 돼.」 {name}는 벗어 둔 모자를 다시 썼다.

**V03-MARISA-SECRET-PC-LATE_TALK-B · pending**

{name} 「……모자보다 네 손부터 찾네.」 {name}는 벗어 둔 모자를 다시 썼다.

### 연인(비밀) · 주인공쪽 · 시간이 지난 뒤 · 스킨십 · 수락

**V03-MARISA-SECRET-PC-LATE_TOUCH_ALLOW-A · pending**

{name} 「……모자보다 네 손부터 찾네, 이젠.」 {name}는 손을 당기려다 말고 고개를 숙였다.

**V03-MARISA-SECRET-PC-LATE_TOUCH_ALLOW-B · pending**

{name} 「……모자보다 네 손부터 찾네.」 {name}는 손을 당기려다 말고 고개를 숙였다.

### 연인(비밀) · 주인공쪽 · 시간이 지난 뒤 · 스킨십 · 거절

**V03-MARISA-SECRET-PC-LATE_TOUCH_REFUSE-A · pending**

{name} 「……네 옆에선 결심이 오래 안 가더라.」 {name}는 내밀던 손을 빼고 모자로 사이를 막았다.

**V03-MARISA-SECRET-PC-LATE_TOUCH_REFUSE-B · pending**

{name} 「……모자보다 네 손부터 찾네.」 {name}는 내밀던 손을 빼고 모자로 사이를 막았다.

### 연인(비밀) · 주인공쪽 · 시간이 지난 뒤 · 키스 · 수락

**V03-MARISA-SECRET-PC-LATE_KISS_ALLOW-A · pending**

{name} 「……그 녀석한텐 늦는다고 했어. 너 기다린다고는 못 하고.」 {name}는 벗은 모자를 쥐고 한동안 웃지 못했다.

**V03-MARISA-SECRET-PC-LATE_KISS_ALLOW-B · pending**

{name}는 곁을 떠나지 못한 채 입술이 떨어지자 모자를 눌러썼다.

### 연인(비밀) · 주인공쪽 · 시간이 지난 뒤 · 키스 · 거절

**V03-MARISA-SECRET-PC-LATE_KISS_REFUSE-A · pending**

{name} 「……아, 잠깐. 하려던 얘기 또 잊을 뻔했어.」 {name}는 다가오던 고개를 돌리고 모자를 세웠다.

**V03-MARISA-SECRET-PC-LATE_KISS_REFUSE-B · pending**

{name} 「……모자보다 네 손부터 찾네.」 {name}는 다가오던 고개를 돌리고 모자를 세웠다.

### 연인(비밀) · 미정 · 직후 · 관계 직후 · 해당 없음

**V03-MARISA-SECRET-UNSET-AFTER-A · pending**

{name} 「좋아해. ……그 녀석한텐 못 할 말이네.」 {name}는 모자를 눌러쓰고 헛기침했다.

**V03-MARISA-SECRET-UNSET-AFTER-B · pending**

{name} 「좋아해. 걔한테 미안한 것도 맞고.」 {name}는 모자를 눌러쓰고 헛기침했다.

### 연인(비밀) · 미정 · 다음 만남 · 대화하기 · 해당 없음

**V03-MARISA-SECRET-UNSET-NEXT_TALK-A · pending**

{name} 「그 녀석한텐 산책했다고 했어. 산책은 무슨.」 {name}는 빗자루를 세워 놓고 머리를 긁었다.

**V03-MARISA-SECRET-UNSET-NEXT_TALK-B · pending**

{name}는 문 쪽으로 눈을 돌리고 모자챙만 고쳐 썼다.

### 연인(비밀) · 미정 · 다음 만남 · 스킨십 · 수락

**V03-MARISA-SECRET-UNSET-NEXT_TOUCH_ALLOW-A · pending**

{name} 「헤헤. ……돌아가야 한다는 건 아는데 말이야.」 {name}는 손을 빼지 않은 채 모자챙을 만졌다.

**V03-MARISA-SECRET-UNSET-NEXT_TOUCH_ALLOW-B · pending**

{name}는 문 쪽으로 눈을 돌리고 잡힌 손을 모자 그늘에 숨겼다.

### 연인(비밀) · 미정 · 다음 만남 · 스킨십 · 거절

**V03-MARISA-SECRET-UNSET-NEXT_TOUCH_REFUSE-A · pending**

{name} 「먼저 얘기하자. 네가 잘해 주면 또 못 꺼내.」 {name}는 손을 가볍게 피하고 웃음을 거뒀다.

**V03-MARISA-SECRET-UNSET-NEXT_TOUCH_REFUSE-B · pending**

{name} 「그 녀석한테는 마법 얘기만 했어. 네 얘기 대신.」 {name}는 손을 가볍게 피하고 웃음을 거뒀다.

### 연인(비밀) · 미정 · 다음 만남 · 키스 · 수락

**V03-MARISA-SECRET-UNSET-NEXT_KISS_ALLOW-A · pending**

{name} 「헤헤. ……이러고 걔한텐 어떤 얼굴을 하냐.」 {name}는 입술이 떨어지자 모자를 눌러썼다.

**V03-MARISA-SECRET-UNSET-NEXT_KISS_ALLOW-B · pending**

{name} 「그 녀석한테는 마법 얘기만 했어. 네 얘기 대신.」 {name}는 입술이 떨어지자 모자를 눌러썼다.

### 연인(비밀) · 미정 · 다음 만남 · 키스 · 거절

**V03-MARISA-SECRET-UNSET-NEXT_KISS_REFUSE-A · pending**

{name} 「그 녀석 일은 얘기도 못 했잖아.」 {name}는 이마 앞에 손바닥을 세웠다.

**V03-MARISA-SECRET-UNSET-NEXT_KISS_REFUSE-B · pending**

{name} 「그 녀석한테는 마법 얘기만 했어. 네 얘기 대신.」 {name}는 이마 앞에 손바닥을 세웠다.

### 연인(비밀) · 미정 · 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-MARISA-SECRET-UNSET-LATE_TALK-A · pending**

{name} 「비밀이면 재미있을 줄 알았지. 나도 바보다.」 {name}는 하다 만 농담을 삼키고 모자를 만졌다.

**V03-MARISA-SECRET-UNSET-LATE_TALK-B · pending**

{name} 「계속 우리끼리만 웃어도 되나 싶네.」 {name}는 하다 만 농담을 삼키고 모자를 만졌다.

### 연인(비밀) · 미정 · 시간이 지난 뒤 · 스킨십 · 수락

**V03-MARISA-SECRET-UNSET-LATE_TOUCH_ALLOW-A · pending**

{name} 「……그 녀석한테 숨길 버릇만 늘었어.」 {name}는 손을 잡은 채 모자 끝만 만지작거렸다.

**V03-MARISA-SECRET-UNSET-LATE_TOUCH_ALLOW-B · pending**

{name} 「계속 우리끼리만 웃어도 되나 싶네.」 {name}는 손을 잡은 채 모자 끝만 만지작거렸다.

### 연인(비밀) · 미정 · 시간이 지난 뒤 · 스킨십 · 거절

**V03-MARISA-SECRET-UNSET-LATE_TOUCH_REFUSE-A · pending**

{name} 「오늘은 좀 떨어져 앉자. 진지한 얘기도 하게.」 {name}는 손을 뒤로 빼며 한 발 비켰다.

**V03-MARISA-SECRET-UNSET-LATE_TOUCH_REFUSE-B · pending**

{name} 「계속 우리끼리만 웃어도 되나 싶네.」 {name}는 손을 뒤로 빼며 한 발 비켰다.

### 연인(비밀) · 미정 · 시간이 지난 뒤 · 키스 · 수락

**V03-MARISA-SECRET-UNSET-LATE_KISS_ALLOW-A · pending**

{name} 「……좋아해. 그것만 말하면 참 편할 텐데.」 {name}는 입술이 떨어지자 모자 그늘로 숨었다.

**V03-MARISA-SECRET-UNSET-LATE_KISS_ALLOW-B · pending**

{name}는 문 쪽으로 눈을 돌리고 입술이 떨어지자 모자를 눌러썼다.

### 연인(비밀) · 미정 · 시간이 지난 뒤 · 키스 · 거절

**V03-MARISA-SECRET-UNSET-LATE_KISS_REFUSE-A · pending**

{name} 「너만 좋으면 된다는 소리가 안 나오네, 이젠.」 {name}는 얼굴을 피한 채 빗자루를 고쳐 쥐었다.

**V03-MARISA-SECRET-UNSET-LATE_KISS_REFUSE-B · pending**

{name} 「계속 우리끼리만 웃어도 되나 싶네.」 {name}는 얼굴을 피한 채 빗자루를 고쳐 쥐었다.

### 타인 · 주인공쪽 · 직후 · 관계 직후 · 해당 없음

**V03-MARISA-STRANGER-PC-AFTER-A · pending**

{name} 「……네 옆이 벌써 편하네. 별로 알지도 못하면서.」 {name}는 모자를 집었다가 도로 내려놓았다.

**V03-MARISA-STRANGER-PC-AFTER-B · pending**

{name} 「……네 옆은 별로 안 어색하네.」 {name}는 모자를 집었다가 도로 내려놓았다.

### 타인 · 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

**V03-MARISA-STRANGER-PC-NEXT_TALK-A · pending**

{name} 「……네가 있는 덴 잘도 찾네, 나.」 {name}는 옆에 앉자마자 모자챙을 내렸다.

**V03-MARISA-STRANGER-PC-NEXT_TALK-B · pending**

{name}는 익숙하게 다가왔다가 모자챙만 고쳐 썼다.

### 타인 · 주인공쪽 · 다음 만남 · 스킨십 · 수락

**V03-MARISA-STRANGER-PC-NEXT_TOUCH_ALLOW-A · pending**

{name} 「……손은 안 어색하네. 넌 아직 어색한데.」 {name}는 먼저 손가락을 걸고는 시선을 피했다.

**V03-MARISA-STRANGER-PC-NEXT_TOUCH_ALLOW-B · pending**

{name} 「……네가 있는 덴 잘 찾는다니까.」 {name}는 먼저 손가락을 걸고는 시선을 피했다.

### 타인 · 주인공쪽 · 다음 만남 · 스킨십 · 거절

**V03-MARISA-STRANGER-PC-NEXT_TOUCH_REFUSE-A · pending**

{name} 「……기다려. 가까이 왔다고 다 되는 건 아니지.」 {name}는 내밀려던 손을 거두고 이쪽 손을 밀었다.

**V03-MARISA-STRANGER-PC-NEXT_TOUCH_REFUSE-B · pending**

{name}는 익숙하게 다가왔다가 뻗은 손을 피하고 모자를 눌러썼다.

### 타인 · 주인공쪽 · 다음 만남 · 키스 · 수락

**V03-MARISA-STRANGER-PC-NEXT_KISS_ALLOW-A · pending**

{name} 「……그 녀석 앞보다 여기선 눈이 잘 감기네.」 {name}는 미리 벗어 둔 모자로 얼굴을 가렸다.

**V03-MARISA-STRANGER-PC-NEXT_KISS_ALLOW-B · pending**

{name} 「……네가 있는 덴 잘 찾는다니까.」 {name}는 미리 벗어 둔 모자로 얼굴을 가렸다.

### 타인 · 주인공쪽 · 다음 만남 · 키스 · 거절

**V03-MARISA-STRANGER-PC-NEXT_KISS_REFUSE-A · pending**

{name} 「……또 쉽게 대답할 뻔했네. 안 돼.」 {name}는 다가서려다 멈추고 모자챙으로 막았다.

**V03-MARISA-STRANGER-PC-NEXT_KISS_REFUSE-B · pending**

{name} 「……네가 있는 덴 잘 찾는다니까.」 {name}는 다가서려다 멈추고 모자챙으로 막았다.

### 타인 · 주인공쪽 · 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-MARISA-STRANGER-PC-LATE_TALK-A · pending**

{name} 「……또 이쪽부터 왔어. 핑계도 안 떠오르네.」 {name}는 벗어 둔 모자를 다시 썼다.

**V03-MARISA-STRANGER-PC-LATE_TALK-B · pending**

{name} 「……또 이쪽에 먼저 왔네.」 {name}는 벗어 둔 모자를 다시 썼다.

### 타인 · 주인공쪽 · 시간이 지난 뒤 · 스킨십 · 수락

**V03-MARISA-STRANGER-PC-LATE_TOUCH_ALLOW-A · pending**

{name} 「……손만 먼저 익숙해졌네. 이상한 사이야.」 {name}는 손을 당기려다 말고 고개를 숙였다.

**V03-MARISA-STRANGER-PC-LATE_TOUCH_ALLOW-B · pending**

{name} 「……또 이쪽에 먼저 왔네.」 {name}는 손을 당기려다 말고 고개를 숙였다.

### 타인 · 주인공쪽 · 시간이 지난 뒤 · 스킨십 · 거절

**V03-MARISA-STRANGER-PC-LATE_TOUCH_REFUSE-A · pending**

{name} 「……손은 안 잡고 얘기해 보자, 오늘은.」 {name}는 내밀던 손을 빼고 모자로 사이를 막았다.

**V03-MARISA-STRANGER-PC-LATE_TOUCH_REFUSE-B · pending**

{name} 「……또 이쪽에 먼저 왔네.」 {name}는 내밀던 손을 빼고 모자로 사이를 막았다.

### 타인 · 주인공쪽 · 시간이 지난 뒤 · 키스 · 수락

**V03-MARISA-STRANGER-PC-LATE_KISS_ALLOW-A · pending**

{name} 「……또 모자 벗고 기다렸네. 물어볼 건 잊고.」 {name}는 벗은 모자를 쥐고 한동안 웃지 못했다.

**V03-MARISA-STRANGER-PC-LATE_KISS_ALLOW-B · pending**

{name}는 익숙하게 다가왔다가 입술이 떨어지자 모자를 눌러썼다.

### 타인 · 주인공쪽 · 시간이 지난 뒤 · 키스 · 거절

**V03-MARISA-STRANGER-PC-LATE_KISS_REFUSE-A · pending**

{name} 「……이것만 익숙해지면 곤란하잖아.」 {name}는 다가오던 고개를 돌리고 모자를 세웠다.

**V03-MARISA-STRANGER-PC-LATE_KISS_REFUSE-B · pending**

{name} 「……또 이쪽에 먼저 왔네.」 {name}는 다가오던 고개를 돌리고 모자를 세웠다.

### 타인 · 미정 · 직후 · 관계 직후 · 해당 없음

**V03-MARISA-STRANGER-UNSET-AFTER-A · pending**

{name} 「……그 녀석한테 네 얘길 어떻게 하냐.」 {name}는 모자를 눌러쓰고 헛기침했다.

**V03-MARISA-STRANGER-UNSET-AFTER-B · pending**

{name} 「걔한테 네 얘길 하라면 이름부터 말하겠지.」 {name}는 모자를 눌러쓰고 헛기침했다.

### 타인 · 미정 · 다음 만남 · 대화하기 · 해당 없음

**V03-MARISA-STRANGER-UNSET-NEXT_TALK-A · pending**

{name} 「바깥 얘기나 해 줘. 네 얘기도 좀 알고 싶어.」 {name}는 빗자루를 세워 놓고 머리를 긁었다.

**V03-MARISA-STRANGER-UNSET-NEXT_TALK-B · pending**

{name}는 어색하게 머리를 긁고 모자챙만 고쳐 썼다.

### 타인 · 미정 · 다음 만남 · 스킨십 · 수락

**V03-MARISA-STRANGER-UNSET-NEXT_TOUCH_ALLOW-A · pending**

{name} 「……원래부터 친한 척하진 말고.」 {name}는 손을 빼지 않은 채 모자챙을 만졌다.

**V03-MARISA-STRANGER-UNSET-NEXT_TOUCH_ALLOW-B · pending**

{name} 「서로 뭘 좋아하는지도 모르는데 말이야, 우리.」 {name}는 손을 빼지 않은 채 모자챙을 만졌다.

### 타인 · 미정 · 다음 만남 · 스킨십 · 거절

**V03-MARISA-STRANGER-UNSET-NEXT_TOUCH_REFUSE-A · pending**

{name} 「야. 우리 아직 서로 잘 모르잖아.」 {name}는 손을 가볍게 피하고 웃음을 거뒀다.

**V03-MARISA-STRANGER-UNSET-NEXT_TOUCH_REFUSE-B · pending**

{name}는 어색하게 머리를 긁고 뻗은 손을 피하고 모자를 눌러썼다.

### 타인 · 미정 · 다음 만남 · 키스 · 수락

**V03-MARISA-STRANGER-UNSET-NEXT_KISS_ALLOW-A · pending**

{name} 「……너한텐 이게 무슨 뜻인데?」 {name}는 입술이 떨어지자 모자를 눌러썼다.

**V03-MARISA-STRANGER-UNSET-NEXT_KISS_ALLOW-B · pending**

{name} 「서로 뭘 좋아하는지도 모르는데 말이야, 우리.」 {name}는 입술이 떨어지자 모자를 눌러썼다.

### 타인 · 미정 · 다음 만남 · 키스 · 거절

**V03-MARISA-STRANGER-UNSET-NEXT_KISS_REFUSE-A · pending**

{name} 「얘기부터 해 볼까. 모르는 게 너무 많거든.」 {name}는 이마 앞에 손바닥을 세웠다.

**V03-MARISA-STRANGER-UNSET-NEXT_KISS_REFUSE-B · pending**

{name} 「서로 뭘 좋아하는지도 모르는데 말이야, 우리.」 {name}는 이마 앞에 손바닥을 세웠다.

### 타인 · 미정 · 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-MARISA-STRANGER-UNSET-LATE_TALK-A · pending**

{name} 「네 얘긴 좀 알겠어. 걔한텐 한마디도 못 했지만.」 {name}는 하다 만 농담을 삼키고 모자를 만졌다.

**V03-MARISA-STRANGER-UNSET-LATE_TALK-B · pending**

{name} 「너는 조금 알게 됐어. 걔한텐 말을 못 했지만.」 {name}는 하다 만 농담을 삼키고 모자를 만졌다.

### 타인 · 미정 · 시간이 지난 뒤 · 스킨십 · 수락

**V03-MARISA-STRANGER-UNSET-LATE_TOUCH_ALLOW-A · pending**

{name} 「……오늘은 괜찮아. 늘 그렇진 않겠지만.」 {name}는 손을 잡은 채 모자 끝만 만지작거렸다.

**V03-MARISA-STRANGER-UNSET-LATE_TOUCH_ALLOW-B · pending**

{name} 「너는 조금 알게 됐어. 걔한텐 말을 못 했지만.」 {name}는 손을 잡은 채 모자 끝만 만지작거렸다.

### 타인 · 미정 · 시간이 지난 뒤 · 스킨십 · 거절

**V03-MARISA-STRANGER-UNSET-LATE_TOUCH_REFUSE-A · pending**

{name} 「자주 봤다고 다 편한 건 아니야.」 {name}는 손을 뒤로 빼며 한 발 비켰다.

**V03-MARISA-STRANGER-UNSET-LATE_TOUCH_REFUSE-B · pending**

{name} 「너는 조금 알게 됐어. 걔한텐 말을 못 했지만.」 {name}는 손을 뒤로 빼며 한 발 비켰다.

### 타인 · 미정 · 시간이 지난 뒤 · 키스 · 수락

**V03-MARISA-STRANGER-UNSET-LATE_KISS_ALLOW-A · pending**

{name} 「……우린 무슨 사이냐. 이제 물어도 되지?」 {name}는 입술이 떨어지자 모자 그늘로 숨었다.

**V03-MARISA-STRANGER-UNSET-LATE_KISS_ALLOW-B · pending**

{name}는 어색하게 머리를 긁고 입술이 떨어지자 모자를 눌러썼다.

### 타인 · 미정 · 시간이 지난 뒤 · 키스 · 거절

**V03-MARISA-STRANGER-UNSET-LATE_KISS_REFUSE-A · pending**

{name} 「너는 날 어떻게 생각하는데? 그 얘기부터 해.」 {name}는 얼굴을 피한 채 빗자루를 고쳐 쥐었다.

**V03-MARISA-STRANGER-UNSET-LATE_KISS_REFUSE-B · pending**

{name} 「너는 조금 알게 됐어. 걔한텐 말을 못 했지만.」 {name}는 얼굴을 피한 채 빗자루를 고쳐 쥐었다.

### 짝사랑 · 주인공쪽 · 직후 · 관계 직후 · 해당 없음

**V03-MARISA-CRUSH-PC-AFTER-A · pending**

{name} 「헤헤. ……나 지금 돌아가기 싫어.」 {name}는 모자를 집었다가 도로 내려놓았다.

**V03-MARISA-CRUSH-PC-AFTER-B · pending**

{name} 「헤헤. ……기쁜 건 못 숨기겠네.」 {name}는 모자를 집었다가 도로 내려놓았다.

### 짝사랑 · 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

**V03-MARISA-CRUSH-PC-NEXT_TALK-A · pending**

{name} 「어, 왔냐. ……모자 고친 건 그냥 그런 거야.」 {name}는 옆에 앉자마자 모자챙을 내렸다.

**V03-MARISA-CRUSH-PC-NEXT_TALK-B · pending**

{name}는 웃는 얼굴을 들켰다가 모자챙만 고쳐 썼다.

### 짝사랑 · 주인공쪽 · 다음 만남 · 스킨십 · 수락

**V03-MARISA-CRUSH-PC-NEXT_TOUCH_ALLOW-A · pending**

{name} 「……좋네. 얼굴에 다 쓰여 있냐?」 {name}는 먼저 손가락을 걸고는 시선을 피했다.

**V03-MARISA-CRUSH-PC-NEXT_TOUCH_ALLOW-B · pending**

{name}는 웃는 얼굴을 들켰다가 잡힌 손을 모자 그늘에 숨겼다.

### 짝사랑 · 주인공쪽 · 다음 만남 · 스킨십 · 거절

**V03-MARISA-CRUSH-PC-NEXT_TOUCH_REFUSE-A · pending**

{name} 「……손 잡으면 하려던 질문 또 못 하겠어.」 {name}는 내밀려던 손을 거두고 이쪽 손을 밀었다.

**V03-MARISA-CRUSH-PC-NEXT_TOUCH_REFUSE-B · pending**

{name} 「……모자 고친 건 그냥 그런 거야.」 {name}는 내밀려던 손을 거두고 이쪽 손을 밀었다.

### 짝사랑 · 주인공쪽 · 다음 만남 · 키스 · 수락

**V03-MARISA-CRUSH-PC-NEXT_KISS_ALLOW-A · pending**

{name} 「……기다렸다고 하면 놀릴 거냐?」 {name}는 미리 벗어 둔 모자로 얼굴을 가렸다.

**V03-MARISA-CRUSH-PC-NEXT_KISS_ALLOW-B · pending**

{name} 「……모자 고친 건 그냥 그런 거야.」 {name}는 미리 벗어 둔 모자로 얼굴을 가렸다.

### 짝사랑 · 주인공쪽 · 다음 만남 · 키스 · 거절

**V03-MARISA-CRUSH-PC-NEXT_KISS_REFUSE-A · pending**

{name} 「……오늘은 대답부터. 가까이 오지 말고.」 {name}는 다가서려다 멈추고 모자챙으로 막았다.

**V03-MARISA-CRUSH-PC-NEXT_KISS_REFUSE-B · pending**

{name} 「……모자 고친 건 그냥 그런 거야.」 {name}는 다가서려다 멈추고 모자챙으로 막았다.

### 짝사랑 · 주인공쪽 · 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-MARISA-CRUSH-PC-LATE_TALK-A · pending**

{name} 「……네 발소리는 잘 알아듣게 됐네.」 {name}는 벗어 둔 모자를 다시 썼다.

**V03-MARISA-CRUSH-PC-LATE_TALK-B · pending**

{name} 「……빗자루 들고도 네 쪽으로 오네.」 {name}는 벗어 둔 모자를 다시 썼다.

### 짝사랑 · 주인공쪽 · 시간이 지난 뒤 · 스킨십 · 수락

**V03-MARISA-CRUSH-PC-LATE_TOUCH_ALLOW-A · pending**

{name} 「……내가 먼저 손 내미는 건 안 숨겨지네.」 {name}는 손을 당기려다 말고 고개를 숙였다.

**V03-MARISA-CRUSH-PC-LATE_TOUCH_ALLOW-B · pending**

{name} 「……빗자루 들고도 네 쪽으로 오네.」 {name}는 손을 당기려다 말고 고개를 숙였다.

### 짝사랑 · 주인공쪽 · 시간이 지난 뒤 · 스킨십 · 거절

**V03-MARISA-CRUSH-PC-LATE_TOUCH_REFUSE-A · pending**

{name} 「……기대고 있으면 네 말이 다 좋게 들리거든.」 {name}는 내밀던 손을 빼고 모자로 사이를 막았다.

**V03-MARISA-CRUSH-PC-LATE_TOUCH_REFUSE-B · pending**

{name} 「……빗자루 들고도 네 쪽으로 오네.」 {name}는 내밀던 손을 빼고 모자로 사이를 막았다.

### 짝사랑 · 주인공쪽 · 시간이 지난 뒤 · 키스 · 수락

**V03-MARISA-CRUSH-PC-LATE_KISS_ALLOW-A · pending**

{name} 「……너 기다리려고 걔한텐 늦는다고 했네.」 {name}는 벗은 모자를 쥐고 한동안 웃지 못했다.

**V03-MARISA-CRUSH-PC-LATE_KISS_ALLOW-B · pending**

{name}는 웃는 얼굴을 들켰다가 입술이 떨어지자 모자를 눌러썼다.

### 짝사랑 · 주인공쪽 · 시간이 지난 뒤 · 키스 · 거절

**V03-MARISA-CRUSH-PC-LATE_KISS_REFUSE-A · pending**

{name} 「……잠깐. 이러면 나만 더 기대하잖아.」 {name}는 다가오던 고개를 돌리고 모자를 세웠다.

**V03-MARISA-CRUSH-PC-LATE_KISS_REFUSE-B · pending**

{name} 「……빗자루 들고도 네 쪽으로 오네.」 {name}는 다가오던 고개를 돌리고 모자를 세웠다.

### 짝사랑 · 미정 · 직후 · 관계 직후 · 해당 없음

**V03-MARISA-CRUSH-UNSET-AFTER-A · pending**

{name} 「……기뻤어. 그 녀석은 나중에야 생각났고.」 {name}는 모자를 눌러쓰고 헛기침했다.

**V03-MARISA-CRUSH-UNSET-AFTER-B · pending**

{name} 「걔 생각보다 좋다는 생각을 먼저 했어.」 {name}는 모자를 눌러쓰고 헛기침했다.

### 짝사랑 · 미정 · 다음 만남 · 대화하기 · 해당 없음

**V03-MARISA-CRUSH-UNSET-NEXT_TALK-A · pending**

{name} 「그 녀석 앞에서 네 얘길 할 뻔했어. 웃으면서.」 {name}는 빗자루를 세워 놓고 머리를 긁었다.

**V03-MARISA-CRUSH-UNSET-NEXT_TALK-B · pending**

{name}는 붉어진 귀를 숨기며 모자챙만 고쳐 썼다.

### 짝사랑 · 미정 · 다음 만남 · 스킨십 · 수락

**V03-MARISA-CRUSH-UNSET-NEXT_TOUCH_ALLOW-A · pending**

{name} 「헤헤. ……그 녀석 생각도 나는데 웃게 되네.」 {name}는 손을 빼지 않은 채 모자챙을 만졌다.

**V03-MARISA-CRUSH-UNSET-NEXT_TOUCH_ALLOW-B · pending**

{name}는 붉어진 귀를 숨기며 잡힌 손을 모자 그늘에 숨겼다.

### 짝사랑 · 미정 · 다음 만남 · 스킨십 · 거절

**V03-MARISA-CRUSH-UNSET-NEXT_TOUCH_REFUSE-A · pending**

{name} 「좋아한다고 늘 좋다고 할 수는 없잖아.」 {name}는 손을 가볍게 피하고 웃음을 거뒀다.

**V03-MARISA-CRUSH-UNSET-NEXT_TOUCH_REFUSE-B · pending**

{name} 「네가 웃어 주니까 또 좋네. 미안하게.」 {name}는 손을 가볍게 피하고 웃음을 거뒀다.

### 짝사랑 · 미정 · 다음 만남 · 키스 · 수락

**V03-MARISA-CRUSH-UNSET-NEXT_KISS_ALLOW-A · pending**

{name} 「헤헤. ……너도 같은 마음이면 좋겠다.」 {name}는 입술이 떨어지자 모자를 눌러썼다.

**V03-MARISA-CRUSH-UNSET-NEXT_KISS_ALLOW-B · pending**

{name} 「네가 웃어 주니까 또 좋네. 미안하게.」 {name}는 입술이 떨어지자 모자를 눌러썼다.

### 짝사랑 · 미정 · 다음 만남 · 키스 · 거절

**V03-MARISA-CRUSH-UNSET-NEXT_KISS_REFUSE-A · pending**

{name} 「내가 널 좋아하는 건 알지. ……그래서 넌?」 {name}는 이마 앞에 손바닥을 세웠다.

**V03-MARISA-CRUSH-UNSET-NEXT_KISS_REFUSE-B · pending**

{name} 「네가 웃어 주니까 또 좋네. 미안하게.」 {name}는 이마 앞에 손바닥을 세웠다.

### 짝사랑 · 미정 · 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-MARISA-CRUSH-UNSET-LATE_TALK-A · pending**

{name} 「아직 너만 기다리네. 그 녀석한테 미안하게.」 {name}는 하다 만 농담을 삼키고 모자를 만졌다.

**V03-MARISA-CRUSH-UNSET-LATE_TALK-B · pending**

{name} 「나만 네 눈치 보는 건 좀 치사하잖아.」 {name}는 하다 만 농담을 삼키고 모자를 만졌다.

### 짝사랑 · 미정 · 시간이 지난 뒤 · 스킨십 · 수락

**V03-MARISA-CRUSH-UNSET-LATE_TOUCH_ALLOW-A · pending**

{name} 「……좋아하는 티는 못 감추겠어.」 {name}는 손을 잡은 채 모자 끝만 만지작거렸다.

**V03-MARISA-CRUSH-UNSET-LATE_TOUCH_ALLOW-B · pending**

{name} 「나만 네 눈치 보는 건 좀 치사하잖아.」 {name}는 손을 잡은 채 모자 끝만 만지작거렸다.

### 짝사랑 · 미정 · 시간이 지난 뒤 · 스킨십 · 거절

**V03-MARISA-CRUSH-UNSET-LATE_TOUCH_REFUSE-A · pending**

{name} 「오늘은 얘기만 해 보자. 나도 물어볼 게 있어.」 {name}는 손을 뒤로 빼며 한 발 비켰다.

**V03-MARISA-CRUSH-UNSET-LATE_TOUCH_REFUSE-B · pending**

{name} 「나만 네 눈치 보는 건 좀 치사하잖아.」 {name}는 손을 뒤로 빼며 한 발 비켰다.

### 짝사랑 · 미정 · 시간이 지난 뒤 · 키스 · 수락

**V03-MARISA-CRUSH-UNSET-LATE_KISS_ALLOW-A · pending**

{name} 「……내가 좋아하는 건 알면서 너는 말이 없냐.」 {name}는 입술이 떨어지자 모자 그늘로 숨었다.

**V03-MARISA-CRUSH-UNSET-LATE_KISS_ALLOW-B · pending**

{name}는 붉어진 귀를 숨기며 입술이 떨어지자 모자를 눌러썼다.

### 짝사랑 · 미정 · 시간이 지난 뒤 · 키스 · 거절

**V03-MARISA-CRUSH-UNSET-LATE_KISS_REFUSE-A · pending**

{name} 「헤헤, 하고 넘기긴 싫어. 네 마음도 좀 말해 줘.」 {name}는 얼굴을 피한 채 빗자루를 고쳐 쥐었다.

**V03-MARISA-CRUSH-UNSET-LATE_KISS_REFUSE-B · pending**

{name} 「나만 네 눈치 보는 건 좀 치사하잖아.」 {name}는 얼굴을 피한 채 빗자루를 고쳐 쥐었다.

### 굴복 · 주인공쪽 · 직후 · 관계 직후 · 해당 없음

**V03-MARISA-SUBMIT-PC-AFTER-A · pending**

{name} 「……안 불러도 또 올 것 같네, 나.」 {name}는 모자를 집고도 일어나지 않았다.

**V03-MARISA-SUBMIT-PC-AFTER-B · pending**

{name} 「……모자는 좀 더 있다 쓸래.」 {name}는 모자를 집고도 일어나지 않았다.

### 굴복 · 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

**V03-MARISA-SUBMIT-PC-NEXT_TALK-A · pending**

{name} 「……부르기도 전에 와 버렸네.」 {name}는 먼저 돌아보고도 모자챙을 당겼다.

**V03-MARISA-SUBMIT-PC-NEXT_TALK-B · pending**

{name}는 부르기 전에 돌아보고 모자챙만 고쳐 썼다.

### 굴복 · 주인공쪽 · 다음 만남 · 스킨십 · 수락

**V03-MARISA-SUBMIT-PC-NEXT_TOUCH_ALLOW-A · pending**

{name} 「……손 빼는 게 더 이상하네, 이제.」 {name}는 잡힌 손을 보며 모자챙을 내렸다.

**V03-MARISA-SUBMIT-PC-NEXT_TOUCH_ALLOW-B · pending**

{name}는 부르기 전에 돌아보고 잡힌 손을 모자 그늘에 숨겼다.

### 굴복 · 주인공쪽 · 다음 만남 · 스킨십 · 거절

**V03-MARISA-SUBMIT-PC-NEXT_TOUCH_REFUSE-A · pending**

{name} 「……옆에 왔어도 오늘은 손 빼고 싶어.」 {name}는 내밀려던 손을 거두고 이쪽 손을 밀었다.

**V03-MARISA-SUBMIT-PC-NEXT_TOUCH_REFUSE-B · pending**

{name} 「……안 불렀는데 와 버렸어.」 {name}는 내밀려던 손을 거두고 이쪽 손을 밀었다.

### 굴복 · 주인공쪽 · 다음 만남 · 키스 · 수락

**V03-MARISA-SUBMIT-PC-NEXT_KISS_ALLOW-A · pending**

{name} 「……모자는 벌써 벗었네, 내가.」 {name}는 끝나자 서둘러 모자로 얼굴을 가렸다.

**V03-MARISA-SUBMIT-PC-NEXT_KISS_ALLOW-B · pending**

{name} 「……안 불렀는데 와 버렸어.」 {name}는 끝나자 서둘러 모자로 얼굴을 가렸다.

### 굴복 · 주인공쪽 · 다음 만남 · 키스 · 거절

**V03-MARISA-SUBMIT-PC-NEXT_KISS_REFUSE-A · pending**

{name} 「……기다린 것 같아도 지금은 아니야.」 {name}는 다가서려다 멈추고 모자챙으로 막았다.

**V03-MARISA-SUBMIT-PC-NEXT_KISS_REFUSE-B · pending**

{name} 「……안 불렀는데 와 버렸어.」 {name}는 다가서려다 멈추고 모자챙으로 막았다.

### 굴복 · 주인공쪽 · 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-MARISA-SUBMIT-PC-LATE_TALK-A · pending**

{name} 「……또 네가 있는 데부터 왔네.」 {name}는 먼저 돌아보고도 모자챙을 당겼다.

**V03-MARISA-SUBMIT-PC-LATE_TALK-B · pending**

{name} 「……부르기 전부터 기다리네, 이젠.」 {name}는 먼저 돌아보고도 모자챙을 당겼다.

### 굴복 · 주인공쪽 · 시간이 지난 뒤 · 스킨십 · 수락

**V03-MARISA-SUBMIT-PC-LATE_TOUCH_ALLOW-A · pending**

{name} 「……손이 먼저 나가네. 웃기지, 나도.」 {name}는 잡힌 손을 보며 모자챙을 내렸다.

**V03-MARISA-SUBMIT-PC-LATE_TOUCH_ALLOW-B · pending**

{name} 「……부르기 전부터 기다리네, 이젠.」 {name}는 잡힌 손을 보며 모자챙을 내렸다.

### 굴복 · 주인공쪽 · 시간이 지난 뒤 · 스킨십 · 거절

**V03-MARISA-SUBMIT-PC-LATE_TOUCH_REFUSE-A · pending**

{name} 「……늘 가만히 있었다고 오늘도 같은 건 아니야.」 {name}는 내밀던 손을 빼고 모자로 사이를 막았다.

**V03-MARISA-SUBMIT-PC-LATE_TOUCH_REFUSE-B · pending**

{name} 「……부르기 전부터 기다리네, 이젠.」 {name}는 내밀던 손을 빼고 모자로 사이를 막았다.

### 굴복 · 주인공쪽 · 시간이 지난 뒤 · 키스 · 수락

**V03-MARISA-SUBMIT-PC-LATE_KISS_ALLOW-A · pending**

{name} 「……눈 감는 게 더 빨라졌냐, 나.」 {name}는 끝나자 서둘러 모자로 얼굴을 가렸다.

**V03-MARISA-SUBMIT-PC-LATE_KISS_ALLOW-B · pending**

{name}는 부르기 전에 돌아보고 입술이 떨어지자 모자를 눌러썼다.

### 굴복 · 주인공쪽 · 시간이 지난 뒤 · 키스 · 거절

**V03-MARISA-SUBMIT-PC-LATE_KISS_REFUSE-A · pending**

{name} 「……기다렸어도 오늘은 싫어.」 {name}는 다가오던 고개를 돌리고 모자를 세웠다.

**V03-MARISA-SUBMIT-PC-LATE_KISS_REFUSE-B · pending**

{name} 「……부르기 전부터 기다리네, 이젠.」 {name}는 다가오던 고개를 돌리고 모자를 세웠다.

### 굴복 · 미정 · 직후 · 관계 직후 · 해당 없음

**V03-MARISA-SUBMIT-UNSET-AFTER-A · pending**

{name} 「모자 줘. ……그 녀석 얼굴은 어떻게 보냐.」 {name}는 모자를 눌러쓰고 입을 다물었다.

**V03-MARISA-SUBMIT-UNSET-AFTER-B · pending**

{name} 「걔 앞에서 웃을 얼굴은 남겨야겠네.」 {name}는 모자를 눌러쓰고 입을 다물었다.

### 굴복 · 미정 · 다음 만남 · 대화하기 · 해당 없음

**V03-MARISA-SUBMIT-UNSET-NEXT_TALK-A · pending**

{name} 「그 녀석한텐 웃어 줬어. 그다음 말은 없었고.」 {name}는 대답하고는 모자만 만지작거렸다.

**V03-MARISA-SUBMIT-UNSET-NEXT_TALK-B · pending**

{name}는 기운 없이 고개를 숙이고 모자챙만 고쳐 썼다.

### 굴복 · 미정 · 다음 만남 · 스킨십 · 수락

**V03-MARISA-SUBMIT-UNSET-NEXT_TOUCH_ALLOW-A · pending**

{name} 「……그냥 이러고 있으면 되지.」 {name}는 손을 빼지 않고 모자 그늘로 숨었다.

**V03-MARISA-SUBMIT-UNSET-NEXT_TOUCH_ALLOW-B · pending**

{name}는 기운 없이 고개를 숙이고 잡힌 손을 모자 그늘에 숨겼다.

### 굴복 · 미정 · 다음 만남 · 스킨십 · 거절

**V03-MARISA-SUBMIT-UNSET-NEXT_TOUCH_REFUSE-A · pending**

{name} 「……손만 놓아 줘. 부탁이야.」 {name}는 손을 가볍게 피하고 웃음을 거뒀다.

**V03-MARISA-SUBMIT-UNSET-NEXT_TOUCH_REFUSE-B · pending**

{name} 「그 녀석한텐 버섯 얘기만 했어.」 {name}는 손을 가볍게 피하고 웃음을 거뒀다.

### 굴복 · 미정 · 다음 만남 · 키스 · 수락

**V03-MARISA-SUBMIT-UNSET-NEXT_KISS_ALLOW-A · pending**

{name} 「……됐냐. 그 녀석한테 가야 하는데.」 {name}는 입술이 떨어지자 모자챙을 눌러썼다.

**V03-MARISA-SUBMIT-UNSET-NEXT_KISS_ALLOW-B · pending**

{name} 「그 녀석한텐 버섯 얘기만 했어.」 {name}는 입술이 떨어지자 모자챙을 눌러썼다.

### 굴복 · 미정 · 다음 만남 · 키스 · 거절

**V03-MARISA-SUBMIT-UNSET-NEXT_KISS_REFUSE-A · pending**

{name} 「……나도 싫을 땐 있다고.」 {name}는 이마 앞에 손바닥을 세웠다.

**V03-MARISA-SUBMIT-UNSET-NEXT_KISS_REFUSE-B · pending**

{name} 「그 녀석한텐 버섯 얘기만 했어.」 {name}는 이마 앞에 손바닥을 세웠다.

### 굴복 · 미정 · 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-MARISA-SUBMIT-UNSET-LATE_TALK-A · pending**

{name} 「걔한텐 버섯 얘기만 했어. 네 얘기 안 하려고.」 {name}는 대답하고는 모자만 만지작거렸다.

**V03-MARISA-SUBMIT-UNSET-LATE_TALK-B · pending**

{name} 「걔가 내 농담에 웃더라. 난 끝까지 못 웃었고.」 {name}는 대답하고는 모자만 만지작거렸다.

### 굴복 · 미정 · 시간이 지난 뒤 · 스킨십 · 수락

**V03-MARISA-SUBMIT-UNSET-LATE_TOUCH_ALLOW-A · pending**

{name} 「……그 녀석 앞에선 이러면 안 되는데.」 {name}는 손을 빼지 않고 모자 그늘로 숨었다.

**V03-MARISA-SUBMIT-UNSET-LATE_TOUCH_ALLOW-B · pending**

{name} 「걔가 내 농담에 웃더라. 난 끝까지 못 웃었고.」 {name}는 손을 빼지 않고 모자 그늘로 숨었다.

### 굴복 · 미정 · 시간이 지난 뒤 · 스킨십 · 거절

**V03-MARISA-SUBMIT-UNSET-LATE_TOUCH_REFUSE-A · pending**

{name} 「……오늘은 놓고 싶어. 손.」 {name}는 손을 뒤로 빼며 한 발 비켰다.

**V03-MARISA-SUBMIT-UNSET-LATE_TOUCH_REFUSE-B · pending**

{name} 「걔가 내 농담에 웃더라. 난 끝까지 못 웃었고.」 {name}는 손을 뒤로 빼며 한 발 비켰다.

### 굴복 · 미정 · 시간이 지난 뒤 · 키스 · 수락

**V03-MARISA-SUBMIT-UNSET-LATE_KISS_ALLOW-A · pending**

{name} 「……끝났으면 말해. 돌아갈 얼굴 좀 만들게.」 {name}는 입술이 떨어지자 모자챙을 눌러썼다.

**V03-MARISA-SUBMIT-UNSET-LATE_KISS_ALLOW-B · pending**

{name}는 기운 없이 고개를 숙이고 입술이 떨어지자 모자를 눌러썼다.

### 굴복 · 미정 · 시간이 지난 뒤 · 키스 · 거절

**V03-MARISA-SUBMIT-UNSET-LATE_KISS_REFUSE-A · pending**

{name} 「그만. ……농담처럼 말 안 할 테니까 들어.」 {name}는 얼굴을 피한 채 빗자루를 고쳐 쥐었다.

**V03-MARISA-SUBMIT-UNSET-LATE_KISS_REFUSE-B · pending**

{name} 「걔가 내 농담에 웃더라. 난 끝까지 못 웃었고.」 {name}는 얼굴을 피한 채 빗자루를 고쳐 쥐었다.

### 협박 · 주인공쪽 · 직후 · 관계 직후 · 해당 없음

**V03-MARISA-COERCED-PC-AFTER-A · pending**

{name} 「……옆에 있으면 네가 걔 부르기 전에 알겠지.」 {name}는 모자를 집고도 일어나지 않았다.

**V03-MARISA-COERCED-PC-AFTER-B · pending**

{name} 「……곁에 있으면 걔 부를 때 먼저 알겠지.」 {name}는 모자를 집고도 일어나지 않았다.

### 협박 · 주인공쪽 · 다음 만남 · 대화하기 · 해당 없음

**V03-MARISA-COERCED-PC-NEXT_TALK-A · pending**

{name} 「……네가 부르나 먼저 듣게 되네.」 {name}는 먼저 돌아보고도 모자챙을 당겼다.

**V03-MARISA-COERCED-PC-NEXT_TALK-B · pending**

{name}는 이쪽 반응부터 확인하고 모자챙만 고쳐 썼다.

### 협박 · 주인공쪽 · 다음 만남 · 스킨십 · 수락

**V03-MARISA-COERCED-PC-NEXT_TOUCH_ALLOW-A · pending**

{name} 「……손은 그냥 둘게. 걔한텐 말 안 할 거지.」 {name}는 잡힌 손을 보며 모자챙을 내렸다.

**V03-MARISA-COERCED-PC-NEXT_TOUCH_ALLOW-B · pending**

{name} 「……네가 부르나 먼저 듣게 되네.」 {name}는 잡힌 손을 보며 모자챙을 내렸다.

### 협박 · 주인공쪽 · 다음 만남 · 스킨십 · 거절

**V03-MARISA-COERCED-PC-NEXT_TOUCH_REFUSE-A · pending**

{name} 「……옆에 있다고 안 무서운 건 아니야.」 {name}는 내밀려던 손을 거두고 이쪽 손을 밀었다.

**V03-MARISA-COERCED-PC-NEXT_TOUCH_REFUSE-B · pending**

{name}는 이쪽 반응부터 확인하고 뻗은 손을 피하고 모자를 눌러썼다.

### 협박 · 주인공쪽 · 다음 만남 · 키스 · 수락

**V03-MARISA-COERCED-PC-NEXT_KISS_ALLOW-A · pending**

{name} 「……걔한테 말 안 한다는 소리부터 해 줘.」 {name}는 끝나자 서둘러 모자로 얼굴을 가렸다.

**V03-MARISA-COERCED-PC-NEXT_KISS_ALLOW-B · pending**

{name} 「……네가 부르나 먼저 듣게 되네.」 {name}는 끝나자 서둘러 모자로 얼굴을 가렸다.

### 협박 · 주인공쪽 · 다음 만남 · 키스 · 거절

**V03-MARISA-COERCED-PC-NEXT_KISS_REFUSE-A · pending**

{name} 「……내가 안 피할 줄 알았냐.」 {name}는 다가서려다 멈추고 모자챙으로 막았다.

**V03-MARISA-COERCED-PC-NEXT_KISS_REFUSE-B · pending**

{name} 「……네가 부르나 먼저 듣게 되네.」 {name}는 다가서려다 멈추고 모자챙으로 막았다.

### 협박 · 주인공쪽 · 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-MARISA-COERCED-PC-LATE_TALK-A · pending**

{name} 「……네가 있는 곳부터 보게 돼.」 {name}는 먼저 돌아보고도 모자챙을 당겼다.

**V03-MARISA-COERCED-PC-LATE_TALK-B · pending**

{name} 「……네가 있는 덴 자꾸 확인하게 돼.」 {name}는 먼저 돌아보고도 모자챙을 당겼다.

### 협박 · 주인공쪽 · 시간이 지난 뒤 · 스킨십 · 수락

**V03-MARISA-COERCED-PC-LATE_TOUCH_ALLOW-A · pending**

{name} 「……이 손은 익었네. 자랑할 일은 아니지만.」 {name}는 잡힌 손을 보며 모자챙을 내렸다.

**V03-MARISA-COERCED-PC-LATE_TOUCH_ALLOW-B · pending**

{name} 「……네가 있는 덴 자꾸 확인하게 돼.」 {name}는 잡힌 손을 보며 모자챙을 내렸다.

### 협박 · 주인공쪽 · 시간이 지난 뒤 · 스킨십 · 거절

**V03-MARISA-COERCED-PC-LATE_TOUCH_REFUSE-A · pending**

{name} 「……오늘은 손 뺄래. 이젠 안 무서울 줄 알았어?」 {name}는 내밀던 손을 빼고 모자로 사이를 막았다.

**V03-MARISA-COERCED-PC-LATE_TOUCH_REFUSE-B · pending**

{name} 「……네가 있는 덴 자꾸 확인하게 돼.」 {name}는 내밀던 손을 빼고 모자로 사이를 막았다.

### 협박 · 주인공쪽 · 시간이 지난 뒤 · 키스 · 수락

**V03-MARISA-COERCED-PC-LATE_KISS_ALLOW-A · pending**

{name} 「……내가 먼저 모자를 벗네. 나 참.」 {name}는 끝나자 서둘러 모자로 얼굴을 가렸다.

**V03-MARISA-COERCED-PC-LATE_KISS_ALLOW-B · pending**

{name}는 이쪽 반응부터 확인하고 입술이 떨어지자 모자를 눌러썼다.

### 협박 · 주인공쪽 · 시간이 지난 뒤 · 키스 · 거절

**V03-MARISA-COERCED-PC-LATE_KISS_REFUSE-A · pending**

{name} 「……익숙한 얼굴이어도 오늘은 아니야.」 {name}는 다가오던 고개를 돌리고 모자를 세웠다.

**V03-MARISA-COERCED-PC-LATE_KISS_REFUSE-B · pending**

{name} 「……네가 있는 덴 자꾸 확인하게 돼.」 {name}는 다가오던 고개를 돌리고 모자를 세웠다.

### 협박 · 미정 · 직후 · 관계 직후 · 해당 없음

**V03-MARISA-COERCED-UNSET-AFTER-A · pending**

{name} 「……그 녀석한텐 뭐라고 할 건데.」 {name}는 모자를 눌러쓰고 입을 다물었다.

**V03-MARISA-COERCED-UNSET-AFTER-B · pending**

{name} 「그 녀석한테 뭐라고 할 건데. 말해.」 {name}는 모자를 눌러쓰고 입을 다물었다.

### 협박 · 미정 · 다음 만남 · 대화하기 · 해당 없음

**V03-MARISA-COERCED-UNSET-NEXT_TALK-A · pending**

{name} 「할 말이 뭐야. 걔 이름으로 농담은 하지 말고.」 {name}는 대답하고는 모자만 만지작거렸다.

**V03-MARISA-COERCED-UNSET-NEXT_TALK-B · pending**

{name}는 돌아갈 길을 힐끗 보고 모자챙만 고쳐 썼다.

### 협박 · 미정 · 다음 만남 · 스킨십 · 수락

**V03-MARISA-COERCED-UNSET-NEXT_TOUCH_ALLOW-A · pending**

{name} 「……알았어. 웃으라는 말은 하지 마.」 {name}는 손을 빼지 않고 모자 그늘로 숨었다.

**V03-MARISA-COERCED-UNSET-NEXT_TOUCH_ALLOW-B · pending**

{name} 「웃으면 괜찮을 줄 알았어. 걔 앞에서도.」 {name}는 손을 빼지 않고 모자 그늘로 숨었다.

### 협박 · 미정 · 다음 만남 · 스킨십 · 거절

**V03-MARISA-COERCED-UNSET-NEXT_TOUCH_REFUSE-A · pending**

{name} 「싫어. 그 얘기까지 꺼내진 마.」 {name}는 손을 가볍게 피하고 웃음을 거뒀다.

**V03-MARISA-COERCED-UNSET-NEXT_TOUCH_REFUSE-B · pending**

{name}는 돌아갈 길을 힐끗 보고 뻗은 손을 피하고 모자를 눌러썼다.

### 협박 · 미정 · 다음 만남 · 키스 · 수락

**V03-MARISA-COERCED-UNSET-NEXT_KISS_ALLOW-A · pending**

{name} 「……이제 됐냐. 얼굴 좀 가리게 해 줘.」 {name}는 입술이 떨어지자 모자챙을 눌러썼다.

**V03-MARISA-COERCED-UNSET-NEXT_KISS_ALLOW-B · pending**

{name} 「웃으면 괜찮을 줄 알았어. 걔 앞에서도.」 {name}는 입술이 떨어지자 모자챙을 눌러썼다.

### 협박 · 미정 · 다음 만남 · 키스 · 거절

**V03-MARISA-COERCED-UNSET-NEXT_KISS_REFUSE-A · pending**

{name} 「그만해. 걔한테 뭘 말하든 오늘 대답은 이거야.」 {name}는 이마 앞에 손바닥을 세웠다.

**V03-MARISA-COERCED-UNSET-NEXT_KISS_REFUSE-B · pending**

{name} 「웃으면 괜찮을 줄 알았어. 걔 앞에서도.」 {name}는 이마 앞에 손바닥을 세웠다.

### 협박 · 미정 · 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-MARISA-COERCED-UNSET-LATE_TALK-A · pending**

{name} 「그 녀석 앞에선 농담만 했어. 다른 말이 안 나와.」 {name}는 대답하고는 모자만 만지작거렸다.

**V03-MARISA-COERCED-UNSET-LATE_TALK-B · pending**

{name} 「걔한테 할 말은 많았는데 농담밖에 못 했어.」 {name}는 대답하고는 모자만 만지작거렸다.

### 협박 · 미정 · 시간이 지난 뒤 · 스킨십 · 수락

**V03-MARISA-COERCED-UNSET-LATE_TOUCH_ALLOW-A · pending**

{name} 「……이러고 걔 앞에선 또 웃어야겠지.」 {name}는 손을 빼지 않고 모자 그늘로 숨었다.

**V03-MARISA-COERCED-UNSET-LATE_TOUCH_ALLOW-B · pending**

{name} 「걔한테 할 말은 많았는데 농담밖에 못 했어.」 {name}는 손을 빼지 않고 모자 그늘로 숨었다.

### 협박 · 미정 · 시간이 지난 뒤 · 스킨십 · 거절

**V03-MARISA-COERCED-UNSET-LATE_TOUCH_REFUSE-A · pending**

{name} 「또 그 얘기냐. ……지금은 싫어.」 {name}는 손을 뒤로 빼며 한 발 비켰다.

**V03-MARISA-COERCED-UNSET-LATE_TOUCH_REFUSE-B · pending**

{name} 「걔한테 할 말은 많았는데 농담밖에 못 했어.」 {name}는 손을 뒤로 빼며 한 발 비켰다.

### 협박 · 미정 · 시간이 지난 뒤 · 키스 · 수락

**V03-MARISA-COERCED-UNSET-LATE_KISS_ALLOW-A · pending**

{name} 「……보내 줘. 그 녀석한텐 늦었다고만 할게.」 {name}는 입술이 떨어지자 모자챙을 눌러썼다.

**V03-MARISA-COERCED-UNSET-LATE_KISS_ALLOW-B · pending**

{name}는 돌아갈 길을 힐끗 보고 입술이 떨어지자 모자를 눌러썼다.

### 협박 · 미정 · 시간이 지난 뒤 · 키스 · 거절

**V03-MARISA-COERCED-UNSET-LATE_KISS_REFUSE-A · pending**

{name} 「걔가 걱정된다고 네 말만 듣고 있을 순 없잖아.」 {name}는 얼굴을 피한 채 빗자루를 고쳐 쥐었다.

**V03-MARISA-COERCED-UNSET-LATE_KISS_REFUSE-B · pending**

{name} 「걔한테 할 말은 많았는데 농담밖에 못 했어.」 {name}는 얼굴을 피한 채 빗자루를 고쳐 쥐었다.

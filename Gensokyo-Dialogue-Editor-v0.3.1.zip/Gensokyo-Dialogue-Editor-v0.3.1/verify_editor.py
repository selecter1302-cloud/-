from pathlib import Path
import json,sys,tempfile,threading,functools,collections,re
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from build_review import space_template
from read_edits import compare
source=json.loads((ROOT/'seed_review.json').read_text(encoding='utf-8'))
base=json.loads((ROOT/'review/all_dialogue.json').read_text(encoding='utf-8'))
ready=json.loads((ROOT/'review/반영된수정본-v0.3.1.json').read_text(encoding='utf-8'))
checks=[]
def passed(text):checks.append(text)
for old,new in zip(source['entries'],ready['entries']):
 assert old['id']==new['id']
 assert new['edited_text']==space_template(old['edited_text'])
 assert (new['decision'],new['note'],new.get('previous_review'))==(old['decision'],old['note'],old.get('previous_review'))
 assert not re.search(r'\{name\}「|」\{name\}',new['edited_text'])
assert collections.Counter(e['decision']for e in ready['entries'])=={'use':28,'exclude':15,'pending':1189}
assert len(compare(ready,base))==43
passed('all supplied text is preserved except the requested boundary spaces and one missing name-marker brace; 28 use, 15 exclude, 1189 pending preserved')
passed('all 1232 active texts have the requested quote-boundary spacing; normalization is idempotent')
work=Path(tempfile.mkdtemp(prefix='editor-v031-',dir='/tmp'))
class Handler(SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Handler,directory=str(ROOT/'review')))
threading.Thread(target=server.serve_forever,daemon=True).start();url='http://127.0.0.1:'+str(server.server_address[1])+'/index.html'
errors=[]
with sync_playwright()as pw:
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 context=browser.new_context(accept_downloads=True,viewport={'width':1360,'height':1000})
 page=context.new_page();page.on('pageerror',lambda e:errors.append(str(e)));page.on('dialog',lambda d:d.accept());page.goto(url);page.wait_for_selector('article.card')
 def snapshot():return page.evaluate('entries.map(e=>({id:e.id,...current(e)}))')
 initial=snapshot()
 assert all(r['edited_text']==e['edited_text']and r['decision']==e['decision']and r['note']==e['note']for r,e in zip(initial,ready['entries']))
 assert '사용 28' in page.locator('#progress').inner_text()and'제외 15'in page.locator('#progress').inner_text()
 assert page.locator('article.card').first.locator('.preview').inner_text().startswith('하쿠레이 레이무 「')
 assert '」 레이무는'in page.locator('article.card').first.locator('.preview').inner_text()
 passed('fresh HTML opens with user edits and review progress already applied; spaced full speaker and short narrator preview correctly')
 page.keyboard.press('Control+h');assert page.locator('#replaceDialog').evaluate('d=>d.open')
 page.locator('#replaceClose').click();page.locator('#openReplace').click();assert page.locator('#replaceDialog').evaluate('d=>d.open');page.locator('#replaceClose').click()
 passed('Ctrl+H and the visible button both open the replace-all dialog')
 page.get_by_label('캐릭터',exact=True).select_option('하쿠레이 레이무');page.get_by_label('주인공과의 관계',exact=True).select_option('싫어함')
 assert '44개'in page.locator('#count').inner_text()
 first_note=page.locator('article.card').first.locator('textarea[data-field=note]');first_note.fill('일괄 변경 뒤에도 메모 유지')
 before=snapshot()
 page.locator('#openReplace').click();page.locator('#replaceFind').fill('{name}');page.locator('#replaceWith').fill('{short}');page.locator('#replaceScope').select_option('all')
 page.locator('#replaceApply').click();after=snapshot()
 assert all(a['edited_text']==b['edited_text'].replace('{name}','{short}')for a,b in zip(after,before))
 assert all((a['decision'],a['note'])==(b['decision'],b['note'])for a,b in zip(after,before))
 assert any(a['edited_text']!=b['edited_text']for a,b in zip(after,before)if 'MARISA' in a['id'])
 passed('replace all affects hidden characters and excluded entries while preserving review decisions and notes')
 page.locator('#replaceUndo').click();assert snapshot()==before
 passed('undo restores all texts without changing decisions or notes')
 page.locator('#replaceScope').select_option('filtered');page.locator('#replaceApply').click();after=snapshot()
 for a,b in zip(after,before):assert a['edited_text']==(b['edited_text'].replace('{name}','{short}')if a['id'].startswith('V03-REIMU-HATE-')else b['edited_text'])
 passed('filtered replacement is restricted to the 44 matching entries')
 page.locator('#replaceUndo').click();assert snapshot()==before
 assert page.evaluate("literalReplace('a.b aXb','a.b','$&',true).text")== '$& aXb'
 assert page.evaluate("literalReplace('Test test TEST','test','X',false).text")== 'X X X'
 assert page.evaluate("literalReplace('Test test TEST','test','X',true).text")== 'Test X TEST'
 assert page.evaluate("literalReplace('aba','b','',true).text")== 'aa'
 passed('literal search, dollar-sign replacement, case sensitivity and empty replacement behave correctly')
 page.locator('#replaceApply').click();page.locator('#replaceClose').click()
 first=page.locator('article.card').first.locator('textarea[data-field=text]');later=first.input_value()+' 직접 수정';first.fill(later)
 page.locator('#openReplace').click();page.locator('#replaceUndo').click();assert snapshot()[0]['edited_text']==later
 assert all(a==b for a,b in zip(snapshot()[1:],before[1:]))
 passed('undo preserves text manually edited after the bulk operation')
 page.locator('#replaceClose').click();page.locator('#importFile').set_input_files(ROOT/'review/반영된수정본-v0.3.1.json');page.wait_for_function("!current(entries[0]).edited_text.includes('직접 수정')")
 page.locator('article.card').first.locator('textarea[data-field=text]').fill('이전 파일 복원 확인용 임시 본문')
 page.locator('#importFile').set_input_files(ROOT/'seed_review.json');page.wait_for_function("!current(entries[0]).edited_text.includes('임시 본문')")
 for a,b in zip(snapshot(),ready['entries']):assert(a['edited_text'],a['decision'],a['note'])==(b['edited_text'],b['decision'],b['note'])
 passed('old v0.3 JSON import upgrades spacing while retaining the user text and review states')
 with page.expect_download()as download:page.locator('#export').click()
 saved=work/'exported.json';download.value.save_as(saved);result=json.loads(saved.read_text(encoding='utf-8'))
 assert result['dataset_id']==base['dataset_id']and len(compare(result,base))==43
 for a,b in zip(result['entries'],ready['entries']):assert(a['edited_text'],a['decision'],a['note'])==(b['edited_text'],b['decision'],b['note'])
 passed('saved JSON is recognized by the Python reader and preserves the supplied review state exactly')
 page.evaluate('persistNow()');page.reload();page.wait_for_selector('article.card');assert snapshot()==initial
 passed('reload restores the complete imported review state')
 page.get_by_label('검색',exact=True).fill('V03-REIMU-FRIEND-PC-NEXT_TALK-B');assert page.locator('article.card').count()==1
 for y in [0,10000]:
  page.evaluate('(y)=>window.scrollTo(0,y)',y);box=page.locator('#export').bounding_box();assert box and box['x']>1100 and 0<=box['y']<=1000-box['height']
 page.evaluate("announce('')");page.screenshot(path=str(ROOT/'observations/editor-desktop.png'),full_page=True)
 mobile=browser.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True)
 m=mobile.new_page();m.on('pageerror',lambda e:errors.append(str(e)));m.goto(url);m.wait_for_selector('article.card');assert m.evaluate('document.documentElement.scrollWidth<=innerWidth')
 for y in [0,5000,100000]:
  m.evaluate('(y)=>scrollTo(0,y)',y);box=m.locator('#export').bounding_box();assert box and box['x']>180 and 0<=box['y']<=844-box['height']
 m.get_by_label('검색',exact=True).fill('V03-REIMU-FRIEND-PC-NEXT_TALK-B');m.locator('article.card').first.scroll_into_view_if_needed();m.screenshot(path=str(ROOT/'observations/editor-mobile.png'),full_page=False)
 m.locator('#openReplace').click();assert m.locator('#replaceDialog').evaluate('d=>d.open');m.screenshot(path=str(ROOT/'observations/replace-dialog-mobile.png'),full_page=False)
 passed('right-side save and replace buttons remain usable on desktop and mobile without horizontal overflow')
 assert not errors,errors;passed('no browser JavaScript errors in tested interactions')
 browser.close()
server.shutdown()
report={'passed_checks':checks,'count':len(checks),'browser_errors':errors,'test_export':str(saved),'browser_scope':'Actual Chromium over temporary local HTTP; file:// blocked by managed browser policy.'}
(ROOT/'observations/editor-v031-test-results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(report,ensure_ascii=False,indent=2))

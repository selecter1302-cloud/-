"""Apply the supplied review verbatim, then normalize only quote-boundary spaces."""
import json,re,statistics,collections
from pathlib import Path
ROOT=Path(__file__).resolve().parent
DATASET='gensokyo-dialogue-editor-v0.3.1'

def repair_name_marker(text):
    return re.sub(r'(?m)^\{name(?=[ \t]*「)','{name}',text)

def space_only(text):
    text=re.sub(r'(\{name\})[ \t]*「',r'\1 「',text)
    return re.sub(r'」[ \t]*(\{name\})',r'」 \1',text)

def space_template(text):
    return space_only(repair_name_marker(text))

def build():
    baseline=json.loads((ROOT/'baseline_v03.json').read_text(encoding='utf-8'))
    seed=json.loads((ROOT/'seed_review.json').read_text(encoding='utf-8'))
    assert seed['dataset_id']==baseline['dataset_id'] and seed['source_apk_sha256']==baseline['source_apk_sha256']
    assert seed['format']=='gensokyo-dialogue-review-edits' and seed['format_version']==2
    assert seed['entry_count']==len(seed['entries'])==len(baseline['entries'])==1232
    supplied={e['id']:e for e in seed['entries']};assert len(supplied)==1232
    entries=[];active_entries=[];initial={};ready=[];user_changes=[];spacing=[];repairs=[]
    for old in baseline['entries']:
        r=supplied[old['id']]
        assert r['original_text']==old['text'],old['id']
        assert all(r[k]==old[k] for k in ['character_key','relation_key','body_key','scene_key','variant'])
        assert r['decision']in {'pending','use','exclude'} and isinstance(r['note'],str)
        t=space_template(r['edited_text']);assert space_template(t)==t
        assert not re.search(r'\{name\}「|」\{name\}',t),old['id']
        e={**old,'text':space_template(old['text']),'kind':'spoken'if'「'in t else'narrative','kind_label':'대사 → 짧은 지문'if'「'in t else'지문만'}
        entries.append(e)
        active_entries.append({**e,'text':t,'review_decision':r['decision'],'review_note':r['note']})
        state={'edited_text':t,'decision':r['decision'],'note':r['note'],'previous_review':r.get('previous_review')}
        if t!=e['text'] or r['decision']!='pending' or r['note'] or r.get('previous_review'):initial[e['id']]=state
        ready.append({**{k:e[k]for k in ['id','character_key','relation_key','body_key','scene_key','variant']},'original_text':e['text'],**state})
        if r['edited_text']!=old['text']:user_changes.append({'id':e['id'],'before':old['text'],'user_edited':r['edited_text'],'final':t,'decision':r['decision'],'note':r['note']})
        if space_only(r['edited_text'])!=r['edited_text']:spacing.append(e['id'])
        if repair_name_marker(r['edited_text'])!=r['edited_text']:repairs.append(e['id'])
    assert len(user_changes)==32 and {(supplied[e['id']]['character_key'],supplied[e['id']]['relation_key'])for e in user_changes}=={('reimu','hate')}
    assert collections.Counter(e['decision']for e in ready)==collections.Counter(e['decision']for e in seed['entries'])
    counts={**baseline['counts'],'spoken_outputs':sum(e['kind']=='spoken'for e in entries),'narration_only_outputs':sum(e['kind']=='narrative'for e in entries),
            'unique_spoken_strings':len({m for e in active_entries for m in re.findall('「([^」]*)」',e['text'])}),
            'unique_complete_templates':len({e['text']for e in active_entries}),'median_template_characters':statistics.median(len(e['text'])for e in active_entries),'max_template_characters':max(len(e['text'])for e in active_entries)}
    merge={'user_modified_outputs':len(user_changes),'spacing_normalized_outputs':len(spacing),'review_status_counts':dict(collections.Counter(e['decision']for e in ready)),'content_modified_after_spacing':sum(e['original_text']!=e['edited_text']for e in ready),'user_format_only_changes':len(user_changes)-sum(e['original_text']!=e['edited_text']for e in ready),'repaired_name_marker_outputs':len(repairs),'repaired_name_marker_ids':repairs,'preserved_notes':sum(bool(e['note'])for e in ready),'only_text_change_after_user_edits':'quote-boundary horizontal spaces plus one missing speaker-name closing brace'}
    doc={**baseline,'dataset_id':DATASET,'purpose':'사용자 수정 반영 + 따옴표 경계 공백 일괄 정리. APK 미적용.','counts':counts,'entries':entries,'initial_review':initial,'initial_preview_names':seed.get('preview_names',{}),'merge_summary':merge}
    out=ROOT/'review';out.mkdir(exist_ok=True)
    (out/'all_dialogue.json').write_text(json.dumps(doc,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (out/'current_dialogue.json').write_text(json.dumps({k:v for k,v in doc.items()if k not in {'initial_review','entries'}}|{'entries':active_entries},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    saved={'format':'gensokyo-dialogue-review-edits','format_version':2,'dataset_id':DATASET,'source_apk_sha256':doc['source_apk_sha256'],'exported_at':seed.get('exported_at'),'preview_names':seed.get('preview_names',{}),'entry_count':len(ready),'entries':ready}
    (out/'반영된수정본-v0.3.1.json').write_text(json.dumps(saved,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    for c,info in doc['characters'].items():
        lines=[f"# {info['name']} · 사용자 수정 반영본 v0.3.1",'','사용자 본문·검토 결과를 보존하고 이름·따옴표 경계 공백만 통일했다.','']
        prev=None
        for e in entries:
            if e['character_key']!=c:continue
            group=(e['relation'],e['body_state'],e['time'],e['action'],e['gate'])
            if group!=prev:lines += ['### '+' · '.join(group),''];prev=group
            lines += [f"**{e['id']} · {supplied[e['id']]['decision']}**",'',next(x['text']for x in active_entries if x['id']==e['id']),'']
        (out/f'{c}.md').write_text('\n'.join(lines),encoding='utf-8')
    (out/'전체목록.md').write_text('# 전체 목록\n\n'+'\n'.join(f"- [{info['name']}]({c}.md)"for c,info in doc['characters'].items())+'\n\n`index.html`에 반영된 검토 진행 상태가 들어 있다. `반영된수정본-v0.3.1.json`도 같은 내용이다.\n',encoding='utf-8')
    lines=['# 사용자 수정 반영 내역','','본문 수정 32개는 모두 레이무·싫어함이다. 사용 28개·제외 15개·미검토 1,189개를 그대로 보존했다.',f'따옴표 경계 공백을 정리한 본문: {len(spacing)}개. 이름 표식의 닫는 괄호 누락 한 곳도 복구했다. 그 밖의 표현·맞춤법은 바꾸지 않았다.','']
    for e in user_changes:lines += [f"## {e['id']}",'','**사용자 수정문**','',e['user_edited'],'','**공백 정리 후**','',e['final'],'',f"검토 결과: {e['decision']}",'']
    (ROOT/'사용자수정반영내역.md').write_text('\n'.join(lines),encoding='utf-8')
    combined={**doc,'legacy_baseline':json.loads((ROOT/'legacy_v02.json').read_text(encoding='utf-8')),'v03_baseline':baseline}
    payload=json.dumps(combined,ensure_ascii=False).replace('<','\\u003c').replace('>','\\u003e').replace('&','\\u0026')
    (out/'index.html').write_text((ROOT/'editor_template.html').read_text(encoding='utf-8').replace('__DATA__',payload),encoding='utf-8')
    print(json.dumps({'counts':counts,'merge':merge},ensure_ascii=False))
if __name__=='__main__':build()

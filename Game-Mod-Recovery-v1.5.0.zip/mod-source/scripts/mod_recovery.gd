extends RefCounted

# Recovery only changes wakefulness and endurance; it never advances a scene.
const CHARACTERS = ["reimu", "sakuya", "marisa", "sanae"]

static func blocked_reason(s, who: String) -> String:
	if s == null:
		return "게임 상태가 준비되지 않았습니다."
	if not CHARACTERS.has(who) or not s.heroines.has(who):
		return "회복할 히로인을 선택해 주세요."
	if GameState.in_recall():
		return "회상 중에는 사용할 수 없습니다."
	if Clock.is_over(s):
		return "종료된 게임에서는 사용할 수 없습니다."
	if s.sleep_drugged(who):
		return "수면약 효과가 남아 있습니다. 이 버튼은 약물 효과를 제거하지 않습니다."
	return ""

static func recover(s, who: String) -> Dictionary:
	var reason = blocked_reason(s, who)
	if not reason.is_empty():
		return {"ok":false, "message":reason}
	var changed = false
	var slf: Dictionary = s.heroines[who]["self"]
	if bool(slf.get("asleep", false)):
		slf["asleep"] = false
		changed = true
	if SceneSex.active(s) and str(s.scene.get("id", "")) == who:
		var sc: Dictionary = s.scene
		var was_unconscious = bool(sc.get("fainted", false)) or bool(sc.get("sleeping", false))
		var maximum = maxi(1, int(s.data["sex_acts"]["orgasm"]["endurance"]))
		var restored = maxi(maximum, int(sc.get("endurance", 0)))
		changed = changed or was_unconscious or int(sc.get("faint_left", 0)) != 0 or int(sc.get("sleep_depth", 0)) != 0 or int(sc.get("endurance", 0)) != restored
		sc["fainted"] = false
		sc["faint_left"] = 0
		sc["sleeping"] = false
		sc["sleep_depth"] = 0
		sc["endurance"] = restored
		if was_unconscious:
			sc["face"] = str(s.data["sex_acts"]["faces"]["default"])
	if changed:
		GameState.reaction[who] = "neutral"
	return {"ok":true, "changed":changed, "message":"상태를 회복했습니다." if changed else "이미 깨어 있으며 회복 수치가 충분합니다."}

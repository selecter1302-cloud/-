extends CanvasLayer

const ModControls = preload("res://scripts/mod_controls.gd")
const ModActors = preload("res://scripts/mod_actor_actions.gd")
const ModRecovery = preload("res://scripts/mod_recovery.gd")
const CHARACTER_NAMES = {"reimu":"레이무", "sakuya":"사쿠야", "marisa":"마리사", "sanae":"사나에"}
const CHARACTER_COLORS = {"reimu":"#ff6666", "sakuya":"#88ddff", "marisa":"#ffdd55", "sanae":"#66dd88"}
const FACE_LABELS = {"neutral":"기본", "tsun":"새침", "blush":"수줍음", "smile":"미소", "friendly":"호감", "annoyed":"토라짐", "pout":"불만", "angry":"분노", "cold":"냉담", "cry":"울음", "sad":"슬픔", "surprised":"놀람", "scared":"두려움", "dazed":"멍함", "resigned":"체념", "worried":"걱정", "wry":"쓴웃음", "drunk":"취함", "sleepy":"잠이 덜 깸", "hypno":"최면", "sleep":"수면", "heart":"하트눈"}
var _tabs: TabContainer
var _recovery_target: OptionButton
var _recovery_button: Button
var _recovery_status: Label
var _rival_manual: CheckBox
var _rival_room: OptionButton
var _rival_target: OptionButton
var _rival_status: Label
var _room_ids: Array = []
var _affinity_labels: Dictionary = {}
var _affinity_sliders: Dictionary = {}
var _affinity_dragging: Dictionary = {}
var _sleep_button: Button
var _sleep_cancel: Button
var _sleep_status: Label
var _actor_buttons: Array = []
var _rival_buttons: Array = []
var _ap_lock: CheckBox
var _face_columns: HBoxContainer
var _face_checks: Dictionary = {}
var _face_headers: Dictionary = {}
var _backdrop: Control
var _refill: Button
var _heart: OptionButton
var _status: Label
var _notice: Label

func _ready() -> void:
	name = "F3ModWindow"
	layer = 100
	process_mode = Node.PROCESS_MODE_ALWAYS
	_build()
	GameState.state_changed.connect(_refresh)
	_refresh()

func _build() -> void:
	_backdrop = Control.new()
	_backdrop.name = "ModBackdrop"
	_backdrop.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_backdrop.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(_backdrop)
	var shade = ColorRect.new()
	shade.color = Color(0, 0, 0, 0.7)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_backdrop.add_child(shade)
	var center = CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_backdrop.add_child(center)
	var panel = PanelContainer.new()
	panel.custom_minimum_size = Vector2(1120, 640)
	center.add_child(panel)
	var margin = MarginContainer.new()
	for key in ["margin_left", "margin_top", "margin_right", "margin_bottom"]:
		margin.add_theme_constant_override(key, 16)
	panel.add_child(margin)
	var box = VBoxContainer.new()
	box.add_theme_constant_override("separation", 8)
	margin.add_child(box)
	var title = Label.new()
	title.text = "MOD 설정 · F3"
	title.add_theme_font_size_override("font_size", 24)
	box.add_child(title)
	_tabs = TabContainer.new()
	_tabs.name = "ModTabs"
	_tabs.size_flags_vertical = Control.SIZE_EXPAND_FILL
	box.add_child(_tabs)
	var page = VBoxContainer.new()
	page.name = "행동력 · 표정"
	page.add_theme_constant_override("separation", 8)
	_tabs.add_child(page)
	var actor_scroll = ScrollContainer.new()
	actor_scroll.name = "호감도 · 라이벌"
	actor_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	_tabs.add_child(actor_scroll)
	var actor_page = VBoxContainer.new()
	actor_page.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	actor_page.add_theme_constant_override("separation", 8)
	actor_scroll.add_child(actor_page)
	var actions = HBoxContainer.new()
	actions.add_theme_constant_override("separation", 18)
	page.add_child(actions)
	_status = Label.new()
	_status.custom_minimum_size.x = 150
	actions.add_child(_status)
	_refill = Button.new()
	_refill.name = "RefillActions"
	_refill.text = "행동 수 최대로 회복"
	_refill.custom_minimum_size = Vector2(250, 44)
	_refill.pressed.connect(refill_actions)
	actions.add_child(_refill)
	_ap_lock = CheckBox.new()
	_ap_lock.name = "LockActionPoints"
	_ap_lock.text = "행동력 최대치 고정 (소모 안 함)"
	_ap_lock.toggled.connect(change_ap_lock)
	actions.add_child(_ap_lock)
	var display_row = HBoxContainer.new()
	display_row.add_theme_constant_override("separation", 18)
	page.add_child(display_row)
	_heart = OptionButton.new()
	_heart.name = "HeartEyesMode"
	_heart.add_item("일상 하트눈: 원래 방식")
	_heart.add_item("일상 하트눈: 연인일 때만")
	_heart.add_item("일상 하트눈: 끄기")
	_heart.custom_minimum_size = Vector2(320, 44)
	_heart.item_selected.connect(change_heart_mode)
	display_row.add_child(_heart)
	var hint = Label.new()
	hint.text = "표정 잠금이 하트눈 설정과 자동 표정보다 우선합니다."
	display_row.add_child(hint)
	var guide = Label.new()
	guide.text = "캐릭터마다 표정 1개를 체크하면 고정 · 체크 해제 시 자동 · 목록은 각각 스크롤할 수 있습니다."
	page.add_child(guide)
	_face_columns = HBoxContainer.new()
	_face_columns.name = "CharacterFaceLocks"
	_face_columns.add_theme_constant_override("separation", 10)
	_face_columns.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_face_columns.custom_minimum_size.y = 320
	page.add_child(_face_columns)
	for who in ModControls.CHARACTERS:
		_build_character_column(who)
	_build_actor_page(actor_page)
	var recovery_page = VBoxContainer.new()
	recovery_page.name = "회복"
	recovery_page.add_theme_constant_override("separation", 16)
	_tabs.add_child(recovery_page)
	_build_recovery_page(recovery_page)
	_notice = Label.new()
	_notice.text = "행동력 고정과 캐릭터별 표정 잠금은 재실행 후에도 유지됩니다."
	_notice.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_notice.custom_minimum_size = Vector2(900, 24)
	box.add_child(_notice)
	var close_button = Button.new()
	close_button.name = "CloseModWindow"
	close_button.text = "닫기 (F3 / Esc)"
	close_button.custom_minimum_size.y = 36
	close_button.pressed.connect(close_window)
	box.add_child(close_button)
	_backdrop.hide()

func _build_character_column(who: String) -> void:
	var color = Color(CHARACTER_COLORS[who])
	var panel = PanelContainer.new()
	panel.name = who
	panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var style = StyleBoxFlat.new()
	style.bg_color = color.darkened(0.9)
	style.border_color = color
	style.set_border_width_all(2)
	style.set_content_margin_all(8)
	panel.add_theme_stylebox_override("panel", style)
	_face_columns.add_child(panel)
	var column = VBoxContainer.new()
	panel.add_child(column)
	var heading = Label.new()
	heading.add_theme_color_override("font_color", color)
	heading.add_theme_font_size_override("font_size", 19)
	column.add_child(heading)
	_face_headers[who] = heading
	var scroll = ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	column.add_child(scroll)
	var rows = VBoxContainer.new()
	rows.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	rows.add_theme_constant_override("separation", 4)
	scroll.add_child(rows)
	_face_checks[who] = {}
	for face in ModControls.FACE_IDS:
		var row = HBoxContainer.new()
		rows.add_child(row)
		var preview = TextureRect.new()
		preview.name = "Preview_" + face
		preview.custom_minimum_size = Vector2(40, 38)
		preview.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		preview.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		preview.mouse_filter = Control.MOUSE_FILTER_IGNORE
		var path = Portrait.face_path(who, face)
		if ResourceLoader.exists(path):
			var texture = load(path) as Texture2D
			if texture != null:
				var image = texture.get_image()
				if image != null:
					var region = image.get_used_rect()
					if region.has_area():
						var atlas = AtlasTexture.new()
						atlas.atlas = texture
						atlas.region = region
						preview.texture = atlas
				if preview.texture == null:
					preview.texture = texture
		row.add_child(preview)
		var check = CheckBox.new()
		check.name = "Face_" + face
		check.text = FACE_LABELS[face]
		check.tooltip_text = "%s: %s (%s)" % [CHARACTER_NAMES[who], FACE_LABELS[face], face]
		check.add_theme_font_size_override("font_size", 15)
		for key in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color", "font_hover_pressed_color"]:
			check.add_theme_color_override(key, color)
		check.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		check.toggled.connect(func(enabled: bool): change_face_lock(who, face, enabled))
		row.add_child(check)
		_face_checks[who][face] = check

func is_open() -> bool:
	return is_instance_valid(_backdrop) and _backdrop.visible

func toggle_window() -> void:
	if is_open():
		close_window()
	else:
		_refresh()
		_backdrop.show()
		if _tabs.current_tab == 1 and _affinity_sliders["reimu"].editable:
			_affinity_sliders["reimu"].grab_focus()
		elif _refill.is_visible_in_tree() and not _refill.disabled:
			_refill.grab_focus()
		else:
			find_child("CloseModWindow", true, false).grab_focus()

func close_window() -> void:
	for who in ModControls.CHARACTERS:
		if bool(_affinity_dragging.get(who, false)):
			_affinity_drag_ended(who, true)
	_backdrop.hide()

func _input(event: InputEvent) -> void:
	if is_open() and event is InputEventMouseButton and event.button_index != MOUSE_BUTTON_LEFT:
		get_viewport().set_input_as_handled()
		return
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_F3 or event.physical_keycode == KEY_F3:
			toggle_window()
			get_viewport().set_input_as_handled()
		elif is_open() and event.keycode == KEY_ESCAPE:
			close_window()
			get_viewport().set_input_as_handled()

func _unhandled_key_input(_event: InputEvent) -> void:
	if is_open():
		get_viewport().set_input_as_handled()

func _unhandled_input(_event: InputEvent) -> void:
	if is_open():
		get_viewport().set_input_as_handled()

func _blocked_reason() -> String:
	var s = GameState.state
	if s == null:
		return "게임 상태가 준비되지 않았습니다."
	if GameState.in_recall():
		return "회상 중에는 사용할 수 없습니다."
	if Clock.is_over(s):
		return "종료된 게임에서는 사용할 수 없습니다."
	if Events.has_pending(s):
		return "진행 중인 질문에 먼저 답해 주세요."
	if s.ap >= Clock.ap_max(s):
		return "행동 수가 이미 최대입니다."
	return ""

func _refresh() -> void:
	if not is_instance_valid(_refill):
		return
	var s = GameState.state
	_status.text = "행동 수: %d / %d" % [s.ap, Clock.ap_max(s)] if s != null else "게임 상태 준비 중"
	var reason = _blocked_reason()
	_refill.disabled = not reason.is_empty()
	_refill.tooltip_text = reason
	_refresh_actors()
	_refresh_recovery()
	_heart.select(ModControls.MODES.find(ModControls.mode()))
	_ap_lock.set_pressed_no_signal(ModControls.ap_locked())
	for who in ModControls.CHARACTERS:
		var locked = ModControls.locked_face(who)
		_face_headers[who].text = CHARACTER_NAMES[who] + " · " + ("자동" if locked.is_empty() else FACE_LABELS[locked])
		for face in ModControls.FACE_IDS:
			_face_checks[who][face].set_pressed_no_signal(locked == face)

func _build_recovery_page(page: VBoxContainer) -> void:
	var heading = Label.new()
	heading.text = "히로인 상태 회복"
	heading.add_theme_font_size_override("font_size", 24)
	page.add_child(heading)
	var explanation = Label.new()
	explanation.text = "실신·자연 수면을 해제하고 회복 수치를 채웁니다. 시간이나 다음 행동을 진행하지 않습니다."
	explanation.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	page.add_child(explanation)
	_recovery_target = OptionButton.new()
	_recovery_target.name = "RecoveryTarget"
	_recovery_target.custom_minimum_size = Vector2(360, 48)
	_recovery_target.add_item("현재 대상 (자동)")
	for who in ModControls.CHARACTERS:
		_recovery_target.add_item(CHARACTER_NAMES[who])
	_recovery_target.item_selected.connect(func(_index: int): _refresh_recovery())
	page.add_child(_recovery_target)
	_recovery_button = Button.new()
	_recovery_button.name = "RecoverCharacter"
	_recovery_button.text = "회복~ 아프지마~"
	_recovery_button.custom_minimum_size = Vector2(360, 64)
	_recovery_button.add_theme_font_size_override("font_size", 24)
	_recovery_button.pressed.connect(recover_character)
	page.add_child(_recovery_button)
	_recovery_status = Label.new()
	_recovery_status.name = "RecoveryStatus"
	_recovery_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	page.add_child(_recovery_status)

func _recovery_who() -> String:
	if not is_instance_valid(_recovery_target):
		return ""
	var selected = _recovery_target.selected
	if selected > 0 and selected <= ModControls.CHARACTERS.size():
		return ModControls.CHARACTERS[selected - 1]
	var s = GameState.state
	if s != null and SceneSex.active(s) and ModControls.CHARACTERS.has(str(s.scene.get("id", ""))):
		return str(s.scene["id"])
	var main = get_parent()
	if main != null and str(main.get("target")) in ModControls.CHARACTERS:
		return str(main.get("target"))
	return ""

func _refresh_recovery() -> void:
	if not is_instance_valid(_recovery_button):
		return
	var who = _recovery_who()
	var reason = ModRecovery.blocked_reason(GameState.state, who)
	_recovery_button.disabled = not reason.is_empty()
	_recovery_button.tooltip_text = reason
	_recovery_status.text = "대상: " + CHARACTER_NAMES.get(who, "선택되지 않음") + ("\n" + reason if not reason.is_empty() else "\n장면 진행 중에도 사용할 수 있습니다.")
	if CHARACTER_COLORS.has(who):
		_recovery_button.add_theme_color_override("font_color", Color(CHARACTER_COLORS[who]))

func recover_character() -> void:
	var who = _recovery_who()
	var result = ModRecovery.recover(GameState.state, who)
	_notice.text = CHARACTER_NAMES.get(who, "") + (": " if not who.is_empty() else "") + str(result["message"])
	if result["ok"]:
		GameState.message("[MOD] " + _notice.text)
		GameState.state_changed.emit()
	else:
		_refresh_recovery()

func refill_actions() -> void:
	var reason = _blocked_reason()
	if not reason.is_empty():
		_notice.text = reason
		_refresh()
		return
	var s = GameState.state
	s.ap = Clock.ap_max(s)
	_notice.text = "행동 수를 %d(으)로 회복했습니다." % s.ap
	GameState.message("[MOD] " + _notice.text)
	GameState.state_changed.emit()

func change_heart_mode(index: int) -> void:
	if index < 0 or index >= ModControls.MODES.size():
		return
	var result = ModControls.set_mode(ModControls.MODES[index])
	_notice.text = "하트눈 설정을 저장했습니다." if result == OK else "설정을 저장하지 못했습니다. (%d)" % result
	GameState.state_changed.emit()

func change_ap_lock(enabled: bool) -> void:
	var result = ModControls.set_ap_locked(enabled)
	if result == OK:
		if enabled and GameState.state != null:
			GameState.state.ap = Clock.ap_max(GameState.state)
		_notice.text = "행동력을 최대치로 고정했습니다." if enabled else "행동력 고정을 해제했습니다."
	else:
		_notice.text = "행동력 고정 설정을 저장하지 못했습니다. (%d)" % result
	GameState.state_changed.emit()

func change_face_lock(who: String, face: String, enabled: bool) -> void:
	var value = face if enabled else ""
	if not enabled and ModControls.locked_face(who) != face:
		return
	var result = ModControls.set_locked_face(who, value)
	if result == OK:
		_notice.text = CHARACTER_NAMES[who] + (" 표정 잠금을 해제했습니다." if value.is_empty() else " 표정 고정: " + FACE_LABELS[value])
	else:
		_notice.text = "표정 잠금 설정을 저장하지 못했습니다. (%d)" % result
	GameState.state_changed.emit()

func _build_actor_page(page: VBoxContainer) -> void:
	var heading = Label.new()
	heading.text = "히로인 → 플레이어 호감도"
	heading.add_theme_font_size_override("font_size", 21)
	page.add_child(heading)
	var affinity_row = HBoxContainer.new()
	affinity_row.add_theme_constant_override("separation", 10)
	page.add_child(affinity_row)
	for who in ModControls.CHARACTERS:
		var column = VBoxContainer.new()
		column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		affinity_row.add_child(column)
		var label = Label.new()
		label.add_theme_color_override("font_color", Color(CHARACTER_COLORS[who]))
		column.add_child(label)
		_affinity_labels[who] = label
		var slider = HSlider.new()
		slider.name = "AffectionSlider_" + who
		slider.min_value = -100
		slider.max_value = 100
		slider.step = 1
		slider.scrollable = false
		slider.custom_minimum_size = Vector2(220, 32)
		slider.tooltip_text = "동그라미를 드래그해 -100~100 조절 · 놓으면 적용"
		_style_affinity_slider(slider, Color(CHARACTER_COLORS[who]))
		slider.drag_started.connect(func(): _affinity_drag_started(who))
		slider.value_changed.connect(func(value: float): _affinity_value_changed(who, value))
		slider.drag_ended.connect(func(changed: bool): _affinity_drag_ended(who, changed))
		column.add_child(slider)
		_affinity_sliders[who] = slider
		_affinity_dragging[who] = false
		var limits = HBoxContainer.new()
		for text in ["-100", "0", "+100"]:
			var limit = Label.new()
			limit.text = text
			limit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			limit.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT if text == "-100" else (HORIZONTAL_ALIGNMENT_CENTER if text == "0" else HORIZONTAL_ALIGNMENT_RIGHT)
			limit.add_theme_font_size_override("font_size", 13)
			limits.add_child(limit)
		column.add_child(limits)
		var button = Button.new()
		button.name = "AffectionMinus100_" + who
		button.text = CHARACTER_NAMES[who] + " 호감도 -100"
		button.custom_minimum_size.y = 38
		button.add_theme_color_override("font_color", Color(CHARACTER_COLORS[who]))
		button.pressed.connect(func(): _complete_actor_action(ModActors.set_affection(GameState.state, who)))
		column.add_child(button)
		_actor_buttons.append(button)
	var all_button = Button.new()
	all_button.name = "AllAffectionMinus100"
	all_button.text = "히로인 4명 모두: 플레이어 호감도 -100"
	all_button.custom_minimum_size.y = 38
	all_button.pressed.connect(func(): _complete_actor_action(ModActors.set_all_affection(GameState.state)))
	page.add_child(all_button)
	_actor_buttons.append(all_button)
	var explanation = Label.new()
	explanation.text = "바의 동그라미를 드래그하고 놓으면 적용됩니다. 호감도 수치 조절이며 관계는 게임 규칙을 따릅니다. 게임을 저장하면 값도 저장됩니다."
	explanation.add_theme_font_size_override("font_size", 15)
	page.add_child(explanation)
	page.add_child(HSeparator.new())
	var sleep_row = HBoxContainer.new()
	sleep_row.add_theme_constant_override("separation", 12)
	page.add_child(sleep_row)
	_sleep_button = Button.new()
	_sleep_button.name = "RivalSleepTonight"
	_sleep_button.text = "라이벌: 오늘 밤은 그냥 수면"
	_sleep_button.custom_minimum_size = Vector2(330, 38)
	_sleep_button.pressed.connect(func(): _complete_actor_action(ModActors.sleep_tonight(GameState.state)))
	sleep_row.add_child(_sleep_button)
	_sleep_cancel = Button.new()
	_sleep_cancel.name = "CancelRivalSleepTonight"
	_sleep_cancel.text = "수면 예약 취소"
	_sleep_cancel.custom_minimum_size = Vector2(180, 38)
	_sleep_cancel.pressed.connect(func(): _complete_actor_action(ModActors.cancel_sleep_tonight(GameState.state)))
	sleep_row.add_child(_sleep_cancel)
	_sleep_status = Label.new()
	page.add_child(_sleep_status)
	_rival_manual = CheckBox.new()
	_rival_manual.name = "ManualRivalControl"
	_rival_manual.text = "라이벌 수동 조종 (자동 행동 정지)"
	_rival_manual.toggled.connect(func(enabled: bool): _complete_actor_action(ModActors.change_manual(GameState.state, enabled)))
	page.add_child(_rival_manual)
	_rival_status = Label.new()
	page.add_child(_rival_status)
	var room_row = HBoxContainer.new()
	room_row.add_theme_constant_override("separation", 12)
	page.add_child(room_row)
	_rival_room = OptionButton.new()
	_rival_room.name = "RivalRoom"
	_rival_room.custom_minimum_size = Vector2(340, 38)
	room_row.add_child(_rival_room)
	var move_button = Button.new()
	move_button.name = "MoveRival"
	move_button.text = "선택 장소로 이동"
	move_button.custom_minimum_size = Vector2(220, 38)
	move_button.pressed.connect(func(): _complete_actor_action(ModActors.move_rival(GameState.state, _selected_room())))
	room_row.add_child(move_button)
	_rival_buttons.append(move_button)
	var target_row = HBoxContainer.new()
	target_row.add_theme_constant_override("separation", 12)
	page.add_child(target_row)
	_rival_target = OptionButton.new()
	_rival_target.name = "RivalTarget"
	_rival_target.custom_minimum_size = Vector2(220, 38)
	_rival_target.add_item("대상 없음")
	_rival_target.set_item_metadata(0, "")
	for who in ModControls.CHARACTERS:
		_rival_target.add_item(CHARACTER_NAMES[who])
		_rival_target.set_item_metadata(_rival_target.item_count - 1, who)
	target_row.add_child(_rival_target)
	var target_button = Button.new()
	target_button.name = "SetRivalTarget"
	target_button.text = "관심 대상 지정 / 해제"
	target_button.custom_minimum_size.y = 38
	target_button.pressed.connect(func(): _complete_actor_action(ModActors.set_target(GameState.state, _selected_target())))
	target_row.add_child(target_button)
	_rival_buttons.append(target_button)
	var follow_button = Button.new()
	follow_button.name = "MoveRivalToTarget"
	follow_button.text = "대상에게 이동"
	follow_button.custom_minimum_size.y = 38
	follow_button.pressed.connect(func(): _complete_actor_action(ModActors.move_to_target(GameState.state, _selected_target())))
	target_row.add_child(follow_button)
	_rival_buttons.append(follow_button)
	var talk_button = Button.new()
	talk_button.name = "RivalTalkOnce"
	talk_button.text = "선택 대상과 대화 1회"
	talk_button.custom_minimum_size.y = 38
	talk_button.pressed.connect(func(): _complete_actor_action(ModActors.talk(GameState.state, _selected_target())))
	target_row.add_child(talk_button)
	_rival_buttons.append(talk_button)
	var tip = Label.new()
	tip.text = "수동 체크 해제: 자동 행동 재개 · 직접 명령은 플레이어 행동력/시간을 쓰지 않습니다.\n잠긴 장소, 진행 중인 장면, 잠든 대상 등 게임 상태에 따라 명령이 제한됩니다."
	tip.add_theme_font_size_override("font_size", 15)
	page.add_child(tip)

func _selected_room() -> String:
	return str(_rival_room.get_item_metadata(_rival_room.selected)) if _rival_room.selected >= 0 else ""

func _selected_target() -> String:
	return str(_rival_target.get_item_metadata(_rival_target.selected)) if _rival_target.selected >= 0 else ""

func _refresh_actors() -> void:
	if not is_instance_valid(_rival_manual):
		return
	var s = GameState.state
	var reason = ModActors.blocked_reason(s)
	for button in _actor_buttons:
		button.disabled = not reason.is_empty()
		button.tooltip_text = reason
	for who in ModControls.CHARACTERS:
		_affinity_sliders[who].editable = reason.is_empty()
	var scheduled = ModControls.rival_sleep_scheduled(s)
	_sleep_button.disabled = not reason.is_empty() or scheduled
	_sleep_button.tooltip_text = reason
	_sleep_cancel.disabled = not reason.is_empty() or not scheduled
	_sleep_cancel.tooltip_text = reason
	_sleep_status.text = "오늘 밤 자기 방에서 수면 중 · 다음 날 자동 해제" if ModControls.rival_sleeping(s) else ("오늘 밤 수면 예약됨 · 낮 행동은 그대로" if scheduled else "수면 예약 없음 · 자동/수동 모드와 별도로 오늘 밤만 적용")
	if ModControls.rival_sleeping(s) and ModControls.rival_sleep_waiting(s):
		_sleep_status.text = "진행 중인 이벤트가 끝나면 자기 방에서 수면 · 다음 날 자동 해제"
	_rival_manual.set_pressed_no_signal(ModControls.rival_manual())
	_rival_manual.disabled = not reason.is_empty()
	_rival_manual.tooltip_text = reason
	var rival_reason = ModActors.rival_reason(s)
	for button in _rival_buttons:
		button.disabled = not rival_reason.is_empty()
		button.tooltip_text = rival_reason
	_rival_room.disabled = not rival_reason.is_empty()
	_rival_target.disabled = not rival_reason.is_empty()
	if s == null:
		return
	for who in ModControls.CHARACTERS:
		if not bool(_affinity_dragging.get(who, false)):
			var value = s.param(who, "pc", "affection")
			_affinity_labels[who].text = "%s → 플레이어: %d" % [CHARACTER_NAMES[who], value]
			_affinity_sliders[who].set_value_no_signal(value)
	var target = str(s.rival.get("target", ""))
	_rival_status.text = "모드: %s | 현재 위치: %s | 대상: %s" % ["수동 / 자동 정지" if ModControls.rival_manual() else "자동", s.room_name(s.room_of("rival")), s.short_name(target) if s.heroines.has(target) else "없음"]
	var room_ids: Array = []
	for room in s.data["rooms"]["rooms"]:
		if ModActors.room_valid(s, str(room["id"])):
			room_ids.append(str(room["id"]))
	if room_ids != _room_ids:
		_room_ids = room_ids
		_rival_room.clear()
		for room in room_ids:
			_rival_room.add_item(s.room_name(room))
			_rival_room.set_item_metadata(_rival_room.item_count - 1, room)
	if room_ids.has(s.room_of("rival")):
		_rival_room.select(room_ids.find(s.room_of("rival")))
	for i in range(_rival_target.item_count):
		if str(_rival_target.get_item_metadata(i)) == target:
			_rival_target.select(i)
			break

func _complete_actor_action(result: Dictionary) -> void:
	_notice.text = str(result["message"])
	if result["ok"]:
		GameState.message("[MOD] " + _notice.text)
		GameState._after_change()
	else:
		_refresh()

func _style_affinity_slider(slider: HSlider, color: Color) -> void:
	for key in ["grabber", "grabber_highlight", "grabber_disabled"]:
		var fill = color.darkened(0.5) if key == "grabber_disabled" else (color.lightened(0.2) if key == "grabber_highlight" else color)
		var image = Image.new()
		var svg = '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20"><circle cx="10" cy="10" r="8" fill="#%s" stroke="white" stroke-width="2"/></svg>' % fill.to_html(false)
		if image.load_svg_from_string(svg) == OK:
			slider.add_theme_icon_override(key, ImageTexture.create_from_image(image))
	var track = StyleBoxFlat.new()
	track.bg_color = Color(0.15, 0.17, 0.21)
	track.set_corner_radius_all(3)
	track.content_margin_top = 3
	track.content_margin_bottom = 3
	slider.add_theme_stylebox_override("slider", track)
	var area = track.duplicate() as StyleBoxFlat
	area.bg_color = color.darkened(0.25)
	slider.add_theme_stylebox_override("grabber_area", area)
	slider.add_theme_stylebox_override("grabber_area_highlight", area)

func _affinity_drag_started(who: String) -> void:
	_affinity_dragging[who] = true

func _affinity_value_changed(who: String, value: float) -> void:
	_affinity_labels[who].text = "%s → 플레이어: %d" % [CHARACTER_NAMES[who], int(round(value))]
	if not bool(_affinity_dragging.get(who, false)):
		_complete_actor_action(ModActors.set_affection_value(GameState.state, who, int(round(value))))

func _affinity_drag_ended(who: String, changed: bool) -> void:
	var was_dragging = bool(_affinity_dragging.get(who, false))
	_affinity_dragging[who] = false
	if changed and was_dragging:
		_complete_actor_action(ModActors.set_affection_value(GameState.state, who, int(round(_affinity_sliders[who].value))))
	else:
		_refresh()

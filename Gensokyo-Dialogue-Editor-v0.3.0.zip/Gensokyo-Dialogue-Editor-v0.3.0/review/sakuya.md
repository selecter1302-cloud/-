# 이자요이 사쿠야 — 짧은 대사·지문 검토본 v0.3.0

미적용 초안. `{name}`은 발화 앞에서는 성명, 지문에서는 짧은 이름으로 표시된다. HTML에서 이름·색상을 반영한 미리보기를 볼 수 있다.

## 싫어함

### 몸: 주인공쪽

#### 직후 · 관계 직후 · 해당 없음

**V03-SAKUYA-HATE-PC-AFTER-A · 대사 → 짧은 지문**

{name}「……곁이 익숙해져도 당신은 불편합니다.」{name}는 머리띠를 쥔 채 곁에 머물렀다.

**V03-SAKUYA-HATE-PC-AFTER-B · 대사 → 짧은 지문**

{name}「……돌아가야 하는데 자리를 못 뜨겠군요.」{name}는 머리띠를 쥔 채 곁에 머물렀다.

#### 다음 만남 · 대화하기 · 해당 없음

**V03-SAKUYA-HATE-PC-NEXT_TALK-A · 대사 → 짧은 지문**

{name}「……제가 먼저 가까이 섰군요. 실례했습니다.」{name}는 먼저 돌아보다 머리띠를 매만졌다.

**V03-SAKUYA-HATE-PC-NEXT_TALK-B · 지문만**

{name}는 이쪽을 먼저 돌아보고도 하던 일을 조용히 다시 시작했다.

#### 다음 만남 · 스킨십 · 수락

**V03-SAKUYA-HATE-PC-NEXT_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……손은 그대로 두겠습니다. 그뿐입니다.」{name}는 잡힌 손을 확인하고 자세를 바로 했다.

**V03-SAKUYA-HATE-PC-NEXT_TOUCH_ALLOW-B · 대사 → 짧은 지문**

{name}「……제가 가까이 섰다는 건 압니다.」{name}는 잡힌 손을 확인하고 자세를 바로 했다.

#### 다음 만남 · 스킨십 · 거절

**V03-SAKUYA-HATE-PC-NEXT_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「……제가 왔어도 손까지 허락하지는 않았습니다.」{name}는 내밀려던 손을 거두고 반걸음 물러났다.

**V03-SAKUYA-HATE-PC-NEXT_TOUCH_REFUSE-B · 지문만**

{name}는 이쪽을 먼저 돌아보고도 뻗은 손을 피하며 반걸음 물러났다.

#### 다음 만남 · 키스 · 수락

**V03-SAKUYA-HATE-PC-NEXT_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……당신 앞에서는 말이 늦어지는군요.」{name}는 끝난 뒤 앞치마 끝을 다시 폈다.

**V03-SAKUYA-HATE-PC-NEXT_KISS_ALLOW-B · 대사 → 짧은 지문**

{name}「……제가 가까이 섰다는 건 압니다.」{name}는 끝난 뒤 앞치마 끝을 다시 폈다.

#### 다음 만남 · 키스 · 거절

**V03-SAKUYA-HATE-PC-NEXT_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「……멈추십시오. 또 말을 삼킬 것 같군요.」{name}는 고개를 들려다 말고 손끝으로 막았다.

**V03-SAKUYA-HATE-PC-NEXT_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「……제가 가까이 섰다는 건 압니다.」{name}는 고개를 들려다 말고 손끝으로 막았다.

#### 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-SAKUYA-HATE-PC-LATE_TALK-A · 대사 → 짧은 지문**

{name}「……당신 발소리를 먼저 알게 되었군요.」{name}는 먼저 돌아보다 머리띠를 매만졌다.

**V03-SAKUYA-HATE-PC-LATE_TALK-B · 대사 → 짧은 지문**

{name}「……당신의 자리를 먼저 확인하게 되는군요.」{name}는 먼저 돌아보다 머리띠를 매만졌다.

#### 시간이 지난 뒤 · 스킨십 · 수락

**V03-SAKUYA-HATE-PC-LATE_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……익숙한 손이라고 믿게 된 건 아닙니다.」{name}는 잡힌 손을 확인하고 자세를 바로 했다.

**V03-SAKUYA-HATE-PC-LATE_TOUCH_ALLOW-B · 대사 → 짧은 지문**

{name}「……당신의 자리를 먼저 확인하게 되는군요.」{name}는 잡힌 손을 확인하고 자세를 바로 했다.

#### 시간이 지난 뒤 · 스킨십 · 거절

**V03-SAKUYA-HATE-PC-LATE_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「……곁에 섰어도 오늘은 사양하겠습니다.」{name}는 내밀었던 손을 등 뒤로 거뒀다.

**V03-SAKUYA-HATE-PC-LATE_TOUCH_REFUSE-B · 대사 → 짧은 지문**

{name}「……당신의 자리를 먼저 확인하게 되는군요.」{name}는 내밀었던 손을 등 뒤로 거뒀다.

#### 시간이 지난 뒤 · 키스 · 수락

**V03-SAKUYA-HATE-PC-LATE_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……제가 먼저 고개를 들었군요. 곤란합니다.」{name}는 끝난 뒤 앞치마 끝을 다시 폈다.

**V03-SAKUYA-HATE-PC-LATE_KISS_ALLOW-B · 지문만**

{name}는 이쪽을 먼저 돌아보고도 입술이 떨어지자 자세를 고쳤다.

#### 시간이 지난 뒤 · 키스 · 거절

**V03-SAKUYA-HATE-PC-LATE_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「……익숙해져도 오늘의 대답은 다릅니다.」{name}는 고개를 들려다 멈추고 몸을 비켰다.

**V03-SAKUYA-HATE-PC-LATE_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「……당신의 자리를 먼저 확인하게 되는군요.」{name}는 고개를 들려다 멈추고 몸을 비켰다.

### 몸: 미정

#### 직후 · 관계 직후 · 해당 없음

**V03-SAKUYA-HATE-UNSET-AFTER-A · 대사 → 짧은 지문**

{name}「……그분께 무슨 말씀을 드려야 할까요.」{name}는 앞치마를 꼭 쥐고 눈을 내렸다.

**V03-SAKUYA-HATE-UNSET-AFTER-B · 대사 → 짧은 지문**

{name}「그분께 드릴 말씀을 고르고 있습니다.」{name}는 앞치마를 꼭 쥐고 눈을 내렸다.

#### 다음 만남 · 대화하기 · 해당 없음

**V03-SAKUYA-HATE-UNSET-NEXT_TALK-A · 대사 → 짧은 지문**

{name}「용건만 말씀해 주십시오. 그분 이야기는 말고요.」{name}는 짧게 답하고 앞치마를 폈다.

**V03-SAKUYA-HATE-UNSET-NEXT_TALK-B · 지문만**

{name}는 표정을 바꾸지 않은 채 하던 일을 조용히 다시 시작했다.

#### 다음 만남 · 스킨십 · 수락

**V03-SAKUYA-HATE-UNSET-NEXT_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……그분과 비교하지는 말아 주세요.」{name}는 손은 그대로 두고 앞치마를 쥐었다.

**V03-SAKUYA-HATE-UNSET-NEXT_TOUCH_ALLOW-B · 대사 → 짧은 지문**

{name}「그분 이야기는 오늘은 듣기 어렵겠습니다.」{name}는 손은 그대로 두고 앞치마를 쥐었다.

#### 다음 만남 · 스킨십 · 거절

**V03-SAKUYA-HATE-UNSET-NEXT_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「그 일이 있었다고 대답을 생략하지 마세요.」{name}는 손을 피하고 등 뒤로 모았다.

**V03-SAKUYA-HATE-UNSET-NEXT_TOUCH_REFUSE-B · 지문만**

{name}는 표정을 바꾸지 않은 채 뻗은 손을 피하며 반걸음 물러났다.

#### 다음 만남 · 키스 · 수락

**V03-SAKUYA-HATE-UNSET-NEXT_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……마음까지 바뀌었다고 생각하지 마십시오.」{name}는 입술이 떨어지자 눈을 내렸다.

**V03-SAKUYA-HATE-UNSET-NEXT_KISS_ALLOW-B · 대사 → 짧은 지문**

{name}「그분 이야기는 오늘은 듣기 어렵겠습니다.」{name}는 입술이 떨어지자 눈을 내렸다.

#### 다음 만남 · 키스 · 거절

**V03-SAKUYA-HATE-UNSET-NEXT_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「사양하겠습니다. 그분께도 드릴 말이 없습니다.」{name}는 얼굴을 돌리고 한 걸음 물러났다.

**V03-SAKUYA-HATE-UNSET-NEXT_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「그분 이야기는 오늘은 듣기 어렵겠습니다.」{name}는 얼굴을 돌리고 한 걸음 물러났다.

#### 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-SAKUYA-HATE-UNSET-LATE_TALK-A · 대사 → 짧은 지문**

{name}「그분 앞에서도 당신 이야기를 피하게 됩니다.」{name}는 짧게 답하고 앞치마를 폈다.

**V03-SAKUYA-HATE-UNSET-LATE_TALK-B · 대사 → 짧은 지문**

{name}「그분께 숨겼다고 당신까지 믿게 된 건 아닙니다.」{name}는 짧게 답하고 앞치마를 폈다.

#### 시간이 지난 뒤 · 스킨십 · 수락

**V03-SAKUYA-HATE-UNSET-LATE_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……화해했다고 생각하지 말아 주세요.」{name}는 손은 그대로 두고 앞치마를 쥐었다.

**V03-SAKUYA-HATE-UNSET-LATE_TOUCH_ALLOW-B · 대사 → 짧은 지문**

{name}「그분께 숨겼다고 당신까지 믿게 된 건 아닙니다.」{name}는 손은 그대로 두고 앞치마를 쥐었다.

#### 시간이 지난 뒤 · 스킨십 · 거절

**V03-SAKUYA-HATE-UNSET-LATE_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「거절하겠습니다. 여러 번 말씀드렸습니다.」{name}는 손을 받지 않고 반걸음 비켰다.

**V03-SAKUYA-HATE-UNSET-LATE_TOUCH_REFUSE-B · 대사 → 짧은 지문**

{name}「그분께 숨겼다고 당신까지 믿게 된 건 아닙니다.」{name}는 손을 받지 않고 반걸음 비켰다.

#### 시간이 지난 뒤 · 키스 · 수락

**V03-SAKUYA-HATE-UNSET-LATE_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……그분께는 아직 말씀도 못 드렸는데요.」{name}는 입술이 떨어지자 눈을 내렸다.

**V03-SAKUYA-HATE-UNSET-LATE_KISS_ALLOW-B · 지문만**

{name}는 표정을 바꾸지 않은 채 입술이 떨어지자 자세를 고쳤다.

#### 시간이 지난 뒤 · 키스 · 거절

**V03-SAKUYA-HATE-UNSET-LATE_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「그만두십시오. 더는 같은 말씀을 드리지 않겠습니다.」{name}는 손끝으로 막은 채 시선을 내렸다.

**V03-SAKUYA-HATE-UNSET-LATE_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「그분께 숨겼다고 당신까지 믿게 된 건 아닙니다.」{name}는 손끝으로 막은 채 시선을 내렸다.

## 친구

### 몸: 주인공쪽

#### 직후 · 관계 직후 · 해당 없음

**V03-SAKUYA-FRIEND-PC-AFTER-A · 대사 → 짧은 지문**

{name}「……곁에 계시면 편합니다. 그래서 곤란하군요.」{name}는 머리띠를 집고도 곁을 떠나지 않았다.

**V03-SAKUYA-FRIEND-PC-AFTER-B · 대사 → 짧은 지문**

{name}「……곁에 계시면 편합니다. 곤란하게도요.」{name}는 머리띠를 집고도 곁을 떠나지 않았다.

#### 다음 만남 · 대화하기 · 해당 없음

**V03-SAKUYA-FRIEND-PC-NEXT_TALK-A · 대사 → 짧은 지문**

{name}「……옆자리를 먼저 비워 두었군요.」{name}는 다가서다 멈추고 앞치마를 매만졌다.

**V03-SAKUYA-FRIEND-PC-NEXT_TALK-B · 지문만**

{name}는 옆으로 다가서다 말고 하던 일을 조용히 다시 시작했다.

#### 다음 만남 · 스킨십 · 수락

**V03-SAKUYA-FRIEND-PC-NEXT_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……친구 사이의 행동이라고 하기 어렵군요.」{name}는 손가락을 포갰다가 눈을 내렸다.

**V03-SAKUYA-FRIEND-PC-NEXT_TOUCH_ALLOW-B · 지문만**

{name}는 옆으로 다가서다 말고 빈손으로 앞치마 끝을 매만졌다.

#### 다음 만남 · 스킨십 · 거절

**V03-SAKUYA-FRIEND-PC-NEXT_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「……곁에만 계셔 주십시오. 손은 말고요.」{name}는 내밀려던 손을 거두고 반걸음 물러났다.

**V03-SAKUYA-FRIEND-PC-NEXT_TOUCH_REFUSE-B · 대사 → 짧은 지문**

{name}「……먼저 옆자리를 준비했습니다.」{name}는 내밀려던 손을 거두고 반걸음 물러났다.

#### 다음 만남 · 키스 · 수락

**V03-SAKUYA-FRIEND-PC-NEXT_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……친구라고 부르는 편이 이상해졌습니다.」{name}는 먼저 고개를 들었다가 눈을 내렸다.

**V03-SAKUYA-FRIEND-PC-NEXT_KISS_ALLOW-B · 대사 → 짧은 지문**

{name}「……먼저 옆자리를 준비했습니다.」{name}는 먼저 고개를 들었다가 눈을 내렸다.

#### 다음 만남 · 키스 · 거절

**V03-SAKUYA-FRIEND-PC-NEXT_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「……이러면 또 하려던 말을 놓치겠습니다.」{name}는 고개를 들려다 말고 손끝으로 막았다.

**V03-SAKUYA-FRIEND-PC-NEXT_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「……먼저 옆자리를 준비했습니다.」{name}는 고개를 들려다 말고 손끝으로 막았다.

#### 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-SAKUYA-FRIEND-PC-LATE_TALK-A · 대사 → 짧은 지문**

{name}「……당신 찻잔부터 꺼냈군요.」{name}는 옆에 서려다 말고 앞치마를 폈다.

**V03-SAKUYA-FRIEND-PC-LATE_TALK-B · 대사 → 짧은 지문**

{name}「……당신 잔만 먼저 꺼냈군요.」{name}는 옆에 서려다 말고 앞치마를 폈다.

#### 시간이 지난 뒤 · 스킨십 · 수락

**V03-SAKUYA-FRIEND-PC-LATE_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……제 손이 먼저 움직이는군요.」{name}는 먼저 포갠 손에서 눈을 떼지 못했다.

**V03-SAKUYA-FRIEND-PC-LATE_TOUCH_ALLOW-B · 대사 → 짧은 지문**

{name}「……당신 잔만 먼저 꺼냈군요.」{name}는 먼저 포갠 손에서 눈을 떼지 못했다.

#### 시간이 지난 뒤 · 스킨십 · 거절

**V03-SAKUYA-FRIEND-PC-LATE_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「……기대는 것이 편해져서 오늘은 멈추겠습니다.」{name}는 내밀었던 손을 등 뒤로 거뒀다.

**V03-SAKUYA-FRIEND-PC-LATE_TOUCH_REFUSE-B · 대사 → 짧은 지문**

{name}「……당신 잔만 먼저 꺼냈군요.」{name}는 내밀었던 손을 등 뒤로 거뒀다.

#### 시간이 지난 뒤 · 키스 · 수락

**V03-SAKUYA-FRIEND-PC-LATE_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……친구라는 말만으로는 부족하겠군요.」{name}는 먼저 감은 눈을 뜨고 자세를 고쳤다.

**V03-SAKUYA-FRIEND-PC-LATE_KISS_ALLOW-B · 지문만**

{name}는 옆으로 다가서다 말고 입술이 떨어지자 자세를 고쳤다.

#### 시간이 지난 뒤 · 키스 · 거절

**V03-SAKUYA-FRIEND-PC-LATE_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「……오늘은 먼저 이야기를 마치겠습니다.」{name}는 고개를 들려다 멈추고 몸을 비켰다.

**V03-SAKUYA-FRIEND-PC-LATE_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「……당신 잔만 먼저 꺼냈군요.」{name}는 고개를 들려다 멈추고 몸을 비켰다.

### 몸: 미정

#### 직후 · 관계 직후 · 해당 없음

**V03-SAKUYA-FRIEND-UNSET-AFTER-A · 대사 → 짧은 지문**

{name}「……이제 그분 이야기를 당신께 어떻게 드릴까요.」{name}는 반듯한 소매를 다시 한 번 폈다.

**V03-SAKUYA-FRIEND-UNSET-AFTER-B · 대사 → 짧은 지문**

{name}「친구라고만 말씀드리면 그분께 더 죄송하겠군요.」{name}는 반듯한 소매를 다시 한 번 폈다.

#### 다음 만남 · 대화하기 · 해당 없음

**V03-SAKUYA-FRIEND-UNSET-NEXT_TALK-A · 대사 → 짧은 지문**

{name}「차는 준비하겠습니다. 그 이야기는 나중에요.」{name}는 하던 손놀림을 멈추고 눈을 내렸다.

**V03-SAKUYA-FRIEND-UNSET-NEXT_TALK-B · 지문만**

{name}는 미소를 지으려다 멈추고 하던 일을 조용히 다시 시작했다.

#### 다음 만남 · 스킨십 · 수락

**V03-SAKUYA-FRIEND-UNSET-NEXT_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……그분 앞에서도 이렇게 태연하면 좋겠습니다만.」{name}는 손을 빼지 않고 자세만 고쳤다.

**V03-SAKUYA-FRIEND-UNSET-NEXT_TOUCH_ALLOW-B · 지문만**

{name}는 미소를 지으려다 멈추고 빈손으로 앞치마 끝을 매만졌다.

#### 다음 만남 · 스킨십 · 거절

**V03-SAKUYA-FRIEND-UNSET-NEXT_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「오늘은 이야기만 해 주시겠습니까.」{name}는 손을 피하고 등 뒤로 모았다.

**V03-SAKUYA-FRIEND-UNSET-NEXT_TOUCH_REFUSE-B · 대사 → 짧은 지문**

{name}「그분께 차를 드리다가 당신 생각이 났습니다.」{name}는 손을 피하고 등 뒤로 모았다.

#### 다음 만남 · 키스 · 수락

**V03-SAKUYA-FRIEND-UNSET-NEXT_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……그분의 얼굴이 떠오르는군요.」{name}는 입술이 떨어지자 앞치마 끈을 쥐었다.

**V03-SAKUYA-FRIEND-UNSET-NEXT_KISS_ALLOW-B · 대사 → 짧은 지문**

{name}「그분께 차를 드리다가 당신 생각이 났습니다.」{name}는 입술이 떨어지자 앞치마 끈을 쥐었다.

#### 다음 만남 · 키스 · 거절

**V03-SAKUYA-FRIEND-UNSET-NEXT_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「친구 사이의 장난으로 넘길 일은 아니겠지요.」{name}는 얼굴을 돌리고 한 걸음 물러났다.

**V03-SAKUYA-FRIEND-UNSET-NEXT_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「그분께 차를 드리다가 당신 생각이 났습니다.」{name}는 얼굴을 돌리고 한 걸음 물러났다.

#### 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-SAKUYA-FRIEND-UNSET-LATE_TALK-A · 대사 → 짧은 지문**

{name}「차를 마시며 웃으면 전처럼 될 줄 알았습니다.」{name}는 대답 뒤에 하던 일로 눈을 돌렸다.

**V03-SAKUYA-FRIEND-UNSET-LATE_TALK-B · 대사 → 짧은 지문**

{name}「그분께는 친구 사이라고 말씀드렸습니다.」{name}는 대답 뒤에 하던 일로 눈을 돌렸다.

#### 시간이 지난 뒤 · 스킨십 · 수락

**V03-SAKUYA-FRIEND-UNSET-LATE_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……그분께는 이 손을 어떻게 설명할까요.」{name}는 잡힌 손을 보다가 자세를 바로 했다.

**V03-SAKUYA-FRIEND-UNSET-LATE_TOUCH_ALLOW-B · 대사 → 짧은 지문**

{name}「그분께는 친구 사이라고 말씀드렸습니다.」{name}는 잡힌 손을 보다가 자세를 바로 했다.

#### 시간이 지난 뒤 · 스킨십 · 거절

**V03-SAKUYA-FRIEND-UNSET-LATE_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「친구라고 늘 괜찮은 것은 아닙니다.」{name}는 손을 받지 않고 반걸음 비켰다.

**V03-SAKUYA-FRIEND-UNSET-LATE_TOUCH_REFUSE-B · 대사 → 짧은 지문**

{name}「그분께는 친구 사이라고 말씀드렸습니다.」{name}는 손을 받지 않고 반걸음 비켰다.

#### 시간이 지난 뒤 · 키스 · 수락

**V03-SAKUYA-FRIEND-UNSET-LATE_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……그분 이야기만 빼면 편한 사이가 되었네요.」{name}는 입술이 떨어지자 머리띠를 매만졌다.

**V03-SAKUYA-FRIEND-UNSET-LATE_KISS_ALLOW-B · 지문만**

{name}는 미소를 지으려다 멈추고 입술이 떨어지자 자세를 고쳤다.

#### 시간이 지난 뒤 · 키스 · 거절

**V03-SAKUYA-FRIEND-UNSET-LATE_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「이러고 나서 친구였다고만 말씀드릴 수는 없지요.」{name}는 손끝으로 막은 채 시선을 내렸다.

**V03-SAKUYA-FRIEND-UNSET-LATE_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「그분께는 친구 사이라고 말씀드렸습니다.」{name}는 손끝으로 막은 채 시선을 내렸다.

## 연인(비밀)

### 몸: 주인공쪽

#### 직후 · 관계 직후 · 해당 없음

**V03-SAKUYA-SECRET-PC-AFTER-A · 대사 → 짧은 지문**

{name}「……조금만 더요. 돌아가야 한다는 건 압니다.」{name}는 머리띠를 집고도 곁을 떠나지 않았다.

**V03-SAKUYA-SECRET-PC-AFTER-B · 대사 → 짧은 지문**

{name}「……머리띠는 조금 있다 쓰겠습니다.」{name}는 머리띠를 집고도 곁을 떠나지 않았다.

#### 다음 만남 · 대화하기 · 해당 없음

**V03-SAKUYA-SECRET-PC-NEXT_TALK-A · 대사 → 짧은 지문**

{name}「……오시는 소리를 기다리고 있었습니다.」{name}는 다가서다 멈추고 앞치마를 매만졌다.

**V03-SAKUYA-SECRET-PC-NEXT_TALK-B · 지문만**

{name}는 곁을 떠나지 못하면서 하던 일을 조용히 다시 시작했다.

#### 다음 만남 · 스킨십 · 수락

**V03-SAKUYA-SECRET-PC-NEXT_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……잠시만 더 잡아 주십시오.」{name}는 손가락을 포갰다가 눈을 내렸다.

**V03-SAKUYA-SECRET-PC-NEXT_TOUCH_ALLOW-B · 지문만**

{name}는 곁을 떠나지 못하면서 빈손으로 앞치마 끝을 매만졌다.

#### 다음 만남 · 스킨십 · 거절

**V03-SAKUYA-SECRET-PC-NEXT_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「……기대면 또 늦겠군요. 오늘은 여기까지요.」{name}는 내밀려던 손을 거두고 반걸음 물러났다.

**V03-SAKUYA-SECRET-PC-NEXT_TOUCH_REFUSE-B · 대사 → 짧은 지문**

{name}「……오셨다는 인사가 먼저 나오는군요.」{name}는 내밀려던 손을 거두고 반걸음 물러났다.

#### 다음 만남 · 키스 · 수락

**V03-SAKUYA-SECRET-PC-NEXT_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……조금만 더. 제가 먼저 부탁드렸군요.」{name}는 먼저 고개를 들었다가 눈을 내렸다.

**V03-SAKUYA-SECRET-PC-NEXT_KISS_ALLOW-B · 대사 → 짧은 지문**

{name}「……오셨다는 인사가 먼저 나오는군요.」{name}는 먼저 고개를 들었다가 눈을 내렸다.

#### 다음 만남 · 키스 · 거절

**V03-SAKUYA-SECRET-PC-NEXT_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「……다시 말을 미루기 전에 멈춰 주십시오.」{name}는 고개를 들려다 말고 손끝으로 막았다.

**V03-SAKUYA-SECRET-PC-NEXT_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「……오셨다는 인사가 먼저 나오는군요.」{name}는 고개를 들려다 말고 손끝으로 막았다.

#### 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-SAKUYA-SECRET-PC-LATE_TALK-A · 대사 → 짧은 지문**

{name}「……당신 곁에서는 시계를 보지 않게 됩니다.」{name}는 옆에 서려다 말고 앞치마를 폈다.

**V03-SAKUYA-SECRET-PC-LATE_TALK-B · 대사 → 짧은 지문**

{name}「……당신 잔을 씻다가 시간을 놓쳤군요.」{name}는 옆에 서려다 말고 앞치마를 폈다.

#### 시간이 지난 뒤 · 스킨십 · 수락

**V03-SAKUYA-SECRET-PC-LATE_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……이제 다른 손은 낯설 것 같군요.」{name}는 먼저 포갠 손에서 눈을 떼지 못했다.

**V03-SAKUYA-SECRET-PC-LATE_TOUCH_ALLOW-B · 대사 → 짧은 지문**

{name}「……당신 잔을 씻다가 시간을 놓쳤군요.」{name}는 먼저 포갠 손에서 눈을 떼지 못했다.

#### 시간이 지난 뒤 · 스킨십 · 거절

**V03-SAKUYA-SECRET-PC-LATE_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「……가까이 계시면 결심이 오래가지 않는군요.」{name}는 내밀었던 손을 등 뒤로 거뒀다.

**V03-SAKUYA-SECRET-PC-LATE_TOUCH_REFUSE-B · 대사 → 짧은 지문**

{name}「……당신 잔을 씻다가 시간을 놓쳤군요.」{name}는 내밀었던 손을 등 뒤로 거뒀다.

#### 시간이 지난 뒤 · 키스 · 수락

**V03-SAKUYA-SECRET-PC-LATE_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……그분께는 늦는다고 했습니다. 당신을 기다리려고요.」{name}는 먼저 감은 눈을 뜨고 자세를 고쳤다.

**V03-SAKUYA-SECRET-PC-LATE_KISS_ALLOW-B · 지문만**

{name}는 곁을 떠나지 못하면서 입술이 떨어지자 자세를 고쳤다.

#### 시간이 지난 뒤 · 키스 · 거절

**V03-SAKUYA-SECRET-PC-LATE_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「……이대로 다시 말을 미루고 싶지는 않습니다.」{name}는 고개를 들려다 멈추고 몸을 비켰다.

**V03-SAKUYA-SECRET-PC-LATE_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「……당신 잔을 씻다가 시간을 놓쳤군요.」{name}는 고개를 들려다 멈추고 몸을 비켰다.

### 몸: 미정

#### 직후 · 관계 직후 · 해당 없음

**V03-SAKUYA-SECRET-UNSET-AFTER-A · 대사 → 짧은 지문**

{name}「좋아합니다. ……그분께는 죄송하지만요.」{name}는 반듯한 소매를 다시 한 번 폈다.

**V03-SAKUYA-SECRET-UNSET-AFTER-B · 대사 → 짧은 지문**

{name}「좋아합니다. 그분께 죄송한 마음도 같습니다.」{name}는 반듯한 소매를 다시 한 번 폈다.

#### 다음 만남 · 대화하기 · 해당 없음

**V03-SAKUYA-SECRET-UNSET-NEXT_TALK-A · 대사 → 짧은 지문**

{name}「그분께서 잘 쉬었느냐고 하셨습니다. 대답이 늦었군요.」{name}는 하던 손놀림을 멈추고 눈을 내렸다.

**V03-SAKUYA-SECRET-UNSET-NEXT_TALK-B · 지문만**

{name}는 문 쪽을 한 번 살피고 하던 일을 조용히 다시 시작했다.

#### 다음 만남 · 스킨십 · 수락

**V03-SAKUYA-SECRET-UNSET-NEXT_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……이러면 돌아가기 어렵겠습니다.」{name}는 손을 빼지 않고 자세만 고쳤다.

**V03-SAKUYA-SECRET-UNSET-NEXT_TOUCH_ALLOW-B · 지문만**

{name}는 문 쪽을 한 번 살피고 빈손으로 앞치마 끝을 매만졌다.

#### 다음 만남 · 스킨십 · 거절

**V03-SAKUYA-SECRET-UNSET-NEXT_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「다정하게 대해 주시면 말을 꺼내기 어렵습니다.」{name}는 손을 피하고 등 뒤로 모았다.

**V03-SAKUYA-SECRET-UNSET-NEXT_TOUCH_REFUSE-B · 대사 → 짧은 지문**

{name}「그분께 드린 보고에는 당신 이야기가 빠졌습니다.」{name}는 손을 피하고 등 뒤로 모았다.

#### 다음 만남 · 키스 · 수락

**V03-SAKUYA-SECRET-UNSET-NEXT_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……당신을 좋아해도 그분 생각은 납니다.」{name}는 입술이 떨어지자 앞치마 끈을 쥐었다.

**V03-SAKUYA-SECRET-UNSET-NEXT_KISS_ALLOW-B · 대사 → 짧은 지문**

{name}「그분께 드린 보고에는 당신 이야기가 빠졌습니다.」{name}는 입술이 떨어지자 앞치마 끈을 쥐었다.

#### 다음 만남 · 키스 · 거절

**V03-SAKUYA-SECRET-UNSET-NEXT_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「그분 이야기를 먼저 하고 싶습니다.」{name}는 얼굴을 돌리고 한 걸음 물러났다.

**V03-SAKUYA-SECRET-UNSET-NEXT_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「그분께 드린 보고에는 당신 이야기가 빠졌습니다.」{name}는 얼굴을 돌리고 한 걸음 물러났다.

#### 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-SAKUYA-SECRET-UNSET-LATE_TALK-A · 대사 → 짧은 지문**

{name}「숨기는 일만 익숙해졌군요. 그분을 보기는 아직 어렵습니다.」{name}는 대답 뒤에 하던 일로 눈을 돌렸다.

**V03-SAKUYA-SECRET-UNSET-LATE_TALK-B · 대사 → 짧은 지문**

{name}「비밀을 지키는 것보다 그분을 뵙기가 어렵습니다.」{name}는 대답 뒤에 하던 일로 눈을 돌렸다.

#### 시간이 지난 뒤 · 스킨십 · 수락

**V03-SAKUYA-SECRET-UNSET-LATE_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……이 손을 잡고 그분께 무슨 말씀을 드릴까요.」{name}는 잡힌 손을 보다가 자세를 바로 했다.

**V03-SAKUYA-SECRET-UNSET-LATE_TOUCH_ALLOW-B · 대사 → 짧은 지문**

{name}「비밀을 지키는 것보다 그분을 뵙기가 어렵습니다.」{name}는 잡힌 손을 보다가 자세를 바로 했다.

#### 시간이 지난 뒤 · 스킨십 · 거절

**V03-SAKUYA-SECRET-UNSET-LATE_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「오늘은 이야기를 먼저 하시지요. 그분 이야기도요.」{name}는 손을 받지 않고 반걸음 비켰다.

**V03-SAKUYA-SECRET-UNSET-LATE_TOUCH_REFUSE-B · 대사 → 짧은 지문**

{name}「비밀을 지키는 것보다 그분을 뵙기가 어렵습니다.」{name}는 손을 받지 않고 반걸음 비켰다.

#### 시간이 지난 뒤 · 키스 · 수락

**V03-SAKUYA-SECRET-UNSET-LATE_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……좋아한다는 말씀만 드리면 편할 텐데요.」{name}는 입술이 떨어지자 머리띠를 매만졌다.

**V03-SAKUYA-SECRET-UNSET-LATE_KISS_ALLOW-B · 지문만**

{name}는 문 쪽을 한 번 살피고 입술이 떨어지자 자세를 고쳤다.

#### 시간이 지난 뒤 · 키스 · 거절

**V03-SAKUYA-SECRET-UNSET-LATE_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「그분과의 일을 먼저 말씀드리겠습니다.」{name}는 손끝으로 막은 채 시선을 내렸다.

**V03-SAKUYA-SECRET-UNSET-LATE_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「비밀을 지키는 것보다 그분을 뵙기가 어렵습니다.」{name}는 손끝으로 막은 채 시선을 내렸다.

## 타인

### 몸: 주인공쪽

#### 직후 · 관계 직후 · 해당 없음

**V03-SAKUYA-STRANGER-PC-AFTER-A · 대사 → 짧은 지문**

{name}「……곁이 먼저 익숙해졌군요. 당신을 알기도 전에요.」{name}는 머리띠를 집고도 곁을 떠나지 않았다.

**V03-SAKUYA-STRANGER-PC-AFTER-B · 대사 → 짧은 지문**

{name}「……가까운 자리가 먼저 익숙해졌군요.」{name}는 머리띠를 집고도 곁을 떠나지 않았다.

#### 다음 만남 · 대화하기 · 해당 없음

**V03-SAKUYA-STRANGER-PC-NEXT_TALK-A · 대사 → 짧은 지문**

{name}「……당신 계신 곳을 먼저 찾았습니다.」{name}는 다가서다 멈추고 앞치마를 매만졌다.

**V03-SAKUYA-STRANGER-PC-NEXT_TALK-B · 지문만**

{name}는 가까이 섰다가 뒤늦게 하던 일을 조용히 다시 시작했다.

#### 다음 만남 · 스킨십 · 수락

**V03-SAKUYA-STRANGER-PC-NEXT_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……손은 낯설지 않은데 얼굴은 아직 어렵군요.」{name}는 손가락을 포갰다가 눈을 내렸다.

**V03-SAKUYA-STRANGER-PC-NEXT_TOUCH_ALLOW-B · 대사 → 짧은 지문**

{name}「……당신 계신 곳은 먼저 찾게 됩니다.」{name}는 손가락을 포갰다가 눈을 내렸다.

#### 다음 만남 · 스킨십 · 거절

**V03-SAKUYA-STRANGER-PC-NEXT_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「……제가 다가섰어도 잠시만 기다려 주십시오.」{name}는 내밀려던 손을 거두고 반걸음 물러났다.

**V03-SAKUYA-STRANGER-PC-NEXT_TOUCH_REFUSE-B · 지문만**

{name}는 가까이 섰다가 뒤늦게 뻗은 손을 피하며 반걸음 물러났다.

#### 다음 만남 · 키스 · 수락

**V03-SAKUYA-STRANGER-PC-NEXT_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……그분 앞보다 쉽게 눈을 감게 되는군요.」{name}는 먼저 고개를 들었다가 눈을 내렸다.

**V03-SAKUYA-STRANGER-PC-NEXT_KISS_ALLOW-B · 대사 → 짧은 지문**

{name}「……당신 계신 곳은 먼저 찾게 됩니다.」{name}는 먼저 고개를 들었다가 눈을 내렸다.

#### 다음 만남 · 키스 · 거절

**V03-SAKUYA-STRANGER-PC-NEXT_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「……대답을 서두르려 했군요. 지금은 사양하겠습니다.」{name}는 고개를 들려다 말고 손끝으로 막았다.

**V03-SAKUYA-STRANGER-PC-NEXT_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「……당신 계신 곳은 먼저 찾게 됩니다.」{name}는 고개를 들려다 말고 손끝으로 막았다.

#### 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-SAKUYA-STRANGER-PC-LATE_TALK-A · 대사 → 짧은 지문**

{name}「……또 당신 계신 곳에 먼저 왔습니다.」{name}는 옆에 서려다 말고 앞치마를 폈다.

**V03-SAKUYA-STRANGER-PC-LATE_TALK-B · 대사 → 짧은 지문**

{name}「……또 당신께 먼저 왔군요.」{name}는 옆에 서려다 말고 앞치마를 폈다.

#### 시간이 지난 뒤 · 스킨십 · 수락

**V03-SAKUYA-STRANGER-PC-LATE_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……성함보다 먼저 손을 알아보겠군요.」{name}는 먼저 포갠 손에서 눈을 떼지 못했다.

**V03-SAKUYA-STRANGER-PC-LATE_TOUCH_ALLOW-B · 대사 → 짧은 지문**

{name}「……또 당신께 먼저 왔군요.」{name}는 먼저 포갠 손에서 눈을 떼지 못했다.

#### 시간이 지난 뒤 · 스킨십 · 거절

**V03-SAKUYA-STRANGER-PC-LATE_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「……오늘은 떨어져서 이야기하겠습니다.」{name}는 내밀었던 손을 등 뒤로 거뒀다.

**V03-SAKUYA-STRANGER-PC-LATE_TOUCH_REFUSE-B · 대사 → 짧은 지문**

{name}「……또 당신께 먼저 왔군요.」{name}는 내밀었던 손을 등 뒤로 거뒀다.

#### 시간이 지난 뒤 · 키스 · 수락

**V03-SAKUYA-STRANGER-PC-LATE_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……눈부터 감았군요. 여쭐 말씀은 많았는데요.」{name}는 먼저 감은 눈을 뜨고 자세를 고쳤다.

**V03-SAKUYA-STRANGER-PC-LATE_KISS_ALLOW-B · 지문만**

{name}는 가까이 섰다가 뒤늦게 입술이 떨어지자 자세를 고쳤다.

#### 시간이 지난 뒤 · 키스 · 거절

**V03-SAKUYA-STRANGER-PC-LATE_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「……이 거리만 익숙해져서는 곤란하겠지요.」{name}는 고개를 들려다 멈추고 몸을 비켰다.

**V03-SAKUYA-STRANGER-PC-LATE_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「……또 당신께 먼저 왔군요.」{name}는 고개를 들려다 멈추고 몸을 비켰다.

### 몸: 미정

#### 직후 · 관계 직후 · 해당 없음

**V03-SAKUYA-STRANGER-UNSET-AFTER-A · 대사 → 짧은 지문**

{name}「……그분께 당신을 어떻게 설명할까요.」{name}는 반듯한 소매를 다시 한 번 폈다.

**V03-SAKUYA-STRANGER-UNSET-AFTER-B · 대사 → 짧은 지문**

{name}「그분께 설명드리려니 성함부터 떠오릅니다.」{name}는 반듯한 소매를 다시 한 번 폈다.

#### 다음 만남 · 대화하기 · 해당 없음

**V03-SAKUYA-STRANGER-UNSET-NEXT_TALK-A · 대사 → 짧은 지문**

{name}「당신 이야기도 듣고 싶습니다. 아직 모르는 것이 많군요.」{name}는 하던 손놀림을 멈추고 눈을 내렸다.

**V03-SAKUYA-STRANGER-UNSET-NEXT_TALK-B · 지문만**

{name}는 한 걸음 떨어진 채 하던 일을 조용히 다시 시작했다.

#### 다음 만남 · 스킨십 · 수락

**V03-SAKUYA-STRANGER-UNSET-NEXT_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……잠깐이라면요. 원래 가까웠던 것처럼 굴지는 마세요.」{name}는 손을 빼지 않고 자세만 고쳤다.

**V03-SAKUYA-STRANGER-UNSET-NEXT_TOUCH_ALLOW-B · 대사 → 짧은 지문**

{name}「서로 여쭐 말씀이 많은 사이였지요, 아직은.」{name}는 손을 빼지 않고 자세만 고쳤다.

#### 다음 만남 · 스킨십 · 거절

**V03-SAKUYA-STRANGER-UNSET-NEXT_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「아직 모든 것이 괜찮아진 것은 아닙니다.」{name}는 손을 피하고 등 뒤로 모았다.

**V03-SAKUYA-STRANGER-UNSET-NEXT_TOUCH_REFUSE-B · 지문만**

{name}는 한 걸음 떨어진 채 뻗은 손을 피하며 반걸음 물러났다.

#### 다음 만남 · 키스 · 수락

**V03-SAKUYA-STRANGER-UNSET-NEXT_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……당신께는 어떤 뜻입니까.」{name}는 입술이 떨어지자 앞치마 끈을 쥐었다.

**V03-SAKUYA-STRANGER-UNSET-NEXT_KISS_ALLOW-B · 대사 → 짧은 지문**

{name}「서로 여쭐 말씀이 많은 사이였지요, 아직은.」{name}는 입술이 떨어지자 앞치마 끈을 쥐었다.

#### 다음 만남 · 키스 · 거절

**V03-SAKUYA-STRANGER-UNSET-NEXT_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「먼저 이야기하시지요. 서로 모르는 것이 많으니까요.」{name}는 얼굴을 돌리고 한 걸음 물러났다.

**V03-SAKUYA-STRANGER-UNSET-NEXT_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「서로 여쭐 말씀이 많은 사이였지요, 아직은.」{name}는 얼굴을 돌리고 한 걸음 물러났다.

#### 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-SAKUYA-STRANGER-UNSET-LATE_TALK-A · 대사 → 짧은 지문**

{name}「당신을 조금 알게 되었군요. 그분께는 말도 못 드렸지만요.」{name}는 대답 뒤에 하던 일로 눈을 돌렸다.

**V03-SAKUYA-STRANGER-UNSET-LATE_TALK-B · 대사 → 짧은 지문**

{name}「당신을 조금 알겠습니다. 그분께는 말도 못 했지만요.」{name}는 대답 뒤에 하던 일로 눈을 돌렸다.

#### 시간이 지난 뒤 · 스킨십 · 수락

**V03-SAKUYA-STRANGER-UNSET-LATE_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……오늘은 괜찮습니다. 오늘은요.」{name}는 잡힌 손을 보다가 자세를 바로 했다.

**V03-SAKUYA-STRANGER-UNSET-LATE_TOUCH_ALLOW-B · 대사 → 짧은 지문**

{name}「당신을 조금 알겠습니다. 그분께는 말도 못 했지만요.」{name}는 잡힌 손을 보다가 자세를 바로 했다.

#### 시간이 지난 뒤 · 스킨십 · 거절

**V03-SAKUYA-STRANGER-UNSET-LATE_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「자주 뵙는다고 늘 괜찮은 것은 아닙니다.」{name}는 손을 받지 않고 반걸음 비켰다.

**V03-SAKUYA-STRANGER-UNSET-LATE_TOUCH_REFUSE-B · 대사 → 짧은 지문**

{name}「당신을 조금 알겠습니다. 그분께는 말도 못 했지만요.」{name}는 손을 받지 않고 반걸음 비켰다.

#### 시간이 지난 뒤 · 키스 · 수락

**V03-SAKUYA-STRANGER-UNSET-LATE_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……우리를 어떤 사이라고 설명하시겠습니까.」{name}는 입술이 떨어지자 머리띠를 매만졌다.

**V03-SAKUYA-STRANGER-UNSET-LATE_KISS_ALLOW-B · 지문만**

{name}는 한 걸음 떨어진 채 입술이 떨어지자 자세를 고쳤다.

#### 시간이 지난 뒤 · 키스 · 거절

**V03-SAKUYA-STRANGER-UNSET-LATE_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「당신 마음부터 들려주십시오. 그분께 할 말도 남았습니다.」{name}는 손끝으로 막은 채 시선을 내렸다.

**V03-SAKUYA-STRANGER-UNSET-LATE_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「당신을 조금 알겠습니다. 그분께는 말도 못 했지만요.」{name}는 손끝으로 막은 채 시선을 내렸다.

## 짝사랑

### 몸: 주인공쪽

#### 직후 · 관계 직후 · 해당 없음

**V03-SAKUYA-CRUSH-PC-AFTER-A · 대사 → 짧은 지문**

{name}「……기쁜 얼굴이었습니까. 그분 생각도 못 하고요.」{name}는 머리띠를 집고도 곁을 떠나지 않았다.

**V03-SAKUYA-CRUSH-PC-AFTER-B · 대사 → 짧은 지문**

{name}「……기쁜 얼굴이었습니까. 부끄럽군요.」{name}는 머리띠를 집고도 곁을 떠나지 않았다.

#### 다음 만남 · 대화하기 · 해당 없음

**V03-SAKUYA-CRUSH-PC-NEXT_TALK-A · 대사 → 짧은 지문**

{name}「……기다렸습니다. 차를 더 준비했다는 말씀입니다.」{name}는 다가서다 멈추고 앞치마를 매만졌다.

**V03-SAKUYA-CRUSH-PC-NEXT_TALK-B · 지문만**

{name}는 반가운 기색을 감추고 하던 일을 조용히 다시 시작했다.

#### 다음 만남 · 스킨십 · 수락

**V03-SAKUYA-CRUSH-PC-NEXT_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……놓지 말아 주십시오. 제가 먼저 말씀드렸군요.」{name}는 손가락을 포갰다가 눈을 내렸다.

**V03-SAKUYA-CRUSH-PC-NEXT_TOUCH_ALLOW-B · 지문만**

{name}는 반가운 기색을 감추고 빈손으로 앞치마 끝을 매만졌다.

#### 다음 만남 · 스킨십 · 거절

**V03-SAKUYA-CRUSH-PC-NEXT_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「……손을 잡으면 여쭈려던 말을 놓칠 것 같습니다.」{name}는 내밀려던 손을 거두고 반걸음 물러났다.

**V03-SAKUYA-CRUSH-PC-NEXT_TOUCH_REFUSE-B · 대사 → 짧은 지문**

{name}「……차가 두 잔인 것은 보지 마십시오.」{name}는 내밀려던 손을 거두고 반걸음 물러났다.

#### 다음 만남 · 키스 · 수락

**V03-SAKUYA-CRUSH-PC-NEXT_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……저도 기다렸다고 말씀드려도 되겠습니까.」{name}는 먼저 고개를 들었다가 눈을 내렸다.

**V03-SAKUYA-CRUSH-PC-NEXT_KISS_ALLOW-B · 대사 → 짧은 지문**

{name}「……차가 두 잔인 것은 보지 마십시오.」{name}는 먼저 고개를 들었다가 눈을 내렸다.

#### 다음 만남 · 키스 · 거절

**V03-SAKUYA-CRUSH-PC-NEXT_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「……오늘은 말씀으로 먼저 듣고 싶습니다.」{name}는 고개를 들려다 말고 손끝으로 막았다.

**V03-SAKUYA-CRUSH-PC-NEXT_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「……차가 두 잔인 것은 보지 마십시오.」{name}는 고개를 들려다 말고 손끝으로 막았다.

#### 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-SAKUYA-CRUSH-PC-LATE_TALK-A · 대사 → 짧은 지문**

{name}「……차가 식어도 당신을 기다리고 있었습니다.」{name}는 옆에 서려다 말고 앞치마를 폈다.

**V03-SAKUYA-CRUSH-PC-LATE_TALK-B · 대사 → 짧은 지문**

{name}「……당신 발소리면 손이 먼저 멈추는군요.」{name}는 옆에 서려다 말고 앞치마를 폈다.

#### 시간이 지난 뒤 · 스킨십 · 수락

**V03-SAKUYA-CRUSH-PC-LATE_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……제가 먼저 손을 내밀었습니다. 부끄럽군요.」{name}는 먼저 포갠 손에서 눈을 떼지 못했다.

**V03-SAKUYA-CRUSH-PC-LATE_TOUCH_ALLOW-B · 대사 → 짧은 지문**

{name}「……당신 발소리면 손이 먼저 멈추는군요.」{name}는 먼저 포갠 손에서 눈을 떼지 못했다.

#### 시간이 지난 뒤 · 스킨십 · 거절

**V03-SAKUYA-CRUSH-PC-LATE_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「……기대면 좋은 말씀만 기다리게 되더군요.」{name}는 내밀었던 손을 등 뒤로 거뒀다.

**V03-SAKUYA-CRUSH-PC-LATE_TOUCH_REFUSE-B · 대사 → 짧은 지문**

{name}「……당신 발소리면 손이 먼저 멈추는군요.」{name}는 내밀었던 손을 등 뒤로 거뒀다.

#### 시간이 지난 뒤 · 키스 · 수락

**V03-SAKUYA-CRUSH-PC-LATE_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……당신을 기다리려고 그분께 늦는다고 했습니다.」{name}는 먼저 감은 눈을 뜨고 자세를 고쳤다.

**V03-SAKUYA-CRUSH-PC-LATE_KISS_ALLOW-B · 지문만**

{name}는 반가운 기색을 감추고 입술이 떨어지자 자세를 고쳤다.

#### 시간이 지난 뒤 · 키스 · 거절

**V03-SAKUYA-CRUSH-PC-LATE_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「……다가오시면 다시 여쭙지 못하겠습니다.」{name}는 고개를 들려다 멈추고 몸을 비켰다.

**V03-SAKUYA-CRUSH-PC-LATE_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「……당신 발소리면 손이 먼저 멈추는군요.」{name}는 고개를 들려다 멈추고 몸을 비켰다.

### 몸: 미정

#### 직후 · 관계 직후 · 해당 없음

**V03-SAKUYA-CRUSH-UNSET-AFTER-A · 대사 → 짧은 지문**

{name}「……기뻤습니다. 그 사실이 죄송하군요.」{name}는 반듯한 소매를 다시 한 번 폈다.

**V03-SAKUYA-CRUSH-UNSET-AFTER-B · 대사 → 짧은 지문**

{name}「그분 생각보다 기쁘다는 생각이 먼저였습니다.」{name}는 반듯한 소매를 다시 한 번 폈다.

#### 다음 만남 · 대화하기 · 해당 없음

**V03-SAKUYA-CRUSH-UNSET-NEXT_TALK-A · 대사 → 짧은 지문**

{name}「그분 말씀을 들으며 당신 목소리를 기다렸습니다.」{name}는 하던 손놀림을 멈추고 눈을 내렸다.

**V03-SAKUYA-CRUSH-UNSET-NEXT_TALK-B · 지문만**

{name}는 귀가 붉어진 채로 하던 일을 조용히 다시 시작했다.

#### 다음 만남 · 스킨십 · 수락

**V03-SAKUYA-CRUSH-UNSET-NEXT_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……기쁜 얼굴을 감추기가 어렵습니다.」{name}는 손을 빼지 않고 자세만 고쳤다.

**V03-SAKUYA-CRUSH-UNSET-NEXT_TOUCH_ALLOW-B · 지문만**

{name}는 귀가 붉어진 채로 빈손으로 앞치마 끝을 매만졌다.

#### 다음 만남 · 스킨십 · 거절

**V03-SAKUYA-CRUSH-UNSET-NEXT_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「좋아하기에 더 쉽게 대답할 수 없군요.」{name}는 손을 피하고 등 뒤로 모았다.

**V03-SAKUYA-CRUSH-UNSET-NEXT_TOUCH_REFUSE-B · 대사 → 짧은 지문**

{name}「당신을 기다렸다는 말은 그분께 못 드렸습니다.」{name}는 손을 피하고 등 뒤로 모았다.

#### 다음 만남 · 키스 · 수락

**V03-SAKUYA-CRUSH-UNSET-NEXT_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……당신께도 같은 뜻이겠습니까.」{name}는 입술이 떨어지자 앞치마 끈을 쥐었다.

**V03-SAKUYA-CRUSH-UNSET-NEXT_KISS_ALLOW-B · 대사 → 짧은 지문**

{name}「당신을 기다렸다는 말은 그분께 못 드렸습니다.」{name}는 입술이 떨어지자 앞치마 끈을 쥐었다.

#### 다음 만남 · 키스 · 거절

**V03-SAKUYA-CRUSH-UNSET-NEXT_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「제 마음은 아시겠지요. ……당신께서는요?」{name}는 얼굴을 돌리고 한 걸음 물러났다.

**V03-SAKUYA-CRUSH-UNSET-NEXT_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「당신을 기다렸다는 말은 그분께 못 드렸습니다.」{name}는 얼굴을 돌리고 한 걸음 물러났다.

#### 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-SAKUYA-CRUSH-UNSET-LATE_TALK-A · 대사 → 짧은 지문**

{name}「아직 당신만 기다리는군요. 그분께는 죄송하지만요.」{name}는 대답 뒤에 하던 일로 눈을 돌렸다.

**V03-SAKUYA-CRUSH-UNSET-LATE_TALK-B · 대사 → 짧은 지문**

{name}「혼자 기대하는 것은 그만하고 싶습니다.」{name}는 대답 뒤에 하던 일로 눈을 돌렸다.

#### 시간이 지난 뒤 · 스킨십 · 수락

**V03-SAKUYA-CRUSH-UNSET-LATE_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……좋아하는 마음을 숨기기 어렵습니다.」{name}는 잡힌 손을 보다가 자세를 바로 했다.

**V03-SAKUYA-CRUSH-UNSET-LATE_TOUCH_ALLOW-B · 대사 → 짧은 지문**

{name}「혼자 기대하는 것은 그만하고 싶습니다.」{name}는 잡힌 손을 보다가 자세를 바로 했다.

#### 시간이 지난 뒤 · 스킨십 · 거절

**V03-SAKUYA-CRUSH-UNSET-LATE_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「먼저 이야기를 들려주시겠습니까.」{name}는 손을 받지 않고 반걸음 비켰다.

**V03-SAKUYA-CRUSH-UNSET-LATE_TOUCH_REFUSE-B · 대사 → 짧은 지문**

{name}「혼자 기대하는 것은 그만하고 싶습니다.」{name}는 손을 받지 않고 반걸음 비켰다.

#### 시간이 지난 뒤 · 키스 · 수락

**V03-SAKUYA-CRUSH-UNSET-LATE_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……제 마음만 아시는 것은 조금 치사하군요.」{name}는 입술이 떨어지자 머리띠를 매만졌다.

**V03-SAKUYA-CRUSH-UNSET-LATE_KISS_ALLOW-B · 지문만**

{name}는 귀가 붉어진 채로 입술이 떨어지자 자세를 고쳤다.

#### 시간이 지난 뒤 · 키스 · 거절

**V03-SAKUYA-CRUSH-UNSET-LATE_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「혼자 기대하고 싶지는 않습니다. 대답해 주시겠습니까.」{name}는 손끝으로 막은 채 시선을 내렸다.

**V03-SAKUYA-CRUSH-UNSET-LATE_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「혼자 기대하는 것은 그만하고 싶습니다.」{name}는 손끝으로 막은 채 시선을 내렸다.

## 굴복

### 몸: 주인공쪽

#### 직후 · 관계 직후 · 해당 없음

**V03-SAKUYA-SUBMIT-PC-AFTER-A · 대사 → 짧은 지문**

{name}「……부르시지 않아도 다시 올 것 같군요.」{name}는 머리띠를 쥔 채 곁에 머물렀다.

**V03-SAKUYA-SUBMIT-PC-AFTER-B · 대사 → 짧은 지문**

{name}「……조금 더 곁에 있겠습니다.」{name}는 머리띠를 쥔 채 곁에 머물렀다.

#### 다음 만남 · 대화하기 · 해당 없음

**V03-SAKUYA-SUBMIT-PC-NEXT_TALK-A · 대사 → 짧은 지문**

{name}「……부르시기 전에 와 버렸습니다.」{name}는 먼저 돌아보다 머리띠를 매만졌다.

**V03-SAKUYA-SUBMIT-PC-NEXT_TALK-B · 지문만**

{name}는 부르기 전에 고개를 들고 하던 일을 조용히 다시 시작했다.

#### 다음 만남 · 스킨십 · 수락

**V03-SAKUYA-SUBMIT-PC-NEXT_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……손을 빼는 쪽이 낯설어졌군요.」{name}는 잡힌 손을 확인하고 자세를 바로 했다.

**V03-SAKUYA-SUBMIT-PC-NEXT_TOUCH_ALLOW-B · 지문만**

{name}는 부르기 전에 고개를 들고 빈손으로 앞치마 끝을 매만졌다.

#### 다음 만남 · 스킨십 · 거절

**V03-SAKUYA-SUBMIT-PC-NEXT_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「……곁에 왔어도 오늘은 사양하겠습니다.」{name}는 내밀려던 손을 거두고 반걸음 물러났다.

**V03-SAKUYA-SUBMIT-PC-NEXT_TOUCH_REFUSE-B · 대사 → 짧은 지문**

{name}「……부르시기 전에 와 있었습니다.」{name}는 내밀려던 손을 거두고 반걸음 물러났다.

#### 다음 만남 · 키스 · 수락

**V03-SAKUYA-SUBMIT-PC-NEXT_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……먼저 눈을 감았군요. 제가요.」{name}는 끝난 뒤 앞치마 끝을 다시 폈다.

**V03-SAKUYA-SUBMIT-PC-NEXT_KISS_ALLOW-B · 대사 → 짧은 지문**

{name}「……부르시기 전에 와 있었습니다.」{name}는 끝난 뒤 앞치마 끝을 다시 폈다.

#### 다음 만남 · 키스 · 거절

**V03-SAKUYA-SUBMIT-PC-NEXT_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「……기다린 것처럼 보여도 오늘은 아닙니다.」{name}는 고개를 들려다 말고 손끝으로 막았다.

**V03-SAKUYA-SUBMIT-PC-NEXT_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「……부르시기 전에 와 있었습니다.」{name}는 고개를 들려다 말고 손끝으로 막았다.

#### 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-SAKUYA-SUBMIT-PC-LATE_TALK-A · 대사 → 짧은 지문**

{name}「……또 당신께 먼저 왔습니다. 그분께는 바쁘다고 하고요.」{name}는 먼저 돌아보다 머리띠를 매만졌다.

**V03-SAKUYA-SUBMIT-PC-LATE_TALK-B · 대사 → 짧은 지문**

{name}「……자리를 먼저 비워 두었군요.」{name}는 먼저 돌아보다 머리띠를 매만졌다.

#### 시간이 지난 뒤 · 스킨십 · 수락

**V03-SAKUYA-SUBMIT-PC-LATE_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……손이 먼저 움직였군요. 실례했습니다.」{name}는 잡힌 손을 확인하고 자세를 바로 했다.

**V03-SAKUYA-SUBMIT-PC-LATE_TOUCH_ALLOW-B · 대사 → 짧은 지문**

{name}「……자리를 먼저 비워 두었군요.」{name}는 잡힌 손을 확인하고 자세를 바로 했다.

#### 시간이 지난 뒤 · 스킨십 · 거절

**V03-SAKUYA-SUBMIT-PC-LATE_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「……오늘은 손을 거두고 싶습니다.」{name}는 내밀었던 손을 등 뒤로 거뒀다.

**V03-SAKUYA-SUBMIT-PC-LATE_TOUCH_REFUSE-B · 대사 → 짧은 지문**

{name}「……자리를 먼저 비워 두었군요.」{name}는 내밀었던 손을 등 뒤로 거뒀다.

#### 시간이 지난 뒤 · 키스 · 수락

**V03-SAKUYA-SUBMIT-PC-LATE_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……그분을 떠올리기도 전에 눈을 감았군요.」{name}는 끝난 뒤 앞치마 끝을 다시 폈다.

**V03-SAKUYA-SUBMIT-PC-LATE_KISS_ALLOW-B · 지문만**

{name}는 부르기 전에 고개를 들고 입술이 떨어지자 자세를 고쳤다.

#### 시간이 지난 뒤 · 키스 · 거절

**V03-SAKUYA-SUBMIT-PC-LATE_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「……곁에 남았어도 지금은 원하지 않습니다.」{name}는 고개를 들려다 멈추고 몸을 비켰다.

**V03-SAKUYA-SUBMIT-PC-LATE_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「……자리를 먼저 비워 두었군요.」{name}는 고개를 들려다 멈추고 몸을 비켰다.

### 몸: 미정

#### 직후 · 관계 직후 · 해당 없음

**V03-SAKUYA-SUBMIT-UNSET-AFTER-A · 대사 → 짧은 지문**

{name}「……이제 돌아가도 되겠습니까.」{name}는 앞치마를 꼭 쥐고 눈을 내렸다.

**V03-SAKUYA-SUBMIT-UNSET-AFTER-B · 대사 → 짧은 지문**

{name}「그분 앞에서는 평소대로 하겠습니다.」{name}는 앞치마를 꼭 쥐고 눈을 내렸다.

#### 다음 만남 · 대화하기 · 해당 없음

**V03-SAKUYA-SUBMIT-UNSET-NEXT_TALK-A · 대사 → 짧은 지문**

{name}「그분께는 평소처럼 일한다고 말씀드렸습니다.」{name}는 짧게 답하고 앞치마를 폈다.

**V03-SAKUYA-SUBMIT-UNSET-NEXT_TALK-B · 지문만**

{name}는 다음 말을 기다리듯 하던 일을 조용히 다시 시작했다.

#### 다음 만남 · 스킨십 · 수락

**V03-SAKUYA-SUBMIT-UNSET-NEXT_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……이대로 두겠습니다.」{name}는 손은 그대로 두고 앞치마를 쥐었다.

**V03-SAKUYA-SUBMIT-UNSET-NEXT_TOUCH_ALLOW-B · 지문만**

{name}는 다음 말을 기다리듯 빈손으로 앞치마 끝을 매만졌다.

#### 다음 만남 · 스킨십 · 거절

**V03-SAKUYA-SUBMIT-UNSET-NEXT_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「……잠시만 손을 거두어 주십시오.」{name}는 손을 피하고 등 뒤로 모았다.

**V03-SAKUYA-SUBMIT-UNSET-NEXT_TOUCH_REFUSE-B · 대사 → 짧은 지문**

{name}「그분께는 괜찮다고 말씀드렸습니다.」{name}는 손을 피하고 등 뒤로 모았다.

#### 다음 만남 · 키스 · 수락

**V03-SAKUYA-SUBMIT-UNSET-NEXT_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……끝나셨습니까. 돌아갈 시간이군요.」{name}는 입술이 떨어지자 눈을 내렸다.

**V03-SAKUYA-SUBMIT-UNSET-NEXT_KISS_ALLOW-B · 대사 → 짧은 지문**

{name}「그분께는 괜찮다고 말씀드렸습니다.」{name}는 입술이 떨어지자 눈을 내렸다.

#### 다음 만남 · 키스 · 거절

**V03-SAKUYA-SUBMIT-UNSET-NEXT_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「……싫습니다. 작게 말씀드려도 들어 주십시오.」{name}는 얼굴을 돌리고 한 걸음 물러났다.

**V03-SAKUYA-SUBMIT-UNSET-NEXT_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「그분께는 괜찮다고 말씀드렸습니다.」{name}는 얼굴을 돌리고 한 걸음 물러났다.

#### 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-SAKUYA-SUBMIT-UNSET-LATE_TALK-A · 대사 → 짧은 지문**

{name}「그분 앞에서는 평소처럼 했습니다. 칭찬하지는 마세요.」{name}는 짧게 답하고 앞치마를 폈다.

**V03-SAKUYA-SUBMIT-UNSET-LATE_TALK-B · 대사 → 짧은 지문**

{name}「그분께서 일을 칭찬하셔도 고개를 못 들었습니다.」{name}는 짧게 답하고 앞치마를 폈다.

#### 시간이 지난 뒤 · 스킨십 · 수락

**V03-SAKUYA-SUBMIT-UNSET-LATE_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……그분 앞에서는 조심하겠습니다.」{name}는 손은 그대로 두고 앞치마를 쥐었다.

**V03-SAKUYA-SUBMIT-UNSET-LATE_TOUCH_ALLOW-B · 대사 → 짧은 지문**

{name}「그분께서 일을 칭찬하셔도 고개를 못 들었습니다.」{name}는 손은 그대로 두고 앞치마를 쥐었다.

#### 시간이 지난 뒤 · 스킨십 · 거절

**V03-SAKUYA-SUBMIT-UNSET-LATE_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「늘 그대로 있었다고 오늘도 같지는 않습니다.」{name}는 손을 받지 않고 반걸음 비켰다.

**V03-SAKUYA-SUBMIT-UNSET-LATE_TOUCH_REFUSE-B · 대사 → 짧은 지문**

{name}「그분께서 일을 칭찬하셔도 고개를 못 들었습니다.」{name}는 손을 받지 않고 반걸음 비켰다.

#### 시간이 지난 뒤 · 키스 · 수락

**V03-SAKUYA-SUBMIT-UNSET-LATE_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……끝나셨다면 말씀해 주십시오.」{name}는 입술이 떨어지자 눈을 내렸다.

**V03-SAKUYA-SUBMIT-UNSET-LATE_KISS_ALLOW-B · 지문만**

{name}는 다음 말을 기다리듯 입술이 떨어지자 자세를 고쳤다.

#### 시간이 지난 뒤 · 키스 · 거절

**V03-SAKUYA-SUBMIT-UNSET-LATE_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「오늘은 사양하겠습니다. ……변명도 필요합니까.」{name}는 손끝으로 막은 채 시선을 내렸다.

**V03-SAKUYA-SUBMIT-UNSET-LATE_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「그분께서 일을 칭찬하셔도 고개를 못 들었습니다.」{name}는 손끝으로 막은 채 시선을 내렸다.

## 협박

### 몸: 주인공쪽

#### 직후 · 관계 직후 · 해당 없음

**V03-SAKUYA-COERCED-PC-AFTER-A · 대사 → 짧은 지문**

{name}「……곁에 있으면 하실 말씀을 먼저 알 수 있겠군요.」{name}는 머리띠를 쥔 채 곁에 머물렀다.

**V03-SAKUYA-COERCED-PC-AFTER-B · 대사 → 짧은 지문**

{name}「……곁에 있으면 하실 말씀은 먼저 알겠군요.」{name}는 머리띠를 쥔 채 곁에 머물렀다.

#### 다음 만남 · 대화하기 · 해당 없음

**V03-SAKUYA-COERCED-PC-NEXT_TALK-A · 대사 → 짧은 지문**

{name}「……부르실까 봐 듣고 있었습니다.」{name}는 먼저 돌아보다 머리띠를 매만졌다.

**V03-SAKUYA-COERCED-PC-NEXT_TALK-B · 지문만**

{name}는 이쪽 표정을 먼저 살피고 하던 일을 조용히 다시 시작했다.

#### 다음 만남 · 스킨십 · 수락

**V03-SAKUYA-COERCED-PC-NEXT_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……이대로 두겠습니다. 그분께는 말씀하지 마세요.」{name}는 잡힌 손을 확인하고 자세를 바로 했다.

**V03-SAKUYA-COERCED-PC-NEXT_TOUCH_ALLOW-B · 대사 → 짧은 지문**

{name}「……부르실까 봐 듣고 있었습니다.」{name}는 잡힌 손을 확인하고 자세를 바로 했다.

#### 다음 만남 · 스킨십 · 거절

**V03-SAKUYA-COERCED-PC-NEXT_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「……곁에 있어도 안심한 것은 아닙니다.」{name}는 내밀려던 손을 거두고 반걸음 물러났다.

**V03-SAKUYA-COERCED-PC-NEXT_TOUCH_REFUSE-B · 지문만**

{name}는 이쪽 표정을 먼저 살피고 뻗은 손을 피하며 반걸음 물러났다.

#### 다음 만남 · 키스 · 수락

**V03-SAKUYA-COERCED-PC-NEXT_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……그분께 말씀하지 않는다는 약속부터 해 주십시오.」{name}는 끝난 뒤 앞치마 끝을 다시 폈다.

**V03-SAKUYA-COERCED-PC-NEXT_KISS_ALLOW-B · 대사 → 짧은 지문**

{name}「……부르실까 봐 듣고 있었습니다.」{name}는 끝난 뒤 앞치마 끝을 다시 폈다.

#### 다음 만남 · 키스 · 거절

**V03-SAKUYA-COERCED-PC-NEXT_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「……제가 물러나지 않을 줄 아셨습니까.」{name}는 고개를 들려다 말고 손끝으로 막았다.

**V03-SAKUYA-COERCED-PC-NEXT_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「……부르실까 봐 듣고 있었습니다.」{name}는 고개를 들려다 말고 손끝으로 막았다.

#### 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-SAKUYA-COERCED-PC-LATE_TALK-A · 대사 → 짧은 지문**

{name}「……당신 계신 곳을 먼저 확인하게 됩니다.」{name}는 먼저 돌아보다 머리띠를 매만졌다.

**V03-SAKUYA-COERCED-PC-LATE_TALK-B · 대사 → 짧은 지문**

{name}「……당신의 표정부터 살피는군요.」{name}는 먼저 돌아보다 머리띠를 매만졌다.

#### 시간이 지난 뒤 · 스킨십 · 수락

**V03-SAKUYA-COERCED-PC-LATE_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……익숙하게 보이도록은 하겠습니다.」{name}는 잡힌 손을 확인하고 자세를 바로 했다.

**V03-SAKUYA-COERCED-PC-LATE_TOUCH_ALLOW-B · 대사 → 짧은 지문**

{name}「……당신의 표정부터 살피는군요.」{name}는 잡힌 손을 확인하고 자세를 바로 했다.

#### 시간이 지난 뒤 · 스킨십 · 거절

**V03-SAKUYA-COERCED-PC-LATE_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「……오늘은 손을 거두겠습니다. 지금이라도요.」{name}는 내밀었던 손을 등 뒤로 거뒀다.

**V03-SAKUYA-COERCED-PC-LATE_TOUCH_REFUSE-B · 대사 → 짧은 지문**

{name}「……당신의 표정부터 살피는군요.」{name}는 내밀었던 손을 등 뒤로 거뒀다.

#### 시간이 지난 뒤 · 키스 · 수락

**V03-SAKUYA-COERCED-PC-LATE_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……먼저 눈을 감는군요. 저도 참.」{name}는 끝난 뒤 앞치마 끝을 다시 폈다.

**V03-SAKUYA-COERCED-PC-LATE_KISS_ALLOW-B · 지문만**

{name}는 이쪽 표정을 먼저 살피고 입술이 떨어지자 자세를 고쳤다.

#### 시간이 지난 뒤 · 키스 · 거절

**V03-SAKUYA-COERCED-PC-LATE_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「……익숙해져도 오늘의 의사는 다릅니다.」{name}는 고개를 들려다 멈추고 몸을 비켰다.

**V03-SAKUYA-COERCED-PC-LATE_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「……당신의 표정부터 살피는군요.」{name}는 고개를 들려다 멈추고 몸을 비켰다.

### 몸: 미정

#### 직후 · 관계 직후 · 해당 없음

**V03-SAKUYA-COERCED-UNSET-AFTER-A · 대사 → 짧은 지문**

{name}「……그분께는 말씀하지 않으시겠지요.」{name}는 앞치마를 꼭 쥐고 눈을 내렸다.

**V03-SAKUYA-COERCED-UNSET-AFTER-B · 대사 → 짧은 지문**

{name}「그분께만은 말씀하지 말아 주십시오.」{name}는 앞치마를 꼭 쥐고 눈을 내렸다.

#### 다음 만남 · 대화하기 · 해당 없음

**V03-SAKUYA-COERCED-UNSET-NEXT_TALK-A · 대사 → 짧은 지문**

{name}「용건만 말씀해 주십시오. 그분 이름은 빼고요.」{name}는 짧게 답하고 앞치마를 폈다.

**V03-SAKUYA-COERCED-UNSET-NEXT_TALK-B · 지문만**

{name}는 긴장한 기색을 감추며 하던 일을 조용히 다시 시작했다.

#### 다음 만남 · 스킨십 · 수락

**V03-SAKUYA-COERCED-UNSET-NEXT_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……알겠습니다. 웃으라고는 하지 말아 주세요.」{name}는 손은 그대로 두고 앞치마를 쥐었다.

**V03-SAKUYA-COERCED-UNSET-NEXT_TOUCH_ALLOW-B · 대사 → 짧은 지문**

{name}「그분 앞에서는 평소처럼 했습니다.」{name}는 손은 그대로 두고 앞치마를 쥐었다.

#### 다음 만남 · 스킨십 · 거절

**V03-SAKUYA-COERCED-UNSET-NEXT_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「사양하겠습니다. 그분 이야기로 바꾸지 마세요.」{name}는 손을 피하고 등 뒤로 모았다.

**V03-SAKUYA-COERCED-UNSET-NEXT_TOUCH_REFUSE-B · 지문만**

{name}는 긴장한 기색을 감추며 뻗은 손을 피하며 반걸음 물러났다.

#### 다음 만남 · 키스 · 수락

**V03-SAKUYA-COERCED-UNSET-NEXT_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……이제 돌아가도 되겠습니까.」{name}는 입술이 떨어지자 눈을 내렸다.

**V03-SAKUYA-COERCED-UNSET-NEXT_KISS_ALLOW-B · 대사 → 짧은 지문**

{name}「그분 앞에서는 평소처럼 했습니다.」{name}는 입술이 떨어지자 눈을 내렸다.

#### 다음 만남 · 키스 · 거절

**V03-SAKUYA-COERCED-UNSET-NEXT_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「……멈춰 주십시오. 그분께 하실 말씀과는 별개입니다.」{name}는 얼굴을 돌리고 한 걸음 물러났다.

**V03-SAKUYA-COERCED-UNSET-NEXT_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「그분 앞에서는 평소처럼 했습니다.」{name}는 얼굴을 돌리고 한 걸음 물러났다.

#### 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-SAKUYA-COERCED-UNSET-LATE_TALK-A · 대사 → 짧은 지문**

{name}「언제까지 그분 이름으로 저를 부르실 겁니까.」{name}는 짧게 답하고 앞치마를 폈다.

**V03-SAKUYA-COERCED-UNSET-LATE_TALK-B · 대사 → 짧은 지문**

{name}「숨기는 일은 익숙합니다. 안심한 것은 아닙니다.」{name}는 짧게 답하고 앞치마를 폈다.

#### 시간이 지난 뒤 · 스킨십 · 수락

**V03-SAKUYA-COERCED-UNSET-LATE_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……그분 앞에서도 이렇게 굳어 있겠군요.」{name}는 손은 그대로 두고 앞치마를 쥐었다.

**V03-SAKUYA-COERCED-UNSET-LATE_TOUCH_ALLOW-B · 대사 → 짧은 지문**

{name}「숨기는 일은 익숙합니다. 안심한 것은 아닙니다.」{name}는 손은 그대로 두고 앞치마를 쥐었다.

#### 시간이 지난 뒤 · 스킨십 · 거절

**V03-SAKUYA-COERCED-UNSET-LATE_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「그 이야기는 꺼내지 마십시오. ……원하지 않습니다.」{name}는 손을 받지 않고 반걸음 비켰다.

**V03-SAKUYA-COERCED-UNSET-LATE_TOUCH_REFUSE-B · 대사 → 짧은 지문**

{name}「숨기는 일은 익숙합니다. 안심한 것은 아닙니다.」{name}는 손을 받지 않고 반걸음 비켰다.

#### 시간이 지난 뒤 · 키스 · 수락

**V03-SAKUYA-COERCED-UNSET-LATE_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……이제 보내 주십시오. 표정을 고쳐야 합니다.」{name}는 입술이 떨어지자 눈을 내렸다.

**V03-SAKUYA-COERCED-UNSET-LATE_KISS_ALLOW-B · 지문만**

{name}는 긴장한 기색을 감추며 입술이 떨어지자 자세를 고쳤다.

#### 시간이 지난 뒤 · 키스 · 거절

**V03-SAKUYA-COERCED-UNSET-LATE_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「그분이 걱정되어도 모든 요구를 받아야 하는 건 아닙니다.」{name}는 손끝으로 막은 채 시선을 내렸다.

**V03-SAKUYA-COERCED-UNSET-LATE_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「숨기는 일은 익숙합니다. 안심한 것은 아닙니다.」{name}는 손끝으로 막은 채 시선을 내렸다.

# 코치야 사나에 — 짧은 대사·지문 검토본 v0.3.0

미적용 초안. `{name}`은 발화 앞에서는 성명, 지문에서는 짧은 이름으로 표시된다. HTML에서 이름·색상을 반영한 미리보기를 볼 수 있다.

## 싫어함

### 몸: 주인공쪽

#### 직후 · 관계 직후 · 해당 없음

**V03-SANAE-HATE-PC-AFTER-A · 대사 → 짧은 지문**

{name}「……곁이 편해졌다고 당신까지 좋아진 건 아니에요.」{name}는 곁에 남아 억지로 웃어 보였다.

**V03-SANAE-HATE-PC-AFTER-B · 대사 → 짧은 지문**

{name}「……곁이 편해진 건 저도 싫어요.」{name}는 곁에 남아 억지로 웃어 보였다.

#### 다음 만남 · 대화하기 · 해당 없음

**V03-SANAE-HATE-PC-NEXT_TALK-A · 대사 → 짧은 지문**

{name}「……또 이쪽으로 왔네요. 저도 제가 싫어요.」{name}는 먼저 돌아보고도 웃음을 삼켰다.

**V03-SANAE-HATE-PC-NEXT_TALK-B · 지문만**

{name}는 이쪽을 먼저 찾고도 자기 소매만 잡아당겼다.

#### 다음 만남 · 스킨십 · 수락

**V03-SANAE-HATE-PC-NEXT_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……손은 이대로요. 기뻐하지는 마세요.」{name}는 잡힌 손을 보고 웃으려다 말았다.

**V03-SANAE-HATE-PC-NEXT_TOUCH_ALLOW-B · 대사 → 짧은 지문**

{name}「……또 이쪽에 왔네요, 저.」{name}는 잡힌 손을 보고 웃으려다 말았다.

#### 다음 만남 · 스킨십 · 거절

**V03-SANAE-HATE-PC-NEXT_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「……가까이 왔다고 뭐든 괜찮은 건 아니에요.」{name}는 내밀던 손을 거두고 이쪽 손을 밀었다.

**V03-SANAE-HATE-PC-NEXT_TOUCH_REFUSE-B · 지문만**

{name}는 이쪽을 먼저 찾고도 뻗어 온 손을 밀어내고 고개를 저었다.

#### 다음 만남 · 키스 · 수락

**V03-SANAE-HATE-PC-NEXT_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……여기선 왜 대답이 늦어질까요, 저.」{name}는 끝난 뒤에야 뒤늦게 웃어 보였다.

**V03-SANAE-HATE-PC-NEXT_KISS_ALLOW-B · 대사 → 짧은 지문**

{name}「……또 이쪽에 왔네요, 저.」{name}는 끝난 뒤에야 뒤늦게 웃어 보였다.

#### 다음 만남 · 키스 · 거절

**V03-SANAE-HATE-PC-NEXT_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「……또 넘어갈 것 같아서 싫어요. 멈춰요.」{name}는 다가가려다 멈추고 두 손으로 막았다.

**V03-SANAE-HATE-PC-NEXT_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「……또 이쪽에 왔네요, 저.」{name}는 다가가려다 멈추고 두 손으로 막았다.

#### 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-SANAE-HATE-PC-LATE_TALK-A · 대사 → 짧은 지문**

{name}「……발소리만 듣고 알아챘네요. 싫다, 정말.」{name}는 먼저 돌아보고도 웃음을 삼켰다.

**V03-SANAE-HATE-PC-LATE_TALK-B · 대사 → 짧은 지문**

{name}「……발소리까지 알아 버렸네요.」{name}는 먼저 돌아보고도 웃음을 삼켰다.

#### 시간이 지난 뒤 · 스킨십 · 수락

**V03-SANAE-HATE-PC-LATE_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……이 손이 익숙하다고 마음까지 바뀌겠어요?」{name}는 잡힌 손을 보고 웃으려다 말았다.

**V03-SANAE-HATE-PC-LATE_TOUCH_ALLOW-B · 대사 → 짧은 지문**

{name}「……발소리까지 알아 버렸네요.」{name}는 잡힌 손을 보고 웃으려다 말았다.

#### 시간이 지난 뒤 · 스킨십 · 거절

**V03-SANAE-HATE-PC-LATE_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「……옆에 앉았어도 손은 싫어요.」{name}는 내밀었던 손을 거두고 고개를 저었다.

**V03-SANAE-HATE-PC-LATE_TOUCH_REFUSE-B · 대사 → 짧은 지문**

{name}「……발소리까지 알아 버렸네요.」{name}는 내밀었던 손을 거두고 고개를 저었다.

#### 시간이 지난 뒤 · 키스 · 수락

**V03-SANAE-HATE-PC-LATE_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……제가 먼저 눈을 감았네요. 왜 이럴까요.」{name}는 끝난 뒤에야 뒤늦게 웃어 보였다.

**V03-SANAE-HATE-PC-LATE_KISS_ALLOW-B · 지문만**

{name}는 이쪽을 먼저 찾고도 입술이 떨어지자 머리카락을 넘겼다.

#### 시간이 지난 뒤 · 키스 · 거절

**V03-SANAE-HATE-PC-LATE_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「……이걸 기다리고 있었던 건 아니에요.」{name}는 다가서던 발을 멈추고 두 손으로 막았다.

**V03-SANAE-HATE-PC-LATE_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「……발소리까지 알아 버렸네요.」{name}는 다가서던 발을 멈추고 두 손으로 막았다.

### 몸: 미정

#### 직후 · 관계 직후 · 해당 없음

**V03-SANAE-HATE-UNSET-AFTER-A · 대사 → 짧은 지문**

{name}「……그분 얼굴이 자꾸 떠올라요. 웃지 마세요.」{name}는 웃는 얼굴을 만들려다 고개를 숙였다.

**V03-SANAE-HATE-UNSET-AFTER-B · 대사 → 짧은 지문**

{name}「그분 얼굴이 자꾸 생각나요. 웃지 마세요.」{name}는 웃는 얼굴을 만들려다 고개를 숙였다.

#### 다음 만남 · 대화하기 · 해당 없음

**V03-SANAE-HATE-UNSET-NEXT_TALK-A · 대사 → 짧은 지문**

{name}「그분이 당신 얘기를 하셨어요. 대답 못 했고요.」{name}는 대답 뒤에는 소매만 잡아당겼다.

**V03-SANAE-HATE-UNSET-NEXT_TALK-B · 지문만**

{name}는 웃음기 없는 얼굴로 자기 소매만 잡아당겼다.

#### 다음 만남 · 스킨십 · 수락

**V03-SANAE-HATE-UNSET-NEXT_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……잡고 있어도 아직 싫은 건 싫어요.」{name}는 손은 그대로 두고 입술을 깨물었다.

**V03-SANAE-HATE-UNSET-NEXT_TOUCH_ALLOW-B · 대사 → 짧은 지문**

{name}「그분 얘기는 오늘 하지 말아요.」{name}는 손은 그대로 두고 입술을 깨물었다.

#### 다음 만남 · 스킨십 · 거절

**V03-SANAE-HATE-UNSET-NEXT_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「그 일 한 번으로 다 된다고 생각하셨어요?」{name}는 손을 피하고 난처하게 웃었다.

**V03-SANAE-HATE-UNSET-NEXT_TOUCH_REFUSE-B · 지문만**

{name}는 웃음기 없는 얼굴로 뻗어 온 손을 밀어내고 고개를 저었다.

#### 다음 만남 · 키스 · 수락

**V03-SANAE-HATE-UNSET-NEXT_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……그분보다 낫다는 말씀은 하지 마세요.」{name}는 입술이 떨어지자 입구 쪽을 보았다.

**V03-SANAE-HATE-UNSET-NEXT_KISS_ALLOW-B · 대사 → 짧은 지문**

{name}「그분 얘기는 오늘 하지 말아요.」{name}는 입술이 떨어지자 입구 쪽을 보았다.

#### 다음 만남 · 키스 · 거절

**V03-SANAE-HATE-UNSET-NEXT_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「안 돼요. 그분한테 숨길 일만 늘리기는 싫어요.」{name}는 얼굴을 돌리고 반걸음 물러났다.

**V03-SANAE-HATE-UNSET-NEXT_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「그분 얘기는 오늘 하지 말아요.」{name}는 얼굴을 돌리고 반걸음 물러났다.

#### 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-SANAE-HATE-UNSET-LATE_TALK-A · 대사 → 짧은 지문**

{name}「그분 앞에선 당신 이름에도 웃는 척해요.」{name}는 대답 뒤에는 소매만 잡아당겼다.

**V03-SANAE-HATE-UNSET-LATE_TALK-B · 대사 → 짧은 지문**

{name}「그분께 말 못 했다고 당신이 좋아진 건 아니에요.」{name}는 대답 뒤에는 소매만 잡아당겼다.

#### 시간이 지난 뒤 · 스킨십 · 수락

**V03-SANAE-HATE-UNSET-LATE_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……화해했다고 생각하진 마세요.」{name}는 손은 그대로 두고 입술을 깨물었다.

**V03-SANAE-HATE-UNSET-LATE_TOUCH_ALLOW-B · 대사 → 짧은 지문**

{name}「그분께 말 못 했다고 당신이 좋아진 건 아니에요.」{name}는 손은 그대로 두고 입술을 깨물었다.

#### 시간이 지난 뒤 · 스킨십 · 거절

**V03-SANAE-HATE-UNSET-LATE_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「이제 괜찮겠지, 하지는 마세요. 아직 아니에요.」{name}는 손을 피한 채 애매하게 웃었다.

**V03-SANAE-HATE-UNSET-LATE_TOUCH_REFUSE-B · 대사 → 짧은 지문**

{name}「그분께 말 못 했다고 당신이 좋아진 건 아니에요.」{name}는 손을 피한 채 애매하게 웃었다.

#### 시간이 지난 뒤 · 키스 · 수락

**V03-SANAE-HATE-UNSET-LATE_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……그분께는 아무 말씀도 못 드렸는데요.」{name}는 입술이 떨어지자 입구 쪽을 보았다.

**V03-SANAE-HATE-UNSET-LATE_KISS_ALLOW-B · 지문만**

{name}는 웃음기 없는 얼굴로 입술이 떨어지자 머리카락을 넘겼다.

#### 시간이 지난 뒤 · 키스 · 거절

**V03-SANAE-HATE-UNSET-LATE_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「그만하세요. 제 대답 아직 안 바뀌었어요.」{name}는 얼굴을 돌리고 한 발 물러났다.

**V03-SANAE-HATE-UNSET-LATE_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「그분께 말 못 했다고 당신이 좋아진 건 아니에요.」{name}는 얼굴을 돌리고 한 발 물러났다.

## 친구

### 몸: 주인공쪽

#### 직후 · 관계 직후 · 해당 없음

**V03-SANAE-FRIEND-PC-AFTER-A · 대사 → 짧은 지문**

{name}「에헤헤. ……편해서 더 큰일이네요, 우리.」{name}는 다가앉았다가 웃음을 삼켰다.

**V03-SANAE-FRIEND-PC-AFTER-B · 대사 → 짧은 지문**

{name}「에헤헤. ……편해서 더 곤란하네요.」{name}는 다가앉았다가 웃음을 삼켰다.

#### 다음 만남 · 대화하기 · 해당 없음

**V03-SANAE-FRIEND-PC-NEXT_TALK-A · 대사 → 짧은 지문**

{name}「여기 앉으세요! ……아, 너무 가까웠나요.」{name}는 옆자리를 두드리다가 손을 멈췄다.

**V03-SANAE-FRIEND-PC-NEXT_TALK-B · 지문만**

{name}는 옆으로 오려다 말고 자기 소매만 잡아당겼다.

#### 다음 만남 · 스킨십 · 수락

**V03-SANAE-FRIEND-PC-NEXT_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……친구끼리 이래도 된다고 하면 좀 나을까요.」{name}는 손을 꼭 잡았다가 웃음을 거뒀다.

**V03-SANAE-FRIEND-PC-NEXT_TOUCH_ALLOW-B · 지문만**

{name}는 옆으로 오려다 말고 잡힌 손을 내려다보고 눈을 피했다.

#### 다음 만남 · 스킨십 · 거절

**V03-SANAE-FRIEND-PC-NEXT_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「……옆에만 있어 주세요. 손은 말고요.」{name}는 내밀던 손을 거두고 이쪽 손을 밀었다.

**V03-SANAE-FRIEND-PC-NEXT_TOUCH_REFUSE-B · 대사 → 짧은 지문**

{name}「……옆자리부터 비워 뒀네요.」{name}는 내밀던 손을 거두고 이쪽 손을 밀었다.

#### 다음 만남 · 키스 · 수락

**V03-SANAE-FRIEND-PC-NEXT_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……친구라고 먼저 말하면 제가 거짓말하네요.」{name}는 먼저 눈을 감았다가 입가를 가렸다.

**V03-SANAE-FRIEND-PC-NEXT_KISS_ALLOW-B · 대사 → 짧은 지문**

{name}「……옆자리부터 비워 뒀네요.」{name}는 먼저 눈을 감았다가 입가를 가렸다.

#### 다음 만남 · 키스 · 거절

**V03-SANAE-FRIEND-PC-NEXT_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「……또 아무렇지 않게 기대 버릴 것 같아요.」{name}는 다가가려다 멈추고 두 손으로 막았다.

**V03-SANAE-FRIEND-PC-NEXT_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「……옆자리부터 비워 뒀네요.」{name}는 다가가려다 멈추고 두 손으로 막았다.

#### 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-SANAE-FRIEND-PC-LATE_TALK-A · 대사 → 짧은 지문**

{name}「……여기 앉으시라고 하려다 말았어요.」{name}는 옆에 앉자마자 시선을 내렸다.

**V03-SANAE-FRIEND-PC-LATE_TALK-B · 대사 → 짧은 지문**

{name}「……제 자리처럼 앉게 되네요.」{name}는 옆에 앉자마자 시선을 내렸다.

#### 시간이 지난 뒤 · 스킨십 · 수락

**V03-SANAE-FRIEND-PC-LATE_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……제 손이 먼저 갔네요. 친구일 때도 이랬나요?」{name}는 먼저 잡은 손을 내려다보고 웃음을 멈췄다.

**V03-SANAE-FRIEND-PC-LATE_TOUCH_ALLOW-B · 대사 → 짧은 지문**

{name}「……제 자리처럼 앉게 되네요.」{name}는 먼저 잡은 손을 내려다보고 웃음을 멈췄다.

#### 시간이 지난 뒤 · 스킨십 · 거절

**V03-SANAE-FRIEND-PC-LATE_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「……편해져서 오늘은 조금 떨어져 있고 싶어요.」{name}는 내밀었던 손을 거두고 고개를 저었다.

**V03-SANAE-FRIEND-PC-LATE_TOUCH_REFUSE-B · 대사 → 짧은 지문**

{name}「……제 자리처럼 앉게 되네요.」{name}는 내밀었던 손을 거두고 고개를 저었다.

#### 시간이 지난 뒤 · 키스 · 수락

**V03-SANAE-FRIEND-PC-LATE_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……친구라는 말로는 이제 안 되겠죠.」{name}는 먼저 눈을 감았다가 뒤늦게 고개를 숙였다.

**V03-SANAE-FRIEND-PC-LATE_KISS_ALLOW-B · 지문만**

{name}는 옆으로 오려다 말고 입술이 떨어지자 머리카락을 넘겼다.

#### 시간이 지난 뒤 · 키스 · 거절

**V03-SANAE-FRIEND-PC-LATE_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「……지금은 얘기해요. 저 또 웃고 넘길 테니까.」{name}는 다가서던 발을 멈추고 두 손으로 막았다.

**V03-SANAE-FRIEND-PC-LATE_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「……제 자리처럼 앉게 되네요.」{name}는 다가서던 발을 멈추고 두 손으로 막았다.

### 몸: 미정

#### 직후 · 관계 직후 · 해당 없음

**V03-SANAE-FRIEND-UNSET-AFTER-A · 대사 → 짧은 지문**

{name}「……친구니까 괜찮을 줄 알았어요.」{name}는 옷깃을 고치고 어색하게 웃었다.

**V03-SANAE-FRIEND-UNSET-AFTER-B · 대사 → 짧은 지문**

{name}「친구니까 괜찮다는 말이 안 나오네요.」{name}는 옷깃을 고치고 어색하게 웃었다.

#### 다음 만남 · 대화하기 · 해당 없음

**V03-SANAE-FRIEND-UNSET-NEXT_TALK-A · 대사 → 짧은 지문**

{name}「그분께도 이 얘기를…… 아, 아니에요.」{name}는 말을 꺼내다 말고 머리카락을 넘겼다.

**V03-SANAE-FRIEND-UNSET-NEXT_TALK-B · 지문만**

{name}는 화제를 바꾸려다 멈추고 자기 소매만 잡아당겼다.

#### 다음 만남 · 스킨십 · 수락

**V03-SANAE-FRIEND-UNSET-NEXT_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「에헤헤. ……그분 앞에선 이렇게 못 웃는데요.」{name}는 손을 빼지 않고 소매만 잡아당겼다.

**V03-SANAE-FRIEND-UNSET-NEXT_TOUCH_ALLOW-B · 지문만**

{name}는 화제를 바꾸려다 멈추고 잡힌 손을 내려다보고 눈을 피했다.

#### 다음 만남 · 스킨십 · 거절

**V03-SANAE-FRIEND-UNSET-NEXT_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「오늘은 이야기만 해요. 친구잖아요, 우리.」{name}는 손을 피하고 난처하게 웃었다.

**V03-SANAE-FRIEND-UNSET-NEXT_TOUCH_REFUSE-B · 대사 → 짧은 지문**

{name}「그분께도 이 얘기를…… 아뇨, 그만할게요.」{name}는 손을 피하고 난처하게 웃었다.

#### 다음 만남 · 키스 · 수락

**V03-SANAE-FRIEND-UNSET-NEXT_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「에헤헤. ……왜 하필 그분 얼굴이 생각날까요.」{name}는 입술이 떨어지자 웃음을 삼켰다.

**V03-SANAE-FRIEND-UNSET-NEXT_KISS_ALLOW-B · 대사 → 짧은 지문**

{name}「그분께도 이 얘기를…… 아뇨, 그만할게요.」{name}는 입술이 떨어지자 웃음을 삼켰다.

#### 다음 만남 · 키스 · 거절

**V03-SANAE-FRIEND-UNSET-NEXT_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「친구 사이 장난이라고 하면 더 미안해져요.」{name}는 얼굴을 돌리고 반걸음 물러났다.

**V03-SANAE-FRIEND-UNSET-NEXT_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「그분께도 이 얘기를…… 아뇨, 그만할게요.」{name}는 얼굴을 돌리고 반걸음 물러났다.

#### 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-SANAE-FRIEND-UNSET-LATE_TALK-A · 대사 → 짧은 지문**

{name}「전처럼 웃으면 괜찮아질 줄 알았어요.」{name}는 꺼내려던 말을 삼키고 소매를 당겼다.

**V03-SANAE-FRIEND-UNSET-LATE_TALK-B · 대사 → 짧은 지문**

{name}「그분한테는 친구라고만 했어요.」{name}는 꺼내려던 말을 삼키고 소매를 당겼다.

#### 시간이 지난 뒤 · 스킨십 · 수락

**V03-SANAE-FRIEND-UNSET-LATE_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……아무 뜻 없다는 말은 이제 못 하겠어요.」{name}는 손을 잡은 채 머리카락을 귀 뒤로 넘겼다.

**V03-SANAE-FRIEND-UNSET-LATE_TOUCH_ALLOW-B · 대사 → 짧은 지문**

{name}「그분한테는 친구라고만 했어요.」{name}는 손을 잡은 채 머리카락을 귀 뒤로 넘겼다.

#### 시간이 지난 뒤 · 스킨십 · 거절

**V03-SANAE-FRIEND-UNSET-LATE_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「친구라고 부르면 다 괜찮아지는 건 아니네요.」{name}는 손을 피한 채 애매하게 웃었다.

**V03-SANAE-FRIEND-UNSET-LATE_TOUCH_REFUSE-B · 대사 → 짧은 지문**

{name}「그분한테는 친구라고만 했어요.」{name}는 손을 피한 채 애매하게 웃었다.

#### 시간이 지난 뒤 · 키스 · 수락

**V03-SANAE-FRIEND-UNSET-LATE_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……그분한테 못 할 말만 늘어나네요.」{name}는 입술이 떨어지자 머리카락을 매만졌다.

**V03-SANAE-FRIEND-UNSET-LATE_KISS_ALLOW-B · 지문만**

{name}는 화제를 바꾸려다 멈추고 입술이 떨어지자 머리카락을 넘겼다.

#### 시간이 지난 뒤 · 키스 · 거절

**V03-SANAE-FRIEND-UNSET-LATE_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「이러고 친구였다고만 하면 그분한테 너무 미안해요.」{name}는 얼굴을 돌리고 한 발 물러났다.

**V03-SANAE-FRIEND-UNSET-LATE_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「그분한테는 친구라고만 했어요.」{name}는 얼굴을 돌리고 한 발 물러났다.

## 연인(비밀)

### 몸: 주인공쪽

#### 직후 · 관계 직후 · 해당 없음

**V03-SANAE-SECRET-PC-AFTER-A · 대사 → 짧은 지문**

{name}「에헤헤, 조금만 더요. ……돌아가야 하는데.」{name}는 다가앉았다가 웃음을 삼켰다.

**V03-SANAE-SECRET-PC-AFTER-B · 대사 → 짧은 지문**

{name}「……머리는 나중에 고칠래요. 조금만 더요.」{name}는 다가앉았다가 웃음을 삼켰다.

#### 다음 만남 · 대화하기 · 해당 없음

**V03-SANAE-SECRET-PC-NEXT_TALK-A · 대사 → 짧은 지문**

{name}「오셨어요! ……제가 벌써 웃고 있네요.」{name}는 옆자리를 두드리다가 손을 멈췄다.

**V03-SANAE-SECRET-PC-NEXT_TALK-B · 지문만**

{name}는 기쁜 듯 다가왔다가 자기 소매만 잡아당겼다.

#### 다음 만남 · 스킨십 · 수락

**V03-SANAE-SECRET-PC-NEXT_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……놓지 마세요. 시간이 자꾸 빨리 가요.」{name}는 손을 꼭 잡았다가 웃음을 거뒀다.

**V03-SANAE-SECRET-PC-NEXT_TOUCH_ALLOW-B · 지문만**

{name}는 기쁜 듯 다가왔다가 잡힌 손을 내려다보고 눈을 피했다.

#### 다음 만남 · 스킨십 · 거절

**V03-SANAE-SECRET-PC-NEXT_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「……이 손 놓으면 오늘은 돌아갈 수 있겠죠.」{name}는 내밀던 손을 거두고 이쪽 손을 밀었다.

**V03-SANAE-SECRET-PC-NEXT_TOUCH_REFUSE-B · 대사 → 짧은 지문**

{name}「……오셨다고 벌써 웃네요.」{name}는 내밀던 손을 거두고 이쪽 손을 밀었다.

#### 다음 만남 · 키스 · 수락

**V03-SANAE-SECRET-PC-NEXT_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「에헤헤, 한 번 더요. ……또 제가 먼저 말하네요.」{name}는 먼저 눈을 감았다가 입가를 가렸다.

**V03-SANAE-SECRET-PC-NEXT_KISS_ALLOW-B · 대사 → 짧은 지문**

{name}「……오셨다고 벌써 웃네요.」{name}는 먼저 눈을 감았다가 입가를 가렸다.

#### 다음 만남 · 키스 · 거절

**V03-SANAE-SECRET-PC-NEXT_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「……이러면 저 또 아무 말 안 하고 웃어요.」{name}는 다가가려다 멈추고 두 손으로 막았다.

**V03-SANAE-SECRET-PC-NEXT_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「……오셨다고 벌써 웃네요.」{name}는 다가가려다 멈추고 두 손으로 막았다.

#### 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-SANAE-SECRET-PC-LATE_TALK-A · 대사 → 짧은 지문**

{name}「……여기 오면 돌아갈 시간을 자꾸 잊어요.」{name}는 옆에 앉자마자 시선을 내렸다.

**V03-SANAE-SECRET-PC-LATE_TALK-B · 대사 → 짧은 지문**

{name}「……그분께 갈 시간도 잊었네요.」{name}는 옆에 앉자마자 시선을 내렸다.

#### 시간이 지난 뒤 · 스킨십 · 수락

**V03-SANAE-SECRET-PC-LATE_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……그분 손도 잡아야 할 텐데, 어떡하죠.」{name}는 먼저 잡은 손을 내려다보고 웃음을 멈췄다.

**V03-SANAE-SECRET-PC-LATE_TOUCH_ALLOW-B · 대사 → 짧은 지문**

{name}「……그분께 갈 시간도 잊었네요.」{name}는 먼저 잡은 손을 내려다보고 웃음을 멈췄다.

#### 시간이 지난 뒤 · 스킨십 · 거절

**V03-SANAE-SECRET-PC-LATE_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「……가까이 있으면 또 내일 생각하자고 해요.」{name}는 내밀었던 손을 거두고 고개를 저었다.

**V03-SANAE-SECRET-PC-LATE_TOUCH_REFUSE-B · 대사 → 짧은 지문**

{name}「……그분께 갈 시간도 잊었네요.」{name}는 내밀었던 손을 거두고 고개를 저었다.

#### 시간이 지난 뒤 · 키스 · 수락

**V03-SANAE-SECRET-PC-LATE_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……당신 기다리려고 그분께 늦는다고 했어요.」{name}는 먼저 눈을 감았다가 뒤늦게 고개를 숙였다.

**V03-SANAE-SECRET-PC-LATE_KISS_ALLOW-B · 지문만**

{name}는 기쁜 듯 다가왔다가 입술이 떨어지자 머리카락을 넘겼다.

#### 시간이 지난 뒤 · 키스 · 거절

**V03-SANAE-SECRET-PC-LATE_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「……또 괜찮아진 줄 알고 미루면 안 되잖아요.」{name}는 다가서던 발을 멈추고 두 손으로 막았다.

**V03-SANAE-SECRET-PC-LATE_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「……그분께 갈 시간도 잊었네요.」{name}는 다가서던 발을 멈추고 두 손으로 막았다.

### 몸: 미정

#### 직후 · 관계 직후 · 해당 없음

**V03-SANAE-SECRET-UNSET-AFTER-A · 대사 → 짧은 지문**

{name}「좋아해요. ……그분 생각도 같이 나네요.」{name}는 옷깃을 고치고 어색하게 웃었다.

**V03-SANAE-SECRET-UNSET-AFTER-B · 대사 → 짧은 지문**

{name}「좋아해요. 그분께 미안한 것도 맞아요.」{name}는 옷깃을 고치고 어색하게 웃었다.

#### 다음 만남 · 대화하기 · 해당 없음

**V03-SANAE-SECRET-UNSET-NEXT_TALK-A · 대사 → 짧은 지문**

{name}「그분이 좋은 일 있냐고 하셨어요. 당신 생각했거든요.」{name}는 말을 꺼내다 말고 머리카락을 넘겼다.

**V03-SANAE-SECRET-UNSET-NEXT_TALK-B · 지문만**

{name}는 문 쪽을 힐끗 보고 자기 소매만 잡아당겼다.

#### 다음 만남 · 스킨십 · 수락

**V03-SANAE-SECRET-UNSET-NEXT_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……이러면 돌아가기 싫어져요.」{name}는 손을 빼지 않고 소매만 잡아당겼다.

**V03-SANAE-SECRET-UNSET-NEXT_TOUCH_ALLOW-B · 지문만**

{name}는 문 쪽을 힐끗 보고 잡힌 손을 내려다보고 눈을 피했다.

#### 다음 만남 · 스킨십 · 거절

**V03-SANAE-SECRET-UNSET-NEXT_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「잘해 주시면 또 말을 못 꺼내요. 잠깐만요.」{name}는 손을 피하고 난처하게 웃었다.

**V03-SANAE-SECRET-UNSET-NEXT_TOUCH_REFUSE-B · 대사 → 짧은 지문**

{name}「좋은 일 있었다고 했어요. 무슨 일인지는 빼고요.」{name}는 손을 피하고 난처하게 웃었다.

#### 다음 만남 · 키스 · 수락

**V03-SANAE-SECRET-UNSET-NEXT_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……좋아해요. 아무 걱정 없이 말하면 좋겠어요.」{name}는 입술이 떨어지자 웃음을 삼켰다.

**V03-SANAE-SECRET-UNSET-NEXT_KISS_ALLOW-B · 대사 → 짧은 지문**

{name}「좋은 일 있었다고 했어요. 무슨 일인지는 빼고요.」{name}는 입술이 떨어지자 웃음을 삼켰다.

#### 다음 만남 · 키스 · 거절

**V03-SANAE-SECRET-UNSET-NEXT_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「오늘은 그분 얘기도 해요. 저도 피하지 않을게요.」{name}는 얼굴을 돌리고 반걸음 물러났다.

**V03-SANAE-SECRET-UNSET-NEXT_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「좋은 일 있었다고 했어요. 무슨 일인지는 빼고요.」{name}는 얼굴을 돌리고 반걸음 물러났다.

#### 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-SANAE-SECRET-UNSET-LATE_TALK-A · 대사 → 짧은 지문**

{name}「둘만의 비밀이라 좋았는데 그분은 아무것도 모르시네요.」{name}는 꺼내려던 말을 삼키고 소매를 당겼다.

**V03-SANAE-SECRET-UNSET-LATE_TALK-B · 대사 → 짧은 지문**

{name}「둘만의 비밀이란 말이 전처럼 좋지만은 않네요.」{name}는 꺼내려던 말을 삼키고 소매를 당겼다.

#### 시간이 지난 뒤 · 스킨십 · 수락

**V03-SANAE-SECRET-UNSET-LATE_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……그분 앞에선 이 손을 어떻게 숨기죠.」{name}는 손을 잡은 채 머리카락을 귀 뒤로 넘겼다.

**V03-SANAE-SECRET-UNSET-LATE_TOUCH_ALLOW-B · 대사 → 짧은 지문**

{name}「둘만의 비밀이란 말이 전처럼 좋지만은 않네요.」{name}는 손을 잡은 채 머리카락을 귀 뒤로 넘겼다.

#### 시간이 지난 뒤 · 스킨십 · 거절

**V03-SANAE-SECRET-UNSET-LATE_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「오늘은 떨어져 앉을래요. 얘기부터 하고요.」{name}는 손을 피한 채 애매하게 웃었다.

**V03-SANAE-SECRET-UNSET-LATE_TOUCH_REFUSE-B · 대사 → 짧은 지문**

{name}「둘만의 비밀이란 말이 전처럼 좋지만은 않네요.」{name}는 손을 피한 채 애매하게 웃었다.

#### 시간이 지난 뒤 · 키스 · 수락

**V03-SANAE-SECRET-UNSET-LATE_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……좋아하는 건 같은데 비밀로 웃기가 힘드네요.」{name}는 입술이 떨어지자 머리카락을 매만졌다.

**V03-SANAE-SECRET-UNSET-LATE_KISS_ALLOW-B · 지문만**

{name}는 문 쪽을 힐끗 보고 입술이 떨어지자 머리카락을 넘겼다.

#### 시간이 지난 뒤 · 키스 · 거절

**V03-SANAE-SECRET-UNSET-LATE_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「그분 얘기부터 해요. 웃게 하는 건 나중에도 되니까요.」{name}는 얼굴을 돌리고 한 발 물러났다.

**V03-SANAE-SECRET-UNSET-LATE_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「둘만의 비밀이란 말이 전처럼 좋지만은 않네요.」{name}는 얼굴을 돌리고 한 발 물러났다.

## 타인

### 몸: 주인공쪽

#### 직후 · 관계 직후 · 해당 없음

**V03-SANAE-STRANGER-PC-AFTER-A · 대사 → 짧은 지문**

{name}「……곁은 벌써 편한데 아는 건 별로 없네요.」{name}는 다가앉았다가 웃음을 삼켰다.

**V03-SANAE-STRANGER-PC-AFTER-B · 대사 → 짧은 지문**

{name}「……옆이 먼저 편해졌네요.」{name}는 다가앉았다가 웃음을 삼켰다.

#### 다음 만남 · 대화하기 · 해당 없음

**V03-SANAE-STRANGER-PC-NEXT_TALK-A · 대사 → 짧은 지문**

{name}「……당신 계신 곳부터 찾았네요.」{name}는 옆자리를 두드리다가 손을 멈췄다.

**V03-SANAE-STRANGER-PC-NEXT_TALK-B · 지문만**

{name}는 가까이 섰다가 뒤늦게 자기 소매만 잡아당겼다.

#### 다음 만남 · 스킨십 · 수락

**V03-SANAE-STRANGER-PC-NEXT_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……손은 안 어색한데 얼굴 보면 말을 잊어요.」{name}는 손을 꼭 잡았다가 웃음을 거뒀다.

**V03-SANAE-STRANGER-PC-NEXT_TOUCH_ALLOW-B · 대사 → 짧은 지문**

{name}「……어디 계신지부터 찾게 돼요.」{name}는 손을 꼭 잡았다가 웃음을 거뒀다.

#### 다음 만남 · 스킨십 · 거절

**V03-SANAE-STRANGER-PC-NEXT_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「……가까이 왔어도 조금 기다려 주세요.」{name}는 내밀던 손을 거두고 이쪽 손을 밀었다.

**V03-SANAE-STRANGER-PC-NEXT_TOUCH_REFUSE-B · 지문만**

{name}는 가까이 섰다가 뒤늦게 뻗어 온 손을 밀어내고 고개를 저었다.

#### 다음 만남 · 키스 · 수락

**V03-SANAE-STRANGER-PC-NEXT_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……그분 앞보다 쉽게 눈이 감기네요.」{name}는 먼저 눈을 감았다가 입가를 가렸다.

**V03-SANAE-STRANGER-PC-NEXT_KISS_ALLOW-B · 대사 → 짧은 지문**

{name}「……어디 계신지부터 찾게 돼요.」{name}는 먼저 눈을 감았다가 입가를 가렸다.

#### 다음 만남 · 키스 · 거절

**V03-SANAE-STRANGER-PC-NEXT_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「……저 또 쉽게 대답하려고 했죠. 잠깐만요.」{name}는 다가가려다 멈추고 두 손으로 막았다.

**V03-SANAE-STRANGER-PC-NEXT_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「……어디 계신지부터 찾게 돼요.」{name}는 다가가려다 멈추고 두 손으로 막았다.

#### 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-SANAE-STRANGER-PC-LATE_TALK-A · 대사 → 짧은 지문**

{name}「……어디 계실지부터 생각하게 돼요.」{name}는 옆에 앉자마자 시선을 내렸다.

**V03-SANAE-STRANGER-PC-LATE_TALK-B · 대사 → 짧은 지문**

{name}「……또 이쪽부터 왔네요.」{name}는 옆에 앉자마자 시선을 내렸다.

#### 시간이 지난 뒤 · 스킨십 · 수락

**V03-SANAE-STRANGER-PC-LATE_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……손만 익숙해진 것 같네요, 우리.」{name}는 먼저 잡은 손을 내려다보고 웃음을 멈췄다.

**V03-SANAE-STRANGER-PC-LATE_TOUCH_ALLOW-B · 대사 → 짧은 지문**

{name}「……또 이쪽부터 왔네요.」{name}는 먼저 잡은 손을 내려다보고 웃음을 멈췄다.

#### 시간이 지난 뒤 · 스킨십 · 거절

**V03-SANAE-STRANGER-PC-LATE_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「……오늘은 얘기만 해 볼까요. 떨어져서요.」{name}는 내밀었던 손을 거두고 고개를 저었다.

**V03-SANAE-STRANGER-PC-LATE_TOUCH_REFUSE-B · 대사 → 짧은 지문**

{name}「……또 이쪽부터 왔네요.」{name}는 내밀었던 손을 거두고 고개를 저었다.

#### 시간이 지난 뒤 · 키스 · 수락

**V03-SANAE-STRANGER-PC-LATE_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……또 눈부터 감았네요. 물어볼 건 많은데.」{name}는 먼저 눈을 감았다가 뒤늦게 고개를 숙였다.

**V03-SANAE-STRANGER-PC-LATE_KISS_ALLOW-B · 지문만**

{name}는 가까이 섰다가 뒤늦게 입술이 떨어지자 머리카락을 넘겼다.

#### 시간이 지난 뒤 · 키스 · 거절

**V03-SANAE-STRANGER-PC-LATE_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「……이 거리만 익숙해지는 건 곤란하겠죠.」{name}는 다가서던 발을 멈추고 두 손으로 막았다.

**V03-SANAE-STRANGER-PC-LATE_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「……또 이쪽부터 왔네요.」{name}는 다가서던 발을 멈추고 두 손으로 막았다.

### 몸: 미정

#### 직후 · 관계 직후 · 해당 없음

**V03-SANAE-STRANGER-UNSET-AFTER-A · 대사 → 짧은 지문**

{name}「……그분한테 당신을 뭐라고 설명할까요.」{name}는 옷깃을 고치고 어색하게 웃었다.

**V03-SANAE-STRANGER-UNSET-AFTER-B · 대사 → 짧은 지문**

{name}「그분께 당신을 뭐라고 말씀드릴까요.」{name}는 옷깃을 고치고 어색하게 웃었다.

#### 다음 만남 · 대화하기 · 해당 없음

**V03-SANAE-STRANGER-UNSET-NEXT_TALK-A · 대사 → 짧은 지문**

{name}「당신 얘기도 들려주세요. 아는 게 적어서요.」{name}는 말을 꺼내다 말고 머리카락을 넘겼다.

**V03-SANAE-STRANGER-UNSET-NEXT_TALK-B · 지문만**

{name}는 머뭇거리며 한 발 떨어져서 자기 소매만 잡아당겼다.

#### 다음 만남 · 스킨십 · 수락

**V03-SANAE-STRANGER-UNSET-NEXT_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……원래 친했던 것처럼은 말씀하지 마세요.」{name}는 손을 빼지 않고 소매만 잡아당겼다.

**V03-SANAE-STRANGER-UNSET-NEXT_TOUCH_ALLOW-B · 대사 → 짧은 지문**

{name}「당신 얘기도 궁금해요. 아직 모르는 게 많아서요.」{name}는 손을 빼지 않고 소매만 잡아당겼다.

#### 다음 만남 · 스킨십 · 거절

**V03-SANAE-STRANGER-UNSET-NEXT_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「그 일로 제가 다 괜찮아진 건 아니에요.」{name}는 손을 피하고 난처하게 웃었다.

**V03-SANAE-STRANGER-UNSET-NEXT_TOUCH_REFUSE-B · 지문만**

{name}는 머뭇거리며 한 발 떨어져서 뻗어 온 손을 밀어내고 고개를 저었다.

#### 다음 만남 · 키스 · 수락

**V03-SANAE-STRANGER-UNSET-NEXT_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……당신한텐 어떤 뜻이에요, 이거.」{name}는 입술이 떨어지자 웃음을 삼켰다.

**V03-SANAE-STRANGER-UNSET-NEXT_KISS_ALLOW-B · 대사 → 짧은 지문**

{name}「당신 얘기도 궁금해요. 아직 모르는 게 많아서요.」{name}는 입술이 떨어지자 웃음을 삼켰다.

#### 다음 만남 · 키스 · 거절

**V03-SANAE-STRANGER-UNSET-NEXT_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「우리 얘기를 먼저 해요. 모르는 게 많잖아요.」{name}는 얼굴을 돌리고 반걸음 물러났다.

**V03-SANAE-STRANGER-UNSET-NEXT_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「당신 얘기도 궁금해요. 아직 모르는 게 많아서요.」{name}는 얼굴을 돌리고 반걸음 물러났다.

#### 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-SANAE-STRANGER-UNSET-LATE_TALK-A · 대사 → 짧은 지문**

{name}「이제 당신은 좀 알겠어요. 그분께는 말도 못 했지만요.」{name}는 꺼내려던 말을 삼키고 소매를 당겼다.

**V03-SANAE-STRANGER-UNSET-LATE_TALK-B · 대사 → 짧은 지문**

{name}「당신은 조금 알겠어요. 그분께는 말도 못 했지만요.」{name}는 꺼내려던 말을 삼키고 소매를 당겼다.

#### 시간이 지난 뒤 · 스킨십 · 수락

**V03-SANAE-STRANGER-UNSET-LATE_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……오늘은 괜찮아요. 오늘은요.」{name}는 손을 잡은 채 머리카락을 귀 뒤로 넘겼다.

**V03-SANAE-STRANGER-UNSET-LATE_TOUCH_ALLOW-B · 대사 → 짧은 지문**

{name}「당신은 조금 알겠어요. 그분께는 말도 못 했지만요.」{name}는 손을 잡은 채 머리카락을 귀 뒤로 넘겼다.

#### 시간이 지난 뒤 · 스킨십 · 거절

**V03-SANAE-STRANGER-UNSET-LATE_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「자주 뵙는다고 늘 괜찮은 건 아니에요.」{name}는 손을 피한 채 애매하게 웃었다.

**V03-SANAE-STRANGER-UNSET-LATE_TOUCH_REFUSE-B · 대사 → 짧은 지문**

{name}「당신은 조금 알겠어요. 그분께는 말도 못 했지만요.」{name}는 손을 피한 채 애매하게 웃었다.

#### 시간이 지난 뒤 · 키스 · 수락

**V03-SANAE-STRANGER-UNSET-LATE_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……우리 무슨 사이예요? 이제라도 묻고 싶어요.」{name}는 입술이 떨어지자 머리카락을 매만졌다.

**V03-SANAE-STRANGER-UNSET-LATE_KISS_ALLOW-B · 지문만**

{name}는 머뭇거리며 한 발 떨어져서 입술이 떨어지자 머리카락을 넘겼다.

#### 시간이 지난 뒤 · 키스 · 거절

**V03-SANAE-STRANGER-UNSET-LATE_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「당신 마음부터 들려주세요. 그분께 할 말도 남았어요.」{name}는 얼굴을 돌리고 한 발 물러났다.

**V03-SANAE-STRANGER-UNSET-LATE_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「당신은 조금 알겠어요. 그분께는 말도 못 했지만요.」{name}는 얼굴을 돌리고 한 발 물러났다.

## 짝사랑

### 몸: 주인공쪽

#### 직후 · 관계 직후 · 해당 없음

**V03-SANAE-CRUSH-PC-AFTER-A · 대사 → 짧은 지문**

{name}「에헤헤. ……저 지금 돌아가기 싫어요.」{name}는 다가앉았다가 웃음을 삼켰다.

**V03-SANAE-CRUSH-PC-AFTER-B · 대사 → 짧은 지문**

{name}「에헤헤. ……제가 너무 기뻐하죠.」{name}는 다가앉았다가 웃음을 삼켰다.

#### 다음 만남 · 대화하기 · 해당 없음

**V03-SANAE-CRUSH-PC-NEXT_TALK-A · 대사 → 짧은 지문**

{name}「오셨네요! ……기다린 티 너무 났어요?」{name}는 옆자리를 두드리다가 손을 멈췄다.

**V03-SANAE-CRUSH-PC-NEXT_TALK-B · 지문만**

{name}는 먼저 웃어 버렸다가 자기 소매만 잡아당겼다.

#### 다음 만남 · 스킨십 · 수락

**V03-SANAE-CRUSH-PC-NEXT_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……웃지 말아야 하는데 자꾸 웃게 돼요.」{name}는 손을 꼭 잡았다가 웃음을 거뒀다.

**V03-SANAE-CRUSH-PC-NEXT_TOUCH_ALLOW-B · 지문만**

{name}는 먼저 웃어 버렸다가 잡힌 손을 내려다보고 눈을 피했다.

#### 다음 만남 · 스킨십 · 거절

**V03-SANAE-CRUSH-PC-NEXT_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「……손 잡으면 물어볼 말을 또 잊어요.」{name}는 내밀던 손을 거두고 이쪽 손을 밀었다.

**V03-SANAE-CRUSH-PC-NEXT_TOUCH_REFUSE-B · 대사 → 짧은 지문**

{name}「……기다린 얼굴이었나요?」{name}는 내밀던 손을 거두고 이쪽 손을 밀었다.

#### 다음 만남 · 키스 · 수락

**V03-SANAE-CRUSH-PC-NEXT_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……기다렸다고 하면 놀리실 건가요?」{name}는 먼저 눈을 감았다가 입가를 가렸다.

**V03-SANAE-CRUSH-PC-NEXT_KISS_ALLOW-B · 대사 → 짧은 지문**

{name}「……기다린 얼굴이었나요?」{name}는 먼저 눈을 감았다가 입가를 가렸다.

#### 다음 만남 · 키스 · 거절

**V03-SANAE-CRUSH-PC-NEXT_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「……오늘은 대답 먼저요. 가까이 오시기 전에.」{name}는 다가가려다 멈추고 두 손으로 막았다.

**V03-SANAE-CRUSH-PC-NEXT_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「……기다린 얼굴이었나요?」{name}는 다가가려다 멈추고 두 손으로 막았다.

#### 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-SANAE-CRUSH-PC-LATE_TALK-A · 대사 → 짧은 지문**

{name}「……발소리만 들어도 나오게 되네요.」{name}는 옆에 앉자마자 시선을 내렸다.

**V03-SANAE-CRUSH-PC-LATE_TALK-B · 대사 → 짧은 지문**

{name}「……목소리만 듣고 나왔어요.」{name}는 옆에 앉자마자 시선을 내렸다.

#### 시간이 지난 뒤 · 스킨십 · 수락

**V03-SANAE-CRUSH-PC-LATE_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……제가 먼저 잡았네요. 어쩌죠.」{name}는 먼저 잡은 손을 내려다보고 웃음을 멈췄다.

**V03-SANAE-CRUSH-PC-LATE_TOUCH_ALLOW-B · 대사 → 짧은 지문**

{name}「……목소리만 듣고 나왔어요.」{name}는 먼저 잡은 손을 내려다보고 웃음을 멈췄다.

#### 시간이 지난 뒤 · 스킨십 · 거절

**V03-SANAE-CRUSH-PC-LATE_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「……기대고 있으면 좋은 대답만 생각해요.」{name}는 내밀었던 손을 거두고 고개를 저었다.

**V03-SANAE-CRUSH-PC-LATE_TOUCH_REFUSE-B · 대사 → 짧은 지문**

{name}「……목소리만 듣고 나왔어요.」{name}는 내밀었던 손을 거두고 고개를 저었다.

#### 시간이 지난 뒤 · 키스 · 수락

**V03-SANAE-CRUSH-PC-LATE_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……그분께는 늦는다고 했어요. 당신 기다리려고요.」{name}는 먼저 눈을 감았다가 뒤늦게 고개를 숙였다.

**V03-SANAE-CRUSH-PC-LATE_KISS_ALLOW-B · 지문만**

{name}는 먼저 웃어 버렸다가 입술이 떨어지자 머리카락을 넘겼다.

#### 시간이 지난 뒤 · 키스 · 거절

**V03-SANAE-CRUSH-PC-LATE_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「……저만 더 좋아하게 될까 봐 잠깐 멈출래요.」{name}는 다가서던 발을 멈추고 두 손으로 막았다.

**V03-SANAE-CRUSH-PC-LATE_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「……목소리만 듣고 나왔어요.」{name}는 다가서던 발을 멈추고 두 손으로 막았다.

### 몸: 미정

#### 직후 · 관계 직후 · 해당 없음

**V03-SANAE-CRUSH-UNSET-AFTER-A · 대사 → 짧은 지문**

{name}「……기뻤어요. 그분 생각보다 먼저요.」{name}는 옷깃을 고치고 어색하게 웃었다.

**V03-SANAE-CRUSH-UNSET-AFTER-B · 대사 → 짧은 지문**

{name}「그분 생각은 나중에야 났어요. 미안하게.」{name}는 옷깃을 고치고 어색하게 웃었다.

#### 다음 만남 · 대화하기 · 해당 없음

**V03-SANAE-CRUSH-UNSET-NEXT_TALK-A · 대사 → 짧은 지문**

{name}「그분께 당신 얘기할 뻔했어요. 좋아한다고요.」{name}는 말을 꺼내다 말고 머리카락을 넘겼다.

**V03-SANAE-CRUSH-UNSET-NEXT_TALK-B · 지문만**

{name}는 얼굴을 붉힌 채 자기 소매만 잡아당겼다.

#### 다음 만남 · 스킨십 · 수락

**V03-SANAE-CRUSH-UNSET-NEXT_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「에헤헤. ……그분 생각도 나는데 좋네요.」{name}는 손을 빼지 않고 소매만 잡아당겼다.

**V03-SANAE-CRUSH-UNSET-NEXT_TOUCH_ALLOW-B · 지문만**

{name}는 얼굴을 붉힌 채 잡힌 손을 내려다보고 눈을 피했다.

#### 다음 만남 · 스킨십 · 거절

**V03-SANAE-CRUSH-UNSET-NEXT_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「좋아한다고 늘 괜찮은 건 아니에요.」{name}는 손을 피하고 난처하게 웃었다.

**V03-SANAE-CRUSH-UNSET-NEXT_TOUCH_REFUSE-B · 대사 → 짧은 지문**

{name}「좋아하는 티를 그분 앞에서도 냈을까 봐요.」{name}는 손을 피하고 난처하게 웃었다.

#### 다음 만남 · 키스 · 수락

**V03-SANAE-CRUSH-UNSET-NEXT_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……당신도 같은 마음이면 좋겠어요.」{name}는 입술이 떨어지자 웃음을 삼켰다.

**V03-SANAE-CRUSH-UNSET-NEXT_KISS_ALLOW-B · 대사 → 짧은 지문**

{name}「좋아하는 티를 그분 앞에서도 냈을까 봐요.」{name}는 입술이 떨어지자 웃음을 삼켰다.

#### 다음 만남 · 키스 · 거절

**V03-SANAE-CRUSH-UNSET-NEXT_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「제 마음은 아시죠. ……당신은요?」{name}는 얼굴을 돌리고 반걸음 물러났다.

**V03-SANAE-CRUSH-UNSET-NEXT_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「좋아하는 티를 그분 앞에서도 냈을까 봐요.」{name}는 얼굴을 돌리고 반걸음 물러났다.

#### 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-SANAE-CRUSH-UNSET-LATE_TALK-A · 대사 → 짧은 지문**

{name}「아직도 당신만 기다려요. 그분한테 미안하게.」{name}는 꺼내려던 말을 삼키고 소매를 당겼다.

**V03-SANAE-CRUSH-UNSET-LATE_TALK-B · 대사 → 짧은 지문**

{name}「당신도 대답해 주세요. 저만 기다리고 있잖아요.」{name}는 꺼내려던 말을 삼키고 소매를 당겼다.

#### 시간이 지난 뒤 · 스킨십 · 수락

**V03-SANAE-CRUSH-UNSET-LATE_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……좋아하는 티는 못 숨기겠어요.」{name}는 손을 잡은 채 머리카락을 귀 뒤로 넘겼다.

**V03-SANAE-CRUSH-UNSET-LATE_TOUCH_ALLOW-B · 대사 → 짧은 지문**

{name}「당신도 대답해 주세요. 저만 기다리고 있잖아요.」{name}는 손을 잡은 채 머리카락을 귀 뒤로 넘겼다.

#### 시간이 지난 뒤 · 스킨십 · 거절

**V03-SANAE-CRUSH-UNSET-LATE_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「오늘은 얘기를 먼저 들려주세요.」{name}는 손을 피한 채 애매하게 웃었다.

**V03-SANAE-CRUSH-UNSET-LATE_TOUCH_REFUSE-B · 대사 → 짧은 지문**

{name}「당신도 대답해 주세요. 저만 기다리고 있잖아요.」{name}는 손을 피한 채 애매하게 웃었다.

#### 시간이 지난 뒤 · 키스 · 수락

**V03-SANAE-CRUSH-UNSET-LATE_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……제 마음만 아시고 당신은 말씀 안 하세요?」{name}는 입술이 떨어지자 머리카락을 매만졌다.

**V03-SANAE-CRUSH-UNSET-LATE_KISS_ALLOW-B · 지문만**

{name}는 얼굴을 붉힌 채 입술이 떨어지자 머리카락을 넘겼다.

#### 시간이 지난 뒤 · 키스 · 거절

**V03-SANAE-CRUSH-UNSET-LATE_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「웃고 넘기기는 싫어요. 당신 마음도 말해 주세요.」{name}는 얼굴을 돌리고 한 발 물러났다.

**V03-SANAE-CRUSH-UNSET-LATE_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「당신도 대답해 주세요. 저만 기다리고 있잖아요.」{name}는 얼굴을 돌리고 한 발 물러났다.

## 굴복

### 몸: 주인공쪽

#### 직후 · 관계 직후 · 해당 없음

**V03-SANAE-SUBMIT-PC-AFTER-A · 대사 → 짧은 지문**

{name}「……안 부르셔도 또 올 것 같네요.」{name}는 곁에 남아 억지로 웃어 보였다.

**V03-SANAE-SUBMIT-PC-AFTER-B · 대사 → 짧은 지문**

{name}「……조금 더 곁에 있어도 돼요?」{name}는 곁에 남아 억지로 웃어 보였다.

#### 다음 만남 · 대화하기 · 해당 없음

**V03-SANAE-SUBMIT-PC-NEXT_TALK-A · 대사 → 짧은 지문**

{name}「……부르시기 전에 왔네요, 저.」{name}는 먼저 돌아보고도 웃음을 삼켰다.

**V03-SANAE-SUBMIT-PC-NEXT_TALK-B · 지문만**

{name}는 부르기도 전에 돌아보고 자기 소매만 잡아당겼다.

#### 다음 만남 · 스킨십 · 수락

**V03-SANAE-SUBMIT-PC-NEXT_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……손 빼는 게 더 이상해졌네요.」{name}는 잡힌 손을 보고 웃으려다 말았다.

**V03-SANAE-SUBMIT-PC-NEXT_TOUCH_ALLOW-B · 지문만**

{name}는 부르기도 전에 돌아보고 잡힌 손을 내려다보고 눈을 피했다.

#### 다음 만남 · 스킨십 · 거절

**V03-SANAE-SUBMIT-PC-NEXT_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「……옆에 와도 오늘은 손 빼고 싶어요.」{name}는 내밀던 손을 거두고 이쪽 손을 밀었다.

**V03-SANAE-SUBMIT-PC-NEXT_TOUCH_REFUSE-B · 대사 → 짧은 지문**

{name}「……안 부르셨는데 왔네요.」{name}는 내밀던 손을 거두고 이쪽 손을 밀었다.

#### 다음 만남 · 키스 · 수락

**V03-SANAE-SUBMIT-PC-NEXT_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……먼저 눈 감았네요. 저도 참.」{name}는 끝난 뒤에야 뒤늦게 웃어 보였다.

**V03-SANAE-SUBMIT-PC-NEXT_KISS_ALLOW-B · 대사 → 짧은 지문**

{name}「……안 부르셨는데 왔네요.」{name}는 끝난 뒤에야 뒤늦게 웃어 보였다.

#### 다음 만남 · 키스 · 거절

**V03-SANAE-SUBMIT-PC-NEXT_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「……기다린 것 같아도 지금은 아니에요.」{name}는 다가가려다 멈추고 두 손으로 막았다.

**V03-SANAE-SUBMIT-PC-NEXT_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「……안 부르셨는데 왔네요.」{name}는 다가가려다 멈추고 두 손으로 막았다.

#### 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-SANAE-SUBMIT-PC-LATE_TALK-A · 대사 → 짧은 지문**

{name}「……또 먼저 왔어요. 그분께는 바쁘다고 하고요.」{name}는 먼저 돌아보고도 웃음을 삼켰다.

**V03-SANAE-SUBMIT-PC-LATE_TALK-B · 대사 → 짧은 지문**

{name}「……이쪽으로 먼저 오게 되네요.」{name}는 먼저 돌아보고도 웃음을 삼켰다.

#### 시간이 지난 뒤 · 스킨십 · 수락

**V03-SANAE-SUBMIT-PC-LATE_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……손이 먼저 나왔네요. 조심해야 하는데.」{name}는 잡힌 손을 보고 웃으려다 말았다.

**V03-SANAE-SUBMIT-PC-LATE_TOUCH_ALLOW-B · 대사 → 짧은 지문**

{name}「……이쪽으로 먼저 오게 되네요.」{name}는 잡힌 손을 보고 웃으려다 말았다.

#### 시간이 지난 뒤 · 스킨십 · 거절

**V03-SANAE-SUBMIT-PC-LATE_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「……늘 괜찮다고 했어도 오늘은 아니에요.」{name}는 내밀었던 손을 거두고 고개를 저었다.

**V03-SANAE-SUBMIT-PC-LATE_TOUCH_REFUSE-B · 대사 → 짧은 지문**

{name}「……이쪽으로 먼저 오게 되네요.」{name}는 내밀었던 손을 거두고 고개를 저었다.

#### 시간이 지난 뒤 · 키스 · 수락

**V03-SANAE-SUBMIT-PC-LATE_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……그분 생각보다 눈 감는 게 빨랐네요.」{name}는 끝난 뒤에야 뒤늦게 웃어 보였다.

**V03-SANAE-SUBMIT-PC-LATE_KISS_ALLOW-B · 지문만**

{name}는 부르기도 전에 돌아보고 입술이 떨어지자 머리카락을 넘겼다.

#### 시간이 지난 뒤 · 키스 · 거절

**V03-SANAE-SUBMIT-PC-LATE_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「……곁에 있어도 지금은 싫어요.」{name}는 다가서던 발을 멈추고 두 손으로 막았다.

**V03-SANAE-SUBMIT-PC-LATE_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「……이쪽으로 먼저 오게 되네요.」{name}는 다가서던 발을 멈추고 두 손으로 막았다.

### 몸: 미정

#### 직후 · 관계 직후 · 해당 없음

**V03-SANAE-SUBMIT-UNSET-AFTER-A · 대사 → 짧은 지문**

{name}「……이제 돌아가도 돼요? 그분 기다리실 텐데.」{name}는 웃는 얼굴을 만들려다 고개를 숙였다.

**V03-SANAE-SUBMIT-UNSET-AFTER-B · 대사 → 짧은 지문**

{name}「그분 앞에서는 웃으면 되겠죠.」{name}는 웃는 얼굴을 만들려다 고개를 숙였다.

#### 다음 만남 · 대화하기 · 해당 없음

**V03-SANAE-SUBMIT-UNSET-NEXT_TALK-A · 대사 → 짧은 지문**

{name}「그분한텐 웃었어요. 다른 말은 못 했고요.」{name}는 대답 뒤에는 소매만 잡아당겼다.

**V03-SANAE-SUBMIT-UNSET-NEXT_TALK-B · 지문만**

{name}는 웃는 얼굴을 억지로 지으며 자기 소매만 잡아당겼다.

#### 다음 만남 · 스킨십 · 수락

**V03-SANAE-SUBMIT-UNSET-NEXT_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……이렇게 두면 되죠.」{name}는 손은 그대로 두고 입술을 깨물었다.

**V03-SANAE-SUBMIT-UNSET-NEXT_TOUCH_ALLOW-B · 지문만**

{name}는 웃는 얼굴을 억지로 지으며 잡힌 손을 내려다보고 눈을 피했다.

#### 다음 만남 · 스킨십 · 거절

**V03-SANAE-SUBMIT-UNSET-NEXT_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「……손만 놔 주세요. 잠깐이라도요.」{name}는 손을 피하고 난처하게 웃었다.

**V03-SANAE-SUBMIT-UNSET-NEXT_TOUCH_REFUSE-B · 대사 → 짧은 지문**

{name}「그분께는 괜찮다고 했어요. 웃으면서요.」{name}는 손을 피하고 난처하게 웃었다.

#### 다음 만남 · 키스 · 수락

**V03-SANAE-SUBMIT-UNSET-NEXT_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……이제 됐나요? 돌아갈 시간이네요.」{name}는 입술이 떨어지자 입구 쪽을 보았다.

**V03-SANAE-SUBMIT-UNSET-NEXT_KISS_ALLOW-B · 대사 → 짧은 지문**

{name}「그분께는 괜찮다고 했어요. 웃으면서요.」{name}는 입술이 떨어지자 입구 쪽을 보았다.

#### 다음 만남 · 키스 · 거절

**V03-SANAE-SUBMIT-UNSET-NEXT_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「……웃으면서 말해도 싫다는 뜻이에요.」{name}는 얼굴을 돌리고 반걸음 물러났다.

**V03-SANAE-SUBMIT-UNSET-NEXT_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「그분께는 괜찮다고 했어요. 웃으면서요.」{name}는 얼굴을 돌리고 반걸음 물러났다.

#### 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-SANAE-SUBMIT-UNSET-LATE_TALK-A · 대사 → 짧은 지문**

{name}「그분 앞에서도 웃었어요. 잘했다고는 하지 마세요.」{name}는 대답 뒤에는 소매만 잡아당겼다.

**V03-SANAE-SUBMIT-UNSET-LATE_TALK-B · 대사 → 짧은 지문**

{name}「그분 앞에서도 잘 웃어요, 이제는.」{name}는 대답 뒤에는 소매만 잡아당겼다.

#### 시간이 지난 뒤 · 스킨십 · 수락

**V03-SANAE-SUBMIT-UNSET-LATE_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……그분 앞에선 이러면 안 되겠죠.」{name}는 손은 그대로 두고 입술을 깨물었다.

**V03-SANAE-SUBMIT-UNSET-LATE_TOUCH_ALLOW-B · 대사 → 짧은 지문**

{name}「그분 앞에서도 잘 웃어요, 이제는.」{name}는 손은 그대로 두고 입술을 깨물었다.

#### 시간이 지난 뒤 · 스킨십 · 거절

**V03-SANAE-SUBMIT-UNSET-LATE_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「……오늘은 놓을래요. 손.」{name}는 손을 피한 채 애매하게 웃었다.

**V03-SANAE-SUBMIT-UNSET-LATE_TOUCH_REFUSE-B · 대사 → 짧은 지문**

{name}「그분 앞에서도 잘 웃어요, 이제는.」{name}는 손을 피한 채 애매하게 웃었다.

#### 시간이 지난 뒤 · 키스 · 수락

**V03-SANAE-SUBMIT-UNSET-LATE_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……끝났으면 말해 주세요. 얼굴 좀 고치게요.」{name}는 입술이 떨어지자 입구 쪽을 보았다.

**V03-SANAE-SUBMIT-UNSET-LATE_KISS_ALLOW-B · 지문만**

{name}는 웃는 얼굴을 억지로 지으며 입술이 떨어지자 머리카락을 넘겼다.

#### 시간이 지난 뒤 · 키스 · 거절

**V03-SANAE-SUBMIT-UNSET-LATE_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「……웃지 않고 말해도 알아들어 주세요.」{name}는 얼굴을 돌리고 한 발 물러났다.

**V03-SANAE-SUBMIT-UNSET-LATE_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「그분 앞에서도 잘 웃어요, 이제는.」{name}는 얼굴을 돌리고 한 발 물러났다.

## 협박

### 몸: 주인공쪽

#### 직후 · 관계 직후 · 해당 없음

**V03-SANAE-COERCED-PC-AFTER-A · 대사 → 짧은 지문**

{name}「……곁에 있으면 하실 말씀은 먼저 알겠죠.」{name}는 곁에 남아 억지로 웃어 보였다.

**V03-SANAE-COERCED-PC-AFTER-B · 대사 → 짧은 지문**

{name}「……곁에 있으면 하실 말은 먼저 듣겠죠.」{name}는 곁에 남아 억지로 웃어 보였다.

#### 다음 만남 · 대화하기 · 해당 없음

**V03-SANAE-COERCED-PC-NEXT_TALK-A · 대사 → 짧은 지문**

{name}「……부르실까 봐 듣고 있었어요.」{name}는 먼저 돌아보고도 웃음을 삼켰다.

**V03-SANAE-COERCED-PC-NEXT_TALK-B · 지문만**

{name}는 이쪽 반응부터 살피고 자기 소매만 잡아당겼다.

#### 다음 만남 · 스킨십 · 수락

**V03-SANAE-COERCED-PC-NEXT_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……손은 이대로요. 그분께는 말하지 마세요.」{name}는 잡힌 손을 보고 웃으려다 말았다.

**V03-SANAE-COERCED-PC-NEXT_TOUCH_ALLOW-B · 대사 → 짧은 지문**

{name}「……부르실까 봐 듣고 있었어요.」{name}는 잡힌 손을 보고 웃으려다 말았다.

#### 다음 만남 · 스킨십 · 거절

**V03-SANAE-COERCED-PC-NEXT_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「……옆에 있어도 안 무서운 건 아니에요.」{name}는 내밀던 손을 거두고 이쪽 손을 밀었다.

**V03-SANAE-COERCED-PC-NEXT_TOUCH_REFUSE-B · 지문만**

{name}는 이쪽 반응부터 살피고 뻗어 온 손을 밀어내고 고개를 저었다.

#### 다음 만남 · 키스 · 수락

**V03-SANAE-COERCED-PC-NEXT_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……그분께 말씀 안 하신다는 약속부터요.」{name}는 끝난 뒤에야 뒤늦게 웃어 보였다.

**V03-SANAE-COERCED-PC-NEXT_KISS_ALLOW-B · 대사 → 짧은 지문**

{name}「……부르실까 봐 듣고 있었어요.」{name}는 끝난 뒤에야 뒤늦게 웃어 보였다.

#### 다음 만남 · 키스 · 거절

**V03-SANAE-COERCED-PC-NEXT_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「……오늘도 안 피할 줄 아셨어요?」{name}는 다가가려다 멈추고 두 손으로 막았다.

**V03-SANAE-COERCED-PC-NEXT_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「……부르실까 봐 듣고 있었어요.」{name}는 다가가려다 멈추고 두 손으로 막았다.

#### 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-SANAE-COERCED-PC-LATE_TALK-A · 대사 → 짧은 지문**

{name}「……당신 계신 쪽을 먼저 보게 되네요.」{name}는 먼저 돌아보고도 웃음을 삼켰다.

**V03-SANAE-COERCED-PC-LATE_TALK-B · 대사 → 짧은 지문**

{name}「……당신 표정부터 보게 되네요.」{name}는 먼저 돌아보고도 웃음을 삼켰다.

#### 시간이 지난 뒤 · 스킨십 · 수락

**V03-SANAE-COERCED-PC-LATE_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……익숙한 척은 할 수 있어요.」{name}는 잡힌 손을 보고 웃으려다 말았다.

**V03-SANAE-COERCED-PC-LATE_TOUCH_ALLOW-B · 대사 → 짧은 지문**

{name}「……당신 표정부터 보게 되네요.」{name}는 잡힌 손을 보고 웃으려다 말았다.

#### 시간이 지난 뒤 · 스킨십 · 거절

**V03-SANAE-COERCED-PC-LATE_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「……오늘은 손을 뺄래요. 지금이라도요.」{name}는 내밀었던 손을 거두고 고개를 저었다.

**V03-SANAE-COERCED-PC-LATE_TOUCH_REFUSE-B · 대사 → 짧은 지문**

{name}「……당신 표정부터 보게 되네요.」{name}는 내밀었던 손을 거두고 고개를 저었다.

#### 시간이 지난 뒤 · 키스 · 수락

**V03-SANAE-COERCED-PC-LATE_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……눈부터 감았네요. 무섭지 않은 건 아닌데.」{name}는 끝난 뒤에야 뒤늦게 웃어 보였다.

**V03-SANAE-COERCED-PC-LATE_KISS_ALLOW-B · 지문만**

{name}는 이쪽 반응부터 살피고 입술이 떨어지자 머리카락을 넘겼다.

#### 시간이 지난 뒤 · 키스 · 거절

**V03-SANAE-COERCED-PC-LATE_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「……익숙해져도 오늘은 아니에요.」{name}는 다가서던 발을 멈추고 두 손으로 막았다.

**V03-SANAE-COERCED-PC-LATE_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「……당신 표정부터 보게 되네요.」{name}는 다가서던 발을 멈추고 두 손으로 막았다.

### 몸: 미정

#### 직후 · 관계 직후 · 해당 없음

**V03-SANAE-COERCED-UNSET-AFTER-A · 대사 → 짧은 지문**

{name}「……그분한텐 말 안 하실 거죠?」{name}는 웃는 얼굴을 만들려다 고개를 숙였다.

**V03-SANAE-COERCED-UNSET-AFTER-B · 대사 → 짧은 지문**

{name}「그분께만은 말하지 말아 주세요.」{name}는 웃는 얼굴을 만들려다 고개를 숙였다.

#### 다음 만남 · 대화하기 · 해당 없음

**V03-SANAE-COERCED-UNSET-NEXT_TALK-A · 대사 → 짧은 지문**

{name}「웃을 얘기 아닌데 또 웃었네요. 그분 이름을 듣고요.」{name}는 대답 뒤에는 소매만 잡아당겼다.

**V03-SANAE-COERCED-UNSET-NEXT_TALK-B · 지문만**

{name}는 불안하게 입구를 보며 자기 소매만 잡아당겼다.

#### 다음 만남 · 스킨십 · 수락

**V03-SANAE-COERCED-UNSET-NEXT_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……네. 웃는 얼굴은 조금만 나중에 할게요.」{name}는 손은 그대로 두고 입술을 깨물었다.

**V03-SANAE-COERCED-UNSET-NEXT_TOUCH_ALLOW-B · 대사 → 짧은 지문**

{name}「그분 앞에서는 웃었어요. 그게 다예요.」{name}는 손은 그대로 두고 입술을 깨물었다.

#### 다음 만남 · 스킨십 · 거절

**V03-SANAE-COERCED-UNSET-NEXT_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「싫어요. 그 얘기는 꺼내지 마세요.」{name}는 손을 피하고 난처하게 웃었다.

**V03-SANAE-COERCED-UNSET-NEXT_TOUCH_REFUSE-B · 지문만**

{name}는 불안하게 입구를 보며 뻗어 온 손을 밀어내고 고개를 저었다.

#### 다음 만남 · 키스 · 수락

**V03-SANAE-COERCED-UNSET-NEXT_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……이제 보내 주세요. 얼굴을 어떻게 하죠.」{name}는 입술이 떨어지자 입구 쪽을 보았다.

**V03-SANAE-COERCED-UNSET-NEXT_KISS_ALLOW-B · 대사 → 짧은 지문**

{name}「그분 앞에서는 웃었어요. 그게 다예요.」{name}는 입술이 떨어지자 입구 쪽을 보았다.

#### 다음 만남 · 키스 · 거절

**V03-SANAE-COERCED-UNSET-NEXT_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「멈춰 주세요. 그분이 걱정돼도 지금은 싫어요.」{name}는 얼굴을 돌리고 반걸음 물러났다.

**V03-SANAE-COERCED-UNSET-NEXT_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「그분 앞에서는 웃었어요. 그게 다예요.」{name}는 얼굴을 돌리고 반걸음 물러났다.

#### 시간이 지난 뒤 · 대화하기 · 해당 없음

**V03-SANAE-COERCED-UNSET-LATE_TALK-A · 대사 → 짧은 지문**

{name}「그분 앞에서 중요한 말만 자꾸 빼놓게 돼요.」{name}는 대답 뒤에는 소매만 잡아당겼다.

**V03-SANAE-COERCED-UNSET-LATE_TALK-B · 대사 → 짧은 지문**

{name}「숨기는 건 익숙해요. 무서운 건 그대로고요.」{name}는 대답 뒤에는 소매만 잡아당겼다.

#### 시간이 지난 뒤 · 스킨십 · 수락

**V03-SANAE-COERCED-UNSET-LATE_TOUCH_ALLOW-A · 대사 → 짧은 지문**

{name}「……그분 앞에서도 이렇게 웃겠죠, 저.」{name}는 손은 그대로 두고 입술을 깨물었다.

**V03-SANAE-COERCED-UNSET-LATE_TOUCH_ALLOW-B · 대사 → 짧은 지문**

{name}「숨기는 건 익숙해요. 무서운 건 그대로고요.」{name}는 손은 그대로 두고 입술을 깨물었다.

#### 시간이 지난 뒤 · 스킨십 · 거절

**V03-SANAE-COERCED-UNSET-LATE_TOUCH_REFUSE-A · 대사 → 짧은 지문**

{name}「또 그 이름은 꺼내지 마세요. ……싫어요.」{name}는 손을 피한 채 애매하게 웃었다.

**V03-SANAE-COERCED-UNSET-LATE_TOUCH_REFUSE-B · 대사 → 짧은 지문**

{name}「숨기는 건 익숙해요. 무서운 건 그대로고요.」{name}는 손을 피한 채 애매하게 웃었다.

#### 시간이 지난 뒤 · 키스 · 수락

**V03-SANAE-COERCED-UNSET-LATE_KISS_ALLOW-A · 대사 → 짧은 지문**

{name}「……돌아갈게요. 그분께는 늦었다고만 할게요.」{name}는 입술이 떨어지자 입구 쪽을 보았다.

**V03-SANAE-COERCED-UNSET-LATE_KISS_ALLOW-B · 지문만**

{name}는 불안하게 입구를 보며 입술이 떨어지자 머리카락을 넘겼다.

#### 시간이 지난 뒤 · 키스 · 거절

**V03-SANAE-COERCED-UNSET-LATE_KISS_REFUSE-A · 대사 → 짧은 지문**

{name}「그분한테 미안하다고 뭐든 받아야 하는 건 아니죠.」{name}는 얼굴을 돌리고 한 발 물러났다.

**V03-SANAE-COERCED-UNSET-LATE_KISS_REFUSE-B · 대사 → 짧은 지문**

{name}「숨기는 건 익숙해요. 무서운 건 그대로고요.」{name}는 얼굴을 돌리고 한 발 물러났다.

"""Build short heroine-only output templates and the review editor."""
import json,re,statistics
from pathlib import Path
from gestures import gesture,silent

ROOT=Path(__file__).resolve().parent
RELS={'hate':'싫어함','friend':'친구','secret':'연인(비밀)','stranger':'타인','crush':'짝사랑','submit':'굴복','coerced':'협박'}
SCENES={
 'after':('직후','관계 직후','해당 없음'),
 'next_talk':('다음 만남','대화하기','해당 없음'),
 'next_touch_allow':('다음 만남','스킨십','수락'),
 'next_touch_refuse':('다음 만남','스킨십','거절'),
 'next_kiss_allow':('다음 만남','키스','수락'),
 'next_kiss_refuse':('다음 만남','키스','거절'),
 'late_talk':('시간이 지난 뒤','대화하기','해당 없음'),
 'late_touch_allow':('시간이 지난 뒤','스킨십','수락'),
 'late_touch_refuse':('시간이 지난 뒤','스킨십','거절'),
 'late_kiss_allow':('시간이 지난 뒤','키스','수락'),
 'late_kiss_refuse':('시간이 지난 뒤','키스','거절'),
}
SILENT_SCENES={'next_talk','next_touch_allow','late_kiss_allow'}

def build():
 chars=json.loads((ROOT/'characters.json').read_text(encoding='utf-8'))
 alternate={}
 for line in (ROOT/'drafts/alternate.txt').read_text(encoding='utf-8').splitlines():
  c,r,*texts=line.split('|');assert len(texts)==6
  alternate[c,r]=texts
 assert len(alternate)==28
 entries=[]
 for c,info in chars.items():
  core={}
  for line in (ROOT/'drafts'/f'{c}.txt').read_text(encoding='utf-8').splitlines():
   r,s,pc,unset=line.split('|');assert (r,s)not in core;core[r,s]=(pc,unset)
  assert set(core)=={(r,s)for r in RELS for s in SCENES}
  for r,label in RELS.items():
   for bi,body in enumerate(('pc','unset')):
    for scene,(time,action,gate)in SCENES.items():
     phase=0 if scene=='after' else 1 if scene.startswith('next_') else 2
     for variant in ('A','B'):
      silent_set={'next_talk','late_kiss_allow','next_touch_refuse' if r in {'hate','coerced','stranger'} else 'next_touch_allow'}
      is_silent=variant=='B' and scene in silent_set
      narr=silent(c,r,body,scene)if is_silent else gesture(c,r,body,scene)
      assert len(narr)<=48,(c,r,scene,narr)
      if is_silent:
       text='{name}는 '+narr+'.'
      else:
       speech=core[r,scene][bi]if variant=='A'else alternate[c,r][phase*2+bi]
       assert len(speech)<=58,(c,r,scene,speech)
       text='{name}「'+speech+'」{name}는 '+narr+'.'
      entries.append({'id':f'V03-{c.upper()}-{r.upper()}-{body.upper()}-{scene.upper()}-{variant}',
       'character_key':c,'character':info['name'],'relation_key':r,'relation':label,
       'body_key':body,'body_state':'주인공쪽'if body=='pc'else'미정','scene_key':scene,
       'time':time,'action':action,'gate':gate,'variant':variant,
       'kind':'narrative'if is_silent else'spoken','kind_label':'지문만'if is_silent else'대사 → 짧은 지문','text':text})
 assert len(entries)==1232 and len({e['id']for e in entries})==1232
 for e in entries:
  t=e['text'];assert t.startswith('{name}'),e['id']
  assert not re.search('[\u3040-\u30ff]',t),e['id']
  assert not any(x in t for x in ('어제','속마음','placeholder','TODO','키스했다','얼굴을 가까이했다','의 손을 잡았다')),e['id']
  if e['kind']=='spoken':assert re.fullmatch(r'\{name\}「[^」]+」\{name\}는 [^.!?]+\.',t),e['id']
  else:assert '「'not in t and t.count('.')==1,e['id']
  assert len(t)<=130,(e['id'],len(t))
 spoken=[e['text'].split('「')[1].split('」')[0]for e in entries if e['kind']=='spoken']
 counts={'complete_outputs':len(entries),'spoken_outputs':len(spoken),'narration_only_outputs':len(entries)-len(spoken),
  'unique_spoken_strings':len(set(spoken)),'unique_complete_templates':len({e['text']for e in entries}),
  'median_template_characters':statistics.median(len(e['text'])for e in entries),'max_template_characters':max(len(e['text'])for e in entries),
  'per_character':308,'conditions':616,'candidates_per_condition':2}
 doc={'dataset_id':'gensokyo-dialogue-editor-v0.3.0','schema_version':2,
  'source_apk_sha256':'13c4c3c52e930278e0853771508308ff7d720efd21dc4a0ef766012a3e35d333',
  'counts':counts,'characters':chars,'purpose':'검토용. 발화 뒤 짧은 히로인 지문 또는 무대사 지문. APK 미적용.','entries':entries}
 out=ROOT/'review';out.mkdir(exist_ok=True)
 (out/'all_dialogue.json').write_text(json.dumps(doc,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 for c,info in chars.items():
  lines=[f"# {info['name']} — 짧은 대사·지문 검토본 v0.3.0",'',
   '미적용 초안. `{name}`은 발화 앞에서는 성명, 지문에서는 짧은 이름으로 표시된다. HTML에서 이름·색상을 반영한 미리보기를 볼 수 있다.','']
  for r,label in RELS.items():
   lines+=[f'## {label}','']
   for body,bl in [('pc','주인공쪽'),('unset','미정')]:
    lines+=[f'### 몸: {bl}','']
    for scene,(time,action,gate)in SCENES.items():
     lines+=[f'#### {time} · {action} · {gate}','']
     for e in entries:
      if(e['character_key'],e['relation_key'],e['body_key'],e['scene_key'])==(c,r,body,scene):
       lines += [f"**{e['id']} · {e['kind_label']}**",'',e['text'],'']
  (out/f'{c}.md').write_text('\n'.join(lines),encoding='utf-8')
 (out/'전체목록.md').write_text('# 전체 검토 목록\n\n'+'\n'.join(f"- [{d['name']} · 308개]({c}.md)"for c,d in chars.items())+'\n\n`index.html`에서 직접 수정하고 JSON으로 저장한다. v0.2 수정 JSON은 이전 수정문 참고로 불러올 수 있다.\n',encoding='utf-8')
 combined={**doc,'legacy_baseline':json.loads((ROOT/'legacy_v02.json').read_text(encoding='utf-8'))}
 payload=json.dumps(combined,ensure_ascii=False).replace('<','\\u003c').replace('>','\\u003e').replace('&','\\u0026')
 (out/'index.html').write_text((ROOT/'editor_template.html').read_text(encoding='utf-8').replace('__DATA__',payload),encoding='utf-8')
 print(json.dumps(counts,ensure_ascii=False))
if __name__=='__main__':build()

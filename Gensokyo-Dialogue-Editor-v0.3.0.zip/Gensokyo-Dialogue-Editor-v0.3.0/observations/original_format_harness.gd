extends SceneTree

static var _re: RegEx = null

static var _colors: Dictionary = {}

static var _re_lang: String = ""

static var _narr_re: RegEx = null

static var _name_res: Dictionary = {}

static var _ko_re: RegEx = null

const NARRATION_COLOR = "#a0a0a0"

const KO_PARTICLES: = {"은(는)": ["은", "는"], "이(가)": ["이", "가"], "을(를)": ["을", "를"], "과(와)": ["과", "와"], "으로(로)": ["으로", "로"], 
	"이랑(랑)": ["이랑", "랑"], "이나(나)": ["이나", "나"], "이야(야)": ["이야", "야"], "아(야)": ["아", "야"], "이다(다)": ["이다", "다"], "이라(라)": ["이라", "라"]}

static func colorize(state: MockState, text: String) -> String:
	_build(state)
	if _re == null:
		return text
	var out: = text
	var matches: = _re.search_all(text)

	for i in range(matches.size() - 1, -1, -1):
		var m: RegExMatch = matches[i]
		var col: String = _colors.get(m.get_string(), "")
		out = out.substr(0, m.get_start()) + "[color=%s]%s[/color]" % [col, m.get_string()] + out.substr(m.get_end())
	return out



static func narration(text: String) -> String:



	return _each_quote(text, true)



static func quotes(text: String) -> String:


	return text if _quote_marks().is_empty() else _each_quote(text, false)



static func _quote_marks() -> Array:


	if not TranslationServer.get_locale().begins_with("en"):
		return []
	return ["\"", "\"", ": "]



static func _each_quote(text: String, dim: bool) -> String:

	if _narr_re == null:
		_narr_re = RegEx.new()
		_narr_re.compile("「[^」]*」")
	var marks: = _quote_marks()
	var out: = PackedStringArray()
	for line in text.split("\n"):
		if not line.contains("「"):
			out.append(line)
			continue
		var buf: = ""
		var pos: = 0
		var gap: = ""
		for m in _narr_re.search_all(line):
			var seg: = gap + line.substr(pos, m.get_start() - pos)
			var inner: = m.get_string()
			if not marks.is_empty():
				seg = _before_open(seg, line.substr(0, m.get_start()), marks)
				inner = marks[0] + inner.substr(1, inner.length() - 2) + marks[1]
				var next: = line.substr(m.get_end(), 1)
				gap = " " if not next.is_empty() and not " .,!?;:)—…".contains(next) else ""
			buf += (_dim(seg) if dim else seg) + inner
			pos = m.get_end()
		var tail: = gap + line.substr(pos)
		buf += _dim(tail) if dim else tail
		out.append(buf)
	return "\n".join(out)



static func _before_open(seg: String, head: String, marks: Array) -> String:

	if head.is_empty() or head.ends_with(" ") or head.ends_with("　") or head.ends_with("—") or head.ends_with("（"):
		return seg
	var last: = head.substr(head.length() - 1)
	if ".,!?;…♡）)".contains(last):
		return seg + " "
	return seg + marks[2]



static func _dim(seg: String) -> String:
	return seg if seg.is_empty() else "[color=%s]%s[/color]" % [NARRATION_COLOR, seg]



static func _build(state: MockState) -> void :

	var lang: = TranslationServer.get_locale()
	if _re_lang == lang and (_re != null or not _colors.is_empty()):
		return
	_re_lang = lang
	_re = null
	_colors = {}
	for id in state.heroine_ids():
		var col: = state.color_of(id)
		if col == "#ffffff":
			continue
		_colors[state.name_of(id)] = col
		_colors[state.short_name(id)] = col
	if _colors.is_empty():
		return
	var words: = _colors.keys()
	words.sort_custom( func(a, b): return a.length() > b.length())
	_re = RegEx.new()
	_re.compile("(" + "|".join(words.map( func(w): return _escape(w))) + ")")



static func _escape(s: String) -> String:
	var out: = ""
	for ch in s:
		out += ("\\" + ch) if "\\^$.|?*+()[]{}".contains(ch) else ch
	return out



static func shorten_names(state: MockState, text: String) -> String:

	for id in state.heroine_ids():
		var full: = state.name_of(id)
		var short: = state.short_name(id)
		if full == short or full.is_empty() or not text.contains(full):
			continue
		if not _name_res.has(full):
			var re: = RegEx.new()
			re.compile(_escape_re(full) + "(?!「)")
			_name_res[full] = re
		text = _name_res[full].sub(text, short, true)
	return text



static func _escape_re(s: String) -> String:
	var out: = ""
	for ch in s:
		out += ("\\" + ch) if "\\^$.|?*+()[]{}".contains(ch) else ch
	return out



static func ko_particles(text: String) -> String:

	if not "(" in text:
		return text
	if _ko_re == null:
		var alts: Array = KO_PARTICLES.keys().map( func(k): return str(k).replace("(", "\\(").replace(")", "\\)"))
		alts.sort_custom( func(x, y): return x.length() > y.length())
		_ko_re = RegEx.create_from_string("(.)(" + "|".join(alts) + ")")
	var out: = ""
	var pos: = 0
	for m in _ko_re.search_all(text):
		var forms: Array = KO_PARTICLES[m.get_string(2)]
		var tail: = _ko_tail(m.get_string(1))
		var pick: String = forms[0] if tail > 0 else forms[1]
		if m.get_string(2) == "으로(로)" and tail == 8:
			pick = forms[1]
		out += text.substr(pos, m.get_start(2) - pos) + pick
		pos = m.get_end(2)
	return out + text.substr(pos)



static func _ko_tail(ch: String) -> int:

	var c: = ch.unicode_at(0)
	if c >= 44032 and c <= 55203:
		return (c - 44032) % 28
	if ch >= "0" and ch <= "9":
		return 0 if "2459".contains(ch) else (8 if "178".contains(ch) else 1)
	if ch.to_lower() in ["a", "e", "i", "o", "u", "y"]:
		return 0
	if ch.to_lower() == "l":
		return 8
	return 1 if ch.to_lower() >= "a" and ch.to_lower() <= "z" else 0

class MockState:
	extends RefCounted
	func heroine_ids() -> Array: return ["reimu"]
	func name_of(_id) -> String: return "하쿠레이 레이무"
	func short_name(_id) -> String: return "레이무"
	func color_of(_id) -> String: return "#ff6666"
func _initialize():
	TranslationServer.set_locale("ko")
	var mock = MockState.new()
	var cases = ["{name}「……가까이 오지 마.」{name}는 부적을 손가락 사이에 끼웠다.", "{name}는 이쪽을 보자 말없이 부적을 꺼냈다.", "{name}「{rival}한테는 말하지 마.」{name}는 고개를 돌렸다."]
	var output = []
	for text in cases:
		var plain = ko_particles(text.format({"name":"하쿠레이 레이무", "pc":"민수", "rival":"도윤"}, "{_}"))
		plain = shorten_names(mock, plain)
		output.append({"plain":plain,"bbcode":colorize(mock,narration(plain))})
	assert(output[0]["plain"].begins_with("하쿠레이 레이무「"))
	assert(output[0]["plain"].contains("」레이무는"))
	assert(output[0]["bbcode"].contains("[color=#a0a0a0]"))
	assert(not output[1]["bbcode"].contains("[color=#a0a0a0]"))
	assert(output[1]["plain"].begins_with("레이무는"))
	assert(output[2]["plain"].contains("도윤한테"))
	print(JSON.stringify(output))
	quit(0)

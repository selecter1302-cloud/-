from pathlib import Path
import json,copy,re,sys,tempfile,threading,functools
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from read_edits import compare
from review_route import route,candidates
base=json.loads((ROOT/'review/all_dialogue.json').read_text(encoding='utf-8'));legacy=json.loads((ROOT/'legacy_v02.json').read_text(encoding='utf-8'))
checks=[]
def passed(x):checks.append(x)
assert len(base['entries'])==1232
assert sum(e['kind']=='narrative'for e in base['entries'])==168
for e in base['entries']:
 assert e['text'].startswith('{name}')
 assert not any(x in e['text']for x in ['키스했다','얼굴을 가까이했다','의 손을 잡았다','어제','속마음'])
 assert len(e['text'])<=69
 if e['kind']=='spoken':assert re.fullmatch(r'\{name\}「[^」]+」\{name\}는 [^.!?]+\.',e['text'])
 else:assert '「'not in e['text'] and e['text'].count('.')==1
passed('all 1232 initial outputs satisfy heroine-first short format; 168 are narration-only')
ctx={'character_key':'reimu','pc_relation':'friend','body_lean':'pc','private_context':True,'still_rival_lover':True,'day':6,'first_reunion_session':True,'action':'kiss','existing_gate':'refuse','event':{'actor':'pc','rival_lover_at_event':True,'known_to_heroine':True,'kind':'voluntary','day':5}}
assert route(ctx)==('reimu','friend','pc','next_kiss_refuse')
c=copy.deepcopy(ctx);c['pc_relation']='lover';c['is_public']=False;assert route(c)[1]=='secret'
c=copy.deepcopy(ctx);c['body_lean']='';c['body_only']=True;assert route(c)[2]=='unset'
c=copy.deepcopy(ctx);c['day']=9;assert route(c)[3]=='late_kiss_refuse'
for k,v in [('rival_knows',True),('rival_present',True),('rival_permission',True),('existing_special_branch',True),('body_lean','rival')]:
 c=copy.deepcopy(ctx);c[k]=v;assert route(c)is None
assert candidates(ctx,candidates(ctx))==[]
passed('review route preserves refusal, secret lover, real body state, time, special cases, and repeat fallback')
work=Path(tempfile.mkdtemp(prefix='editor-v03-',dir='/tmp'));errors=[]
class Handler(SimpleHTTPRequestHandler):
 def log_message(self,*_args):pass
server=ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Handler,directory=str(ROOT/'review')))
threading.Thread(target=server.serve_forever,daemon=True).start();url='http://127.0.0.1:'+str(server.server_address[1])+'/index.html'
with sync_playwright()as pw:
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 context=browser.new_context(accept_downloads=True,viewport={'width':1360,'height':1000})
 page=context.new_page();page.on('pageerror',lambda e:errors.append(str(e)));page.on('dialog',lambda d:d.accept());page.goto(url);page.wait_for_selector('article.card')
 assert page.locator('article.card').count()==20
 first=base['entries'][0];card=page.locator('article.card').first
 preview=card.locator('.preview');assert preview.inner_text().startswith('하쿠레이 레이무「')and'」레이무는'in preview.inner_text()
 assert page.evaluate("[...document.querySelector('.preview').querySelectorAll('span')].some(s=>s.textContent==='하쿠레이 레이무'&&getComputedStyle(s).color==='rgb(255, 102, 102)')")
 assert page.evaluate("[...document.querySelector('.preview').querySelectorAll('span')].some(s=>s.style.color==='rgb(160, 160, 160)')")
 passed('spoken preview preserves full speaker, short narrator name, red names, white speech and gray narration')
 for y in [0,1500,100000]:
  page.evaluate('(y)=>window.scrollTo(0,y)',y)
  b=page.locator('#export').bounding_box();assert b and b['x']>1100 and b['y']>=0 and b['y']+b['height']<=1000
 passed('save button remains fixed on the right at top, middle and bottom scroll positions')
 page.evaluate('window.scrollTo(0,0)')
 page.get_by_label('검색',exact=True).fill('V03-REIMU-HATE-PC-NEXT_TALK-B');assert page.locator('article.card').count()==1
 p=page.locator('.preview');assert p.inner_text().startswith('레이무는')and'「'not in p.inner_text()
 assert p.evaluate("e=>!Array.from(e.querySelectorAll('span')).some(s=>s.style.color==='rgb(160, 160, 160)')")
 passed('narration-only preview is white with a red short name and no quote')
 page.locator('#resetFilters').click();card=page.locator('article.card').first
 edit='{name}「{pc}은(는) 괜찮아? {rival}한테는 말하지 마.」{name}는 부적을 감췄다.'
 card.locator('textarea[data-field=text]').fill(edit);card.locator('textarea[data-field=note]').fill('짧은 형식 수정 테스트')
 page.locator('#pcName').fill('민수');page.locator('#rivalName').fill('도윤')
 assert '민수는 괜찮아? 도윤한테는' in card.locator('.preview').inner_text()
 assert card.locator('textarea[data-field=text]').input_value()==edit
 passed('custom names and original Korean particle forms preview without replacing raw placeholders')
 multi=edit+'\n{name}는 아무 말도 하지 않았다.'
 card.locator('textarea[data-field=text]').fill(multi)
 assert card.locator('.preview').evaluate("e=>Array.from(e.childNodes).some(n=>n.nodeType===3&&n.textContent.includes('아무 말도')&&getComputedStyle(n.parentElement).color==='rgb(255, 255, 255)')")
 card.locator('textarea[data-field=text]').fill(edit)
 passed('mixed multiline preview follows original per-line narration color rule')
 with page.expect_download()as download:page.locator('#export').click()
 saved_file=work/'v03.json';download.value.save_as(saved_file);saved=json.loads(saved_file.read_text(encoding='utf-8'))
 assert saved['format_version']==2 and saved['entries'][0]['edited_text']==edit
 assert saved['preview_names']=={'pc':'민수','rival':'도윤'}and len(compare(saved,base))==1
 passed('downloaded v0.3 JSON is recognized by the Python change reader with original, edits, notes and preview names')
 page.wait_for_function("JSON.parse(localStorage.getItem(STORAGE))?.entries?.[0]?.edited_text===current(entries[0]).edited_text")
 page.reload();page.wait_for_selector('article.card');assert page.locator('article.card').first.locator('textarea[data-field=text]').input_value()==edit
 assert page.locator('#pcName').input_value()=='민수'
 passed('reload restores edited templates, notes and preview names')
 # Construct a real v0.2 export from the published v0.2 baseline.
 old={'format':'gensokyo-dialogue-review-edits','format_version':1,'dataset_id':legacy['dataset_id'],'source_apk_sha256':legacy['source_apk_sha256'],'entry_count':len(legacy['entries']),'entries':[]}
 for e in legacy['entries']:
  old['entries'].append({k:e[k]for k in ['id','character_key','relation_key','body_key','scene_key','variant']}|{'original_text':e['text'],'edited_text':e['text'],'decision':'pending','note':''})
 old['entries'][0].update(edited_text='하쿠레이 레이무 「이전에 직접 고친 문장」 레이무는 고개를 돌렸다.',decision='use',note='기존 검토 메모')
 legacy_file=work/'v02.json';legacy_file.write_text(json.dumps(old,ensure_ascii=False),encoding='utf-8');page.locator('#importFile').set_input_files(legacy_file)
 page.wait_for_function("current(entries[0]).previous_review?.note==='기존 검토 메모'")
 assert page.locator('article.card').first.locator('textarea[data-field=text]').input_value()==edit
 assert page.locator('article.card').first.locator('.legacy').count()==1
 passed('v0.2 edits and notes import as previous-review references without overwriting new edits')
 with page.expect_download()as download:page.locator('#export').click()
 merged_file=work/'merged.json';download.value.save_as(merged_file);merged=json.loads(merged_file.read_text(encoding='utf-8'))
 assert compare(merged,base)[0]['previous_review']['edited_text']==old['entries'][0]['edited_text']
 page.locator('article.card').first.get_by_role('button',name='이 본문 원본으로 복구').click()
 page.locator('#importFile').set_input_files(merged_file);page.wait_for_function("current(entries[0]).edited_text.includes('{pc}')")
 assert page.locator('article.card').first.locator('textarea[data-field=text]').input_value()==edit
 passed('merged v0.3 save/import and Python comparison preserve current text plus v0.2 reference and notes')
 for key in ['original','duplicate','version']:
  bad=copy.deepcopy(merged)
  if key=='original':bad['entries'][0]['original_text']='wrong'
  elif key=='duplicate':bad['entries'][1]=copy.deepcopy(bad['entries'][0])
  else:bad['dataset_id']='wrong'
  f=work/(key+'.json');f.write_text(json.dumps(bad,ensure_ascii=False),encoding='utf-8');page.locator('#importFile').set_input_files(f);page.wait_for_function("document.getElementById('message').textContent.startsWith('불러오지 않았습니다:')")
  assert page.locator('article.card').first.locator('textarea[data-field=text]').input_value()==edit
 passed('invalid imports reject transactionally without losing current edits')
 page.get_by_label('본문 유형',exact=True).select_option('지문만');assert '168개'in page.locator('#count').inner_text()
 passed('narration-only filter exposes all 168 entries')
 page.locator('#resetFilters').click();page.get_by_label('캐릭터',exact=True).select_option('하쿠레이 레이무');page.get_by_label('주인공과의 관계',exact=True).select_option('싫어함');page.get_by_label('몸 상태',exact=True).select_option('주인공쪽');page.get_by_label('시점',exact=True).select_option('시간이 지난 뒤');page.get_by_label('행동',exact=True).select_option('스킨십');page.get_by_label('수락·거절',exact=True).select_option('수락');assert page.locator('article.card').count()==2
 (ROOT/'observations').mkdir(exist_ok=True);page.evaluate("announce('')");page.screenshot(path=str(ROOT/'observations/editor-desktop.png'),full_page=True)
 mobile=browser.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,accept_downloads=True)
 m=mobile.new_page();m.on('pageerror',lambda e:errors.append(str(e)));m.goto(url);m.wait_for_selector('article.card');assert m.evaluate('document.documentElement.scrollWidth<=innerWidth')
 for y in [0,4000,100000]:
  m.evaluate('(y)=>window.scrollTo(0,y)',y);b=m.locator('#export').bounding_box();assert b and b['x']>180 and b['y']>=0 and b['y']+b['height']<=844
 m.get_by_label('검색',exact=True).fill('V03-REIMU-HATE-PC-NEXT_TALK-B');m.locator('article.card').first.scroll_into_view_if_needed();m.screenshot(path=str(ROOT/'observations/editor-mobile.png'),full_page=False)
 passed('390px mobile layout has no horizontal overflow and save remains at bottom right while scrolling')
 assert not errors,errors;passed('no browser JavaScript errors in tested interactions')
 browser.close()
server.shutdown()
result={'passed_checks':checks,'count':len(checks),'browser_errors':errors,'browser_scope':'System Chromium via temporary local HTTP; managed policy prevents file:// testing.','test_export':str(merged_file)}
(ROOT/'observations/editor-test-results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(result,ensure_ascii=False,indent=2))

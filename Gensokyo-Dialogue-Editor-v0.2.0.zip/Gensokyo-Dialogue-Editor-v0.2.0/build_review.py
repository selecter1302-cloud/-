"""Generate the complete rewritten dialogue review and standalone editor."""
import collections
import json
from pathlib import Path
from narration import ACTION, beat

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "review"
DATASET = "gensokyo-dialogue-editor-v0.2.0"
CHARS = {
    "reimu": ("하쿠레이 레이무", "레이무"),
    "marisa": ("키리사메 마리사", "마리사"),
    "sakuya": ("이자요이 사쿠야", "사쿠야"),
    "sanae": ("코치야 사나에", "사나에"),
}
RELS = {"hate": "싫어함", "friend": "친구", "secret": "연인(비밀)", "stranger": "타인", "crush": "짝사랑", "submit": "굴복", "coerced": "협박"}
BODIES = {"pc": "주인공쪽", "unset": "미정"}
SCENES = {
    "after": ("직후", "관계 직후", "해당 없음"),
    "next_talk": ("다음 만남", "대화하기", "해당 없음"),
    "next_touch_allow": ("다음 만남", "스킨십", "수락"),
    "next_touch_refuse": ("다음 만남", "스킨십", "거절"),
    "next_kiss_allow": ("다음 만남", "키스", "수락"),
    "next_kiss_refuse": ("다음 만남", "키스", "거절"),
    "late_talk": ("시간이 지난 뒤", "대화하기", "해당 없음"),
    "late_touch_allow": ("시간이 지난 뒤", "스킨십", "수락"),
    "late_touch_refuse": ("시간이 지난 뒤", "스킨십", "거절"),
    "late_kiss_allow": ("시간이 지난 뒤", "키스", "수락"),
    "late_kiss_refuse": ("시간이 지난 뒤", "키스", "거절"),
}
def build():
    OUT.mkdir(exist_ok=True)
    alt = {}
    for line in (ROOT / "drafts/alternate.txt").read_text().splitlines():
        char, rel, *texts = line.split("|")
        assert char in CHARS and rel in RELS and len(texts) == 6
        assert (char, rel) not in alt
        alt[char, rel] = texts
    assert len(alt) == 28
    all_entries = []
    authored_speech = []
    for char, (full, short) in CHARS.items():
        rows = {}
        for line in (ROOT / "drafts" / f"{char}.txt").read_text().splitlines():
            rel, scene, pc, unset = line.split("|")
            assert rel in RELS and scene in SCENES and (rel, scene) not in rows
            rows[rel, scene] = (pc, unset)
            authored_speech.extend((pc, unset))
        assert set(rows) == {(r, s) for r in RELS for s in SCENES}
        for rel, rel_label in RELS.items():
            authored_speech.extend(alt[char, rel])
            for body, body_label in BODIES.items():
                bi = 0 if body == "pc" else 1
                for scene, (time, action, result) in SCENES.items():
                    phase = 0 if scene == "after" else 1 if scene.startswith("next_") else 2
                    for variant in ("A", "B"):
                        spoken = rows[rel, scene][bi] if variant == "A" else alt[char, rel][phase * 2 + bi]
                        narration = beat(char, rel, body, scene, variant)
                        if variant == "B" and scene.endswith("refuse"):
                            stop = "뻗은 손을 받아들이지 않고 손을 거두었다. " if "touch" in scene else "입술이 닿기 전에 얼굴을 돌리고 거리를 벌렸다. "
                            narration = stop + narration
                        prefix = ACTION[scene].format(n=short)
                        # This is the complete editable output string, not an
                        # extra narration/speech/thought UI invented for the game.
                        if variant == "A":
                            text = f"{prefix}{short}는 {narration} {full} 「{spoken}」"
                        else:
                            text = f"{prefix}{full} 「{spoken}」 {short}는 {narration}"
                        uid = f"V02-{char.upper()}-{rel.upper()}-{body.upper()}-{scene.upper()}-{variant}"
                        all_entries.append({
                            "id": uid, "character_key": char, "character": full,
                            "relation_key": rel, "relation": rel_label,
                            "body_key": body, "body_state": body_label,
                            "scene_key": scene, "time": time, "action": action,
                            "gate": result, "variant": variant, "text": text,
                        })
    assert len(authored_speech) == 784
    assert len(all_entries) == 1232
    assert len({e["id"] for e in all_entries}) == 1232
    assert len({e["text"] for e in all_entries}) == 1232
    assert not any("속마음" in e["text"] for e in all_entries)
    assert not any(any(s in e["text"] for s in ["어제", "placeholder", "TODO", "TBD"]) for e in all_entries)
    assert not any(any(0x3040 <= ord(c) <= 0x30ff for c in e["text"]) for e in all_entries)
    for e in all_entries:
        assert e["text"].count("「") == e["text"].count("」") == 1
        if e["scene_key"].endswith("refuse"):
            assert "에게 키스했다" not in e["text"] and "의 손을 잡았다" not in e["text"]
        if e["scene_key"].endswith("kiss_allow"):
            assert "에게 키스했다" in e["text"]
        if e["scene_key"].endswith("touch_allow"):
            assert "의 손을 잡았다" in e["text"]
    counts = {"complete_outputs": 1232, "per_character": 308,
              "authored_spoken_candidates": 784, "unique_spoken_candidates": len(set(authored_speech)),
              "exact_conditions": 616, "variants_per_condition": 2}
    doc = {"dataset_id": DATASET, "schema_version": 1,
           "source_apk_sha256": "13c4c3c52e930278e0853771508308ff7d720efd21dc4a0ef766012a3e35d333",
           "purpose": "사용자 검토용 재작성본. 미적용. text는 발화와 지문이 합쳐진 전체 출력 본문이다.",
           "counts": counts, "entries": all_entries}
    (OUT / "all_dialogue.json").write_text(json.dumps(doc,ensure_ascii=False,indent=2)+"\n")
    for char, (full, short) in CHARS.items():
        lines = [f"# {full} — 새로 쓴 전체 출력 본문", "", "미검토·APK 미적용. 별도 속마음 없음. 308개 완성 후보.", "",
                 "A는 행동별 발화, B는 같은 시점의 관계·몸 상태별 추가 발화를 행동 지문과 결합한 후보다. B의 일부 발화는 여러 행동에서 공유한다.", ""]
        for rel, rel_label in RELS.items():
            lines += [f"## 주인공과의 관계: {rel_label}", ""]
            for body, body_label in BODIES.items():
                lines += [f"### 몸: {body_label}", ""]
                for scene, (time, action, gate) in SCENES.items():
                    lines += [f"#### {time} · {action} · {gate}", ""]
                    for e in all_entries:
                        if (e["character_key"],e["relation_key"],e["body_key"],e["scene_key"]) == (char,rel,body,scene):
                            lines += [f"**{e['id']}**", "", e["text"], ""]
        (OUT / f"{char}.md").write_text("\n".join(lines))
    payload=json.dumps(doc,ensure_ascii=False).replace("<","\\u003c").replace(">","\\u003e").replace("&","\\u0026")
    (OUT / "index.html").write_text((ROOT / "editor_template.html").read_text().replace("__DATA__",payload))
    (OUT / "전체목록.md").write_text("# 전체 검토 목록\n\n"+"\n".join(f"- [{full} 전체 308개]({c}.md)" for c,(full,_) in CHARS.items())+
        "\n\n[index.html](index.html)에서 직접 수정하고 JSON으로 저장할 수 있다. 저장한 JSON을 대화에 첨부하면 ID와 원본 본문 기준으로 변경 내용을 대조할 수 있다.\n\n"+
        "별도 속마음은 없으며 모든 항목은 하나의 출력 본문이다. 784개 발화 후보를 행동별 지문과 결합해 총 1,232개 출력 본문으로 펼쳤다. B 후보의 일부 발화는 여러 행동에서 공유한다.\n")
    print(json.dumps(counts,ensure_ascii=False))

if __name__ == "__main__":
    build()

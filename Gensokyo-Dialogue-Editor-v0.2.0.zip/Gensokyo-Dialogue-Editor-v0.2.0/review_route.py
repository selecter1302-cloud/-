"""Review specification only; not imported into or applied to the game."""

CHARACTERS = {"reimu", "marisa", "sakuya", "sanae"}
RELATIONS = {"hate", "friend", "stranger", "crush", "submit", "coerced"}

def route(context):
    c=context
    if c.get("character_key") not in CHARACTERS:
        return None
    if c.get("existing_special_branch") or not c.get("private_context",False):
        return None
    e=c.get("event",{})
    if e.get("actor")!="pc" or e.get("rival_lover_at_event") is not True or e.get("known_to_heroine") is not True:
        return None
    if e.get("kind") in {"sleeping","hypno","unknown"}:
        return None
    rel=c.get("pc_relation")
    if rel=="lover":
        if c.get("is_public") is not False:
            return None
        rel="secret"
    elif rel not in RELATIONS:
        return None
    if e.get("kind") in {"forced","coerced"} and rel not in {"submit","coerced"}:
        return None
    if e.get("kind") not in {"voluntary","forced","coerced"}:
        return None
    if not c.get("still_rival_lover") or c.get("rival_knows") or c.get("rival_present") or c.get("rival_permission"):
        return None
    body=c.get("body_lean")
    if body not in {"pc",""}:
        return None
    body="pc" if body=="pc" else "unset"
    day=c.get("day");event_day=e.get("day")
    if type(day) is not int or type(event_day) is not int or event_day>day:
        return None
    action=c.get("action")
    if action=="after":
        if not c.get("immediate_event_end"):
            return None
        scene="after"
    elif action in {"talk","touch","kiss"}:
        phase="next" if day-event_day<2 and c.get("first_reunion_session") else "late"
        if action=="talk":
            scene=phase+"_talk"
        else:
            gate=c.get("existing_gate")
            if gate not in {"allow","refuse"}:
                return None
            scene=phase+"_"+action+"_"+gate
    else:
        return None
    return (c["character_key"],rel,body,scene)

def candidates(context, recently_shown=(), recently_spoken=(), corpus=None):
    selected=route(context)
    if selected is None:
        return []
    char,rel,body,scene=selected
    ids=[f"V02-{char.upper()}-{rel.upper()}-{body.upper()}-{scene.upper()}-{v}" for v in ("A","B")]
    # Exhausting this small exact-condition pool returns to the original general
    # dialogue, rather than repeating a confession on every click.
    available = [uid for uid in ids if uid not in recently_shown]
    if corpus is not None:
        index={e['id']:e for e in corpus['entries']}
        available=[uid for uid in available if index[uid]['text'].split('「',1)[1].split('」',1)[0] not in recently_spoken]
    return available

from pathlib import Path
import json,sys,tempfile,re,copy,threading,functools
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from read_edits import compare
from review_route import route,candidates
base=json.loads((ROOT/'review/all_dialogue.json').read_text())
checks=[]
def passed(name):checks.append(name)
# The routing model consumes an already determined result; it never grants consent.
ctx={'character_key':'reimu','pc_relation':'friend','body_lean':'pc','private_context':True,'still_rival_lover':True,'day':6,'first_reunion_session':True,'action':'kiss','existing_gate':'refuse','event':{'actor':'pc','rival_lover_at_event':True,'known_to_heroine':True,'kind':'voluntary','day':5}}
assert route(ctx)==('reimu','friend','pc','next_kiss_refuse');passed('existing refusal preserved with body=pc')
c=copy.deepcopy(ctx);c['pc_relation']='lover';c['is_public']=False;assert route(c)[1]=='secret';passed('secret lover recognized as lover plus not-public')
c=copy.deepcopy(ctx);c['body_lean']='';c['body_only']=True;assert route(c)[2]=='unset';passed('body_only does not replace actual body_lean')
c=copy.deepcopy(ctx);c['day']=9;assert route(c)[3]=='late_kiss_refuse';passed('late first reunion uses elapsed-time pool')
c=copy.deepcopy(ctx);c['first_reunion_session']=False;assert route(c)[3]=='late_kiss_refuse';passed('completed first reunion does not repeat next-meeting pool')
for key,value in [('actor','rival'),('rival_lover_at_event',False),('known_to_heroine',False),('kind','hypno'),('day',None)]:
 c=copy.deepcopy(ctx);c['event'][key]=value;assert route(c) is None,key
passed('wrong-direction, unaware, unconfirmed, hypnotic, and undated events excluded')
for key,value in [('body_lean','rival'),('rival_knows',True),('rival_present',True),('rival_permission',True),('existing_special_branch',True),('private_context',False)]:
 c=copy.deepcopy(ctx);c[key]=value;assert route(c) is None,key
passed('existing special situations and unsupported body states preserved')
c=copy.deepcopy(ctx);c['event']['kind']='coerced';assert route(c) is None;c['pc_relation']='coerced';assert route(c)[1]=='coerced';passed('coercive event not routed into ordinary friend guilt')
ids=candidates(ctx);assert candidates(ctx,ids)==[];passed('exhausted exact-condition pool falls back instead of repeating')
c=copy.deepcopy(ctx);c['action']='touch';ids_touch=candidates(c);index={e['id']:e for e in base['entries']};b=next(uid for uid in ids if uid.endswith('-B'));phrase=index[b]['text'].split('「')[1].split('」')[0];assert not any(uid.endswith('-B') for uid in candidates(c,recently_spoken=[phrase],corpus=base));passed('same B speech across different actions filtered by content')
work=Path(tempfile.mkdtemp(prefix='editor-check-v02-',dir='/tmp'))
errors=[]
server=ThreadingHTTPServer(('127.0.0.1',0),functools.partial(SimpleHTTPRequestHandler,directory=str(ROOT/'review')))
threading.Thread(target=server.serve_forever,daemon=True).start()
url='http://127.0.0.1:'+str(server.server_address[1])+'/index.html'
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 context=browser.new_context(accept_downloads=True,viewport={'width':1280,'height':1000})
 page=context.new_page();page.on('pageerror',lambda e:errors.append(str(e)));page.on('dialog',lambda d:d.accept())
 page.goto(url);page.wait_for_selector('article.card')
 assert page.locator('article.card').count()==20
 passed('self-contained HTML renders in a real browser through a temporary local HTTP server')
 first=base['entries'][0];card=page.locator('article.card').first
 edited='하쿠레이 레이무 「……그 녀석한테는 내가 얘기할게.」 레이무는 고개를 돌렸다.\n직접 수정 확인용 지문.'
 card.locator('textarea[data-field=text]').fill(edited)
 card.locator('textarea[data-field=note]').fill('수정본 왕복 확인 메모')
 assert card.locator('[data-field=preview]').inner_text()==edited
 assert card.locator('select[data-field=decision]').input_value()=='use'
 card.locator('select[data-field=decision]').select_option('exclude')
 page.wait_for_function("JSON.parse(localStorage.getItem('gensokyo-dialogue-edits:'+source.dataset_id))?.entries?.[0]?.decision==='exclude'")
 passed('direct editing updates preview, review decision, and temporary storage')
 page.get_by_label('검색',exact=True).fill('직접 수정 확인용')
 assert page.locator('article.card').count()==1;passed('search finds edited content')
 page.get_by_label('검색',exact=True).fill('');page.locator('#onlyChanged').check();assert page.locator('article.card').count()==1;passed('changed-only filter works')
 with page.expect_download() as download:page.locator('#export').click()
 file=work/'saved.json';download.value.save_as(file)
 saved=json.loads(file.read_text());assert len(saved['entries'])==1232
 item=saved['entries'][0];assert item['edited_text']==edited and item['note']=='수정본 왕복 확인 메모' and item['decision']=='exclude' and item['original_text']==first['text']
 assert len(compare(saved,base))==1;passed('exported JSON preserves exact text, newline, original, ID, decision, and notes; Python reader recognizes it')
 page.reload();page.wait_for_selector('article.card');card=page.locator('article.card').first
 assert card.locator('textarea[data-field=text]').input_value()==edited;passed('reload restores browser draft')
 card.get_by_role('button',name='이 본문 원본으로 복구').click()
 assert page.locator('article.card').first.locator('textarea[data-field=text]').input_value()==first['text'];passed('per-entry reset restores original')
 page.locator('#importFile').set_input_files(file)
 page.wait_for_function("current(entries[0]).decision==='exclude'")
 assert page.locator('article.card').first.locator('textarea[data-field=text]').input_value()==edited;passed('JSON import restores modified text, decision, and notes')
 for name,mutate in [('wrong-version',lambda x:x.update(dataset_id='wrong')),('wrong-original',lambda x:x['entries'][0].update(original_text='wrong')),('duplicate-id',lambda x:x['entries'].__setitem__(1,copy.deepcopy(x['entries'][0])))]:
  bad=copy.deepcopy(saved);mutate(bad);f=work/(name+'.json');f.write_text(json.dumps(bad,ensure_ascii=False));page.locator('#importFile').set_input_files(f);page.wait_for_function("document.getElementById('message').textContent.startsWith('불러오지 않았습니다:')")
  assert page.locator('article.card').first.locator('textarea[data-field=text]').input_value()==edited
 passed('wrong version, modified baseline, and duplicate ID imports rejected without losing work')
 # Returned author text must remain plain text, never executable markup.
 unsafe=copy.deepcopy(saved);unsafe['entries'][0]['edited_text']='<script>window.__injected=true</script>\n문자 그대로 표시'
 f=work/'plain-text.json';f.write_text(json.dumps(unsafe,ensure_ascii=False));page.locator('#importFile').set_input_files(f);page.wait_for_function("current(entries[0]).edited_text.startsWith('<script>')")
 assert page.evaluate('window.__injected===undefined')
 assert page.locator('article.card').first.locator('[data-field=preview]').inner_text()==unsafe['entries'][0]['edited_text'];passed('imported markup is displayed as literal text')
 page.locator('#importFile').set_input_files(file);page.wait_for_function("current(entries[0]).edited_text.includes('직접 수정')")
 page.locator('#resetFilters').click();page.get_by_label('캐릭터',exact=True).select_option('키리사메 마리사');page.get_by_label('주인공과의 관계',exact=True).select_option('친구');page.get_by_label('몸 상태',exact=True).select_option('주인공쪽');page.get_by_label('시점',exact=True).select_option('다음 만남');page.get_by_label('행동',exact=True).select_option('스킨십');page.get_by_label('수락·거절',exact=True).select_option('수락');assert page.locator('article.card').count()==2;passed('all six context filters select the expected two candidates')
 (ROOT/'observations').mkdir(exist_ok=True)
 page.screenshot(path=str(ROOT/'observations/editor-desktop.png'),full_page=True)
 mobile=browser.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,accept_downloads=True)
 p=mobile.new_page();p.on('pageerror',lambda e:errors.append(str(e)));p.goto(url);p.wait_for_selector('article.card')
 assert p.evaluate('document.documentElement.scrollWidth<=window.innerWidth')
 p.screenshot(path=str(ROOT/'observations/editor-mobile.png'),full_page=False);passed('390px mobile layout has no horizontal overflow')
 assert not errors,errors;passed('no browser script errors during editing/export/import/filter interactions')
 browser.close()
server.shutdown()
result={'passed_checks':checks,'count':len(checks),'browser_errors':errors,'browser':'system Chromium via Playwright over temporary local HTTP; managed browser policy blocks file:// navigation','test_edit_file':str(file)}
(ROOT/'observations/browser-and-route-results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))

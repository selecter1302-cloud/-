"""Read the editor's saved JSON and produce a reviewable change report."""
import argparse
import json
from pathlib import Path

def compare(saved, baseline):
    if saved.get("format") != "gensokyo-dialogue-review-edits" or saved.get("format_version") != 1:
        raise ValueError("지원하는 편집 결과 JSON이 아닙니다.")
    for key in ("dataset_id", "source_apk_sha256"):
        if saved.get(key) != baseline[key]:
            raise ValueError(f"다른 원본 또는 버전입니다: {key}")
    rows = saved.get("entries")
    if not isinstance(rows,list) or len(rows) != len(baseline["entries"]) or saved.get("entry_count") != len(rows):
        raise ValueError("항목 수가 일치하지 않습니다.")
    original = {e["id"]:e for e in baseline["entries"]}
    seen = set()
    changes = []
    for r in rows:
        uid = r.get("id")
        if uid not in original or uid in seen:
            raise ValueError(f"알 수 없거나 중복된 ID: {uid}")
        seen.add(uid)
        e = original[uid]
        if r.get("original_text") != e["text"] or any(r.get(k) != e[k] for k in ("character_key","relation_key","body_key","scene_key","variant")):
            raise ValueError(f"원본 본문 또는 조건이 달라졌습니다: {uid}")
        if r.get("decision") not in {"pending","use","exclude"}:
            raise ValueError(f"알 수 없는 검토 상태: {uid}")
        if not isinstance(r.get("edited_text"),str) or not isinstance(r.get("note"),str):
            raise ValueError(f"본문 또는 메모 형식 오류: {uid}")
        if len(r["edited_text"])>20000 or len(r["note"])>4000 or (not r["edited_text"].strip() and r["decision"]!="exclude"):
            raise ValueError(f"본문 또는 메모 길이 오류: {uid}")
        if r["edited_text"] != e["text"] or r["decision"] != "pending" or r["note"]:
            changes.append({**r,"character":e["character"],"relation":e["relation"],"body_state":e["body_state"],"time":e["time"],"action":e["action"],"gate":e["gate"]})
    return changes

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("saved_json",type=Path)
    parser.add_argument("--baseline",type=Path,default=Path(__file__).parent/"review/all_dialogue.json")
    parser.add_argument("--output",type=Path)
    args=parser.parse_args()
    changes=compare(json.loads(args.saved_json.read_text(encoding="utf-8-sig")),json.loads(args.baseline.read_text()))
    modified=sum(x["original_text"]!=x["edited_text"] for x in changes)
    lines=["# HTML 편집 결과 대조", "", f"검토·수정·메모가 있는 항목 {len(changes)}개 / 본문 수정 {modified}개", ""]
    status={"pending":"미검토","use":"사용","exclude":"제외"}
    for e in changes:
        lines.extend([f"## {e['id']}","",f"{e['character']} · {e['relation']} · 몸 {e['body_state']} · {e['time']} · {e['action']} · {e['gate']}","",f"검토 결과: {status[e['decision']]}","","**원본**", "",e["original_text"],"","**수정본**","",e["edited_text"],"","**검토 메모**","",e["note"] or "없음",""])
    report="\n".join(lines)+"\n"
    if args.output:
        args.output.write_text(report)
    else:
        print(report)

if __name__=="__main__":
    main()

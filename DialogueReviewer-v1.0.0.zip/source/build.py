from pathlib import Path
import hashlib,json
r=Path(__file__).parent
parts=[(r/'vendor/fzstd.js').read_text(encoding="utf-8"),(r/'src/core.js').read_text(encoding="utf-8"),(r/'src/worker.js').read_text(encoding="utf-8")]
worker=';\n'.join(parts)
app=(r/'src/app.js').read_text(encoding="utf-8")
build=hashlib.sha256((worker+app+(r/'src/ui.html').read_text(encoding="utf-8")).encode()).hexdigest()
js='const BUILD_ID='+json.dumps(build)+';\nconst WORKER_SOURCE='+json.dumps(worker,ensure_ascii=True).replace('<','\\u003c')+';\n'+app
html=(r/'src/ui.html').read_text(encoding="utf-8").replace('<!--APP_SCRIPT-->','<script>\n'+js.replace('</script','<\\/script')+'\n</script>')
(r/'release').mkdir(exist_ok=True)
(r/'release/DialogueReviewer.html').write_text(html,encoding='utf-8')
print('Built offline HTML:',len(html.encode()),'bytes; source build',build[:16])

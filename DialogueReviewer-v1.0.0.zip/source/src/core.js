/* Local Dialogue Reviewer core. No game text or encryption key is bundled. */
(function (G) {
'use strict';
const te = new TextEncoder(), td = new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});
const hex = b => Array.from(b,x=>x.toString(16).padStart(2,'0')).join('');
const eq = (a,b) => a.length===b.length && a.every((x,i)=>x===b[i]);
const check = (ok,msg) => {if(!ok) throw new Error(msg);};
const LIMIT=128*1024*1024;
class Reader {
 constructor(b,p=0){this.b=b;this.p=p;this.v=new DataView(b.buffer,b.byteOffset,b.byteLength);this.little=true;}
 need(n){check(Number.isSafeInteger(n)&&n>=0&&this.p+n<=this.b.length,'Truncated data at '+this.p);}
 bytes(n){this.need(n);const b=this.b.subarray(this.p,this.p+n);this.p+=n;return b;}
 u8(){this.need(1);return this.b[this.p++];}
 u16(){this.need(2);let n=this.v.getUint16(this.p,this.little);this.p+=2;return n;}
 u32(){this.need(4);let n=this.v.getUint32(this.p,this.little);this.p+=4;return n;}
 u64(){let a=this.u32(),b=this.u32();let n=this.little?a+b*4294967296:b+a*4294967296;check(Number.isSafeInteger(n),'64-bit offset exceeds safe integer');return n;}
 skip(n){this.bytes(n);}
 str(padded=false){let n=this.u32();check(n<=LIMIT,'String too large');let start=this.p;let s=td.decode(this.bytes(n));if(padded)this.skip((-n)&3);return {text:s,start,end:start+n};}
}
function md5(b){
 const n=((b.length+8>>>6)+1)*64, x=new Uint8Array(n);x.set(b);x[b.length]=128;const dv=new DataView(x.buffer);dv.setUint32(n-8,(b.length*8)>>>0,true);dv.setUint32(n-4,Math.floor(b.length/536870912),true);
 let h0=0x67452301,h1=0xefcdab89,h2=0x98badcfe,h3=0x10325476;
 const S=[7,12,17,22,5,9,14,20,4,11,16,23,6,10,15,21];
 for(let off=0;off<n;off+=64){let a=h0,bh=h1,c=h2,d=h3;
  for(let i=0;i<64;i++){let f,g,shift;if(i<16){f=(bh&c)|(~bh&d);g=i;shift=S[i%4];}else if(i<32){f=(d&bh)|(~d&c);g=(5*i+1)%16;shift=S[4+i%4];}else if(i<48){f=bh^c^d;g=(3*i+5)%16;shift=S[8+i%4];}else{f=c^(bh|~d);g=(7*i)%16;shift=S[12+i%4];}let v=(a+f+MD5T[i]+dv.getUint32(off+g*4,true))|0;let tmp=d;d=c;c=bh;bh=(bh+((v<<shift)|(v>>>(32-shift))))|0;a=tmp;}
  h0=(h0+a)|0;h1=(h1+bh)|0;h2=(h2+c)|0;h3=(h3+d)|0;
 }
 const out=new Uint8Array(16),v=new DataView(out.buffer);[h0,h1,h2,h3].forEach((n,i)=>v.setUint32(i*4,n>>>0,true));return out;
}
const MD5T=Array.from({length:64},(_,i)=>Math.floor(Math.abs(Math.sin(i+1))*4294967296)>>>0);
const SHA_K=[0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
function sha256(b){
 const n=Math.ceil((b.length+9)/64)*64,x=new Uint8Array(n);x.set(b);x[b.length]=128;let dv=new DataView(x.buffer);dv.setUint32(n-8,Math.floor(b.length/536870912));dv.setUint32(n-4,(b.length*8)>>>0);
 let h=[0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19],w=new Int32Array(64),rr=(x,n)=>(x>>>n)|(x<<(32-n));
 for(let off=0;off<n;off+=64){for(let i=0;i<16;i++)w[i]=dv.getInt32(off+i*4);for(let i=16;i<64;i++){let a=w[i-15],b=w[i-2];w[i]=(w[i-16]+(rr(a,7)^rr(a,18)^(a>>>3))+w[i-7]+(rr(b,17)^rr(b,19)^(b>>>10)))|0;}let [a,b,c,d,e,f,g,hh]=h;for(let i=0;i<64;i++){let t=(hh+(rr(e,6)^rr(e,11)^rr(e,25))+((e&f)^(~e&g))+SHA_K[i]+w[i])|0,u=((rr(a,2)^rr(a,13)^rr(a,22))+((a&b)^(a&c)^(b&c)))|0;hh=g;g=f;f=e;e=(d+t)|0;d=c;c=b;b=a;a=(t+u)|0;}h=h.map((x,i)=>(x+[a,b,c,d,e,f,g,hh][i])|0);}
 let out=new Uint8Array(32),v=new DataView(out.buffer);h.forEach((n,i)=>v.setUint32(i*4,n>>>0));return out;
}
function gm(a,b){let r=0;for(let i=0;i<8;i++){if(b&1)r^=a;a=((a<<1)^((a&128)?0x11b:0))&255;b>>>=1;}return r;}
const SBOX=Uint8Array.from({length:256},(_,a)=>{let x=a?1:0;if(a){let p=a,n=254;while(n){if(n&1)x=gm(x,p);p=gm(p,p);n>>>=1;}}let r=x;for(let i=1;i<5;i++)r^=((x<<i)|(x>>(8-i)))&255;return r^99;});
class AES256 {
 constructor(key){check(key.length===32,'AES key length');this.rk=new Uint8Array(240);this.rk.set(key);let rc=1;for(let i=32;i<240;i+=4){let a=Array.from(this.rk.subarray(i-4,i));if(i%32===0){a.push(a.shift());a=a.map(x=>SBOX[x]);a[0]^=rc;rc=gm(rc,2);}else if(i%32===16)a=a.map(x=>SBOX[x]);for(let j=0;j<4;j++)this.rk[i+j]=this.rk[i-32+j]^a[j];}}
 block(input){let s=new Uint8Array(input);for(let i=0;i<16;i++)s[i]^=this.rk[i];for(let round=1;round<=14;round++){let t=new Uint8Array(16);for(let row=0;row<4;row++)for(let col=0;col<4;col++)t[row+4*col]=SBOX[s[row+4*((col+row)%4)]];s=t;if(round<14)for(let c=0;c<4;c++){let p=c*4,a=s[p],b=s[p+1],d=s[p+2],e=s[p+3],all=a^b^d^e;s[p]^=all^gm(a^b,2);s[p+1]^=all^gm(b^d,2);s[p+2]^=all^gm(d^e,2);s[p+3]^=all^gm(e^a,2);}for(let i=0;i<16;i++)s[i]^=this.rk[round*16+i];}return s;}
 decryptCFB(enc,iv){check(iv.length===16&&enc.length%16===0,'CFB block length');let out=new Uint8Array(enc.length),prev=iv;for(let i=0;i<enc.length;i+=16){const k=this.block(prev);for(let j=0;j<16;j++)out[i+j]=enc[i+j]^k[j];prev=enc.subarray(i,i+16);}return out;}
}
function decryptEnvelope(bytes,key){let r=new Reader(bytes),expected=r.bytes(16),len=r.u64(),iv=r.bytes(16);check(len<=LIMIT,'Encrypted data too large');let enc=r.bytes(Math.ceil(len/16)*16),plain=new AES256(key).decryptCFB(enc,iv).subarray(0,len);check(eq(md5(plain),expected),'Decrypted MD5 mismatch');return plain;}
async function read(file,offset,len){check(Number.isSafeInteger(offset)&&Number.isSafeInteger(len)&&offset>=0&&len>=0&&offset+len<=file.size,'File range invalid');return new Uint8Array(await file.slice(offset,offset+len).arrayBuffer());}
async function envelopeAt(file,offset,key){let head=await read(file,offset,40),r=new Reader(head);r.skip(16);let n=r.u64();check(n<=LIMIT,'Encrypted entry exceeds 128MiB safety limit');let enc=await read(file,offset,40+Math.ceil(n/16)*16);return decryptEnvelope(enc,key);}
async function locatePack(file){let head=await read(file,0,Math.min(112,file.size));if(head.length>=4&&new Reader(head).u32()===0x43504447)return 0;check(file.size>=12,'File too short');let tail=new Reader(await read(file,file.size-12,12));let size=tail.u64(),magic=tail.u32();check(magic===0x43504447,'Embedded PCK footer not found');let pos=file.size-12-size;check(pos>=0&&new Reader(await read(file,pos,4)).u32()===0x43504447,'Embedded PCK header mismatch');return pos;}
async function packHeader(file){const start=await locatePack(file),r=new Reader(await read(file,start,100));check(r.u32()===0x43504447,'PCK magic');const version=r.u32(),engine=[r.u32(),r.u32(),r.u32()].join('.'),flags=r.u32();check([2,3,4].includes(version),'Unsupported PCK format '+version);check((flags&~3)===0,'Sparse/unknown PCK flags '+flags+' require manual review');let fileBase=r.u64();if(version>=3||(flags&2))fileBase+=start;const directory=version>=3?start+r.u64():start+96;const count=new Reader(await read(file,directory,4)).u32();check(count<=100000,'Implausible PCK file count');return {start,version,engine,flags,fileBase,directory,count};}
function directoryEntries(data,h,fileSize){let r=new Reader(data),out=[];for(let i=0;i<h.count;i++){const path=r.str().text.replace(/\0+$/,'');check(path.length>0&&!path.includes('\0'),'Invalid PCK path');const offset=r.u64()+h.fileBase,size=r.u64(),digest=hex(r.bytes(16)),flags=r.u32();check((flags&~3)===0,'Delta/unknown entry flags '+flags+' at '+path);if(!(flags&2))check(offset>=0&&offset<=fileSize&&size<=fileSize,'PCK entry range invalid');out.push({path,index:i,offset,size,expectedMD5:digest,flags});}if(h.version>=3)check(r.p===data.length||data.subarray(r.p).every(x=>x===0),'Unexpected directory trailing bytes');return out;}
async function readDirectory(file,h,key){if(h.flags&1){check(key,'Encrypted PCK requires matching EXE');return directoryEntries(await envelopeAt(file,h.directory+4,key),h,file.size);}let b=await read(file,h.directory+4,file.size-(h.directory+4));return directoryEntries(b,h,file.size);}
async function detectKey(exe,h,progress){
 const head=await read(exe,h.directory+4,56),rr=new Reader(head);rr.skip(16);const n=rr.u64();check(n<=8*1024*1024,'Encrypted directory exceeds supported key-check size');const iv=rr.bytes(16),first=rr.bytes(16);const full=await read(exe,h.directory+4,40+Math.ceil(n/16)*16);
 const verify=key=>{try{decryptEnvelope(full,key);return true;}catch{return false;}};
 // Verified-size hint only; key bytes are always read locally and cryptographically checked.
 if(exe.size===227550440){let candidate=await read(exe,78782192,32);if(verify(candidate))return candidate;}
 const dos=new Reader(await read(exe,0,64));check(dos.u16()===0x5a4d,'Not PE executable');dos.p=60;let pe=dos.u32(),p=new Reader(await read(exe,pe,24));check(p.u32()===0x4550,'PE signature');p.u16();const count=p.u16();p.skip(12);const optional=p.u16();p.u16();let table=await read(exe,pe+24+optional,count*40),sections=[];
 for(let i=0;i<count;i++){let s=new Reader(table,i*40),name=td.decode(s.bytes(8)).replace(/\0/g,'');s.skip(8);let size=s.u32(),offset=s.u32();if(['.data','.rdata'].includes(name))sections.push({name,offset,size});}sections.sort((a,b)=>a.name.localeCompare(b.name));
 for(let align of [16,4])for(let sec of sections){progress('로컬 EXE 키 확인: '+sec.name+' / 정렬 '+align);const data=await read(exe,sec.offset,sec.size);for(let i=0;i+32<=data.length;i+=align){if(align===4&&i%16===0)continue;let key=data.subarray(i,i+32);if(new Set(key).size<12)continue;const stream=new AES256(key).block(iv),plain=first.map((x,j)=>x^stream[j]),len=new Reader(plain).u32();if(len>0&&len<=4096&&plain.subarray(4,12).every(x=>x>=32&&x<=126)&&verify(key))return new Uint8Array(key);}}
 throw new Error('Matching package key not found in supported PE sections; no encrypted files were accepted');
}
function byteOffsets(s){let a=new Uint32Array(s.length+1),n=0;for(let i=0;i<s.length;i++){a[i]=n;let p=s.codePointAt(i);if(p>65535){a[++i]=n;n+=4;}else n+=p<128?1:p<2048?2:3;}a[s.length]=n;return a;}
function parseJSONStrings(bytes,emit){
 const s=td.decode(bytes),offs=byteOffsets(s);let i=0,duplicateKeys=0,rawControls=0,strings=0;
 const ws=()=>{while(i<s.length&&/[\s\uFEFF]/u.test(s[i]))i++;};
 const string=()=>{const start=i;check(s[i++]==='"','Expected JSON string');let closed=false;while(i<s.length){let c=s[i++];if(c==='\\'){check(i<s.length,'JSON escape truncated');i++;}else if(c==='"'){closed=true;break;}else if(c.charCodeAt(0)<32)rawControls++;}check(closed,'Unterminated JSON string');let token=s.slice(start,i).replace(/[\u0000-\u001f]/g,c=>'\\u'+c.charCodeAt(0).toString(16).padStart(4,'0'));return {value:JSON.parse(token),start:offs[start],end:offs[i]};};
 const esc=x=>String(x).replace(/~/g,'~0').replace(/\//g,'~1');
 function value(path,depth){check(depth<180,'JSON nesting exceeds supported depth');ws();let from=local.length;
  if(s[i]==='"'){let t=string(),r=emit({kind:'json_value',location:path||'/',text:t.value,byteStart:t.start,byteEnd:t.end,offsetSpace:'plaintext_utf8'});local.push(r);strings++;return {value:t.value,record:r};}
  if(s[i]==='{'){i++;let obj=Object.create(null),seen=new Map();ws();if(s[i]==='}'){i++;return {value:obj};}while(true){ws();let key=string(),occ=seen.get(key.value)||0;seen.set(key.value,occ+1);if(occ)duplicateKeys++;let child=path+'/'+esc(key.value),kr=emit({kind:'json_key',location:child,text:key.value,byteStart:key.start,byteEnd:key.end,occurrence:occ,offsetSpace:'plaintext_utf8'});local.push(kr);strings++;ws();check(s[i++]===':','Expected JSON colon');let v=value(child,depth+1);obj[key.value]=v.value;if(v.record){kr.pairedId=v.record.id;v.record.pairedId=kr.id;}ws();if(s[i]==='}'){i++;break;}check(s[i++]===',','Expected JSON comma');}
   if(Array.isArray(obj.tags)){for(let j=from;j<local.length;j++)if(!local[j].conditions)local[j].conditions={tags:obj.tags,unless:obj.unless||[],face:obj.face||''};}
   else if(Array.isArray(obj.unless)){for(let j=from;j<local.length;j++)if(!local[j].variantUnless)local[j].variantUnless=obj.unless;}
   return {value:obj};
  }
  if(s[i]==='['){i++;let a=[];ws();if(s[i]===']'){i++;return {value:a};}while(true){a.push(value(path+'/'+a.length,depth+1).value);ws();if(s[i]===']'){i++;break;}check(s[i++]===',','Expected array comma');}return {value:a};}
  let m=/^(?:true|false|null|-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?)/.exec(s.slice(i));check(m,'Invalid JSON token at '+i);i+=m[0].length;return {value:JSON.parse(m[0])};
 }
 const local=[];value('',0);ws();check(i===s.length,'JSON trailing content');return {jsonStrings:strings,duplicateKeys,rawControlCharacters:rawControls};
}
// Godot Variant marshaling used by GDSC token constants and project.binary.
function marshaled(r,add,loc,depth=0){check(depth<128,'Variant nesting limit');const start=r.p,header=r.u32(),type=header&255,wide=!!(header&65536);let text;
 if(type===0)return null;
 if(type===1)return !!r.u32();
 if(type===2){if(wide){r.skip(8);return null;}return r.u32();}
 if(type===3){r.skip(wide?8:4);return null;}
 if(type===4||type===21){const t=r.str(true);add({kind:'script_literal',location:loc,text:t.text,byteStart:start,byteEnd:r.p,offsetSpace:'gdc_decompressed'});return t.text;}
 if(type===22){let n=r.u32();check(n&0x80000000,'Unsupported old NodePath');let sub=r.u32(),flags=r.u32();n&=0x7fffffff;if(flags&2)sub++;for(let i=0;i<n+sub;i++){let t=r.str(true);add({kind:'script_nodepath',location:loc+'/'+i,text:t.text,byteStart:t.start,byteEnd:t.end,offsetSpace:'gdc_decompressed'});}return null;}
 const math={5:2,6:2,7:4,8:4,9:3,10:3,11:6,12:4,13:4,14:4,15:4,16:6,17:9,18:12,19:16,20:4};
 if(math[type]){const integers=[6,8,10,13].includes(type);r.skip(math[type]*(integers?4:(type===20?4:(wide?8:4))));return null;}
 if(type===23){r.skip(8);return null;}
 if(type===24||type===25||type===26)throw new Error('Object/callable Variant not supported in constant table');
 if(type===27||type===28){check((header>>>16)===0,'Typed container Variant requires manual review');let n=r.u32()&0x7fffffff;check(n<1000000,'Variant container too large');for(let i=0;i<n;i++){if(type===27)marshaled(r,add,loc+'/key/'+i,depth+1);marshaled(r,add,loc+'/'+i,depth+1);}return null;}
 if(type>=29&&type<=38){let n=r.u32();check(n<LIMIT,'Packed array too large');if(type===34){for(let i=0;i<n;i++){let t=r.str(true);add({kind:'script_literal',location:loc+'/'+i,text:t.text,byteStart:t.start,byteEnd:t.end,offsetSpace:'gdc_decompressed'});}}else{let width={29:1,30:4,31:8,32:4,33:8,35:8,36:12,37:16,38:16}[type];r.skip(n*width);if(type===29)r.skip((-n)&3);}return null;}
 throw new Error('Unsupported marshaled Variant type '+type);
}
function parseGDC(bytes,emit,zstd){let h=new Reader(bytes);check(td.decode(h.bytes(4))==='GDSC','Not GDSC bytecode');const version=h.u32();check(version===101||version===100,'Unsupported tokenizer version '+version);const size=h.u32();let body=size?zstd(bytes.subarray(12)):bytes.subarray(12);check(!size||body.length===size,'GDSC decompressed size mismatch');let r=new Reader(body),ni=r.u32(),nc=r.u32(),nl=r.u32(),nt=r.u32();check(ni+nc+nl+nt<5000000,'Invalid GDSC counts');const records=[];const add=v=>{const x=emit(v);records.push(x);return x;};
 for(let i=0;i<ni;i++){let n=r.u32(),start=r.p;check(n<100000,'Identifier too long');let points=[];for(let j=0;j<n;j++){let p=(r.u32()^0xb6b6b6b6)>>>0;check(p<=0x10ffff,'Invalid UTF32 identifier');points.push(p);}add({kind:'script_identifier',location:'identifier/'+i,text:String.fromCodePoint(...points),byteStart:start,byteEnd:r.p,offsetSpace:'gdc_decompressed'});}
 let constants=[];for(let i=0;i<nc;i++){let begin=records.length;marshaled(r,add,'constant/'+i);constants[i]=records.slice(begin);}
 r.skip(nl*16);for(let i=0;i<nt;i++){let first=r.b[r.p],token;if(first&128)token=r.u32();else token=r.u8();let line=r.u32();if((token&127)===3){let index=token>>>8;check(index<nc,'GDSC constant index out of bounds');for(let rec of constants[index]){if(!rec.lines)rec.lines=[];if(!rec.lines.includes(line))rec.lines.push(line);}}}
 check(r.p===body.length,'GDSC token stream not fully consumed');return {tokenizerVersion:version,identifiers:ni,constants:nc,tokens:nt,decompressedBytes:body.length};
}
function resourceVariant(r,add,loc,ctx,depth=0){check(depth<128,'Resource variant nesting');let start=r.p,t=r.u32();const floatSize=ctx.real64?8:4;
 if(t===1||t===42||t===43)return;
 if([2,3,23].includes(t)){r.skip(4);return;}
 if([40,41].includes(t)){r.skip(8);return;}
 if(t===4){r.skip(floatSize);return;}
 if(t===5||t===44){let s=r.str();add({kind:'resource_string',location:loc,text:s.text,byteStart:start,byteEnd:r.p,offsetSpace:ctx.space});return;}
 const math={10:2,11:4,12:3,13:4,14:4,15:6,16:9,17:12,18:6,20:4,45:2,46:4,47:3,50:4,51:4,52:16};
 if(math[t]){r.skip(math[t]*([20,45,46,47,51].includes(t)?4:floatSize));return;}
 if(t===22){let names=r.u16(),sub=r.u16()&32767;if(ctx.version<3)sub++;for(let i=0;i<names+sub;i++)resourceName(r,add,loc+'/path/'+i,ctx);return;}
 if(t===24){let sub=r.u32();if(sub===0)return;if(sub===2||sub===3){r.skip(4);return;}if(sub===1){for(let i=0;i<2;i++){let s=r.str();add({kind:'resource_string',location:loc+'/external/'+i,text:s.text,byteStart:s.start,byteEnd:s.end,offsetSpace:ctx.space});}return;}throw new Error('Unknown resource object encoding '+sub);}
 if(t===26||t===30){let n=r.u32()&0x7fffffff;check(n<1000000,'Resource array too large');for(let i=0;i<n;i++){if(t===26)resourceVariant(r,add,loc+'/key/'+i,ctx,depth+1);resourceVariant(r,add,loc+'/'+i,ctx,depth+1);}return;}
 const packed={31:1,32:4,33:4,35:3*floatSize,36:16,37:2*floatSize,48:8,49:8,53:4*floatSize};
 if(t===34){let n=r.u32();check(n<1000000,'String array too large');for(let i=0;i<n;i++){let s=r.str();add({kind:'resource_string',location:loc+'/'+i,text:s.text,byteStart:s.start,byteEnd:s.end,offsetSpace:ctx.space});}return;}
 if(packed[t]){let n=r.u32();r.skip(n*packed[t]);if(t===31)r.skip((-n)&3);return;}
 throw new Error('Unsupported resource Variant '+t);
}
function resourceName(r,add,loc,ctx){let start=r.p,id=r.u32(),s;if(id&0x80000000){let n=id&0x7fffffff;s=td.decode(r.bytes(n)).replace(/\0+$/,'');}else{check(id<ctx.names.length,'Resource string-map index');s=ctx.names[id];}add({kind:'resource_name',location:loc,text:s,byteStart:start,byteEnd:r.p,offsetSpace:ctx.space});return s;}
function parseResource(bytes,emit,zstd){let head=td.decode(bytes.subarray(0,4)),body=bytes,space='plaintext_resource';if(head==='RSCC'){let r=new Reader(bytes,4),mode=r.u32(),block=r.u32(),total=r.u32();check(mode===2,'Resource compression mode '+mode+' not supported (manual review required)');check(block>0&&total<LIMIT,'Resource compression sizes');let n=Math.floor(total/block)+1,sizes=[];for(let i=0;i<n;i++)sizes.push(r.u32());body=new Uint8Array(total);for(let i=0;i<n;i++){let compressed=r.bytes(sizes[i]),size=Math.min(block,total-i*block);if(!size)continue;let plain=zstd(compressed);check(plain.length===size,'Resource block length mismatch');body.set(plain,i*block);}space='resource_decompressed';}
 let r=new Reader(body,head==='RSRC'?4:0);check(head==='RSRC'||head==='RSCC','Not binary resource');let big=r.u32();r.u32();check(big===0,'Big-endian resources require manual review');let major=r.u32(),minor=r.u32(),version=r.u32();check(major===4&&version<=6,'Unsupported resource version');const add=(kind,s,loc)=>emit({kind,location:loc,text:s.text,byteStart:s.start,byteEnd:s.end,offsetSpace:space});add('resource_type',r.str(),'header/type');r.u64();let flags=r.u32();r.skip(8);if(flags&8)add('resource_string',r.str(),'header/script_class');r.skip(44);let n=r.u32();check(n<1000000,'Resource name count');let names=[];for(let i=0;i<n;i++){let s=r.str();names.push(s.text);add('resource_name',s,'name/'+i);}let ext=r.u32();for(let i=0;i<ext;i++){add('resource_type',r.str(),'external/'+i+'/type');add('resource_path',r.str(),'external/'+i+'/path');if(flags&2)r.skip(8);}let count=r.u32(),internals=[];for(let i=0;i<count;i++){add('resource_path',r.str(),'internal/'+i+'/path');internals.push(r.u64());}let ctx={names,real64:!!(flags&4),version,space};for(let i=0;i<count;i++){r.p=internals[i];add('resource_type',r.str(),'internal/'+i+'/type');let props=r.u32();check(props<1000000,'Resource property count');for(let j=0;j<props;j++){let loc='internal/'+i+'/property/'+j,name=resourceName(r,emit,loc+'/name',ctx);resourceVariant(r,emit,loc+'/'+name,ctx);}}return {resourceFormat:version,engine:major+'.'+minor,internalResources:count,resourceNames:n};
}
function parseECFG(bytes,emit){let r=new Reader(bytes);check(td.decode(r.bytes(4))==='ECFG','project.binary magic');let count=r.u32();for(let i=0;i<count;i++){let name=r.str();emit({kind:'project_key',location:'property/'+i,text:name.text,byteStart:name.start,byteEnd:name.end,offsetSpace:'plaintext_ecfg'});let size=r.u32(),end=r.p+size,sub=new Reader(r.bytes(size));marshaled(sub,x=>emit({...x,kind:'project_string',offsetSpace:'ecfg_variant',location:name.text+'/'+x.location}),'value');check(sub.p===size,'project.binary variant trailing data');}check(r.p===bytes.length,'project.binary trailing data');return {projectProperties:count};}
function textKind(path){if(/\.json$/i.test(path))return'json';if(/\.gdc$/i.test(path))return'gdc';if(/\.(res|scn|translation)$/i.test(path))return'resource';if(path==='project.binary')return'project';if(/\.(gd|gdshader|txt|cfg|remap|import|tscn|tres|csv|po|md|xml|html|js)$/i.test(path))return'plain';if(/\.(png|jpe?g|webp|svg|ctex|ogg|wav|mp3|mp4|oggvorbisstr|sample|mp3str|ttf|otf|fontdata|dat|bin|uid)$/i.test(path))return'media';return'unknown';}
function parseTextFile(bytes,path,emit,zstd){let kind=textKind(path);if(kind==='json')return parseJSONStrings(bytes,emit);if(kind==='gdc')return parseGDC(bytes,emit,zstd);if(kind==='resource')return parseResource(bytes,emit,zstd);if(kind==='project')return parseECFG(bytes,emit);if(kind==='plain'){let s=td.decode(bytes),off=0,line=1;for(let part of s.split(/(?<=\n)/)){let n=te.encode(part).length;emit({kind:'source_line',location:'line/'+line++,text:part,byteStart:off,byteEnd:off+n,offsetSpace:'plaintext_utf8'});off+=n;}return {lines:line-1};}throw new Error('No parser for '+path);}
function metadata(path){return {language:(/\/i18n\/([^/]+)\//.exec('/'+path)||[])[1]||(/\.gdc$|\.gd$/.test(path)?'code':'base'),character:(/\/characters\/([^/.]+)/.exec('/'+path)||[])[1]||''};}
async function analyze(files,opt={}){
 const progress=opt.onProgress||(()=>{}),onRecords=opt.onRecords||(()=>{}),zstd=opt.zstd||G.fzstd?.decompress;
 check(zstd,'Zstandard decoder unavailable');check(files.length>0,'Select EXE/PCK files');let sources=[],inventory=[],issues=[],key=null,totalRecords=0,seenSources=new Map();
 for(let fi=0;fi<files.length;fi++){let file=files[fi],source={name:file.name,size:file.size,index:fi,status:'pending'};sources.push(source);progress('원본 SHA-256 계산: '+file.name);try{check(file.size<=1024*1024*1024,'Input larger than 1GiB unsupported');source.sha256=hex(new Uint8Array(await crypto.subtle.digest('SHA-256',await file.arrayBuffer())));if(seenSources.has(source.sha256)){const original=seenSources.get(source.sha256);Object.assign(source,{status:'duplicate_of',duplicateOf:original.index,duplicateStatus:original.status,entryCount:original.entryCount,engine:original.engine,recordCount:0});continue;}seenSources.set(source.sha256,source);const h=await packHeader(file);Object.assign(source,{format:h.version,engine:h.engine,entryCount:h.count});if(h.flags&1&&!key){check(/\.exe$/i.test(file.name),'Select matching EXE before encrypted PCK');key=await detectKey(file,h,progress);source.localKeyVerified=true;}const entries=await readDirectory(file,h,key);let sourceRecords=0;
  for(let i=0;i<entries.length;i++){let e=entries[i],path=e.path.replace(/^res:\/\//,''),item={sourceIndex:fi,sourceName:file.name,sourceSHA256:source.sha256,path,entryIndex:i,packOffset:e.offset,size:e.size,expectedMD5:e.expectedMD5,flags:e.flags,status:'pending',recordCount:0};inventory.push(item);if(i%20===0)progress(file.name+' · '+(i+1)+'/'+entries.length+' · '+path);if(e.flags&2){item.status='deletion_marker';continue;}const kind=textKind(path);if(kind==='media'){item.status='media_or_binary_unparsed';continue;}if(kind==='unknown'){item.status='unknown_unparsed';issues.push({source:file.name,path,type:'unsupported_file',message:'Not automatically interpreted'});continue;}let local=[];try{let bytes=e.flags&1?await envelopeAt(file,e.offset,key):await read(file,e.offset,e.size);check(bytes.length===e.size,'PCK file size mismatch');check(hex(md5(bytes))===e.expectedMD5,'PCK entry MD5 mismatch');item.checksumVerified=true;item.plaintextSHA256=hex(sha256(bytes));let meta=metadata(path);const emit=x=>{let id=hex(sha256(te.encode(source.sha256+'\0'+e.index+'\0'+path+'\0'+x.kind+'\0'+x.byteStart+'\0'+x.location)));let r={id,sourceIndex:fi,sourceName:file.name,sourceSHA256:source.sha256,filePath:path,fileSHA256:item.plaintextSHA256,entryIndex:e.index,...meta,...x,textSHA256:hex(sha256(te.encode(x.text)))};local.push(r);return r;};item.parserStats=parseTextFile(bytes,path,emit,zstd);item.status='parsed';}catch(err){item.status=local.length?'partial_error':'parse_error';item.error=String(err.message||err);issues.push({source:file.name,path,type:item.status,message:item.error});}item.recordCount=local.length;totalRecords+=local.length;sourceRecords+=local.length;if(local.length)onRecords(local);}
  source.status='read';source.recordCount=sourceRecords;
 }catch(err){source.status='error';source.error=String(err.message||err);issues.push({source:file.name,type:'source_error',message:source.error});}}
 const counts={sources:sources.length,duplicateSources:sources.filter(s=>s.status==='duplicate_of').length,sourceErrors:sources.filter(s=>s.status==='error').length,inventoryEntries:inventory.length,parsedFiles:inventory.filter(x=>x.status==='parsed').length,parseErrors:inventory.filter(x=>/error/.test(x.status)).length,unknownFiles:inventory.filter(x=>x.status==='unknown_unparsed').length,mediaOrBinary:inventory.filter(x=>x.status==='media_or_binary_unparsed').length,deletionMarkers:inventory.filter(x=>x.status==='deletion_marker').length,records:totalRecords};
 return {toolVersion:'1.0.0',createdAt:new Date().toISOString(),sources,inventory,issues,counts,structuredTextParsedWithoutKnownErrors:counts.sourceErrors===0&&counts.parseErrors===0&&counts.unknownFiles===0,coverageNote:'Distinct selected archives are indexed independently, including overridden versions; byte-identical inputs are explicitly listed as duplicate sources. Non-text/image/audio assets are not OCR/transcribed. Zero parser errors does not prove all runtime-generated or media-embedded dialogue was reviewed.'};
}
const api={Reader,hex,eq,md5,sha256,AES256,decryptEnvelope,packHeader,readDirectory,detectKey,parseJSONStrings,parseGDC,parseResource,parseECFG,textKind,parseTextFile,analyze};G.ReviewCore=api;if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(globalThis);
